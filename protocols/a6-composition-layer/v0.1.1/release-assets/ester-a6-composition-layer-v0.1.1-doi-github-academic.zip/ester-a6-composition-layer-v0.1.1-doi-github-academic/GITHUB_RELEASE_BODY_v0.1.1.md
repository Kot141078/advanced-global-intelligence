# A6 Composition Layer v0.1.1

This release finalizes the A6 composition correction.

## Core correction

A6 is not a merged super-anchor. A6 is a mapped composition over A0-A5.

```text
A6-EXIT  = revoke-and-continue
A6-SPLIT = freeze-and-escalate
```

## Included

- `docs/a6/A6_Composition_Layer_v0.1.1.md`
- `docs/anchor/ANCHOR_CLASS_BOUNDARIES_v0.2.1.md`
- `docs/core/c_a_b_protocol_v1.1_L4_EN.md`
- PDF versions for DOI deposit
- `.zenodo.json`
- `CITATION.cff`
- schemas and examples
- checksums

## Non-claims

No legal personhood, public-law activation, post-anchor sovereignty, merged identity, or certification is created by this release.
