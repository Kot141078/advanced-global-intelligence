# Manifest

Generated: 2026-06-18 19:10:42 UTC

| Path | SHA256 |
|---|---|
| `.zenodo.json` | `5f0a9668a04d4e0222314dbf4677ae7ae2a472c63203a22a4fd69376b707c0f6` |
| `CHANGELOG.md` | `ff67a55906e5086e68c36bd7d39e3faf9c0fd617800de7999a67fda9b86fe975` |
| `CITATION.bib` | `1ebf804486119e341c1bbe8caa2ab3abb06f494f380919a699c2441c0a302901` |
| `CITATION.cff` | `99349f0561d9507912cbce0c25fdfb8ec45398510999bb8b8bd57126280f3bee` |
| `DOI_GITHUB_RELEASE_CHECKLIST.md` | `fef054dde3b447f548d78756949e5f68d563b9bb24e1556a73b29cb0002880ce` |
| `GITHUB_RELEASE_BODY_v0.1.1.md` | `8b2ad0c4827477ab382a24b331e90c2c5c171521aacabd0b74de0edcae5d28b2` |
| `LICENSE.md` | `4963ba1baadd7823aba3c2c12c94c8fbd5433aac270b1894d3cbcbc66486b54f` |
| `README.md` | `14422c1119ad8ed0885e13c0d7337e61bc7021ecd3d60277f060b4822e931b33` |
| `RELEASE_NOTES_v0.1.1.md` | `6965f821476f9b819b1cda49cce9c6e1e8513061dbc56fe3147f4aa26352169e` |
| `VERSION` | `80447316529fc62014fbaa047fb67c51ac30e32830cda370405349d8d66d196c` |
| `build/ACADEMIC_PDF_BUILD_NOTES.md` | `c21c922ac3c5f0f0335c8fa831b9e2a033d69d38572a5d8e2fc532d166be1b82` |
| `build/academic_pdf_html/a6_academic.html` | `175b50286d16518f03512cfa95dfc302715c88692fda79edc79f98684ffd0467` |
| `build/academic_pdf_html/anchor_academic.html` | `984aa7ce456a97de2d54baa19d3022a323a4e991f70bef073aaf30ae64a0c197` |
| `docs/a6/A6_Composition_Layer_v0.1.1.md` | `86ce1b25f619b020cfce1ec93aa2ee665c690881c5301858f8b85b33b3942047` |
| `docs/anchor/ANCHOR_CLASS_BOUNDARIES_v0.2.1.md` | `6d3c38a7923ca12cea9329ab39ef7c9938e1ec17e777bb13cfbf7e12d1006d52` |
| `docs/core/c_a_b_protocol_v1.1_L4_EN.md` | `1168474cd5a309b1392bfc2a2bcf8f0b67c10f7b366797db573b23c9fbd103e7` |
| `examples/a6_resource_and_custodian_map.example.json` | `46ad1826d6364291172de4164b9264aa715535fe1d55ea9eb5c5845f9d6558f4` |
| `examples/a6_witness_packet.example.json` | `3dfe2d00a6a2f1d88174f780ed24272595559d4e1461c48eb49304f10ecde36b` |
| `metadata/doi_deposit_metadata.json` | `5f0a9668a04d4e0222314dbf4677ae7ae2a472c63203a22a4fd69376b707c0f6` |
| `pdf/A6_Composition_Layer_v0.1.1.pdf` | `6fff1ca5ef97e4c27723e6ddd9a5ecbe35f05c149f25b2dff715819037af9256` |
| `pdf/A6_Composition_Layer_v0.1.1_academic.pdf` | `6fff1ca5ef97e4c27723e6ddd9a5ecbe35f05c149f25b2dff715819037af9256` |
| `pdf/ANCHOR_CLASS_BOUNDARIES_v0.2.1.pdf` | `62f6b08f4639433837e63b072bdb32738fcaa276c04ded2f46d49ed49be634ca` |
| `pdf/ANCHOR_CLASS_BOUNDARIES_v0.2.1_academic.pdf` | `62f6b08f4639433837e63b072bdb32738fcaa276c04ded2f46d49ed49be634ca` |
| `quality_control/PACKAGE_QA.md` | `5b4ad0df2ed8d1ec63393d8aaa837f30cd0adfed0b9c45dfa2c26f5d9a13485f` |
| `schemas/a6_resource_and_custodian_map_v0.1.1.schema.json` | `47fd3b3f1c3ae105e4c4d0e3271280b4ee7f1af54b5b7789e402f00fbb6ccbf4` |
| `schemas/a6_witness_packet_v0.1.1.schema.json` | `db4e2dcb1415d9620a524384170af4b3ff4cb78fa52c914226c2ca2da89e248b` |
