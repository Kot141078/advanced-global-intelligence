# Semantic Review Record — 04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS v0.1.1

**Record class:** b-layer semantic review record (advisory) — CGAM normative-document review
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-07-03
**Record short name:** `DOC04_C_CONTINUITY_METRIC_v0_1_1_REVIEW__b`
**Reviewed artifact:** `04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS_v0_1_1.md`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: DOC04_C_CONTINUITY_METRIC_v0_1_1_REVIEW__b
  record_version: "0.1.1"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]

  reviewed_artifact:
    title: "04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS v0.1.1"
    artifact_type: normative_document
    artifact_sha256: "db640fe68ff56055749c3021ca6d5d75cedf9d4ebdf0baa6c37bd546fd42a0c7"
    project: "Self-Evo / Ester / c = a + b"
    verification_basis:
      - full_normative_text_reread_2174_lines
      - matrix_pass_over_known_defect_classes_not_queue
      - exact_line_verification_of_every_finding
      - cross_document_consistency_doc01_doc02_doc03_claim_force

  verdict:
    result: FINDINGS_RAISED
    qualifier: d4_01_closed_five_new_findings_one_under_block_path
    meaning: >
      D4-01 is verified CLOSED: all thirteen invariants I0..I12 carry canonical projections
      in Section 5.2, the projection registry and health registry are complete, and the
      health/equivalence separation is clean throughout. The document's discipline is
      consistent with docs 01-03 and the claim-force corpus. Five new findings are raised.
      Four are advisory. One (D4-03) contains a genuine under-block: one of the two
      normative code paths (Section 20.3 standalone) can return CONTINUES for a replay,
      archive, or restored trace — exactly the laundering the document itself names in
      Section 11.1 — and the relation RESTORED_FROM, declared in Section 3.3 and required
      by Section 13, is unreachable in both the Section 8.1 classifier and Section 20.4.
      A version increment is recommended; a b-layer v0.1.2 proposal is attached by hash.
    blocking_findings: 0
    under_block_paths: 1
    safety_escalations: 0
    new_findings: [D4-02, D4-03, D4-04, D4-05, D4-06]

  closure:
    D4-01_projection_incompleteness:
      status: RESOLVED_AS_CLASS
      resolution: >
        Sections 5.1-5.5 verified against actual text: pi_k defined for every I0..I12;
        ProjectionRegistry and HealthRegistry complete (13/13 each); source-class
        discipline (first_class / referenced / derived-by-reconstruction /
        implementation_deferred) present; implementation_deferred routes to UNKNOWN_HOLD;
        HEALTH_LEAK_INTO_EQUIVALENCE and CONTINUITY_PROJECTION_REGISTRY_DRIFT codes exist.
        The continuity vector (Section 6) maps 1:1 onto the invariant stack, 13/13.

  findings:
    D4-02_boolean_match_cannot_carry_unknown:
      severity: medium
      blocking: false
      fail_direction: mixed_over_distance_plus_broken_reflexivity
      location: "Section 7 definition; Section 20.1 validator.match boolean; vs Sections 5, 6.1"
      statement: >
        Section 5 requires PROJECTION_UNCOMPUTABLE -> UNKNOWN_HOLD and Section 6.1 declares
        U a distinct value ("Unknown is not zero"), but the ultrametric layer evaluates
        match_i as a boolean: an uncomputable projection is silently converted into
        MISMATCH. Consequences verified on the text: (1) d_U(x,x) != 0 for any state with
        an uncomputable projection, so the claimed metric reflexivity fails; (2) a partial
        relation is not an equivalence relation over the full state space, so the Section 7
        ultrametric claim as stated is void exactly where UNKNOWN occurs; (3) the vector
        layer distinguishes U from 3 while the metric layer cannot — the two-result-
        vocabularies-without-crosswalk pattern.
      recommended_fix: >
        Tri-state evaluation outcome {MATCH, MISMATCH, UNKNOWN}; UNKNOWN halts prefix
        counting; d_U returns U (not a number) and routes per Section 6.1; emit
        ULTRAMETRIC_OVER_UNKNOWN if a numeric d_U is produced over an UNKNOWN projection;
        state that the equivalence-relation property holds over computable projections.
    D4-03_relation_coverage_and_fragment_under_block:
      severity: medium_high
      blocking: false
      fail_direction: under_block_in_one_of_two_paths
      location: "Sections 3.3, 8.1, 13, 20.3, 20.4"
      statement: >
        RESTORED_FROM is declared in Section 3.3 and required by Section 13
        (claim_force = RESTORED_FROM) but has no reachable branch in the Section 8.1
        classifier nor in Section 20.4; a restored trace with preserved invariants
        classifies as CONTINUES, which Section 13 forbids. Independently, Section 20.3
        validate_trace returns CONTINUES after invariant checks only, with no special-
        relation check and no stated precedence of Section 20.4: an implementer using
        20.3 standalone emits CONTINUES for a replay trace — the exact laundering named
        REPLAY_LAUNDERED_AS_CONTINUITY in Section 11.1. Additionally the reduced/pending/
        held branch maps an OR-condition onto a slash-list of three relations without
        binding which condition yields which relation.
      why_not_blocking: >
        The composed path (Section 8.1) routes replay and archive correctly; the defect is
        confined to relation coverage (restoration) and to fragment-precedence being
        unstated. It is nevertheless the strongest finding because its failure direction
        admits rather than blocks, unlike D4-02.
      recommended_fix: >
        Add restoration branch to classifier and 20.4; declare 20.4 precedence over 20.3;
        forbid 20.3 from emitting CONTINUES standalone (intermediate status
        INVARIANTS_PRESERVED); bind pending->CONTINUES_PENDING_ANCHOR,
        held->CONTINUES_HELD, reduced->CONTINUES_REDUCED explicitly; add
        RELATION_UNREACHABLE_IN_CLASSIFIER; keep rupture-class dominance over special
        markers so a replay marker cannot launder an unauthorized branch.
    D4-04_style_projection_load_bearing_in_snapshot_equivalence:
      severity: low_medium
      blocking: false
      location: "Section 5.1 I12 row; Section 7 full-stack N; Section 21.1"
      statement: >
        pi_style is declared advisory-only, yet Section 21.1 defines snapshot equivalence
        over ALL canonical projections and the Section 7 ultrametric requires match_12 for
        d_U = 0. An advisory-only projection is thereby load-bearing for the strongest
        equivalence class, contradicting the advisory label.
      recommended_fix: >
        Define HardStack = I0..I11; snapshot equivalence over HardStack; full-stack match
        as a separate presentation-identical relation carrying no additional authority;
        clarify I12 participates in the metric only at the least-significant position and
        never in authority.
    D4-05_validator_order_unbound:
      severity: low
      blocking: false
      location: "Sections 20.1, 20.2 validators parameter vs Section 4 order declaration"
      statement: >
        Section 4 declares invariant order load-bearing, but the algorithms accept
        validators as a free parameter with no binding to ProjectionRegistry order; an
        unordered list yields a meaningless prefix m without any emitted finding.
      recommended_fix: "Require registry order; emit VALIDATOR_ORDER_MISMATCH otherwise."
    D4-06_vocabulary_cosmetics:
      severity: cosmetic
      blocking: false
      location: "Section 16.1 header; Section 19.10 expected token"
      statement: >
        Section 16.1 is titled 'Allowed claim-force transitions' over a list of classes
        (the transitions are the MUST NOT list). Section 19.10 places the claim-force
        outcome token C-A5_CANDIDATE in a relation-expectation slot; it is not a
        ContinuityRelation and the fixture involves no shared trace.
      recommended_fix: >
        Retitle 16.1; split 19.10 into expected_relation: n/a and
        expected_claim_force_outcome: C-A5_CANDIDATE with is_not_the_same_c non-claim.

  verified_clean:
    - "Health/equivalence separation: unary vs binary held in every I0..I12 pair; Section 4.3 canonical example correct."
    - "Fail-closed discipline: missing != empty (24.3), unknown authority-bearing (24.4), self-accusing flags rejected (24.5) — consistent with checker v2.3 vocabulary."
    - "Authority containment I4 uses derived-canonical authorized_surfaces, consistent with doc-03 v0.1.2 D3-01 closure."
    - "Causal projection I3 distinguishes pairwise replay-equality from edge chaining — consistent with TR-02 closure (pre_state_snapshot binding)."
    - "Scalar prohibition for authority (6, 24.1); lexicographic dominance (6.2); transition-bias local audit (17-18.1)."
    - "Claim-force boundaries: no silent C-A7/C-A6/C-A5 -> C-A1 upgrade; Sections 22-23 hold the C-A5 and C-A1 scaffold boundaries; Section 23 explicitly refuses to fill the axiom slot."
    - "Memory categories and laundering codes consistent with EA->LA anti-laundering layer."

  b_layer_proposal:
    title: "04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS_v0_1_2 (b-layer proposal, NOT ratified)"
    proposal_sha256: "35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9"
    incorporates: [D4-02, D4-03, D4-04, D4-05, D4-06]
    changes: >
      Sections 0.6 incorporation map; 4.2 tri-state outcome; 5.1/5.2 I12 metric-participant
      clarification + HardStack/FullStack; 6.3 scalar distance discipline binding d_U to
      24.1; 7 rewritten with U routing and ULTRAMETRIC_OVER_UNKNOWN; 8.1 classifier with
      restoration branch, bound reduced/pending/held mapping, RELATION_UNREACHABLE_IN_
      CLASSIFIER, normative branch order; 16.1 retitle; 19.10 fixture split; 20.0-20.5
      algorithm discipline (registry-order binding, 20.4 precedence, 20.3 fragment never
      emits CONTINUES, composed classifier 20.5, rupture-dominance inside 20.4); 21.1
      snapshot equivalence over HardStack + presentation-identical relation; O0 and
      Section 28 checklists extended. All v0.1.1 content otherwise preserved verbatim.
    status: awaiting_anchor_review_and_c_gate

  bridges:
    explicit_c_a_b_bridge: >
      Continuity in c = a + b is the persistence of the governed plus: the metric layer
      measures whether the +_g binding between a and b remains structurally alive over the
      trace; when the metric cannot compute, the honest value is U routed back to a — the
      terminal oracle — never a number that lets b answer in a's place.
    quiet_bridge_1: >
      A posterior cannot be computed from an undefined likelihood; assigning MISMATCH to
      an uncomputable projection is inventing evidence — the honest move is to widen the
      interval, not to pick a tail.
    quiet_bridge_2: >
      A conduction study distinguishes a nerve that fails the test from a nerve that
      cannot be tested through a cast; charting the second as the first is a documentation
      error that changes the surgical decision.
    earth_paragraph: >
      Bridge inspectors have three verdicts, not two: pass, fail, and could-not-inspect —
      a bearing hidden under formwork is logged as uninspected and the load rating is
      withheld, because rating a span on the assumption that the hidden bearing failed is
      as wrong as assuming it held. v0.1.1's boolean match is an inspector form with the
      could-not-inspect box missing; every hidden bearing gets marked failed, the rating
      math still produces a number, and the number is wrong in both directions at once.

  non_claims:
    - "This record does NOT claim doc-04 is correct, complete, or proven."
    - "This record does NOT claim any live system is continuous, a person, or conscious."
    - "This record does NOT ratify the attached v0.1.2 proposal; it is b-layer text awaiting a."
    - "This record does NOT claim the ultrametric layer, once fixed, proves identity — d_U remains evidence, never authority."
    - "This record does NOT authorize register append; append requires a-ratification."

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "db640fe68ff56055749c3021ca6d5d75cedf9d4ebdf0baa6c37bd546fd42a0c7"
    verdict: FINDINGS_RAISED
    blocking: false
    findings: [D4-02, D4-03, D4-04, D4-05, D4-06]
    proposal_sha256: "35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9"
    recommended_next:
      - "Anchor review of v0.1.2 proposal; on acceptance, re-upload for clean-pass review."
      - "04a continuity-checker seed can begin from the O0 fixture list extended in v0.1.2."
    record_sha256: "SIDE_CAR_BOUND"
```

---

## 2. Verdict statement (human-readable)

D4-01 is genuinely closed — the projection layer is complete and the health/equivalence
separation, which is the hardest discipline in this document to keep, holds in all
thirteen pairs. The document is the strongest of the four so far in one respect: it names
its own attack classes (resemblance laundering, replay laundering, scalar authority) and
then mostly guards them.

Mostly. The five findings share the corpus's two recurring roots. D4-02 and D4-05 are the
two-vocabularies pattern: the vector layer speaks {0,1,2,3,U} while the metric layer
speaks boolean, and UNKNOWN gets silently converted at the seam — breaking the very
metric property (reflexivity) the section claims. D4-03 is the coverage pattern: a
declared relation (RESTORED_FROM) with no reachable branch, plus a code fragment (20.3)
that can emit CONTINUES for a replay trace — the one place in the document where the
failure direction is admit, not block, which is why it ranks highest. D4-04 is smaller
but real: calling I12 advisory while making it load-bearing for snapshot equivalence is a
quiet self-contradiction that a hostile reader would use.

None of this blocks: the composed classifier routes correctly, and the fixes are
mechanical. The attached v0.1.2 closes all five as class, preserves everything else
verbatim, and adds three finding codes. It is a b-layer proposal — the version is yours
to accept, amend, or reject.

---

## 3. What was verified (executed)

- Full text read, 2174 lines; every finding verified against exact line locations, not summaries.
- Matrix pass over known defect classes: vocabulary seams, coverage gaps, UNKNOWN handling, fail direction, scalar authority, health leak, claim-force overreach, laundering routes.
- Cross-document consistency with doc-01/02/03 closures (D3-01 derived-canonical, TR-01 seam, TR-02 causal binding) and the EA/LA anti-laundering layer.
- v0.1.2 proposal built by verbatim-preserving targeted edits; all replacements asserted unique before application; internal dominance-order divergence introduced during editing was caught and corrected before sealing (20.4 rupture-dominance).
