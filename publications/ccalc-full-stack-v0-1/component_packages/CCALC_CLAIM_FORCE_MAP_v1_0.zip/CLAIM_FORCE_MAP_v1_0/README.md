# CCALC Claim-Force Map v1.0

A claim-strength map for the CCALC witness corpus.

Run integrity check:

```bash
sha256sum -c SHA256SUMS.txt
```

Main files:

- `CLAIM_FORCE_MAP_v1_0.md`
- `CLAIM_FORCE_MAP_v1_0.json`
- `CLAIM_FORCE_MATRIX.tsv`
- `SUPPLEMENTAL_POST_DOCMAP_CLAIM_FORCE.tsv`
- `CLAIM_CLASS_LEGEND.md`
- `NON_CLAIMS_AND_BOUNDARIES.md`
- `PUBLIC_STATEMENT_TEMPLATE.md`

Scope: DOC_MAP v1.2 + selected post-DOCMAP artifacts known in the current working set.
