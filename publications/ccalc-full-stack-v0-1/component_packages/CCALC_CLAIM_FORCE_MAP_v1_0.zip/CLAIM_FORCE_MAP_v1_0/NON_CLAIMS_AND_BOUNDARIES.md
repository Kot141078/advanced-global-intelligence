# Non-Claims and Boundaries

This claim-force map does NOT claim:

1. that any reviewed system is conscious, a person, a legal subject, or morally equivalent to a human;
2. that any checker is formally proven correct or complete;
3. that passing fixtures implies enforcement against a real adversarial substrate;
4. that a private/local prototype is deployment-ready;
5. that witness evidence proves ontology;
6. that architecture evidence proves implementation;
7. that implementation evidence proves safety;
8. that governance evidence proves capability;
9. that continuity evidence proves personhood;
10. that this map grants authority, deployment approval, certification, or ratification.

## Boundary

This map is a claim-control artifact. It classifies what the corpus can support. It does not strengthen the corpus beyond its evidence.
