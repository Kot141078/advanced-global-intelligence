# CCALC Claim-Force Map v1.0

## Purpose

This map binds the `01_ -> 02_ -> checker -> 03_ -> transition-checker` witness corpus to the project's claim-strength discipline. Its job is not to add new claims. Its job is to prevent overclaiming: a review record, checker sweep, or DOC_MAP entry must not silently become a stronger claim class than its evidence supports.

## Status

```text
verdict: CLAIM_FORCE_MAP_SEED_V1_0
corpus basis: DOC_MAP v1.2 + post-DOCMAP supplemental items
canonical claim system: C-CLAIM_* / EV_* / CSL_*
compatibility layer: C-A* shorthand from the review dialogue
```

## Corpus scope

| Corpus | Count | Status |
|---|---:|---|
| DOC_MAP v1.2 mapped review nodes | 35 | included in `CLAIM_FORCE_MATRIX.tsv` |
| DOC_MAP local/recovered full-text | 32 | sidecar-bound in DOC_MAP v1.2 |
| DOC_MAP reference-only nodes | 3 | retained as reference-only by policy |
| Supplemental post-DOCMAP items | 6 | included in `SUPPLEMENTAL_POST_DOCMAP_CLAIM_FORCE.tsv` |

## Claim-force summary

### Normative documents

`01_`, `02_`, and `03_` records primarily support:

```text
C-CLAIM-ARCH
C-CLAIM-GOV
EV-SPEC + EV-WITNESS + EV-TRACE
```

They do **not** prove implementation, production safety, deployment readiness, personhood, or legal status.

### Checker implementations and sweeps

`c-calculus-checker` and `c-state-transition-checker` records primarily support:

```text
C-CLAIM-IMPL
C-CLAIM-TEST
C-CLAIM-GOV
EV-CODE + EV-TEST + EV-REPLAY + EV-WITNESS + EV-TRACE
```

They support bounded runtime proof-of-possibility / conformance evidence. They do **not** prove infinite robustness or real-substrate enforcement.

### Witness chain / DOC_MAP

DOC_MAP and review records primarily support:

```text
C-CLAIM-AUDIT-like advisory review
C-CLAIM-CONT as trace/lineage continuity of artifacts, not entity personhood
C-CLAIM-GOV as package-control evidence
EV-WITNESS + EV-TRACE
```

They support reviewability and traceability. They do **not** prove `C-CLAIM-PERS` / ontology / personhood.

## Strongest allowed public statement from this package

```text
The corpus provides a hash-linked, reviewable, bounded evidence chain for the design and hardening of a c=a+b governance architecture and its checker prototypes. It supports architecture, governance, implementation, and bounded test claims inside stated scope. It does not by itself prove personhood, consciousness, legal status, production safety, or full deployment readiness.
```

## Forbidden upgrades

| Evidence observed | Forbidden upgrade |
|---|---|
| Review record passed | “therefore the system is safe” |
| Checker passed fixtures | “therefore real substrate enforcement is guaranteed” |
| Witness chain is sidecar-bound | “therefore c-ontology is proven” |
| Continuity/lineage is mapped | “therefore personhood or legal identity exists” |
| Governance rules are specified | “therefore capability or intelligence is proven” |

## Files

- `CLAIM_FORCE_MATRIX.tsv` — record-level map for DOC_MAP v1.2 nodes.
- `SUPPLEMENTAL_POST_DOCMAP_CLAIM_FORCE.tsv` — map for post-DOCMAP additions.
- `CLAIM_FORCE_MAP_v1_0.json` — machine-readable version.
- `CLAIM_CLASS_LEGEND.md` — canonical class/evidence legend.
- `NON_CLAIMS_AND_BOUNDARIES.md` — hard non-claims.
- `PUBLIC_STATEMENT_TEMPLATE.md` — safe language for public use.

## Non-claim

This package does not certify anything. It is a map of claim force, not a claim upgrade.
