# Claim Force Legend v1.0

This package normalizes the witness corpus into claim-force classes to prevent claim laundering.

## Canonical fields used here

- `C-CLAIM-*` — formal claim class from the local Claim Strength Taxonomy.
- `EV-*` — evidence class.
- `CSL-*` — claim strength / maturity level.
- `C-A*` — compatibility shorthand used in the dialogue and review notes; not the canonical field for this map.

## Core rule

```text
claim class first;
evidence class second;
no cross-class upgrade without bridge evidence.
```

## Most important boundary

```text
witness evidence (C-A7 / EV-WITNESS / EV-TRACE)
  does not prove
ontology/personhood/c-ness (C-A1 / C-CLAIM-PERS).
```

## Compatibility mapping used

| Dialogue tag | Normalized meaning in this package |
|---|---|
| `C-A1` | Axiomatic / ontological claim. Not proven by this package. |
| `C-A4` | Draft normative / profile claim -> `C-CLAIM-ARCH`, `C-CLAIM-GOV`. |
| `C-A5` | Observed practice stability / fifth-ring candidate -> future `C-CLAIM-TEST`/`C-CLAIM-CONT` with field evidence. |
| `C-A6` | Runtime proof-of-possibility -> `C-CLAIM-IMPL`, `C-CLAIM-TEST`, `C-CLAIM-GOV` with `EV-CODE`, `EV-TEST`, `EV-REPLAY`. |
| `C-A7` | Evidence/witness layer -> `EV-WITNESS`, `EV-TRACE`, often `C-CLAIM-AUDIT`/`C-CLAIM-GOV`. |
| `C-A10` | Control/package artifact -> `C-CLAIM-GOV`, `EV-SPEC`, `EV-TRACE`. |

## Non-upgrade examples

```text
checker passes fixtures -> not production safety
witness chain sidecar-bound -> not c-ontology
normative architecture stable -> not implementation
continuity evidence -> not personhood
local execution -> not sovereignty
```
