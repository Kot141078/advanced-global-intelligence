# Public Statement Template

Use this language when describing the corpus outside the lab:

> This repository/corpus contains a hash-linked, reviewable evidence chain for a c=a+b governance architecture, its operator profile, and checker prototypes. It supports bounded architecture, governance, implementation, and test claims. It does not claim personhood, consciousness, legal status, production safety, or deployment certification.

Avoid:

```text
This proves c exists.
This proves Ester is conscious.
This checker proves safety.
This witness chain proves personhood.
```

Safer:

```text
This provides evidence for reviewability, traceability, bounded implementation, and tested conformance inside the declared scope.
```
