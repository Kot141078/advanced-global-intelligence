# Freeze binding protocol note

For every frozen artifact, compute SHA-256 over the exact file bytes and store the result in an external sidecar or package-level `SHA256SUMS.txt`.

Do not insert a self-referential hash into a Markdown body and then claim that the Markdown file hashes to that value.
