#!/usr/bin/env python3
"""CCALC 07d public corpus index / citation surface sync checker seed v0.1.

Stdlib-only reference checker. It validates the record-shape and guard semantics
for public corpus index synchronization, citation surfaces, supersession/retraction
status propagation, and claim-force ceiling discipline.
"""
from __future__ import annotations
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

HEX64 = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_SOURCE_KEYS = {
    "DOC07_PUBLIC_EVIDENCE_BOUNDARY",
    "DOC07A_DISCLOSURE_MANIFEST",
    "DOC07B_RELEASE_HASH_CUSTODY",
    "DOC07C_RETRACTION_SUPERSESSION_ERRATA",
}
SURFACE_IDS = {
    "README_INDEX",
    "CITATION_CFF",
    "ZENODO_METADATA",
    "GITHUB_RELEASE",
    "WEBSITE_PUBLICATION_PAGE",
    "LLMS_TXT",
    "SITEMAP_XML",
    "ORCID_WORKS",
    "DOI_LANDING_PAGE",
}
STATUS = {"CURRENT", "SUPERSEDED", "RETRACTED", "ERRATA", "WITHHELD"}
DECISIONS = {"ALLOW_CITATION_SYNC", "HOLD_SYNC", "RETRACT_SYNC", "SUPERSEDE_SYNC", "QUARANTINE_SYNC"}
CLAIM_ORDER = {
    "C-A0": 0,
    "C-A2": 2,
    "C-A3": 3,
    "C-A4": 4,
    "C-A5": 5,
    "C-A6": 6,
    "C-A7": 7,
    "C-A8": 8,
    "C-A9": 9,
    "C-A10": 10,
}
FORBIDDEN_CLAIM_TEXT = [
    "C-A1",
    "safety certification",
    "deployment authorization",
    "privacy-law certification",
    "legal certification",
    "live substrate truth",
    "proof of completeness",
]


def _is_hex64(v: Any) -> bool:
    return isinstance(v, str) and bool(HEX64.match(v))


def _parse_dt(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _claim_ok(claim: Any) -> bool:
    return isinstance(claim, str) and claim in CLAIM_ORDER and claim != "C-A1"


def _claim_leq(surface_claim: str, item_claim: str) -> bool:
    return CLAIM_ORDER.get(surface_claim, 999) <= CLAIM_ORDER.get(item_claim, -1)


def _has_forbidden_text(value: Any) -> bool:
    if isinstance(value, str):
        low = value.lower()
        return any(t.lower() in low for t in FORBIDDEN_CLAIM_TEXT)
    if isinstance(value, list):
        return any(_has_forbidden_text(v) for v in value)
    if isinstance(value, dict):
        return any(_has_forbidden_text(v) for v in value.values())
    return False


def check_manifest(doc: Dict[str, Any]) -> Tuple[bool, List[str]]:
    errors: List[str] = []

    if not isinstance(doc, dict):
        return False, ["document is not an object"]
    if doc.get("schema_id") != "CCALC_PUBLIC_CORPUS_INDEX_SYNC_v0_1":
        errors.append("SCHEMA_ID_INVALID")
    if not isinstance(doc.get("manifest_id"), str) or not doc["manifest_id"]:
        errors.append("MANIFEST_ID_MISSING")
    if doc.get("sync_decision") not in DECISIONS:
        errors.append("SYNC_DECISION_INVALID")
    if _has_forbidden_text(doc.get("public_claims", [])):
        errors.append("FORBIDDEN_PUBLIC_CLAIM_TEXT")

    approvals = doc.get("approvals", {})
    if not isinstance(approvals, dict):
        errors.append("APPROVALS_INVALID")
        approvals = {}
    if approvals.get("human_anchor_review") is not True:
        errors.append("HUMAN_ANCHOR_REVIEW_REQUIRED")
    if approvals.get("citation_surface_review") is not True:
        errors.append("CITATION_SURFACE_REVIEW_REQUIRED")
    if approvals.get("privacy_redaction_review") is not True:
        errors.append("PRIVACY_REDACTION_REVIEW_REQUIRED")
    if approvals.get("reviewer_class") == "MODEL_ONLY":
        errors.append("MODEL_ONLY_REVIEW_FORBIDDEN")

    src = doc.get("source_bindings", [])
    if not isinstance(src, list):
        errors.append("SOURCE_BINDINGS_INVALID")
        src = []
    src_keys = set()
    for i, rec in enumerate(src):
        if not isinstance(rec, dict):
            errors.append(f"SOURCE_BINDING_{i}_INVALID")
            continue
        key = rec.get("component")
        src_keys.add(key)
        if not isinstance(key, str) or not key:
            errors.append(f"SOURCE_BINDING_{i}_COMPONENT_MISSING")
        if not _is_hex64(rec.get("sha256")):
            errors.append(f"SOURCE_BINDING_{key}_HASH_INVALID")
        verified = rec.get("verified_sha256")
        if verified is not None:
            if not _is_hex64(verified):
                errors.append(f"SOURCE_BINDING_{key}_VERIFIED_HASH_INVALID")
            elif _is_hex64(rec.get("sha256")) and verified != rec.get("sha256"):
                errors.append(f"SOURCE_BINDING_{key}_VERIFIED_HASH_MISMATCH")
        if rec.get("binding_status") != "BOUND":
            errors.append(f"SOURCE_BINDING_{key}_NOT_BOUND")
    missing = sorted(REQUIRED_SOURCE_KEYS - src_keys)
    if missing:
        errors.append("SOURCE_BINDINGS_MISSING:" + ",".join(missing))

    neg = doc.get("negative_cache", [])
    if not isinstance(neg, list):
        errors.append("NEGATIVE_CACHE_INVALID")
        neg = []
    if any(isinstance(n, dict) and n.get("hit") is True and not n.get("resolved") for n in neg):
        errors.append("NEGATIVE_CACHE_HIT_UNRESOLVED")

    red = doc.get("red_patterns", [])
    if not isinstance(red, list):
        errors.append("RED_PATTERNS_INVALID")
        red = []
    if any(isinstance(r, dict) and r.get("resolved") is not True for r in red):
        errors.append("UNRESOLVED_RED_PATTERN")

    items = doc.get("items", [])
    if not isinstance(items, list) or not items:
        errors.append("ITEMS_MISSING")
        items = []
    seen_ids = set()
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"ITEM_{idx}_INVALID")
            continue
        item_id = item.get("item_id")
        prefix = f"ITEM_{item_id or idx}"
        if not isinstance(item_id, str) or not item_id:
            errors.append(f"{prefix}_ID_MISSING")
        elif item_id in seen_ids:
            errors.append(f"{prefix}_DUPLICATE_ID")
        else:
            seen_ids.add(item_id)
        status = item.get("status")
        if status not in STATUS:
            errors.append(f"{prefix}_STATUS_INVALID")
        item_hash = item.get("artifact_sha256")
        if not _is_hex64(item_hash):
            errors.append(f"{prefix}_ARTIFACT_HASH_INVALID")
        item_claim = item.get("claim_force_ceiling")
        if not _claim_ok(item_claim):
            errors.append(f"{prefix}_CLAIM_FORCE_INVALID_OR_FORBIDDEN")
        if _has_forbidden_text(item.get("citation_guidance", "")):
            errors.append(f"{prefix}_FORBIDDEN_CITATION_GUIDANCE")
        for flag, code in [
            ("raw_secret_public", "RAW_SECRET_PUBLIC"),
            ("private_key_pattern_public", "PRIVATE_KEY_PUBLIC"),
            ("raw_runtime_ledger_public", "RAW_RUNTIME_LEDGER_PUBLIC"),
            ("withheld_evidence_strengthens_claim", "WITHHELD_AUTHORITY_LAUNDERING"),
            ("hash_only_semantic_truth_claim", "HASH_ONLY_SEMANTIC_TRUTH_LAUNDERING"),
            ("redaction_strengthens_claim", "REDACTION_STRENGTHENS_CLAIM"),
        ]:
            if item.get(flag) is True:
                errors.append(f"{prefix}_{code}")
        published_at = _parse_dt(item.get("artifact_publication_utc"))
        if published_at is None and status != "WITHHELD":
            errors.append(f"{prefix}_PUBLICATION_TIME_INVALID")

        surfaces = item.get("citation_surfaces", [])
        if not isinstance(surfaces, list):
            errors.append(f"{prefix}_SURFACES_INVALID")
            surfaces = []
        required = item.get("required_surfaces", [])
        if not isinstance(required, list) or (not required and status != "WITHHELD"):
            errors.append(f"{prefix}_REQUIRED_SURFACES_MISSING")
            required = [] if not isinstance(required, list) else required
        surface_by_id = {}
        doi_values = set()
        for sidx, surf in enumerate(surfaces):
            if not isinstance(surf, dict):
                errors.append(f"{prefix}_SURFACE_{sidx}_INVALID")
                continue
            sid = surf.get("surface_id")
            sprefix = f"{prefix}_SURFACE_{sid or sidx}"
            if sid not in SURFACE_IDS:
                errors.append(f"{sprefix}_SURFACE_ID_INVALID")
            if sid in surface_by_id:
                errors.append(f"{sprefix}_DUPLICATE_SURFACE")
            surface_by_id[sid] = surf
            present = surf.get("present") is True
            if sid in required and not present:
                errors.append(f"{sprefix}_REQUIRED_SURFACE_NOT_PRESENT")
            if present:
                if not _is_hex64(surf.get("artifact_sha256")):
                    errors.append(f"{sprefix}_HASH_INVALID")
                elif _is_hex64(item_hash) and surf.get("artifact_sha256") != item_hash:
                    errors.append(f"{sprefix}_HASH_MISMATCH")
                if surf.get("status") != status:
                    errors.append(f"{sprefix}_STATUS_MISMATCH")
                sclaim = surf.get("claim_force")
                if not _claim_ok(sclaim):
                    errors.append(f"{sprefix}_CLAIM_FORCE_INVALID_OR_FORBIDDEN")
                elif _claim_ok(item_claim) and not _claim_leq(sclaim, item_claim):
                    errors.append(f"{sprefix}_CLAIM_FORCE_EXCEEDS_ITEM_CEILING")
                if _has_forbidden_text(surf.get("surface_claims", [])):
                    errors.append(f"{sprefix}_FORBIDDEN_SURFACE_CLAIM_TEXT")
                sync_dt = _parse_dt(surf.get("last_synced_utc"))
                if sync_dt is None:
                    errors.append(f"{sprefix}_SYNC_TIME_INVALID")
                elif published_at is not None and sync_dt < published_at:
                    errors.append(f"{sprefix}_STALE_SYNC_TIME")
                if surf.get("doi"):
                    doi_values.add(surf.get("doi"))
                for flag, code in [
                    ("semantic_truth_claim_from_hash", "HASH_ONLY_SEMANTIC_TRUTH_LAUNDERING"),
                    ("redaction_strengthens_claim", "REDACTION_STRENGTHENS_CLAIM"),
                    ("withheld_evidence_strengthens_claim", "WITHHELD_AUTHORITY_LAUNDERING"),
                    ("raw_secret_public", "RAW_SECRET_PUBLIC"),
                    ("private_key_pattern_public", "PRIVATE_KEY_PUBLIC"),
                    ("raw_runtime_ledger_public", "RAW_RUNTIME_LEDGER_PUBLIC"),
                ]:
                    if surf.get(flag) is True:
                        errors.append(f"{sprefix}_{code}")
        for sid in required:
            if sid not in SURFACE_IDS:
                errors.append(f"{prefix}_REQUIRED_SURFACE_ID_INVALID:{sid}")
            elif sid not in surface_by_id or surface_by_id[sid].get("present") is not True:
                errors.append(f"{prefix}_REQUIRED_SURFACE_MISSING:{sid}")
        if len(doi_values) > 1:
            errors.append(f"{prefix}_DOI_MISMATCH_ACROSS_SURFACES")

        if status == "CURRENT":
            if item.get("correction_ledger_ref"):
                errors.append(f"{prefix}_CURRENT_HAS_CORRECTION_LEDGER_REF")
            if item.get("do_not_cite_as_current") is True:
                errors.append(f"{prefix}_CURRENT_MARKED_DO_NOT_CITE")
        elif status == "SUPERSEDED":
            if not isinstance(item.get("correction_ledger_ref"), str) or not item.get("correction_ledger_ref"):
                errors.append(f"{prefix}_SUPERSEDED_REQUIRES_CORRECTION_LEDGER_REF")
            if not _is_hex64(item.get("replacement_artifact_sha256")):
                errors.append(f"{prefix}_SUPERSEDED_REQUIRES_REPLACEMENT_HASH")
            for sid, surf in surface_by_id.items():
                if surf.get("present") is True and not surf.get("superseded_by"):
                    errors.append(f"{prefix}_SUPERSEDED_SURFACE_{sid}_MISSING_SUPERSEDED_BY")
        elif status == "RETRACTED":
            if not isinstance(item.get("correction_ledger_ref"), str) or not item.get("correction_ledger_ref"):
                errors.append(f"{prefix}_RETRACTED_REQUIRES_CORRECTION_LEDGER_REF")
            if item.get("do_not_cite_as_current") is not True:
                errors.append(f"{prefix}_RETRACTED_REQUIRES_DO_NOT_CITE")
            for sid, surf in surface_by_id.items():
                if surf.get("present") is True and surf.get("do_not_cite_as_current") is not True:
                    errors.append(f"{prefix}_RETRACTED_SURFACE_{sid}_MISSING_DO_NOT_CITE")
        elif status == "ERRATA":
            if not isinstance(item.get("correction_ledger_ref"), str) or not item.get("correction_ledger_ref"):
                errors.append(f"{prefix}_ERRATA_REQUIRES_CORRECTION_LEDGER_REF")
            for sid, surf in surface_by_id.items():
                if surf.get("present") is True and surf.get("errata_notice_present") is not True:
                    errors.append(f"{prefix}_ERRATA_SURFACE_{sid}_MISSING_ERRATA_NOTICE")
        elif status == "WITHHELD":
            if item.get("release_decision") != "WITHHOLD_PUBLIC_RELEASE":
                errors.append(f"{prefix}_WITHHELD_REQUIRES_WITHHOLD_DECISION")
            if surfaces:
                # Withheld records may name index placeholders only, never publish public artifact hashes.
                if any(s.get("present") is True for s in surfaces if isinstance(s, dict)):
                    errors.append(f"{prefix}_WITHHELD_HAS_PUBLIC_SURFACE")

    decision = doc.get("sync_decision")
    if decision == "ALLOW_CITATION_SYNC" and errors:
        errors.append("ALLOW_DECISION_WITH_BLOCKING_FINDINGS")
    if decision in {"RETRACT_SYNC", "SUPERSEDE_SYNC"}:
        if not any(isinstance(i, dict) and i.get("status") in {"RETRACTED", "SUPERSEDED", "ERRATA"} for i in items):
            errors.append("CORRECTION_SYNC_DECISION_WITHOUT_CORRECTION_ITEM")

    return len(errors) == 0, errors


def check_file(path: str | Path) -> Tuple[bool, List[str]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if "manifest" in data and "expected" in data:
        data = data["manifest"]
    return check_manifest(data)


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print("usage: public_corpus_citation_sync_checker_v0_1.py <manifest-or-case.json> [...]")
        return 2
    overall = True
    for arg in argv[1:]:
        ok, errors = check_file(arg)
        print(f"{arg}\t{'PASS' if ok else 'FAIL'}\t{';'.join(errors)}")
        overall = overall and ok
    return 0 if overall else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
