# Open issues and next steps — 07d

## Open issues

- Real public site / GitHub / Zenodo / ORCID adapters remain outside this seed package.
- Real DOI publication requires human-side repository and Zenodo operations.
- Privacy-law review remains external; this package only encodes technical redaction/citation discipline.
- Complete public corpus enumeration is a release-time operation, not a claim made by this seed.

## Next steps

1. Close the `07` layer with `CCALC_DOC07_PUBLIC_EVIDENCE_STACK_UMBRELLA_v0_1`.
2. Use the umbrella for future Zenodo/GitHub/site release packs.
3. Move to the next semantic layer only after `07` is frozen.
