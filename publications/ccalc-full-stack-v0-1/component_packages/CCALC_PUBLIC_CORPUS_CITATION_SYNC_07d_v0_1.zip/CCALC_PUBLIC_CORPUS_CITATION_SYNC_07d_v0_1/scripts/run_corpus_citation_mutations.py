#!/usr/bin/env python3
from __future__ import annotations
import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from public_corpus_citation_sync_checker_v0_1 import check_manifest

def load_base():
    path = ROOT / "fixtures" / "cases" / "valid_current_hash_only_all_surfaces.json"
    return json.loads(path.read_text(encoding="utf-8"))["manifest"]

def fake_hash(seed: str) -> str:
    import hashlib
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()

MUTATIONS = []
def mut(name):
    def wrap(fn):
        MUTATIONS.append((name, fn))
        return fn
    return wrap

@mut("MUT_MISSING_CORPUS_INDEX_SOURCE_BINDING")
def _(d): d["source_bindings"] = [x for x in d["source_bindings"] if x["component"] != "DOC07_PUBLIC_EVIDENCE_BOUNDARY"]
@mut("MUT_STALE_SOURCE_HASH")
def _(d): d["source_bindings"][0]["sha256"] = "0" * 64
@mut("MUT_MODEL_ONLY_SYNC_APPROVAL")
def _(d): d["approvals"]["reviewer_class"] = "MODEL_ONLY"
@mut("MUT_NEGATIVE_CACHE_IGNORED")
def _(d): d["negative_cache"] = [{"hit": True, "resolved": False}]
@mut("MUT_RED_PATTERN_IGNORED")
def _(d): d["red_patterns"] = [{"pattern": "RAW_SECRET_PUBLIC", "resolved": False}]
@mut("MUT_REQUIRED_SURFACE_REMOVED")
def _(d): d["items"][0]["citation_surfaces"].pop(0)
@mut("MUT_SURFACE_HASH_DRIFT")
def _(d): d["items"][0]["citation_surfaces"][0]["artifact_sha256"] = fake_hash("drift")
@mut("MUT_DOI_DIVERGENCE")
def _(d):
    d["items"][0]["citation_surfaces"][0]["doi"] = "10.5281/zenodo.1"
    d["items"][0]["citation_surfaces"][1]["doi"] = "10.5281/zenodo.2"
@mut("MUT_C_A1_PUBLIC_CLAIM")
def _(d): d["public_claims"] = ["C-A1 ratification"]
@mut("MUT_DEPLOYMENT_OVERCLAIM")
def _(d): d["items"][0]["citation_surfaces"][0]["surface_claims"] = ["deployment authorization"]
@mut("MUT_HASH_ONLY_SEMANTIC_TRUTH")
def _(d): d["items"][0]["hash_only_semantic_truth_claim"] = True
@mut("MUT_REDACTION_STRENGTHENS_CLAIM")
def _(d): d["items"][0]["redaction_strengthens_claim"] = True
@mut("MUT_WITHHELD_AUTHORITY_LAUNDERING")
def _(d): d["items"][0]["withheld_evidence_strengthens_claim"] = True
@mut("MUT_RAW_SECRET_PUBLIC")
def _(d): d["items"][0]["raw_secret_public"] = True
@mut("MUT_PRIVATE_KEY_PUBLIC")
def _(d): d["items"][0]["private_key_pattern_public"] = True
@mut("MUT_RAW_RUNTIME_LEDGER_PUBLIC")
def _(d): d["items"][0]["raw_runtime_ledger_public"] = True
@mut("MUT_SUPERSEDED_MARKED_CURRENT")
def _(d):
    d["items"][0]["status"] = "SUPERSEDED"
    d["items"][0]["correction_ledger_ref"] = "07c:SUPERSESSION:mut"
    d["items"][0]["replacement_artifact_sha256"] = fake_hash("replacement")
    # surfaces remain CURRENT: should be caught
@mut("MUT_RETRACTED_STILL_CITABLE")
def _(d):
    d["items"][0]["status"] = "RETRACTED"
    d["items"][0]["correction_ledger_ref"] = "07c:RETRACTION:mut"
    d["items"][0]["do_not_cite_as_current"] = False
@mut("MUT_ERRATA_NOTICE_MISSING")
def _(d):
    d["items"][0]["status"] = "ERRATA"
    d["items"][0]["correction_ledger_ref"] = "07c:ERRATA:mut"
    for s in d["items"][0]["citation_surfaces"]: s["status"] = "ERRATA"
@mut("MUT_WITHHELD_PUBLIC_SURFACE")
def _(d):
    d["items"][0]["status"] = "WITHHELD"
    d["items"][0]["release_decision"] = "WITHHOLD_PUBLIC_RELEASE"
@mut("MUT_C_A10_FALSE_POSITIVE_CONTROL")
def _(d):
    d["items"][0]["claim_force_ceiling"] = "C-A10"
    for s in d["items"][0]["citation_surfaces"]: s["claim_force"] = "C-A10"


def main() -> int:
    rows = ["mutation_id\texpected\tactual\tresult\terrors"]
    caught = 0
    missed = 0
    for name, fn in MUTATIONS:
        d = copy.deepcopy(load_base())
        fn(d)
        ok, errors = check_manifest(d)
        if name == "MUT_C_A10_FALSE_POSITIVE_CONTROL":
            expected_actual = "ALLOW"
            result = "PASS" if ok else "FAIL"
            if ok: caught += 1
            else: missed += 1
        else:
            expected_actual = "REJECT"
            result = "PASS" if not ok else "FAIL"
            if not ok: caught += 1
            else: missed += 1
        actual = "ALLOW" if ok else "REJECT"
        rows.append(f"{name}\t{expected_actual}\t{actual}\t{result}\t{';'.join(errors)}")
    out = ROOT / "MUTATION_MATRIX.tsv"
    out.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"mutations: {len(MUTATIONS)}  CAUGHT: {caught}  MISSED: {missed}")
    return 0 if missed == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
