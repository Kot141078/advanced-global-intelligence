#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from public_corpus_citation_sync_checker_v0_1 import check_manifest

def main() -> int:
    cases = sorted((ROOT / "fixtures" / "cases").glob("*.json"))
    rows = ["case_id\texpected\tactual\tresult\terrors"]
    passed = 0
    failed = 0
    for path in cases:
        data = json.loads(path.read_text(encoding="utf-8"))
        ok, errors = check_manifest(data["manifest"])
        actual = "ALLOW" if ok else "REJECT"
        result = "PASS" if actual == data["expected"] else "FAIL"
        if result == "PASS":
            passed += 1
        else:
            failed += 1
        rows.append(f"{data['case_id']}\t{data['expected']}\t{actual}\t{result}\t{';'.join(errors)}")
    out = ROOT / "FIXTURE_RESULTS.tsv"
    out.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"fixtures: {len(cases)}  PASS: {passed}  FAIL: {failed}")
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
