# CCALC Public Corpus Citation Sync 07d v0.1

This package contains `07d_PUBLIC_CORPUS_INDEX_AND_CITATION_SURFACE_SYNC_v0_1.md`, schemas, a stdlib checker seed, fixture cases, mutation probes, registries, source bindings, and package verification records.

Run:

```bash
python3 scripts/run_corpus_citation_fixtures.py
python3 scripts/run_corpus_citation_mutations.py
sha256sum -c SHA256SUMS.txt
```
