# Reading Order — 08b

1. `08b_EXTERNAL_REVIEW_CONFLICT_RESOLUTION_AND_PATCH_INTAKE_LEDGER_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `registry/*.tsv`
4. `schemas/*.schema.json`
5. `src/external_review_patch_intake_checker_v0_1.py`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
