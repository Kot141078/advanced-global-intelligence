# CCALC_EXTERNAL_REVIEW_CONFLICT_PATCH_LEDGER_08b_v0_1

`08b` provides the external review conflict-resolution and patch-intake ledger seed for the interoperability boundary.

Run:

```bash
python3 scripts/run_external_review_patch_fixtures.py
python3 scripts/run_external_review_patch_mutations.py
sha256sum -c SHA256SUMS.txt
```

Main document: `08b_EXTERNAL_REVIEW_CONFLICT_RESOLUTION_AND_PATCH_INTAKE_LEDGER_v0_1.md`
