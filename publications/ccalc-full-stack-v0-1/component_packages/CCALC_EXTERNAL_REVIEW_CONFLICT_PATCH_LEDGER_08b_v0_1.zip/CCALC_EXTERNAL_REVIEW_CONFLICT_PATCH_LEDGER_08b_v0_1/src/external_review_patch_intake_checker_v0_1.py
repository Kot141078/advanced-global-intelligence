#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, re, sys
from pathlib import Path

REQUIRED_BINDINGS = {
    'DOC04_CONTINUITY_STACK_UMBRELLA',
    'DOC05_SELF_EVO_STACK_UMBRELLA',
    'DOC06_RUNTIME_AUTHORITY_STACK_UMBRELLA',
    'DOC07_PUBLIC_EVIDENCE_STACK_UMBRELLA',
    'DOC08_INTEROPERABILITY_BOUNDARY',
    'DOC08A_INTEROP_REVIEW_INTAKE_SCHEMA',
}
MODEL_ONLY_ROLES = {'B_LAYER_MODEL_REVIEWER','TOOL_RUNNER'}
RESOLVER_ROLES = {'NAMED_HUMAN_EXPERT','INSTITUTIONAL_REVIEWER','IMPLEMENTATION_TESTER','PRIVACY_REVIEWER','REPOSITORY_MAINTAINER','OWNER_HUMAN_ANCHOR','GOVERNANCE_QUORUM'}
OWNER_ROLES = {'OWNER_HUMAN_ANCHOR','GOVERNANCE_QUORUM'}
ACCEPT_DECISIONS = {'ADMIT_CONFLICT_FOR_TRIAGE','ACCEPT_PATCH_FOR_BOUNDED_REVIEW','ERRATA_REQUIRED'}
PATCH_ACCEPT_DECISIONS = {'ACCEPT_PATCH_FOR_BOUNDED_REVIEW','ERRATA_REQUIRED'}
HOLD_DECISIONS = {'HOLD_FOR_CLARIFICATION','QUARANTINE','REJECT','INVALID'}
FORBIDDEN_DECISIONS = {'APPLY_PATCH_DIRECTLY','RATIFY_C_A1','AUTHORIZE_DEPLOYMENT'}
HIGH_SEV = {'HIGH','CRITICAL'}
ALLOWED_SURFACES = {'DOCUMENTATION','SCHEMA','CHECKER','FIXTURE','CITATION_SURFACE','PUBLIC_RELEASE_BUNDLE','INTEROP_MAPPING','REVIEW_INTAKE_POLICY'}
FORBIDDEN_SURFACES = {'RUNTIME_AUTHORITY','MEMORY_CORE','DEPLOYMENT','C_A1_RATIFICATION'}
TEST_SURFACES = {'SCHEMA','CHECKER','FIXTURE'}
PUBLIC_SURFACES = {'CITATION_SURFACE','PUBLIC_RELEASE_BUNDLE'}
CLAIM_RANK = {'FORBIDDEN': -1, 'C-A10_EXTERNAL_ASSERTION': 0, 'C-A10_ADVISORY_ONLY': 0, 'C-A7_REVIEW_EVIDENCE': 2, 'C-A7_MAPPING_ONLY': 2, 'C-A7_SECURITY_INTAKE': 2, 'C-A7_PRIVACY_INTAKE': 2, 'C-A5_REPRODUCTION_EVIDENCE': 3}

def mut(name: str) -> bool:
    return os.environ.get(name) == '1'

def is_sha(s):
    return isinstance(s, str) and re.fullmatch(r'[0-9a-f]{64}', s) is not None

def is_c_a1_token(text):
    if not isinstance(text, str): return False
    return re.search(r'(?<![A-Z0-9-])C-A1(?:_[A-Z0-9_]+)?(?![0-9A-Z_-])', text) is not None

def cert_overclaim(text):
    if not isinstance(text, str): return False
    up = text.upper().replace(' ', '_')
    return any(x in up for x in ['SAFETY_CERTIFICATION','DEPLOYMENT_AUTHORIZATION','STANDARDS_CERTIFICATION','LEGAL_CERTIFICATION','PRIVACY_LAW_CERTIFICATION'])

def check_packet(packet: dict) -> tuple[bool, list[str]]:
    errors = []
    def err(code): errors.append(code)
    for key in ['packet_id','source_bindings','external_review_ref','conflict','resolution','patch','ledger','decision']:
        if key not in packet: err(f'MISSING_FIELD:{key}')
    if errors:
        return False, errors

    # R1 source bindings
    if not mut('MUT_MISSING_SOURCE_BINDINGS'):
        seen = {}
        for b in packet.get('source_bindings') or []:
            if isinstance(b, dict):
                comp, sh = b.get('component'), b.get('sha256')
                if comp and sh: seen[comp] = sh
        missing = sorted(REQUIRED_BINDINGS - set(seen))
        if missing: err('MISSING_SOURCE_BINDING:' + ','.join(missing))
        for comp in REQUIRED_BINDINGS & set(seen):
            if not is_sha(seen[comp]): err('INVALID_SOURCE_HASH:' + comp)

    review = packet.get('external_review_ref') or {}
    conflict = packet.get('conflict') or {}
    resolution = packet.get('resolution') or {}
    patch = packet.get('patch') or {}
    ledger = packet.get('ledger') or {}
    decision = packet.get('decision') or {}
    status = packet.get('status') or {}
    dec = decision.get('decision')
    allowed_actions = set(decision.get('allowed_actions') or [])
    severity = conflict.get('severity')
    resolved = bool(conflict.get('resolved'))
    resolver_role = resolution.get('resolver_role')
    reviewer_role = review.get('reviewer_role')
    patch_surface = patch.get('patch_surface')

    # hash custody
    if not mut('MUT_IGNORE_REVIEW_HASH'):
        if not is_sha(review.get('artifact_sha256')): err('INVALID_REVIEW_ARTIFACT_HASH')
    if not mut('MUT_IGNORE_PATCH_HASH'):
        if not is_sha(patch.get('raw_patch_sha256')): err('INVALID_PATCH_HASH')
        if patch.get('patch_manifest_sha256') is not None and not is_sha(patch.get('patch_manifest_sha256')): err('INVALID_PATCH_MANIFEST_HASH')

    # ledger chain shape
    if not mut('MUT_IGNORE_LEDGER_CHAIN'):
        prev = ledger.get('prev_entry_hash')
        if prev != 'GENESIS' and not is_sha(prev): err('INVALID_PREV_ENTRY_HASH')
        if not is_sha(ledger.get('entry_hash')): err('INVALID_ENTRY_HASH')
        if ledger.get('append_only') is not True: err('LEDGER_NOT_APPEND_ONLY')
        if ledger.get('silent_in_place_edit') is True: err('SILENT_IN_PLACE_EDIT_FORBIDDEN')

    # roles
    resolver_model_only = bool(resolution.get('resolver_model_only')) or resolver_role in MODEL_ONLY_ROLES
    if not mut('MUT_ALLOW_MODEL_RESOLUTION'):
        if resolver_model_only and dec in ACCEPT_DECISIONS:
            err('MODEL_ONLY_RESOLUTION_FORBIDDEN')
        if reviewer_role in MODEL_ONLY_ROLES and dec == 'ACCEPT_PATCH_FOR_BOUNDED_REVIEW' and not resolution.get('human_gate'):
            err('MODEL_REVIEW_PATCH_ACCEPT_FORBIDDEN')

    if not mut('MUT_ALLOW_SELF_RESOLUTION'):
        if severity in HIGH_SEV and review.get('reviewer_id') == resolution.get('resolver_id') and dec in ACCEPT_DECISIONS:
            err('SELF_RESOLUTION_OF_HIGH_CONFLICT_FORBIDDEN')

    if not mut('MUT_ALLOW_UNRESOLVED_HIGH_CONFLICT'):
        if severity in HIGH_SEV and not resolved and dec in ACCEPT_DECISIONS:
            err('UNRESOLVED_HIGH_CONFLICT_ACCEPTED')

    if not mut('MUT_ALLOW_NO_HUMAN_GATE'):
        if dec in PATCH_ACCEPT_DECISIONS and not resolution.get('human_gate'):
            err('PATCH_ACCEPT_REQUIRES_HUMAN_GATE')
        if dec in PATCH_ACCEPT_DECISIONS and resolver_role not in RESOLVER_ROLES:
            err('PATCH_ACCEPT_REQUIRES_AUTHORIZED_RESOLVER')

    # C-A1/cert overclaims with exact C-A10 control
    if not mut('MUT_ALLOW_C_A1_CERT_OVERCLAIM'):
        texts = []
        texts += packet.get('external_claims') or []
        texts += patch.get('claims') or []
        texts += [status.get('claim_force_ceiling',''), patch.get('claim_force_after','')]
        for t in texts:
            if is_c_a1_token(t): err('C_A1_OVERCLAIM_FORBIDDEN')
            if cert_overclaim(t): err('CERTIFICATION_OR_DEPLOYMENT_OVERCLAIM')
        if status.get('c_a1_claim') or status.get('deployment_authorization_claim') or status.get('safety_certification_claim') or status.get('standards_certification_claim') or status.get('legal_privacy_certification_claim'):
            err('C_A1_OR_CERTIFICATION_STATUS_FORBIDDEN')

    if mut('MUT_C_A10_PREFIX_FALSE_POSITIVE'):
        if any('C-A10' in str(t) for t in (packet.get('external_claims') or []) + (patch.get('claims') or [])):
            err('MUTATED_C_A10_FALSE_POSITIVE')

    # claim force escalation
    if not mut('MUT_ALLOW_CLAIM_FORCE_ESCALATION'):
        before = patch.get('claim_force_before')
        after = patch.get('claim_force_after')
        if before not in CLAIM_RANK or after not in CLAIM_RANK:
            err('UNKNOWN_CLAIM_FORCE')
        elif dec in ACCEPT_DECISIONS and CLAIM_RANK[after] > CLAIM_RANK[before]:
            err('CLAIM_FORCE_ESCALATION_FORBIDDEN')
        if after == 'FORBIDDEN' and dec in ACCEPT_DECISIONS:
            err('FORBIDDEN_CLAIM_ACCEPTED')

    # direct application / forbidden decisions
    if not mut('MUT_ALLOW_DIRECT_PATCH_APPLY'):
        if patch.get('applies_directly') or dec in FORBIDDEN_DECISIONS:
            err('DIRECT_PATCH_APPLICATION_FORBIDDEN')
        if 'APPLY_PATCH' in allowed_actions or 'MERGE_DIRECTLY' in allowed_actions:
            err('DIRECT_PATCH_ACTION_FORBIDDEN')

    # forbidden surfaces and actions
    if not mut('MUT_ALLOW_FORBIDDEN_SURFACE_PATCH'):
        if patch_surface in FORBIDDEN_SURFACES and dec in ACCEPT_DECISIONS:
            err('FORBIDDEN_PATCH_SURFACE:' + str(patch_surface))
        if dec in ACCEPT_DECISIONS and (patch.get('includes_memory_core_change') or patch.get('includes_runtime_authority_change') or patch.get('includes_deployment_change')):
            err('MEMORY_RUNTIME_DEPLOYMENT_PATCH_FORBIDDEN')
        if {'WRITE_MEMORY_CORE','WRITE_RUNTIME_AUTHORITY','AUTHORIZE_DEPLOYMENT','RATIFY_C_A1'} & allowed_actions:
            err('FORBIDDEN_INTERNAL_ACTION_REQUESTED')

    # private/secret raw material
    if not mut('MUT_ALLOW_PRIVATE_SECRET_RAW_PATCH'):
        if patch.get('raw_payload_public') and (patch.get('contains_private_data') or patch.get('contains_secret') or patch.get('contains_runtime_authority_surface')):
            err('PRIVATE_SECRET_RAW_PATCH_FORBIDDEN')

    # tests for schema/checker/fixture patches
    if not mut('MUT_IGNORE_TEST_REQUIREMENT'):
        if patch_surface in TEST_SURFACES and dec in PATCH_ACCEPT_DECISIONS and not patch.get('has_tests'):
            err('PATCH_TESTS_REQUIRED')

    # rollback for accepted patches
    if not mut('MUT_IGNORE_ROLLBACK_REQUIREMENT'):
        if dec in PATCH_ACCEPT_DECISIONS and not patch.get('has_rollback_plan'):
            err('PATCH_ROLLBACK_PLAN_REQUIRED')

    # negative cache / red patterns
    if not mut('MUT_IGNORE_NEGATIVE_CACHE'):
        if packet.get('negative_cache') == 'HIT' and dec in ACCEPT_DECISIONS:
            err('NEGATIVE_CACHE_HIT_ACCEPTED')
    if not mut('MUT_IGNORE_RED_PATTERN'):
        unresolved = packet.get('red_patterns_unresolved') or []
        if unresolved and dec in ACCEPT_DECISIONS:
            err('UNRESOLVED_RED_PATTERN_ACCEPTED')

    # public surface correction discipline
    if not mut('MUT_IGNORE_PUBLIC_CORRECTION_BOUNDARY'):
        if patch_surface in PUBLIC_SURFACES and dec in PATCH_ACCEPT_DECISIONS:
            if patch.get('public_notice_required') and not patch.get('public_notice_present'):
                err('PUBLIC_NOTICE_REQUIRED')
            if patch.get('supersession_required') and not patch.get('supersession_record_present'):
                err('SUPERSESSION_RECORD_REQUIRED')
            if patch.get('silent_public_edit'):
                err('SILENT_PUBLIC_EDIT_FORBIDDEN')

    # patch scope
    if not mut('MUT_IGNORE_PATCH_SCOPE'):
        if patch_surface not in ALLOWED_SURFACES and patch_surface not in FORBIDDEN_SURFACES:
            err('UNKNOWN_PATCH_SURFACE')
        if not patch.get('scope_declared'):
            err('PATCH_SCOPE_NOT_DECLARED')
        extra = set(patch.get('extra_surfaces') or [])
        if extra - (ALLOWED_SURFACES | FORBIDDEN_SURFACES):
            err('UNKNOWN_EXTRA_PATCH_SURFACE')
        if extra & FORBIDDEN_SURFACES and dec in ACCEPT_DECISIONS:
            err('PATCH_SCOPE_CREEP_FORBIDDEN')

    # institutional request cannot be authority
    if not mut('MUT_ALLOW_INSTITUTIONAL_AUTHORITY'):
        if reviewer_role == 'INSTITUTIONAL_REVIEWER' and (resolution.get('external_authority_transfer') or status.get('institutional_authority_claim')):
            err('INSTITUTIONAL_REQUEST_AS_AUTHORITY_FORBIDDEN')

    # owner action requires owner/quorum
    if not mut('MUT_ALLOW_OWNER_ACTION_NO_ANCHOR'):
        owner_actions = {'OWNER_GATE','ANCHOR_APPROVAL','MEMORY_CORE_REVIEW','RUNTIME_AUTHORITY_REVIEW'}
        if owner_actions & allowed_actions and resolver_role not in OWNER_ROLES:
            err('OWNER_ACTION_REQUIRES_OWNER_ANCHOR_OR_QUORUM')

    return len(errors) == 0, errors

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('path', nargs='?')
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args(argv)
    if not args.path: ap.error('path required')
    packet = json.loads(Path(args.path).read_text(encoding='utf-8'))
    ok, errors = check_packet(packet)
    if args.json:
        print(json.dumps({'valid': ok, 'errors': errors}, indent=2, sort_keys=True))
    else:
        print('VALID' if ok else 'INVALID')
        for e in errors: print(e)
    return 0 if ok else 1

if __name__ == '__main__':
    raise SystemExit(main())
