# Open Issues and Next Steps — 08b

Open items:

1. Add signed reviewer identity binding once real external review signatures exist.
2. Add richer patch-diff structure for multi-file patches.
3. Bind to repository PR metadata in a future implementation profile.
4. Add implementation/reproduction report mapping in `08c`.

Next layer:

```text
08c_INTEROP_IMPLEMENTATION_REPORT_AND_REPRODUCTION_MAPPING_v0_1
```
