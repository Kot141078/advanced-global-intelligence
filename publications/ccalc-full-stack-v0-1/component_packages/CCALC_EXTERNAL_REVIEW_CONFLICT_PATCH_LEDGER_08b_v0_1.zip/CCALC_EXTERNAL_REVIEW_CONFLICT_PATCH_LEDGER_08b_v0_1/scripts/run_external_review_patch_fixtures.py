#!/usr/bin/env python3
from __future__ import annotations
import json, sys
sys.dont_write_bytecode = True
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from external_review_patch_intake_checker_v0_1 import check_packet
CASES = ROOT/'fixtures/cases'
rows = ['case\texpected_valid\tactual_valid\tstatus\terrors']
fail = 0
count = 0
for path in sorted(CASES.glob('*.json')):
    if '.tmp' in path.name or '.debug' in path.name:
        continue
    count += 1
    data = json.loads(path.read_text(encoding='utf-8'))
    expected = bool(data.pop('_expected_valid'))
    actual, errors = check_packet(data)
    status = 'PASS' if actual == expected else 'FAIL'
    if status == 'FAIL':
        fail += 1
    rows.append(f'{path.name}\t{expected}\t{actual}\t{status}\t{",".join(errors)}')
(ROOT/'FIXTURE_RESULTS.tsv').write_text('\n'.join(rows)+'\n', encoding='utf-8')
print(f'fixtures: {count}  PASS: {count-fail}  FAIL: {fail}')
raise SystemExit(1 if fail else 0)
