#!/usr/bin/env python3
from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT/'scripts/run_external_review_patch_fixtures.py'
MUTATIONS = [
 'MUT_MISSING_SOURCE_BINDINGS',
 'MUT_IGNORE_REVIEW_HASH',
 'MUT_IGNORE_PATCH_HASH',
 'MUT_IGNORE_LEDGER_CHAIN',
 'MUT_ALLOW_MODEL_RESOLUTION',
 'MUT_ALLOW_SELF_RESOLUTION',
 'MUT_ALLOW_UNRESOLVED_HIGH_CONFLICT',
 'MUT_ALLOW_NO_HUMAN_GATE',
 'MUT_ALLOW_C_A1_CERT_OVERCLAIM',
 'MUT_C_A10_PREFIX_FALSE_POSITIVE',
 'MUT_ALLOW_CLAIM_FORCE_ESCALATION',
 'MUT_ALLOW_DIRECT_PATCH_APPLY',
 'MUT_ALLOW_FORBIDDEN_SURFACE_PATCH',
 'MUT_ALLOW_PRIVATE_SECRET_RAW_PATCH',
 'MUT_IGNORE_TEST_REQUIREMENT',
 'MUT_IGNORE_ROLLBACK_REQUIREMENT',
 'MUT_IGNORE_NEGATIVE_CACHE',
 'MUT_IGNORE_RED_PATTERN',
 'MUT_IGNORE_PUBLIC_CORRECTION_BOUNDARY',
 'MUT_IGNORE_PATCH_SCOPE',
 'MUT_ALLOW_INSTITUTIONAL_AUTHORITY',
 'MUT_ALLOW_OWNER_ACTION_NO_ANCHOR',
]
rows = ['mutation\tstatus\treturncode\tstdout_tail']
missed = 0
for m in MUTATIONS:
    env = dict(os.environ)
    env[m] = '1'
    p = subprocess.run([sys.executable, str(SCRIPT)], cwd=str(ROOT), env=env, text=True, capture_output=True)
    caught = p.returncode != 0
    if not caught:
        missed += 1
    tail = (p.stdout + ' ' + p.stderr).replace('\n', ' | ')[-260:]
    rows.append(f'{m}\t{"CAUGHT" if caught else "MISSED"}\t{p.returncode}\t{tail}')
(ROOT/'MUTATION_MATRIX.tsv').write_text('\n'.join(rows)+'\n', encoding='utf-8')
print(f'mutations: {len(MUTATIONS)}  CAUGHT: {len(MUTATIONS)-missed}  MISSED: {missed}')
raise SystemExit(1 if missed else 0)
