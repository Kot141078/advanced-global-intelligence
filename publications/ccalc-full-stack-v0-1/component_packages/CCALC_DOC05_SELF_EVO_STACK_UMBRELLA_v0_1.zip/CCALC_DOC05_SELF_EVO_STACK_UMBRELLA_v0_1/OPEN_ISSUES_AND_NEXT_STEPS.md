# Open Issues and Next Steps — DOC05 Self-Evo Stack Umbrella v0.1

## Closed in this umbrella

```text
05   bounded growth semantics
05a  proposal packet schema + checker seed
05b  boundary hardening fixtures + mutations
05c  promotion ledger + rollback drill
05d  post-promotion watch + decay guard
```

## Still outside this umbrella

```text
live runtime deployment certification
production policy integration
multi-contour federation / quorum execution semantics
hardware/substrate authority mapping
legal/organizational authorization workflows
C-A1 ontology or personhood ratification
```

## Natural next layer

```text
06_C_RUNTIME_AUTHORITY_AND_MULTI_CONTOUR_DEPLOYMENT_BOUNDARY_v0_1
```

Suggested purpose of `06`: bind runtime authority, multi-contour quorum, execution scopes, operator control, and deployment boundaries so self-evolution outputs cannot jump directly into live authority.
