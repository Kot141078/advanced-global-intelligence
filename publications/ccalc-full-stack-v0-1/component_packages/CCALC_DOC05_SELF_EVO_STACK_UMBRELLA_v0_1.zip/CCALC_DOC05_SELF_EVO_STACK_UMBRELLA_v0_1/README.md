# CCALC DOC05 Self-Evo Stack Umbrella v0.1

Umbrella closure package for the `05` bounded self-evolution layer.

## Included stack

```text
05   bounded growth semantics
05a  proposal packet schema + checker seed
05b  boundary hardening fixtures + mutations
05c  promotion ledger + rollback drill
05d  post-promotion watch + decay guard
```

## Primary manifest

Read:

```text
CCALC_DOC05_SELF_EVO_STACK_INDEX_AND_RELEASE_MANIFEST_v0_1.md
```

## Operational formula

```text
proposal -> admission -> bounded trial -> evidence -> promotion decision -> rollback drill -> ledger -> apply -> watch -> keep|hold|rollback|quarantine|fork-reclassification
```

## Source binding

This package includes the `04` continuity stack umbrella as a source binding. The `05` layer depends on continuity classification and does not replace it.

## Verification

```text
component packages present: PASS
component SHA-256 recomputed: PASS
zip integrity: PASS
internal SHA256SUMS: PASS
executable rerun summary: PASS
umbrella SHA256SUMS: PASS
```

## Status

```text
CURRENT_05_SELF_EVO_STACK_UMBRELLA_CLOSED
```
