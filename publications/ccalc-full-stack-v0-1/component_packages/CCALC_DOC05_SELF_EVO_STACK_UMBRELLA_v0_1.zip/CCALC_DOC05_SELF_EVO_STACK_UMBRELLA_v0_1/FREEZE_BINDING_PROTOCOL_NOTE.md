# Freeze Binding Protocol Note

Use external SHA-256 sidecars for freeze binding.

```text
sha256sum exact_file_bytes > filename.sha256
```

A Markdown file MUST NOT contain a hash of itself as an internal authoritative binding. The binding is external: file bytes plus sidecar hash plus package-level `SHA256SUMS.txt`.
