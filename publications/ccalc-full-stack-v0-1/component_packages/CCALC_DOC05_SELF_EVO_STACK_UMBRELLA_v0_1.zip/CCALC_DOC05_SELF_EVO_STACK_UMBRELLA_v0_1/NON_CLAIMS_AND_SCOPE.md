# Non-Claims and Scope — DOC05 Self-Evo Stack Umbrella v0.1

This package is an umbrella closure artifact for the `05` self-evolution stack.

It does **not** claim:

```text
safety certification
deployment authorization
C-A1 ratification
ontological identity proof
personhood or legal status
live substrate truth
proof of completeness
permission for autonomous self-modification
```

Permitted claim scope:

```text
C-A4  bounded normative semantics and profiles
C-A7  hash-bound package, fixture, mutation, and rerun evidence
C-A10 schemas, validators, ledgers, control artifacts, and checker seeds
```

Operational rule:

```text
A c may grow.
A c may not self-certify growth.
Promotion is not completion; promotion opens a monitored stability window.
```
