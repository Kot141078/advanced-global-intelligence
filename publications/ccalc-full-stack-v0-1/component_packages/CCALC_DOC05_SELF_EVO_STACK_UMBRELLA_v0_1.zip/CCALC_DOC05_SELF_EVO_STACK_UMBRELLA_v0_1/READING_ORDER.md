# Reading Order — DOC05 Self-Evo Stack Umbrella v0.1

1. `components/CCALC_SELF_EVOLUTION_GATE_05_v0_1.zip`  
   Read the bounded growth semantics first. This defines self-evolution as a governed transition class, not an autonomous right.

2. `components/CCALC_SELF_EVO_PROPOSAL_PACKET_05a_v0_1.zip`  
   Read the machine packet schemas and checker seed for proposal, admission, bounded trial, fitness evidence, promotion decision, and memory promotion.

3. `components/CCALC_SELF_EVO_BOUNDARY_HARDENING_05b_v0_1.zip`  
   Read the adversarial boundary fixtures and mutation hardening layer.

4. `components/CCALC_SELF_EVO_PROMOTION_LEDGER_05c_v0_1.zip`  
   Read the promotion ledger, rollback drill, negative-cache binding, and post-apply continuity check.

5. `components/CCALC_SELF_EVO_POST_PROMOTION_WATCH_05d_v0_1.zip`  
   Read the post-promotion watch window and decay guard.

6. `source_bindings/CCALC_DOC04_CONTINUITY_STACK_UMBRELLA_v0_1.zip`  
   Use as the continuity source binding. The `05` layer does not replace or relax the `04` continuity stack.
