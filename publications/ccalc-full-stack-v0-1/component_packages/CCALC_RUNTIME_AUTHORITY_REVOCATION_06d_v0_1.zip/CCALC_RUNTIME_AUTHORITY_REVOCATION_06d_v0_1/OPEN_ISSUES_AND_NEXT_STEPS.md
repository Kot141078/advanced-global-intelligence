# Open Issues and Next Steps

- Integrate 06d record shapes with a live runtime audit sink.
- Add real credential-provider adapters only behind a separate privileged implementation profile.
- Add post-session artifact retention policy and operator-facing dashboard profile.
- Close doc-06 with an umbrella manifest after 06d acceptance.
