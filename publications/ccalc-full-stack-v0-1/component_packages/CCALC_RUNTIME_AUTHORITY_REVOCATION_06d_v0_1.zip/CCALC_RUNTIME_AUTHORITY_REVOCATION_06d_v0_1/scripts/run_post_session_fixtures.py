#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from runtime_authority_revocation_checker_v0_1 import validate

def main() -> int:
    cases = sorted((ROOT / "fixtures" / "cases").glob("*.json"))
    rows = ["case\texpected_admissible\tactual_admissible\tdecision\trequired_decision\tfinding_codes\tstatus"]
    fail = 0
    for path in cases:
        data = json.loads(path.read_text(encoding="utf-8"))
        res = validate(data["packet"])
        exp = bool(data["expected"]["admissible"])
        must = data["expected"].get("must_find", [])
        ok = (res["admissible"] == exp) and all(code in res["finding_codes"] for code in must)
        if not ok:
            fail += 1
        rows.append("\t".join([
            path.name,
            str(exp),
            str(res["admissible"]),
            res["decision"],
            res["required_decision"],
            ",".join(res["finding_codes"]),
            "PASS" if ok else "FAIL",
        ]))
    out = ROOT / "FIXTURE_RESULTS.tsv"
    out.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"fixtures: {len(cases)}  PASS: {len(cases)-fail}  FAIL: {fail}")
    return 0 if fail == 0 else 1
if __name__ == "__main__":
    raise SystemExit(main())
