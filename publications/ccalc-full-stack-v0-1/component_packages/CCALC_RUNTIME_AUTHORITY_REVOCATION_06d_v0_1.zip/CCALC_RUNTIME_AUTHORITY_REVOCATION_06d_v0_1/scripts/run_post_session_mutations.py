#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from runtime_authority_revocation_checker_v0_1 import validate, MUTATIONS

TARGET = {
    "MUT_IGNORE_SOURCE_BINDINGS": "SOURCE_BINDING_INVALID",
    "MUT_IGNORE_LEDGER_CHAIN": "LEDGER_CHAIN_INVALID",
    "MUT_ALLOW_ACTIVE_TOOL_LEASE": "STALE_TOOL_LEASE",
    "MUT_ALLOW_PERSISTENT_CREDENTIAL": "PERSISTENT_CREDENTIAL",
    "MUT_IGNORE_HANDOFF_CLOSEOUT": "PENDING_HANDOFF_CLOSEOUT",
    "MUT_IGNORE_OPEN_HOLD": "OPEN_EMERGENCY_HOLD",
    "MUT_IGNORE_NEGATIVE_CACHE_UPDATE": "NEGATIVE_CACHE_UPDATE_MISSING",
    "MUT_IGNORE_PENDING_RISK_CARRYOVER": "PENDING_RISK_CARRYOVER",
    "MUT_IGNORE_CONTINUITY_UNKNOWN": "CONTINUITY_UNKNOWN_OR_HOLD",
    "MUT_ALLOW_STALE_AUTHORITY": "STALE_AUTHORITY_GRANT",
    "MUT_ALLOW_ZOMBIE_SESSION": "ZOMBIE_SESSION",
    "MUT_IGNORE_SHARED_INFRA_RESIDUE": "SHARED_INFRA_AUTHORITY_RESIDUE",
    "MUT_ALLOW_MODEL_NEXT_SESSION_ADMISSION": "MODEL_NEXT_SESSION_ADMISSION",
    "MUT_ALLOW_C_A1_DEPLOYMENT_OVERCLAIM": "C_A1_OR_DEPLOYMENT_OVERCLAIM",
    "MUT_IGNORE_NEXT_SESSION_AUDIT_BINDING": "NEXT_SESSION_AUDIT_BINDING_MISSING",
    "MUT_ALLOW_DIRTY_CLOSE": "DIRTY_CLOSE",
}

def main() -> int:
    cases = []
    for path in sorted((ROOT / "fixtures" / "cases").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        base = validate(data["packet"])
        cases.append((path.name, data, base))
    rows = ["mutation\ttarget_finding\tflipped_cases\tstatus"]
    missed = 0
    for mut in sorted(MUTATIONS):
        target = TARGET[mut]
        flipped = []
        for name, data, base in cases:
            if target not in base["finding_codes"]:
                continue
            changed = validate(data["packet"], mutations=[mut])
            # A mutation is caught if at least one targeted fixture changes admissibility or drops the target finding.
            if changed["admissible"] != base["admissible"] or target not in changed["finding_codes"]:
                flipped.append(name)
        status = "CAUGHT" if flipped else "MISSED"
        if not flipped:
            missed += 1
        rows.append(f"{mut}\t{target}\t{','.join(flipped[:12])}\t{status}")
    (ROOT / "MUTATION_MATRIX.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"mutations: {len(MUTATIONS)}  CAUGHT: {len(MUTATIONS)-missed}  MISSED: {missed}")
    return 0 if missed == 0 else 1
if __name__ == "__main__":
    raise SystemExit(main())
