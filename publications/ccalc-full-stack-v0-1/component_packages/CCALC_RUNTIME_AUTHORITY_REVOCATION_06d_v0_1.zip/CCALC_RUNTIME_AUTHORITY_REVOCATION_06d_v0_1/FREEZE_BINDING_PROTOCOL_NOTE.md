# Freeze Binding Protocol Note

Files are bound by external SHA256 sidecars and by `SHA256SUMS.txt`.

Do not embed a file's own hash inside that file. Use external sidecars:

```bash
sha256sum exact_file_bytes > filename.sha256
```
