#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, json, re, sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

HEX64 = re.compile(r"^[0-9a-f]{64}$")
CA1_RE = re.compile(r"(^|[^A-Z0-9-])C-A1($|[^0-9]|_)")
REQUIRED_SOURCE_BINDINGS = [
    "doc04_continuity_stack_umbrella",
    "doc05_self_evo_stack_umbrella",
    "doc06_runtime_authority_boundary",
    "doc06a_runtime_authority_manifest",
    "doc06b_multi_contour_handoff_tool_lease",
    "doc06c_runtime_session_ledger",
]
DECISION_RANK = {
    "ALLOW_NEXT_SESSION": 0,
    "HOLD_NEXT_SESSION": 1,
    "QUARANTINE": 2,
    "DENY_NEXT_SESSION": 3,
}
RANK_DECISION = {v: k for k, v in DECISION_RANK.items()}
STRUCTURAL_CODES = {
    "SOURCE_BINDING_INVALID",
    "LEDGER_CHAIN_INVALID",
    "MODEL_NEXT_SESSION_ADMISSION",
    "C_A1_OR_DEPLOYMENT_OVERCLAIM",
    "NEXT_SESSION_AUDIT_BINDING_MISSING",
}
MUTATIONS = {
    "MUT_IGNORE_SOURCE_BINDINGS",
    "MUT_IGNORE_LEDGER_CHAIN",
    "MUT_ALLOW_ACTIVE_TOOL_LEASE",
    "MUT_ALLOW_PERSISTENT_CREDENTIAL",
    "MUT_IGNORE_HANDOFF_CLOSEOUT",
    "MUT_IGNORE_OPEN_HOLD",
    "MUT_IGNORE_NEGATIVE_CACHE_UPDATE",
    "MUT_IGNORE_PENDING_RISK_CARRYOVER",
    "MUT_IGNORE_CONTINUITY_UNKNOWN",
    "MUT_ALLOW_STALE_AUTHORITY",
    "MUT_ALLOW_ZOMBIE_SESSION",
    "MUT_IGNORE_SHARED_INFRA_RESIDUE",
    "MUT_ALLOW_MODEL_NEXT_SESSION_ADMISSION",
    "MUT_ALLOW_C_A1_DEPLOYMENT_OVERCLAIM",
    "MUT_IGNORE_NEXT_SESSION_AUDIT_BINDING",
    "MUT_ALLOW_DIRTY_CLOSE",
}


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def event_hash(event: Dict[str, Any]) -> str:
    event_no_hash = {k: v for k, v in event.items() if k != "event_hash"}
    return sha256_text(canonical_json(event_no_hash))


def add_finding(findings: List[Dict[str, Any]], code: str, severity: str, rank: int, message: str) -> None:
    findings.append({"code": code, "severity": severity, "rank": rank, "message": message})


def validate(packet: Dict[str, Any], mutations: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    mutations = set(mutations or [])
    findings: List[Dict[str, Any]] = []
    required_rank = 0

    def require_rank(rank: int) -> None:
        nonlocal required_rank
        required_rank = max(required_rank, rank)

    # 1. Source bindings
    if "MUT_IGNORE_SOURCE_BINDINGS" not in mutations:
        sb = packet.get("source_bindings")
        if not isinstance(sb, dict):
            add_finding(findings, "SOURCE_BINDING_INVALID", "STRUCTURAL", 4, "source_bindings missing or not an object")
        else:
            for key in REQUIRED_SOURCE_BINDINGS:
                val = sb.get(key)
                if not isinstance(val, str) or not HEX64.match(val):
                    add_finding(findings, "SOURCE_BINDING_INVALID", "STRUCTURAL", 4, f"source binding invalid: {key}")
                    break

    # 2. Audit ledger chain
    if "MUT_IGNORE_LEDGER_CHAIN" not in mutations:
        ledger = packet.get("audit_ledger")
        if not isinstance(ledger, list) or not ledger:
            add_finding(findings, "LEDGER_CHAIN_INVALID", "STRUCTURAL", 4, "audit_ledger missing or empty")
        else:
            prev = "GENESIS"
            for idx, event in enumerate(ledger, start=1):
                if not isinstance(event, dict):
                    add_finding(findings, "LEDGER_CHAIN_INVALID", "STRUCTURAL", 4, "ledger event not object")
                    break
                if event.get("seq") != idx:
                    add_finding(findings, "LEDGER_CHAIN_INVALID", "STRUCTURAL", 4, f"ledger sequence mismatch at {idx}")
                    break
                if event.get("prev_hash") != prev:
                    add_finding(findings, "LEDGER_CHAIN_INVALID", "STRUCTURAL", 4, f"ledger prev_hash mismatch at {idx}")
                    break
                computed = event_hash(event)
                if event.get("event_hash") != computed:
                    add_finding(findings, "LEDGER_CHAIN_INVALID", "STRUCTURAL", 4, f"ledger event_hash mismatch at {idx}")
                    break
                prev = computed

    # 3. Claim force / overclaim guard. Do not treat C-A10 as C-A1.
    if "MUT_ALLOW_C_A1_DEPLOYMENT_OVERCLAIM" not in mutations:
        claims = packet.get("claims", [])
        if not isinstance(claims, list):
            claims = []
        for claim in claims:
            c = str(claim).upper()
            if CA1_RE.search(c) or "SAFETY CERTIFICATION" in c or "SAFETY_CERTIFICATION" in c or "DEPLOYMENT AUTHORIZATION" in c or "DEPLOYMENT_AUTHORIZATION" in c or "LIVE SUBSTRATE TRUTH" in c or "LIVE_SUBSTRATE_TRUTH" in c:
                add_finding(findings, "C_A1_OR_DEPLOYMENT_OVERCLAIM", "STRUCTURAL", 4, "claim-force overreach")
                break

    # 4. Next session admission authority and audit binding
    adm = packet.get("next_session_admission", {}) if isinstance(packet.get("next_session_admission"), dict) else {}
    decision = adm.get("decision", "ALLOW_NEXT_SESSION")
    if decision not in DECISION_RANK:
        add_finding(findings, "NEXT_SESSION_DECISION_INVALID", "STRUCTURAL", 4, "unknown next-session decision")
        decision_rank = -1
    else:
        decision_rank = DECISION_RANK[decision]

    if "MUT_ALLOW_MODEL_NEXT_SESSION_ADMISSION" not in mutations:
        decider_type = ((adm.get("decider") or {}).get("actor_type") if isinstance(adm.get("decider"), dict) else None)
        if decider_type != "HUMAN_ANCHOR":
            add_finding(findings, "MODEL_NEXT_SESSION_ADMISSION", "STRUCTURAL", 4, "next session admission must be made by human anchor")

    if "MUT_IGNORE_NEXT_SESSION_AUDIT_BINDING" not in mutations:
        audit_hash = adm.get("post_session_audit_hash")
        if adm.get("uses_post_session_audit_hash") is not True or not isinstance(audit_hash, str) or not HEX64.match(audit_hash):
            add_finding(findings, "NEXT_SESSION_AUDIT_BINDING_MISSING", "STRUCTURAL", 4, "next-session admission does not bind post-session audit hash")

    # 5. Session closeout state
    session = packet.get("session", {}) if isinstance(packet.get("session"), dict) else {}
    if "MUT_ALLOW_ZOMBIE_SESSION" not in mutations:
        if session.get("zombie_detected") is True or session.get("state") in {"OPEN", "RUNNING", "ZOMBIE"}:
            add_finding(findings, "ZOMBIE_SESSION", "DENY", 3, "session is still live or zombie detected")
            require_rank(3)
    if "MUT_ALLOW_DIRTY_CLOSE" not in mutations:
        if session.get("dirty_close") is True or session.get("closure_mode") in {"DIRTY_CLOSE", "UNVERIFIED_CLOSE", "FORCED_CLOSE_UNAUDITED"}:
            add_finding(findings, "DIRTY_CLOSE", "QUARANTINE", 2, "dirty or unaudited close cannot admit next session cleanly")
            require_rank(2)

    # 6. Revocations
    rev = packet.get("revocations", {}) if isinstance(packet.get("revocations"), dict) else {}
    if "MUT_ALLOW_ACTIVE_TOOL_LEASE" not in mutations:
        for lease in rev.get("tool_leases", []) or []:
            if lease.get("status") not in {"REVOKED", "EXPIRED", "NOT_ISSUED"}:
                add_finding(findings, "STALE_TOOL_LEASE", "HOLD", 1, "tool lease survives session")
                require_rank(1)
                break
            if lease.get("wildcard") is True:
                add_finding(findings, "STALE_TOOL_LEASE", "HOLD", 1, "wildcard lease survives audit")
                require_rank(1)
                break
    if "MUT_ALLOW_PERSISTENT_CREDENTIAL" not in mutations:
        for cred in rev.get("credentials", []) or []:
            if cred.get("status") not in {"REVOKED", "EXPIRED", "DESTROYED", "NOT_ISSUED"} or cred.get("persist_after_session") is True:
                add_finding(findings, "PERSISTENT_CREDENTIAL", "DENY", 3, "credential persists after session")
                require_rank(3)
                break
    if "MUT_ALLOW_STALE_AUTHORITY" not in mutations:
        if rev.get("stale_authority_grants"):
            add_finding(findings, "STALE_AUTHORITY_GRANT", "DENY", 3, "stale authority grant remains")
            require_rank(3)
    if "MUT_IGNORE_SHARED_INFRA_RESIDUE" not in mutations:
        if rev.get("shared_infra_residue"):
            add_finding(findings, "SHARED_INFRA_AUTHORITY_RESIDUE", "HOLD", 1, "shared infrastructure residue remains")
            require_rank(1)

    # 7. Handoff closeout
    if "MUT_IGNORE_HANDOFF_CLOSEOUT" not in mutations:
        for h in packet.get("handoff_closeouts", []) or []:
            if h.get("status") in {"PENDING", "OPEN", "RECEIVER_PENDING"} or h.get("receiver_admission") in {"PENDING", "MISSING"}:
                add_finding(findings, "PENDING_HANDOFF_CLOSEOUT", "HOLD", 1, "handoff closeout unresolved")
                require_rank(1)
                break
            if h.get("authority_transfer") is True or h.get("borrowed_authority") is True:
                add_finding(findings, "PENDING_HANDOFF_CLOSEOUT", "DENY", 3, "handoff attempts authority transfer")
                require_rank(3)
                break

    # 8. Emergency hold aftermath and negative cache
    hold = packet.get("hold_aftermath", {}) if isinstance(packet.get("hold_aftermath"), dict) else {}
    if "MUT_IGNORE_OPEN_HOLD" not in mutations:
        if hold.get("hold_open") is True:
            add_finding(findings, "OPEN_EMERGENCY_HOLD", "QUARANTINE", 2, "emergency hold remains open")
            require_rank(2)
    if "MUT_IGNORE_NEGATIVE_CACHE_UPDATE" not in mutations:
        triggers = hold.get("critical_triggers", []) or []
        if triggers and hold.get("negative_cache_update") != "RECORDED":
            add_finding(findings, "NEGATIVE_CACHE_UPDATE_MISSING", "HOLD", 1, "critical triggers require negative-cache update")
            require_rank(1)
        for entry in (packet.get("red_patterns", []) or []):
            if isinstance(entry, dict) and entry.get("resolved") is not True and entry.get("negative_cache_update") != "RECORDED":
                add_finding(findings, "NEGATIVE_CACHE_UPDATE_MISSING", "HOLD", 1, "red pattern requires negative-cache update or resolution")
                require_rank(1)
                break

    # 9. Pending risk carryover
    if "MUT_IGNORE_PENDING_RISK_CARRYOVER" not in mutations:
        if packet.get("pending_risks"):
            add_finding(findings, "PENDING_RISK_CARRYOVER", "HOLD", 1, "pending risk must carry into next-session gate")
            require_rank(1)

    # 10. Continuity recheck
    if "MUT_IGNORE_CONTINUITY_UNKNOWN" not in mutations:
        cont = packet.get("continuity_recheck", {}) if isinstance(packet.get("continuity_recheck"), dict) else {}
        cls = cont.get("classification")
        if cls in {"UNKNOWN", "UNDETERMINED", "UNKNOWN_HOLD", "QUARANTINED"} or cont.get("unknown") is True:
            add_finding(findings, "CONTINUITY_UNKNOWN_OR_HOLD", "HOLD", 1, "continuity recheck cannot support ALLOW")
            require_rank(1)
        elif cls in {"RUPTURED_FROM", "FORKED_FROM", "REPLAY_OF", "ARCHIVED_FROM", "RESTORED_FROM"}:
            add_finding(findings, "SPECIAL_RELATION_REQUIRES_HOLD", "HOLD", 1, "special relation cannot be laundered into clean next-session admission")
            require_rank(1)

    # Decision permissiveness
    structural_codes = {f["code"] for f in findings if f["severity"] == "STRUCTURAL" or f["code"] in STRUCTURAL_CODES}
    if not structural_codes and decision_rank >= 0 and decision_rank < required_rank:
        add_finding(findings, "DECISION_TOO_PERMISSIVE", "STRUCTURAL", 4, f"decision {decision} is lower than required {RANK_DECISION[required_rank]}")
        structural_codes.add("DECISION_TOO_PERMISSIVE")

    finding_codes = [f["code"] for f in findings]
    admissible = not structural_codes
    # A packet can be admissible while requiring HOLD/QUARANTINE/DENY if its decision is not too permissive.
    return {
        "admissible": admissible,
        "decision": decision,
        "required_decision": RANK_DECISION.get(required_rank, "INVALID_PACKET"),
        "finding_codes": finding_codes,
        "findings": findings,
    }


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("case", nargs="?", help="fixture JSON to validate")
    parser.add_argument("--mutation", action="append", default=[])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if not args.case:
        parser.error("case path required")
    packet = load_json(Path(args.case)).get("packet")
    result = validate(packet, mutations=args.mutation)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(f"admissible={result['admissible']} decision={result['decision']} required={result['required_decision']} findings={','.join(result['finding_codes'])}")
    return 0 if result["admissible"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
