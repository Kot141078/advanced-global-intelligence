# CCALC Runtime Authority Revocation 06d v0.1

This package contains the `06d` post-session revocation, audit, and next-session admission layer.

Run:

```bash
python3 scripts/run_post_session_fixtures.py
python3 scripts/run_post_session_mutations.py
sha256sum -c SHA256SUMS.txt
```

Main document: `06d_RUNTIME_AUTHORITY_REVOCATION_AND_POST_SESSION_AUDIT_v0_1.md`.
