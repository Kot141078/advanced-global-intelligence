# Reading Order

1. `06d_RUNTIME_AUTHORITY_REVOCATION_AND_POST_SESSION_AUDIT_v0_1.md`
2. `registry/DECISION_LATTICE.tsv`
3. `registry/POST_SESSION_RED_PATTERN_REGISTRY.tsv`
4. `schemas/runtime_post_session_audit_packet.schema.json`
5. `src/runtime_authority_revocation_checker_v0_1.py`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `PACKAGE_VERIFICATION_LOG.md`
