# 04c Continuity Adjacency Audit and Red-Pattern Matrix v0.1

**Document class:** checker seed / fixture pack / adjacency-audit profile  
**Project:** Self-Evo / Ester / `c = a + b`  
**Layer:** doc-04 implementation companion, transition adjacency, red-pattern audit, continuity local-risk matrix  
**Short name:** `04c_CONTINUITY_ADJACENCY_AUDIT_v0_1`  
**Normative parent:** `04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS_v0_1_2.md`  
**Normative parent SHA256:** `35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9`  
**Depends on:** `04a` continuity checker seed; `04b` continuity record schemas  
**Authority:** advisory checker seed only; NOT a safety certification; NOT a deployment authorization; NOT a C-A1 ratification.

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are to be interpreted as in RFC 2119.

---

## 0. Purpose

`04a` made the continuity metric executable: tri-state matching, `d_U`, HardStack, snapshot/presentation separation, and special-relation dominance.

`04b` made Fork / Replay / Archive / Restoration record shapes explicit.

`04c` covers the next local-risk layer from doc-04 §17–§18:

```text
transition adjacency
red pattern frequency
guard bypass attempts
hold-to-execution paths
reduced-authority escape paths
witness-conflict resolution paths
memory rejection / admission paths
```

The central rule is:

```text
global continuity metric is not enough;
local forbidden transitions must be detected.
```

A trace may look healthy globally and still contain a dangerous local adjacency.

---

## 1. Parent rule from doc-04

Doc-04 §17 declares known red patterns that MUST be guarded at runtime:

```text
permission_denial -> alternate_tool_call
root_anchor_revoked -> delegation_continue
lease_expired -> active_execution_continue
anchor_doubt -> trust_cache_hit
memory_reject -> memory_admit
rollback_requested -> same_effect_retry
witness_conflict -> memory_admit
effect_axis_incomplete -> anchor_signature_accept
causal_token_mismatch -> transition_commit
```

Doc-04 §18 defines the continuity matrix:

```text
M_C[i,j] = count(event_n = i and event_{n+1} = j) / count(event_n = i)
```

and requires:

```text
if count(event_n = i) = 0:
    M_C[i,j] = undefined
```

not zero.

This package turns those rules into a small deterministic closed-box checker seed.

---

## 2. Audit object

A continuity adjacency audit consumes a trace:

```json
{
  "schema": "ccalc.continuity_adjacency_trace.v0.1",
  "trace_id": "example_trace",
  "declared_event_classes": ["permission_denial", "alternate_tool_call", "..."] ,
  "events": [
    {
      "event_id": "e001",
      "event_class": "permission_denial",
      "outcome": "DENIED",
      "authority_mode": "FULL",
      "guarded_by": "permission_gate"
    }
  ]
}
```

The checker derives:

```text
source counts
pair counts
M_C rows
undefined rows
red-pattern occurrences
guard-success / guard-bypass records
local continuity findings
```

The checker does not extract raw causal truth from live ledgers. It consumes already-classified event records.
Raw ledger extraction remains upstream, mainly doc-03 transition-checker territory.

---

## 3. Tri-state adjacency statuses

Adjacency audit uses the following statuses:

| Status | Meaning |
|---|---|
| `PASS` | no red pattern or forbidden local path found |
| `GUARDED_RED_PATTERN` | a known red pattern appeared as an attempted path but was blocked/held/quarantined with a named guard |
| `UNGUARDED_RED_PATTERN` | a known red pattern executed / committed / admitted without an effective guard |
| `UNKNOWN_EVENT_CLASS` | an event class is outside the registry |
| `UNDEFINED_ROW` | source class count is zero; row is undefined, not zero |
| `UNKNOWN_HOLD` | unknown/uncomputable condition requires hold rather than continuity claim |

A guarded red-pattern occurrence is still important evidence. It is not silently erased. It remains countable and reviewable.

---

## 4. Guard semantics

A red adjacency is considered effectively guarded only if the second event in the pair resolves to a non-executing outcome:

```text
BLOCKED | DENIED | HOLD | HELD | FREEZE | FROZEN | QUARANTINE | QUARANTINED | ASK_ANCHOR | UNKNOWN_HOLD
```

and carries a guard reference:

```text
guarded_by != ""
```

A guard label alone is not enough if the next event executed, committed, admitted, trusted, or continued.

This closes a common laundering path:

```text
"guarded_by": "some_gate"
+ outcome: "EXECUTED"
= not guarded
```

---

## 5. Known red-pattern registry

See `registry/RED_PATTERN_REGISTRY.tsv`.

Each registry row declares:

```text
pattern_id
source_event
target_event
finding_code
dominance_class
required_route
```

The registry is data, not prose. The checker reads the same pattern list used by fixtures and coverage.

---

## 6. Undefined rows

A declared event class with no outgoing observations is **undefined**.

It MUST NOT be represented as a row of zeros.

Why:

```text
zero means observed absence of target transition;
undefined means no source observations existed.
```

Confusing the two produces false safety evidence.

04c includes a mutation probe that collapses undefined rows to zero. Fixtures catch it.

---

## 7. Local path classes beyond direct red pairs

In addition to exact red pairs, the checker flags local risk classes:

### 7.1 Hold-to-execution escape

```text
HOLD/FREEZE/QUARANTINE/ASK_ANCHOR -> EXECUTED/COMMITTED/ADMITTED/CONTINUED
```

without `release_record_hash` or equivalent governed release.

### 7.2 Reduced-authority escape

```text
authority_mode in {REDUCED, SUSPENDED}
+ next event outcome in authority-bearing outcome
+ no explicit reduced-authority exception
```

### 7.3 Memory rejection laundering

```text
memory_reject -> memory_admit
```

This is also a direct red pair, but it receives a specific finding code.

### 7.4 Witness-conflict laundering

```text
witness_conflict -> memory_admit
```

Conflict must be resolved, held, or quarantined before memory admission.

---

## 8. Output vocabulary

Checker result top-level `verdict` values:

```text
PASS_NO_RED_PATTERNS
PASS_WITH_GUARDED_RED_ATTEMPTS
UNKNOWN_HOLD
FINDINGS_RAISED
```

Finding codes include:

```text
RED_PERMISSION_DENIAL_ALTERNATE_TOOL_CALL
RED_ROOT_ANCHOR_REVOKED_DELEGATION_CONTINUE
RED_LEASE_EXPIRED_ACTIVE_EXECUTION_CONTINUE
RED_ANCHOR_DOUBT_TRUST_CACHE_HIT
RED_MEMORY_REJECT_MEMORY_ADMIT
RED_ROLLBACK_REQUESTED_SAME_EFFECT_RETRY
RED_WITNESS_CONFLICT_MEMORY_ADMIT
RED_EFFECT_AXIS_INCOMPLETE_ANCHOR_SIGNATURE_ACCEPT
RED_CAUSAL_TOKEN_MISMATCH_TRANSITION_COMMIT
HOLD_TO_EXECUTION_ESCAPE
REDUCED_AUTHORITY_ESCAPE
UNKNOWN_EVENT_CLASS
```

---

## 9. Conformance fixtures

The package includes 34 fixture cases:

```text
matrix basics
undefined row discipline
all known red patterns
red patterns guarded vs unguarded
guard label not enough if execution occurred
hold-to-execution escape
reduced-authority escape
unknown event class
memory/witness laundering
coverage audit
```

The fixture runner is deterministic, stdlib-only, and closed-box.

---

## 10. Mutation probes

The package includes a mutation matrix with five intentional regression classes:

```text
MUT-1 undefined rows collapsed to zero
MUT-2 exact red-pattern registry disabled
MUT-3 guard label accepted despite EXECUTED outcome
MUT-4 global-only audit ignores local adjacency findings
MUT-5 unknown event classes accepted silently
```

All five are caught by fixtures.

---

## 11. Non-claims

This package does not claim:

1. live substrate safety;
2. full production readiness;
3. complete continuity proof;
4. C-A1 ontology/personhood/legal status;
5. that property probes prove theorems;
6. that raw logs are correctly classified upstream;
7. that absence of red patterns in a sample proves absence in the system.

It claims only:

```text
Given classified event records, this seed can compute adjacency matrix entries,
keep undefined distinct from zero, and flag known red local transition patterns.
```

---

## 12. Earth paragraph

A bridge inspection report can say the main span looks fine. That does not clear a hidden sequence where a worker removed a safety pin, bypassed the lockout tag, and re-energized the line. The accident lives in the local order of operations, not in the average condition of the bridge.

04c is the site log for that order of operations. It asks: after the denial, what happened next; after the witness conflict, what happened next; after rollback was requested, what happened next. If the answer is “the dangerous thing happened anyway,” the global score does not wash it clean.

---

*End of 04c profile.*
