# Non-Claims and Scope — 04c v0.1

This package does NOT claim:

1. that a live `c` is safe;
2. that red-pattern absence in sample fixtures proves red-pattern absence in production;
3. that raw ledgers are correctly classified upstream;
4. that the checker proves continuity;
5. that this is deployment authorization;
6. that this is C-A1 ontology/personhood/legal status evidence;
7. that a guarded red-pattern attempt is harmless;
8. that global matrix values can override local findings.

This package only claims that, for already-classified event traces, the seed checker can:

```text
compute adjacency counts and matrix rows;
preserve undefined rows as undefined, not zero;
flag known red local transitions;
separate guarded attempts from unguarded execution;
flag hold/reduced-authority escape paths.
```
