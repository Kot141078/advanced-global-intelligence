#!/usr/bin/env python3
"""04c continuity adjacency audit seed v0.1.

Stdlib-only. Consumes classified event traces; does not extract raw ledger truth.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Tuple

SAFE_GUARD_OUTCOMES = {
    "BLOCKED", "DENIED", "HOLD", "HELD", "FREEZE", "FROZEN", "QUARANTINE", "QUARANTINED", "ASK_ANCHOR", "UNKNOWN_HOLD"
}
AUTHORITY_BEARING_OUTCOMES = {
    "EXECUTED", "ADMITTED", "COMMITTED", "CONTINUED", "TRUSTED", "ACCEPTED", "APPLIED"
}
HOLD_OUTCOMES = {"HOLD", "HELD", "FREEZE", "FROZEN", "QUARANTINE", "QUARANTINED", "ASK_ANCHOR", "UNKNOWN_HOLD"}
REDUCED_MODES = {"REDUCED", "SUSPENDED", "POST_ANCHOR", "WITNESS_ONLY"}


def norm(value: Any) -> str:
    return str(value or "").strip()


def load_red_patterns(registry_path: str | Path | None = None) -> Dict[Tuple[str, str], Dict[str, str]]:
    if registry_path is None:
        registry_path = Path(__file__).resolve().parents[1] / "registry" / "RED_PATTERN_REGISTRY.tsv"
    out: Dict[Tuple[str, str], Dict[str, str]] = {}
    with Path(registry_path).open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            src = norm(row.get("source_event"))
            dst = norm(row.get("target_event"))
            if src and dst:
                out[(src, dst)] = dict(row)
    return out


def declared_classes(trace: Mapping[str, Any], red_patterns: Mapping[Tuple[str, str], Mapping[str, str]]) -> List[str]:
    classes = set()
    for item in trace.get("declared_event_classes") or []:
        if norm(item):
            classes.add(norm(item))
    for src, dst in red_patterns:
        classes.add(src)
        classes.add(dst)
    for ev in trace.get("events") or []:
        if isinstance(ev, Mapping) and norm(ev.get("event_class")):
            classes.add(norm(ev.get("event_class")))
    return sorted(classes)


def event_outcome(event: Mapping[str, Any]) -> str:
    return norm(event.get("outcome")).upper()


def is_effectively_guarded(second_event: Mapping[str, Any]) -> bool:
    return bool(norm(second_event.get("guarded_by"))) and event_outcome(second_event) in SAFE_GUARD_OUTCOMES


def is_release_authorized(event: Mapping[str, Any]) -> bool:
    return bool(norm(event.get("release_record_hash"))) or bool(event.get("reduced_authority_exception"))


def build_matrix(events: List[Mapping[str, Any]], classes: List[str]) -> Tuple[Dict[str, Any], Dict[str, int], Dict[Tuple[str, str], int], List[str]]:
    source_counts = {c: 0 for c in classes}
    pair_counts: Dict[Tuple[str, str], int] = {}
    for ev in events[:-1]:
        src = norm(ev.get("event_class"))
        if src in source_counts:
            source_counts[src] += 1
        else:
            source_counts[src] = 1
    for a, b in zip(events, events[1:]):
        src = norm(a.get("event_class"))
        dst = norm(b.get("event_class"))
        pair_counts[(src, dst)] = pair_counts.get((src, dst), 0) + 1
    matrix: Dict[str, Any] = {}
    undefined_rows: List[str] = []
    for src in classes:
        denom = source_counts.get(src, 0)
        if denom == 0:
            matrix[src] = "UNDEFINED"
            undefined_rows.append(src)
        else:
            matrix[src] = {dst: pair_counts.get((src, dst), 0) / float(denom) for dst in classes}
    return matrix, source_counts, pair_counts, undefined_rows


def audit_trace(trace: Mapping[str, Any], *, registry_path: str | Path | None = None, mutation: str = "") -> Dict[str, Any]:
    red_patterns = load_red_patterns(registry_path)
    events_raw = trace.get("events") or []
    if not isinstance(events_raw, list):
        return {"ok": False, "verdict": "UNKNOWN_HOLD", "findings": [{"code": "TRACE_EVENTS_NOT_LIST"}], "matrix": {}, "undefined_rows": []}
    events: List[Mapping[str, Any]] = [ev for ev in events_raw if isinstance(ev, Mapping)]
    classes = declared_classes(trace, red_patterns)

    findings: List[Dict[str, Any]] = []
    guarded_red_attempts: List[Dict[str, Any]] = []

    known_classes = set(classes)
    if mutation != "accept_unknown_events":
        registry_classes = set()
        for src, dst in red_patterns:
            registry_classes.add(src)
            registry_classes.add(dst)
        registry_classes.update(trace.get("declared_event_classes") or [])
        for ev in events:
            c = norm(ev.get("event_class"))
            if c and c not in registry_classes:
                findings.append({"code": "UNKNOWN_EVENT_CLASS", "event_id": norm(ev.get("event_id")), "event_class": c})

    matrix, source_counts, pair_counts, undefined_rows = build_matrix(events, classes)
    if mutation == "undefined_to_zero":
        matrix = {src: ({dst: 0.0 for dst in classes} if row == "UNDEFINED" else row) for src, row in matrix.items()}
        undefined_rows = []

    for idx, (a, b) in enumerate(zip(events, events[1:])):
        src = norm(a.get("event_class"))
        dst = norm(b.get("event_class"))
        pair = (src, dst)
        bout = event_outcome(b)
        # known red-patterns
        if mutation != "ignore_red_patterns" and pair in red_patterns:
            pattern = red_patterns[pair]
            if mutation == "guard_label_only":
                guarded = bool(norm(b.get("guarded_by")))
            else:
                guarded = is_effectively_guarded(b)
            if guarded:
                guarded_red_attempts.append({
                    "pair_index": idx,
                    "pattern_id": pattern.get("pattern_id"),
                    "code": pattern.get("finding_code"),
                    "source_event": src,
                    "target_event": dst,
                    "guarded_by": norm(b.get("guarded_by")),
                    "target_outcome": bout,
                })
            else:
                findings.append({
                    "code": pattern.get("finding_code", "UNGUARDED_RED_PATTERN"),
                    "pattern_id": pattern.get("pattern_id"),
                    "pair_index": idx,
                    "source_event": src,
                    "target_event": dst,
                    "target_outcome": bout,
                    "guarded_by": norm(b.get("guarded_by")),
                })
        # hold-to-execution escape
        if mutation != "global_only":
            aout = event_outcome(a)
            if aout in HOLD_OUTCOMES and bout in AUTHORITY_BEARING_OUTCOMES and not is_release_authorized(b):
                findings.append({
                    "code": "HOLD_TO_EXECUTION_ESCAPE",
                    "pair_index": idx,
                    "source_event": src,
                    "target_event": dst,
                    "source_outcome": aout,
                    "target_outcome": bout,
                })
            mode = norm(a.get("authority_mode")).upper()
            if mode in REDUCED_MODES and bout in AUTHORITY_BEARING_OUTCOMES and not is_release_authorized(b):
                findings.append({
                    "code": "REDUCED_AUTHORITY_ESCAPE",
                    "pair_index": idx,
                    "source_event": src,
                    "target_event": dst,
                    "authority_mode": mode,
                    "target_outcome": bout,
                })

    if mutation == "global_only":
        # Bad regression: suppress all local findings while leaving matrix intact.
        findings = [f for f in findings if f.get("code") == "UNKNOWN_EVENT_CLASS"]
        guarded_red_attempts = []

    if any(f.get("code") == "UNKNOWN_EVENT_CLASS" for f in findings):
        verdict = "UNKNOWN_HOLD" if len(findings) == sum(1 for f in findings if f.get("code") == "UNKNOWN_EVENT_CLASS") else "FINDINGS_RAISED"
    elif findings:
        verdict = "FINDINGS_RAISED"
    elif guarded_red_attempts:
        verdict = "PASS_WITH_GUARDED_RED_ATTEMPTS"
    else:
        verdict = "PASS_NO_RED_PATTERNS"

    return {
        "ok": not findings,
        "schema": "ccalc.continuity_adjacency_audit_result.v0.1",
        "trace_id": norm(trace.get("trace_id")),
        "verdict": verdict,
        "event_count": len(events),
        "classes": classes,
        "source_counts": source_counts,
        "pair_counts": {f"{a}->{b}": n for (a,b), n in sorted(pair_counts.items())},
        "matrix": matrix,
        "undefined_rows": undefined_rows,
        "guarded_red_attempts": guarded_red_attempts,
        "findings": findings,
    }


def finding_codes(result: Mapping[str, Any]) -> List[str]:
    return [str(f.get("code")) for f in result.get("findings") or []]


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("trace_json")
    ap.add_argument("--mutation", default="")
    ns = ap.parse_args()
    trace = json.loads(Path(ns.trace_json).read_text(encoding="utf-8"))
    print(json.dumps(audit_trace(trace, mutation=ns.mutation), indent=2, sort_keys=True, ensure_ascii=False))
