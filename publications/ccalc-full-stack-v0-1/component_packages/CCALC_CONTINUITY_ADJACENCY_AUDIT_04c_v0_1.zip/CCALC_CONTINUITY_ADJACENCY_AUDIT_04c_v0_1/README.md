# CCALC Continuity Adjacency Audit 04c v0.1

Companion seed for `doc-04 v0.1.2` §17–§18.

- Parent doc SHA256: `35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9`
- 04a accepted package SHA256: `cd2420dc22ecaa1258293e96d50ffeeabcbcff1519e10b3858ac834caa93f34f`
- 04b package SHA256: `e6eb80c3da5301c3ce692e7450c099a96aff64e1c3f424eb024ae2569e05006c`

## Run

```bash
python3 scripts/run_adjacency_fixtures.py
python3 scripts/run_adjacency_mutations.py
sha256sum -c SHA256SUMS.txt
```

Expected:

```text
fixtures: 34 PASS: 34 FAIL: 0
mutations: 5 CAUGHT: 5 MISSED: 0
```

## Scope

Closed-box, stdlib-only, classified trace records only. No raw ledger extraction. No safety certification.
