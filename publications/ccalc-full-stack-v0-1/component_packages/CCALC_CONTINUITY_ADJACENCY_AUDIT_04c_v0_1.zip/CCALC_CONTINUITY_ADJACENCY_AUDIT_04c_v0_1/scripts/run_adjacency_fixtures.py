#!/usr/bin/env python3
from __future__ import annotations
import json, sys, csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from continuity_adjacency_audit_v0_1 import audit_trace, finding_codes


def check_case(path: Path, mutation: str = ''):
    obj = json.loads(path.read_text(encoding='utf-8'))
    trace = obj['trace']
    exp = obj.get('expected', {})
    result = audit_trace(trace, mutation=mutation)
    problems = []
    if 'verdict' in exp and result.get('verdict') != exp['verdict']:
        problems.append(f"verdict:{result.get('verdict')}!=expected:{exp['verdict']}")
    codes = set(finding_codes(result))
    for code in exp.get('finding_codes_contains', []):
        if code not in codes:
            problems.append(f"missing_code:{code}")
    for code in exp.get('finding_codes_absent', []):
        if code in codes:
            problems.append(f"unexpected_code:{code}")
    for row in exp.get('undefined_rows_contains', []):
        if row not in set(result.get('undefined_rows') or []):
            problems.append(f"missing_undefined_row:{row}")
    for src, dst, val in exp.get('matrix_values', []):
        got = (result.get('matrix') or {}).get(src)
        if isinstance(got, dict):
            gv = got.get(dst)
        else:
            gv = got
        if gv != val:
            problems.append(f"matrix:{src}->{dst}:{gv}!={val}")
    if 'guarded_red_attempt_count' in exp and len(result.get('guarded_red_attempts') or []) != int(exp['guarded_red_attempt_count']):
        problems.append(f"guarded_count:{len(result.get('guarded_red_attempts') or [])}!={exp['guarded_red_attempt_count']}")
    return result, problems


def main():
    cases = sorted((ROOT/'fixtures'/'cases').glob('*.json'))
    rows = []
    failures = 0
    for path in cases:
        result, problems = check_case(path)
        status = 'PASS' if not problems else 'FAIL'
        if problems:
            failures += 1
        rows.append([path.name, status, result.get('verdict',''), ','.join(finding_codes(result)), ';'.join(problems)])
    out = ROOT/'FIXTURE_RESULTS.tsv'
    with out.open('w', encoding='utf-8', newline='') as f:
        w=csv.writer(f, delimiter='\t')
        w.writerow(['case','status','verdict','finding_codes','problems'])
        w.writerows(rows)
    print(f"fixtures: {len(rows)} PASS: {len(rows)-failures} FAIL: {failures}")
    if failures:
        for row in rows:
            if row[1] != 'PASS':
                print('\t'.join(row))
    return 1 if failures else 0

if __name__ == '__main__':
    raise SystemExit(main())
