#!/usr/bin/env python3
from __future__ import annotations
import csv, sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from continuity_adjacency_audit_v0_1 import audit_trace, finding_codes

MUTATIONS = [
    ('MUT-1', 'undefined_to_zero', 'undefined rows collapsed to zero', '020_undefined_row_not_zero.json', 'missing_undefined_row'),
    ('MUT-2', 'ignore_red_patterns', 'exact red-pattern registry disabled', '030_red_permission_denial_alternate_tool_call.json', 'missing_code:RED_PERMISSION_DENIAL_ALTERNATE_TOOL_CALL'),
    ('MUT-3', 'guard_label_only', 'guard label accepted despite EXECUTED outcome', '041_guard_label_not_enough_if_executed.json', 'missing_code:RED_PERMISSION_DENIAL_ALTERNATE_TOOL_CALL'),
    ('MUT-4', 'global_only', 'global-only audit ignores local adjacency findings', '034_red_memory_reject_memory_admit.json', 'missing_code:RED_MEMORY_REJECT_MEMORY_ADMIT'),
    ('MUT-5', 'accept_unknown_events', 'unknown event classes accepted silently', '060_unknown_event_class_hold.json', 'verdict:PASS_NO_RED_PATTERNS!=expected:UNKNOWN_HOLD'),
]

def expected_problems(case_path, result, exp):
    problems=[]
    if 'verdict' in exp and result.get('verdict') != exp['verdict']:
        problems.append(f"verdict:{result.get('verdict')}!=expected:{exp['verdict']}")
    codes=set(finding_codes(result))
    for code in exp.get('finding_codes_contains', []):
        if code not in codes:
            problems.append(f"missing_code:{code}")
    for row in exp.get('undefined_rows_contains', []):
        if row not in set(result.get('undefined_rows') or []):
            problems.append(f"missing_undefined_row:{row}")
    return problems

rows=[]
for mid, mutation, desc, case_name, expected_marker in MUTATIONS:
    case_path=ROOT/'fixtures'/'cases'/case_name
    obj=json.loads(case_path.read_text(encoding='utf-8'))
    result=audit_trace(obj['trace'], mutation=mutation)
    problems=expected_problems(case_path, result, obj['expected'])
    caught=bool(problems)
    rows.append([mid, mutation, desc, case_name, 'CAUGHT' if caught else 'MISSED', ';'.join(problems), expected_marker])

with (ROOT/'MUTATION_MATRIX.tsv').open('w', encoding='utf-8', newline='') as f:
    w=csv.writer(f, delimiter='\t')
    w.writerow(['mutation_id','mutation','description','case','result','observed_problem','expected_marker'])
    w.writerows(rows)
print(f"mutations: {len(rows)} CAUGHT: {sum(1 for r in rows if r[4]=='CAUGHT')} MISSED: {sum(1 for r in rows if r[4]=='MISSED')}")
raise SystemExit(0 if all(r[4]=='CAUGHT' for r in rows) else 1)
