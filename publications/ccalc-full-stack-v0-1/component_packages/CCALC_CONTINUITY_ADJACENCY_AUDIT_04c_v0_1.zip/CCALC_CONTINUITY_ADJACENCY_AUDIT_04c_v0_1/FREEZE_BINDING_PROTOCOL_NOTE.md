# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each package file:

```text
sha256sum exact_file_bytes > filename.sha256
```

The file itself does not mutate to include its own hash. This avoids self-referential instability.
