# Execution Log — 04c v0.1

Created: 2026-07-03T18:53:10.398055+00:00

## Fixture run

Command:

```bash
python3 scripts/run_adjacency_fixtures.py
```

Return code: `0`

Stdout:

```text
fixtures: 34 PASS: 34 FAIL: 0
```

Stderr:

```text

```

## Mutation run

Command:

```bash
python3 scripts/run_adjacency_mutations.py
```

Return code: `0`

Stdout:

```text
mutations: 5 CAUGHT: 5 MISSED: 0
```

Stderr:

```text

```

## Seal note

Sidecars are outside `fixtures/cases/`; the runner only reads `*.json` fixture cases.
