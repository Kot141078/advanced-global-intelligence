# CCALC checker v2.3 final known-class conformance sweep v1.0

This package records a final sweep of `c-calculus-checker v2.3` against the accumulated known-class vocabulary.

Files:

- `FINAL_SWEEP_REPORT_v1_0.md` — human-readable summary and scope boundary.
- `FINAL_SWEEP_MATRIX.json` — machine-readable mechanism × class matrix.
- `MECHANISM_CLASS_MATRIX.tsv` — tabular matrix.
- `CHECKER_MECHANISM_INDEX.tsv` — implemented mechanism index.
- `FIXTURE_COVERAGE.tsv` — fixture expected/actual/status table.
- `ERROR_CLASS_COVERAGE.tsv` — finding-code coverage summary.
- `NON_CLAIMS_AND_SCOPE.md` — explicit non-claims.
- `SHA256SUMS.txt` — package hashes.

Legend for matrix cells:

- `C` — covered by seed fixture/error evidence.
- `NA` — not applicable to the mechanism.
- `OOS` — out of checker scope.
- `P` — partial/local coverage.
- `R` — review-backed but not standalone fixture in this package.
