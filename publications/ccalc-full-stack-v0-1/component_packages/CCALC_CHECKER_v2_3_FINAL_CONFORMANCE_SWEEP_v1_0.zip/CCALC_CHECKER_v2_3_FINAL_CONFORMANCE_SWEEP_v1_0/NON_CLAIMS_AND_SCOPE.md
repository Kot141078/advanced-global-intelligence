# Non-claims and scope boundary

This final sweep does **not** claim:

1. that `c-calculus-checker v2.3` is correct, complete, or proven;
2. that passing fixtures implies safety against a real adversarial substrate;
3. that any live system satisfies the spec;
4. that viewport/review-binding is fully implemented as a production display/review subsystem;
5. that the checker can decide personhood, consciousness, or legal status;
6. that the external c-criterion is solved in code.

It claims only this: within the implemented checker surface, the accumulated known-class vocabulary has been mapped to mechanisms and current fixture evidence passes.
