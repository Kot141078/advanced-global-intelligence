# Freeze Binding Protocol Note

Hashes are external sidecars and package manifests. Do not embed a self-referential hash inside a Markdown file that changes the bytes being hashed.

Use exact-file-byte SHA-256 sidecars:

```bash
sha256sum <file> > <file>.sha256
```
