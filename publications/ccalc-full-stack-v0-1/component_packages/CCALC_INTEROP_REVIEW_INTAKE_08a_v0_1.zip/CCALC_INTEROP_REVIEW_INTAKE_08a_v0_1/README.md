# CCALC_INTEROP_REVIEW_INTAKE_08a_v0_1

`08a` provides the external review intake schema and checker seed for the interoperability boundary defined by `08`.

Run:

```bash
python3 scripts/run_interop_fixtures.py
python3 scripts/run_interop_mutations.py
sha256sum -c SHA256SUMS.txt
```

Main document: `08a_INTEROP_REVIEW_INTAKE_SCHEMA_AND_CHECKER_SEED_v0_1.md`
