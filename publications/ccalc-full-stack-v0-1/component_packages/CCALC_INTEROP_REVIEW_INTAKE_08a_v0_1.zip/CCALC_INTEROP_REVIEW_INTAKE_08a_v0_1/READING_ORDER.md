# Reading Order — 08a

1. `08a_INTEROP_REVIEW_INTAKE_SCHEMA_AND_CHECKER_SEED_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `registry/*.tsv`
4. `schemas/*.schema.json`
5. `src/interop_review_intake_checker_v0_1.py`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
