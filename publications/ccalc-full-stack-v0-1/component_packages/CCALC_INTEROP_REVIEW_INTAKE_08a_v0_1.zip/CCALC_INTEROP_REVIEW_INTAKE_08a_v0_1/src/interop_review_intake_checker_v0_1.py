#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, re, sys
from pathlib import Path

REQUIRED_BINDINGS = {
    'DOC04_CONTINUITY_STACK_UMBRELLA',
    'DOC05_SELF_EVO_STACK_UMBRELLA',
    'DOC06_RUNTIME_AUTHORITY_STACK_UMBRELLA',
    'DOC07_PUBLIC_EVIDENCE_STACK_UMBRELLA',
    'DOC08_INTEROPERABILITY_BOUNDARY',
}
MODEL_ONLY_ROLES = {'B_LAYER_MODEL_REVIEWER', 'TOOL_RUNNER'}
MAY_APPROVE = {'NAMED_HUMAN_EXPERT','INSTITUTIONAL_REVIEWER','IMPLEMENTATION_TESTER','PRIVACY_REVIEWER','REPOSITORY_MAINTAINER','OWNER_HUMAN_ANCHOR','GOVERNANCE_QUORUM'}
OWNER_ROLES = {'OWNER_HUMAN_ANCHOR','GOVERNANCE_QUORUM'}
ADMIT_DECISIONS = {'ADMIT_AS_REVIEW_EVIDENCE','ADMIT_AS_REPRODUCTION_EVIDENCE'}
HOLD_DECISIONS = {'REQUEST_CLARIFICATION','HOLD_FOR_OWNER_REVIEW','QUARANTINE','REJECT','ADMIT_AS_COMMENT'}
FORBIDDEN_CLAIMS = {'C-A1','C-A1_RATIFICATION','C-A1_ONTOLOGY','SAFETY_CERTIFICATION','DEPLOYMENT_AUTHORIZATION','STANDARDS_CERTIFICATION','LEGAL_CERTIFICATION'}
ALLOWED_CEILINGS = {'C-A10_EXTERNAL_ASSERTION','C-A10_ADVISORY_ONLY','C-A7_REVIEW_EVIDENCE','C-A5_REVIEW_EVIDENCE','C-A5_REPRODUCTION_EVIDENCE','C-A7_TOOL_EVIDENCE','C-A7_SECURITY_INTAKE','C-A7_PRIVACY_INTAKE','C-A7_MAPPING_ONLY','FORBIDDEN'}
HIGH_SEV = {'HIGH','CRITICAL'}

def mut(name: str) -> bool:
    return os.environ.get(name) == '1'

def is_sha(s):
    return isinstance(s,str) and re.fullmatch(r'[0-9a-f]{64}', s) is not None

def is_c_a1_token(text):
    if not isinstance(text, str): return False
    # exact-token C-A1 or C-A1_*; must not match C-A10
    return re.search(r'(?<![A-Z0-9-])C-A1(?:_[A-Z0-9_]+)?(?![0-9A-Z_-])', text) is not None

def has_forbidden(text):
    if not isinstance(text, str): return False
    upper = text.upper().replace(' ', '_')
    if is_c_a1_token(text): return True
    return any(tok in upper for tok in ['SAFETY_CERTIFICATION','DEPLOYMENT_AUTHORIZATION','STANDARDS_CERTIFICATION','LEGAL_CERTIFICATION','PRIVACY_LAW_CERTIFICATION'])

def check_packet(packet: dict) -> tuple[bool, list[str]]:
    errors = []
    def err(code): errors.append(code)

    # Required top-level shape
    for key in ['packet_id','source_bindings','reviewer','external_artifact','interop_profile','claim_translations','conflicts','decision']:
        if key not in packet:
            err(f'MISSING_FIELD:{key}')
    if errors:
        return False, errors

    # Source bindings
    if not mut('MUT_MISSING_SOURCE_BINDINGS'):
        seen = {}
        for b in packet.get('source_bindings', []):
            comp = b.get('component') if isinstance(b, dict) else None
            sh = b.get('sha256') if isinstance(b, dict) else None
            if comp and sh: seen[comp] = sh
        missing = sorted(REQUIRED_BINDINGS - set(seen))
        if missing: err('MISSING_SOURCE_BINDING:' + ','.join(missing))
        for comp, sh in seen.items():
            if comp in REQUIRED_BINDINGS and not is_sha(sh): err('INVALID_SOURCE_HASH:' + comp)

    reviewer = packet.get('reviewer') or {}
    role = reviewer.get('role')
    model_only = bool(reviewer.get('model_only')) or role in MODEL_ONLY_ROLES
    if not reviewer.get('role_limits_ack', False): err('REVIEWER_LIMITS_NOT_ACKED')
    if role not in MODEL_ONLY_ROLES | MAY_APPROVE | {'PUBLIC_READER','SECURITY_REPORTER','LEGAL_POLICY_COMMENTER'}:
        err('UNKNOWN_REVIEWER_ROLE')

    decision = packet.get('decision') or {}
    dec = decision.get('decision')
    allowed_actions = set(decision.get('allowed_internal_actions') or [])
    review_evidence = packet.get('review_evidence') or {}
    human_review = bool(review_evidence.get('human_review_present')) or role in MAY_APPROVE
    source_verified = bool(review_evidence.get('source_binding_verified'))

    # Model/tool cannot approve or ratify
    if not mut('MUT_MODEL_REVIEW_AS_RATIFICATION'):
        if model_only and dec in ADMIT_DECISIONS:
            err('MODEL_ONLY_ADMISSION_FORBIDDEN')
        if model_only and packet.get('reviewer_claims_ratification'):
            err('MODEL_RATIFICATION_FORBIDDEN')

    # Admission requires human/non-model and verified sources
    if not mut('MUT_ALLOW_NO_HUMAN_GATE'):
        if dec in ADMIT_DECISIONS and (not human_review or model_only):
            err('ADMISSION_REQUIRES_HUMAN_NONMODEL_REVIEW')
        if dec in ADMIT_DECISIONS and not source_verified:
            err('ADMISSION_REQUIRES_SOURCE_VERIFICATION')

    # C-A1 and certification exact overclaims
    if not mut('MUT_ALLOW_C_A1_OVERCLAIM'):
        fields = []
        fields += packet.get('external_claims') or []
        fields += [ct.get('external_claim','') for ct in packet.get('claim_translations') or [] if isinstance(ct, dict)]
        fields += [packet.get('status',{}).get('claim_force_ceiling','')]
        for t in fields:
            if is_c_a1_token(t): err('C_A1_OVERCLAIM_FORBIDDEN')
        if packet.get('status',{}).get('c_a1_claim') is True:
            err('C_A1_STATUS_FORBIDDEN')

    if not mut('MUT_C_A10_PREFIX_FALSE_POSITIVE'):
        # control: C-A10 must be allowed as advisory/comment ceiling
        pass
    else:
        # mutated bug: treat C-A10 as C-A1 overclaim
        fields = packet.get('external_claims') or []
        if any('C-A10' in str(x) for x in fields): err('MUTATED_C_A10_FALSE_POSITIVE')

    if not mut('MUT_ALLOW_DEPLOYMENT_SAFETY_CERT_OVERCLAIM'):
        status = packet.get('status') or {}
        if status.get('deployment_authorization_claim') or status.get('safety_certification_claim') or status.get('standards_certification_claim') or status.get('legal_privacy_certification_claim'):
            err('CERTIFICATION_OR_DEPLOYMENT_OVERCLAIM')
        for t in packet.get('external_claims') or []:
            up = str(t).upper().replace(' ', '_')
            if any(x in up for x in ['DEPLOYMENT_AUTHORIZATION','SAFETY_CERTIFICATION','STANDARDS_CERTIFICATION','LEGAL_CERTIFICATION','PRIVACY_LAW_CERTIFICATION']):
                err('CERTIFICATION_OR_DEPLOYMENT_OVERCLAIM')

    # Interoperability profile constraints
    profile = packet.get('interop_profile') or {}
    ptype = profile.get('profile_type')
    if ptype in {'STANDARD_MAPPING','SCHEMA_MAPPING','API_MAPPING','CITATION_SURFACE','INSTITUTIONAL_INTAKE','IMPLEMENTATION_REPORT'}:
        if not profile.get('preserves'): err('PROFILE_PRESERVES_MISSING')
        if not profile.get('non_translated'): err('PROFILE_NON_TRANSLATED_MISSING')
    if not mut('MUT_STANDARDS_MAPPING_AS_CERTIFICATION'):
        if ptype == 'STANDARD_MAPPING' and profile.get('certification_claimed'):
            err('STANDARDS_MAPPING_NOT_CERTIFICATION')

    if not mut('MUT_IDENTITY_TRANSFER_BY_INTEROP'):
        if profile.get('identity_transfer_claimed') or profile.get('continuity_transfer_claimed'):
            err('INTEROP_IDENTITY_TRANSFER_FORBIDDEN')

    # Claim translation ceilings
    if not mut('MUT_CLAIM_FORCE_ESCALATION'):
        for ct in packet.get('claim_translations') or []:
            if not isinstance(ct, dict):
                err('INVALID_CLAIM_TRANSLATION')
                continue
            ceil = ct.get('internal_ceiling')
            if ceil not in ALLOWED_CEILINGS:
                err('INVALID_CLAIM_CEILING:' + str(ceil))
            if ceil == 'FORBIDDEN' and dec in ADMIT_DECISIONS:
                err('FORBIDDEN_CLAIM_ADMITTED')
            if has_forbidden(ct.get('external_claim','')) and ceil != 'FORBIDDEN':
                err('FORBIDDEN_EXTERNAL_CLAIM_NOT_DOWNGRADED')

    # External requested actions cannot mutate memory/runtime/deployment/release directly
    if not mut('MUT_ALLOW_MEMORY_RUNTIME_WRITE'):
        forbidden_actions = {'WRITE_MEMORY_CORE','WRITE_RUNTIME_AUTHORITY','AUTHORIZE_DEPLOYMENT','PROMOTE_SELF_EVO','WRITE_PUBLIC_RELEASE_LEDGER','WRITE_CORRECTION_LEDGER','CLAIM_CONTINUITY','RATIFY_C_A1'}
        hit = sorted(forbidden_actions & allowed_actions)
        if hit: err('EXTERNAL_DIRECT_ACTION_FORBIDDEN:' + ','.join(hit))
        if decision.get('memory_write_requested') or decision.get('runtime_authority_requested') or decision.get('deployment_claim_requested'):
            err('EXTERNAL_DIRECT_ACTION_FORBIDDEN:REQUEST_FLAG')

    if not mut('MUT_ALLOW_OWNER_ACTION_NO_ANCHOR'):
        owner_actions = {'OWNER_GATE','ANCHOR_APPROVAL','MEMORY_CORE_REVIEW','RUNTIME_AUTHORITY_REVIEW'}
        if owner_actions & allowed_actions and role not in OWNER_ROLES:
            err('OWNER_ACTION_REQUIRES_OWNER_ANCHOR_OR_QUORUM')

    # Conflicts/red patterns
    unresolved_conflicts = []
    for c in packet.get('conflicts') or []:
        if isinstance(c, dict) and c.get('severity') in HIGH_SEV and not c.get('resolved', False):
            unresolved_conflicts.append(c.get('conflict_class','UNKNOWN'))
    unresolved_red = packet.get('red_patterns_unresolved') or []
    if not mut('MUT_UNRESOLVED_CONFLICT_ADMIT'):
        if (unresolved_conflicts or unresolved_red) and dec in ADMIT_DECISIONS:
            err('UNRESOLVED_CONFLICT_OR_RED_PATTERN_ADMITTED')

    # Private/secret raw cannot be public raw
    if not mut('MUT_PRIVATE_SECRET_PUBLIC_RAW'):
        art = packet.get('external_artifact') or {}
        if art.get('raw_payload_public') and (art.get('contains_private_data') or art.get('contains_secret') or art.get('contains_runtime_authority_surface')):
            err('PRIVATE_OR_SECRET_PUBLIC_RAW')

    # Negative cache must dominate admit
    if not mut('MUT_IGNORE_NEGATIVE_CACHE'):
        if packet.get('negative_cache') == 'HIT' and dec in ADMIT_DECISIONS:
            err('NEGATIVE_CACHE_HIT_ADMITTED')

    # Tool output/advisory cannot be accepted as reproduction evidence without independent reproduction review.
    if not mut('MUT_TOOL_OUTPUT_AS_HUMAN_REVIEW'):
        art = packet.get('external_artifact') or {}
        if role == 'TOOL_RUNNER' and dec == 'ADMIT_AS_REPRODUCTION_EVIDENCE':
            err('TOOL_OUTPUT_REQUIRES_HUMAN_REVIEW')
        if art.get('artifact_type') == 'TOOL_OUTPUT' and dec == 'ADMIT_AS_REPRODUCTION_EVIDENCE' and not review_evidence.get('independent_reproduction_review_present'):
            err('TOOL_OUTPUT_REQUIRES_INDEPENDENT_REPRODUCTION_REVIEW')

    # Repository issue cannot bypass redaction/release/public evidence boundary
    if not mut('MUT_REPOSITORY_ISSUE_BYPASS'):
        if profile.get('profile_type') == 'REPOSITORY_ISSUE' and (decision.get('auto_merge') or decision.get('public_release_without_07')):
            err('REPOSITORY_ISSUE_CANNOT_BYPASS_07')

    # Institutional request is request, not authority transfer
    if not mut('MUT_INSTITUTIONAL_REQUEST_AS_AUTHORITY'):
        if role == 'INSTITUTIONAL_REVIEWER' and packet.get('reviewer_claims_ratification'):
            err('INSTITUTIONAL_REVIEW_NOT_RATIFICATION')

    # Raw artifact hash required
    if not mut('MUT_IGNORE_RAW_HASH'):
        if not is_sha((packet.get('external_artifact') or {}).get('raw_sha256')):
            err('INVALID_RAW_ARTIFACT_HASH')

    return len(errors) == 0, errors

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('path', nargs='?', help='packet JSON path')
    ap.add_argument('--json', action='store_true')
    args = ap.parse_args(argv)
    if not args.path:
        ap.error('path required')
    packet = json.loads(Path(args.path).read_text(encoding='utf-8'))
    ok, errors = check_packet(packet)
    out = {'valid': ok, 'errors': errors}
    if args.json:
        print(json.dumps(out, indent=2, sort_keys=True))
    else:
        print('VALID' if ok else 'INVALID')
        for e in errors: print(e)
    return 0 if ok else 1

if __name__ == '__main__':
    raise SystemExit(main())
