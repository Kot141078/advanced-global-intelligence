# Open Issues and Next Steps — 08a

Open items:

1. Add richer institutional intake examples after real external forms exist.
2. Add optional JSON Schema draft validation if a dependency policy allows it.
3. Add reviewer identity binding profiles for signed human review records.
4. Add cross-package conflict ledger integration in `08b`.

Next layer:

```text
08b_EXTERNAL_REVIEW_CONFLICT_RESOLUTION_AND_PATCH_INTAKE_LEDGER_v0_1
```
