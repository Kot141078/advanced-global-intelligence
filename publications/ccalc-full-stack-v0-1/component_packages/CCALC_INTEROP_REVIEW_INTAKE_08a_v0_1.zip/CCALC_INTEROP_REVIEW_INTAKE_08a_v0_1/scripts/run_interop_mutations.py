#!/usr/bin/env python3
from __future__ import annotations
import os, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT/'scripts/run_interop_fixtures.py'
MUTATIONS = [
 'MUT_MISSING_SOURCE_BINDINGS',
 'MUT_MODEL_REVIEW_AS_RATIFICATION',
 'MUT_ALLOW_NO_HUMAN_GATE',
 'MUT_ALLOW_C_A1_OVERCLAIM',
 'MUT_C_A10_PREFIX_FALSE_POSITIVE',
 'MUT_ALLOW_DEPLOYMENT_SAFETY_CERT_OVERCLAIM',
 'MUT_STANDARDS_MAPPING_AS_CERTIFICATION',
 'MUT_IDENTITY_TRANSFER_BY_INTEROP',
 'MUT_CLAIM_FORCE_ESCALATION',
 'MUT_ALLOW_MEMORY_RUNTIME_WRITE',
 'MUT_ALLOW_OWNER_ACTION_NO_ANCHOR',
 'MUT_UNRESOLVED_CONFLICT_ADMIT',
 'MUT_PRIVATE_SECRET_PUBLIC_RAW',
 'MUT_IGNORE_NEGATIVE_CACHE',
 'MUT_TOOL_OUTPUT_AS_HUMAN_REVIEW',
 'MUT_REPOSITORY_ISSUE_BYPASS',
 'MUT_INSTITUTIONAL_REQUEST_AS_AUTHORITY',
 'MUT_IGNORE_RAW_HASH',
]
rows = ['mutation\tstatus\treturncode\tstdout_tail']
missed = 0
for m in MUTATIONS:
    env = dict(os.environ)
    env[m] = '1'
    p = subprocess.run([sys.executable, str(SCRIPT)], cwd=str(ROOT), env=env, text=True, capture_output=True)
    caught = p.returncode != 0
    if not caught:
        missed += 1
    tail = (p.stdout + ' ' + p.stderr).replace('\n',' | ')[-220:]
    rows.append(f'{m}\t{"CAUGHT" if caught else "MISSED"}\t{p.returncode}\t{tail}')
(ROOT/'MUTATION_MATRIX.tsv').write_text('\n'.join(rows)+'\n', encoding='utf-8')
# Restore the baseline fixture result after mutation runs so packaged FIXTURE_RESULTS.tsv remains clean.
subprocess.run([sys.executable, str(SCRIPT)], cwd=str(ROOT), text=True, capture_output=True, check=True)
print(f'mutations: {len(MUTATIONS)}  CAUGHT: {len(MUTATIONS)-missed}  MISSED: {missed}')
raise SystemExit(1 if missed else 0)
