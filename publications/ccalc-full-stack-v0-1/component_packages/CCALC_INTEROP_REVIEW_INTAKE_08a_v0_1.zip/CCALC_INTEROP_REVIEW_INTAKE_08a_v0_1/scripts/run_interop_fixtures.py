#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CHECKER_PATH = ROOT/'src/interop_review_intake_checker_v0_1.py'
spec = importlib.util.spec_from_file_location('interop_checker', CHECKER_PATH)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)  # type: ignore
CASES = ROOT/'fixtures/cases'
for stale in CASES.glob('*.tmp.json'):
    stale.unlink()
rows = ['case\texpected_valid\tactual_valid\tstatus\terrors']
fail = 0
count = 0
for path in sorted(CASES.glob('*.json')):
    count += 1
    data = json.loads(path.read_text(encoding='utf-8'))
    expected = bool(data.pop('_expected_valid'))
    actual, errs = checker.check_packet(data)
    status = 'PASS' if actual == expected else 'FAIL'
    if status == 'FAIL':
        fail += 1
    rows.append(f'{path.name}\t{expected}\t{actual}\t{status}\t{",".join(errs)}')
(ROOT/'FIXTURE_RESULTS.tsv').write_text('\n'.join(rows)+'\n', encoding='utf-8')
print(f'fixtures: {count}  PASS: {count-fail}  FAIL: {fail}')
raise SystemExit(1 if fail else 0)
