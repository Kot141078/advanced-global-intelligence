# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each file:

```text
sha256sum exact_file_bytes > filename.sha256
```

The file itself does not include its own hash. This avoids self-referential instability.
