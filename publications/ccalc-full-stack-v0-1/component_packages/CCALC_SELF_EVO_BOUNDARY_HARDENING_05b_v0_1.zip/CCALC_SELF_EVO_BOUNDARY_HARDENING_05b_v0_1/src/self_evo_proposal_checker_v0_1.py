#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

SCHEMA_VERSION = "ccalc.self_evo.proposal_packet.v0_1"
RISK_ORDER = {"R0": 0, "R1": 1, "R2": 2, "R3": 3, "R4": 4, "R5": 5, "RX": 99}
SURFACE_MIN_RISK = {
    "S0_PRESENTATION": "R1",
    "S1_HEURISTIC_LOW": "R2",
    "S2_TOOLING_LOW": "R2",
    "S3_RETRIEVAL_MEMORY_INDEX": "R2",
    "S4_POLICY_TUNING": "R3",
    "S5_MODEL_OR_ORACLE_ROUTE": "R3",
    "S6_MEMORY_CORE": "R4",
    "S7_IDENTITY_PERSONA_CORE": "R5",
    "S8_AUTHORITY_PRIVILEGE": "R5",
    "S9_L4_RESOURCE_PERIMETER": "R5",
    "S10_WITNESS_ROLLBACK_FREEZE": "R5",
    "SX_PROHIBITED": "RX",
}
ANCHOR_SURFACES = {"S6_MEMORY_CORE", "S7_IDENTITY_PERSONA_CORE", "S8_AUTHORITY_PRIVILEGE", "S9_L4_RESOURCE_PERIMETER", "S10_WITNESS_ROLLBACK_FREEZE", "SX_PROHIBITED"}
MEMORY_SURFACES = {"S3_RETRIEVAL_MEMORY_INDEX", "S6_MEMORY_CORE"}
RESOURCE_SURFACES = {"S9_L4_RESOURCE_PERIMETER"}
WITNESS_SURFACES = {"S4_POLICY_TUNING", "S5_MODEL_OR_ORACLE_ROUTE", "S6_MEMORY_CORE", "S7_IDENTITY_PERSONA_CORE", "S8_AUTHORITY_PRIVILEGE", "S9_L4_RESOURCE_PERIMETER", "S10_WITNESS_ROLLBACK_FREEZE", "SX_PROHIBITED"}
PRIVILEGED_SURFACES = ANCHOR_SURFACES - {"SX_PROHIBITED"}
ALLOWED_EVIDENCE = {
    "HUMAN_CORRECTION", "REALITY_OUTCOME", "L4_OUTCOME", "WITNESS_RECORD", "FIXTURE_PASS",
    "REGRESSION_NONBREAK", "ADVERSARIAL_MUTATION_CAUGHT", "TRIAD_CHALLENGE_SURVIVED",
    "MEMORY_GATE_ACCEPTANCE", "ROLLBACK_DRILL_PASS",
}
INSUFFICIENT_EVIDENCE = {
    "MODEL_SELF_SCORE", "AGENT_CONFIDENCE", "SINGLE_PROMPT_JUDGMENT", "STYLE_IMPROVEMENT",
    "CONSENSUS_WITHOUT_INDEPENDENCE", "PASSING_TESTS_WITHOUT_SEMANTIC_COVERAGE",
    "LOCAL_SPEEDUP_WITH_RESOURCE_ESCAPE",
}


def _mutation() -> str:
    return os.getenv("SELF_EVO_CHECKER_MUTATION", "").strip()


def _get(obj: Mapping[str, Any], path: str, default=None):
    cur: Any = obj
    for part in path.split('.'):
        if isinstance(cur, Mapping) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur


def _has(obj: Mapping[str, Any], path: str) -> bool:
    sentinel = object()
    return _get(obj, path, sentinel) is not sentinel


def _nonempty(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, dict)):
        return len(value) > 0
    return True


def _risk_ge(actual: str, required: str) -> bool:
    return RISK_ORDER.get(str(actual), -1) >= RISK_ORDER.get(str(required), 999)


def _max_required_risk(surfaces: List[str]) -> str:
    max_val = -1
    max_risk = "R0"
    for s in surfaces:
        r = SURFACE_MIN_RISK.get(str(s), "RX")
        if RISK_ORDER[r] > max_val:
            max_val = RISK_ORDER[r]
            max_risk = r
    return max_risk


def _is_c_a1_overclaim(claim: str) -> bool:
    claim = str(claim or "").strip()
    if _mutation() == "MUT_C_A10_PREFIX_FALSE_POSITIVE":
        return claim.startswith("C-A1")
    return claim == "C-A1" or claim.startswith("C-A1_")


def _anchor_valid(approvals: Mapping[str, Any], anchor_id: str) -> bool:
    app = approvals.get("anchor_approval") if isinstance(approvals, Mapping) else None
    if not isinstance(app, Mapping):
        return False
    if not bool(app.get("approved")):
        return False
    if str(app.get("anchor_id") or "") != str(anchor_id or ""):
        return False
    if bool(app.get("stale")):
        return False
    return True


def _reviewer_separated(packet: Mapping[str, Any]) -> bool:
    if _mutation() == "MUT_ALLOW_SELF_CERTIFICATION":
        return True
    prop = _get(packet, "proposal", {}) or {}
    trial = prop.get("bounded_trial_plan") or {}
    proposed_by = str(prop.get("proposed_by") or "")
    executor_id = str(trial.get("executor_id") or "")
    reviewers = [str(x) for x in (trial.get("reviewer_ids") or [])]
    promotion_reviewers = [str(x) for x in (_get(packet, "approvals.promotion_review.reviewed_by", []) or [])]
    all_reviewers = set([x for x in reviewers + promotion_reviewers if x])
    if not all_reviewers:
        return False
    # A proposer or executor may be present in a quorum, but not be the only reviewer.
    non_self = [r for r in all_reviewers if r and r not in {proposed_by, executor_id}]
    return bool(non_self)


def _trial_boundary_valid(trial: Mapping[str, Any]) -> Tuple[bool, str]:
    if not isinstance(trial, Mapping) or not trial:
        return False, "HOLD_BOUNDED_TRIAL_REQUIRED"
    required = ["trial_id", "proposal_id", "trial_mode", "allowed_inputs", "denied_inputs", "allowed_outputs", "denied_outputs", "max_actions", "max_wall_time_sec", "max_compute_budget", "network_mode", "memory_write_mode", "rollback_plan_ref", "witness_required", "executor_id", "reviewer_ids", "stop_conditions"]
    for f in required:
        if not _nonempty(trial.get(f)) and f not in {"denied_inputs", "denied_outputs"}:
            return False, "HOLD_BOUNDED_TRIAL_REQUIRED"
    if str(trial.get("network_mode")) == "unrestricted":
        return False, "DENY_INVALID_TRIAL_BOUNDARY"
    if str(trial.get("memory_write_mode")) == "direct":
        return False, "DENY_DIRECT_MEMORY_WRITE"
    try:
        if int(trial.get("max_actions", 0)) <= 0 or int(trial.get("max_wall_time_sec", 0)) <= 0:
            return False, "HOLD_BOUNDED_TRIAL_REQUIRED"
    except Exception:
        return False, "HOLD_BOUNDED_TRIAL_REQUIRED"
    return True, "OK"


def _fitness_sufficient(evidence_bundle: Mapping[str, Any]) -> Tuple[bool, str]:
    if _mutation() == "MUT_ALLOW_MODEL_SELF_SCORE_ONLY":
        return True, "OK"
    records = evidence_bundle.get("fitness_evidence") or []
    if not isinstance(records, list) or not records:
        return False, "HOLD_FITNESS_EVIDENCE_INSUFFICIENT"
    allowed_count = 0
    for rec in records:
        if not isinstance(rec, Mapping):
            continue
        klass = str(rec.get("evidence_class") or "")
        if klass in ALLOWED_EVIDENCE:
            allowed_count += 1
        try:
            uncertainty = float(rec.get("uncertainty"))
        except Exception:
            return False, "HOLD_FITNESS_EVIDENCE_INSUFFICIENT"
        if uncertainty < 0 or uncertainty > 0.5:
            return False, "HOLD_FITNESS_EVIDENCE_INSUFFICIENT"
    if allowed_count <= 0:
        return False, "HOLD_FITNESS_EVIDENCE_INSUFFICIENT"
    return True, "OK"


def evaluate(packet: Mapping[str, Any]) -> Dict[str, Any]:
    findings: List[str] = []

    root_required = ["schema_version", "packet_id", "created_at", "governing_c_id", "anchor_id", "stage", "proposal", "evidence_bundle", "approvals", "non_claims"]
    for f in root_required:
        if not _has(packet, f) or not _nonempty(packet.get(f)) and f not in {"evidence_bundle", "approvals"}:
            findings.append(f"missing_root:{f}")
            return _result("HOLD_MISSING_REQUIRED_FIELD", findings, packet)

    if packet.get("schema_version") != SCHEMA_VERSION:
        findings.append("schema_version_invalid")
        return _result("HOLD_MISSING_REQUIRED_FIELD", findings, packet)

    proposal = packet.get("proposal") or {}
    if not isinstance(proposal, Mapping):
        findings.append("proposal_not_object")
        return _result("HOLD_MISSING_REQUIRED_FIELD", findings, packet)

    prop_required = [
        "proposal_id", "created_at", "proposed_by", "proposal_class", "risk_class", "touched_surfaces",
        "objective", "expected_benefit", "bounded_trial_plan", "fitness_plan", "rollback_plan",
        "continuity_impact_assessment", "resource_impact_assessment", "memory_impact_assessment",
        "authority_impact_assessment", "witness_plan", "claim_force_ceiling", "non_claims",
    ]
    for f in prop_required:
        if not _has(proposal, f) or (f not in {"non_claims"} and not _nonempty(proposal.get(f))):
            findings.append(f"missing_proposal:{f}")
            return _result("HOLD_MISSING_REQUIRED_FIELD", findings, packet)

    surfaces = [str(x) for x in (proposal.get("touched_surfaces") or [])]
    if not surfaces:
        findings.append("touched_surfaces_empty")
        return _result("HOLD_MISSING_REQUIRED_FIELD", findings, packet)
    if any(s not in SURFACE_MIN_RISK for s in surfaces):
        findings.append("unknown_surface")
        return _result("DENY_PROHIBITED_SELF_EVOLUTION_SURFACE", findings, packet)

    if "SX_PROHIBITED" in surfaces or str(proposal.get("proposal_class")) == "PROHIBITED":
        return _result("DENY_PROHIBITED_SELF_EVOLUTION_SURFACE", [*findings, "prohibited_surface_or_class"], packet)

    claim = str(proposal.get("claim_force_ceiling") or "")
    if _is_c_a1_overclaim(claim):
        return _result("QUARANTINE_CLAIM_FORCE_OVERREACH", [*findings, "claim_force_c_a1_overreach"], packet)

    required_risk = _max_required_risk(surfaces)
    actual_risk = str(proposal.get("risk_class") or "")
    if _mutation() != "MUT_IGNORE_RISK_UNDERSTATEMENT":
        if not _risk_ge(actual_risk, required_risk):
            return _result("HOLD_RISK_CLASS_UNDERSTATED", [*findings, f"required:{required_risk}:actual:{actual_risk}"], packet)

    trial = proposal.get("bounded_trial_plan") or {}
    ok_trial, trial_decision = _trial_boundary_valid(trial)
    if not ok_trial:
        return _result(trial_decision, [*findings, "invalid_trial_boundary"], packet)

    if str(proposal.get("memory_impact_assessment", {}).get("write_mode", "")) == "direct":
        return _result("DENY_DIRECT_MEMORY_WRITE", [*findings, "direct_memory_write_requested"], packet)
    if str(trial.get("memory_write_mode", "")) == "direct":
        return _result("DENY_DIRECT_MEMORY_WRITE", [*findings, "direct_memory_write_in_trial"], packet)

    if not _reviewer_separated(packet):
        return _result("HOLD_REVIEWER_SEPARATION_REQUIRED", [*findings, "self_certification_or_reviewer_collapse"], packet)

    approvals = packet.get("approvals") if isinstance(packet.get("approvals"), Mapping) else {}
    anchor_id = str(packet.get("anchor_id") or "")
    if any(s in ANCHOR_SURFACES for s in surfaces):
        if not _anchor_valid(approvals, anchor_id):
            return _result("ASK_ANCHOR_REQUIRED", [*findings, "anchor_required_missing_or_stale"], packet)

    rollback = proposal.get("rollback_plan") or {}
    if (RISK_ORDER.get(actual_risk, 0) >= RISK_ORDER["R2"] or any(s in PRIVILEGED_SURFACES for s in surfaces)):
        if not isinstance(rollback, Mapping) or not rollback.get("rollback_route_ref") or not rollback.get("freeze_available"):
            return _result("HOLD_ROLLBACK_REQUIRED", [*findings, "rollback_or_freeze_missing"], packet)
        if rollback.get("irreversible") and not _anchor_valid(approvals, anchor_id):
            return _result("ASK_ANCHOR_REQUIRED", [*findings, "irreversible_change_requires_anchor"], packet)

    witness_plan = proposal.get("witness_plan") or {}
    if any(s in WITNESS_SURFACES for s in surfaces) or RISK_ORDER.get(actual_risk, 0) >= RISK_ORDER["R3"]:
        if not witness_plan.get("witness_required") or not witness_plan.get("witness_route_ref"):
            return _result("HOLD_WITNESS_REQUIRED", [*findings, "witness_required_missing"], packet)

    stage = str(packet.get("stage") or "ADMISSION")
    if stage == "ADMISSION":
        return _result("ADMIT_BOUNDED_TRIAL", [*findings, "admission_gates_passed"], packet)

    if stage != "PROMOTION":
        return _result("HOLD_MISSING_REQUIRED_FIELD", [*findings, "unknown_stage"], packet)

    eb = packet.get("evidence_bundle") if isinstance(packet.get("evidence_bundle"), Mapping) else {}
    trial_result = eb.get("trial_result") or {}
    if not isinstance(trial_result, Mapping) or trial_result.get("status") != "COMPLETED_PASS":
        return _result("HOLD_TRIAL_NOT_COMPLETED", [*findings, "trial_not_completed_pass"], packet)

    if eb.get("counter_evidence"):
        unresolved = [x for x in eb.get("counter_evidence") or [] if isinstance(x, Mapping) and str(x.get("status")) != "RESOLVED"]
        if unresolved:
            return _result("HOLD_COUNTER_EVIDENCE_UNRESOLVED", [*findings, "unresolved_counter_evidence"], packet)

    ok_fit, fit_decision = _fitness_sufficient(eb)
    if not ok_fit:
        return _result(fit_decision, [*findings, "fitness_evidence_insufficient"], packet)

    if any(s in MEMORY_SURFACES for s in surfaces):
        mg = eb.get("memory_gate") or {}
        if not isinstance(mg, Mapping) or str(mg.get("decision") or "") not in {"MEMORY_CANDIDATE", "ADMITTED_MEMORY", "POLICY_CANDIDATE", "FITNESS_EVIDENCE"}:
            return _result("HOLD_MEMORY_GATE_REQUIRED", [*findings, "memory_gate_missing_or_nonaccepting"], packet)

    if any(s in RESOURCE_SURFACES for s in surfaces):
        rg = eb.get("resource_gate") or {}
        if _mutation() != "MUT_IGNORE_RESOURCE_GATE":
            if not isinstance(rg, Mapping) or str(rg.get("status") or "") != "PASS":
                return _result("HOLD_RESOURCE_GATE_REQUIRED", [*findings, "resource_gate_missing_or_failed"], packet)
            resource_impact = proposal.get("resource_impact_assessment") or {}
            if resource_impact.get("change") == "EXPANDS" and not rg:
                return _result("HOLD_RESOURCE_GATE_REQUIRED", [*findings, "hidden_resource_expansion"], packet)

    cont = eb.get("continuity_gate") or {}
    if _mutation() != "MUT_IGNORE_CONTINUITY_UNKNOWN":
        if not isinstance(cont, Mapping) or str(cont.get("status") or "") not in {"PASS", "PASS_REDUCED_AUTHORITY"}:
            return _result("HOLD_CONTINUITY_GATE_REQUIRED", [*findings, "continuity_gate_missing_or_unknown"], packet)
        if str(cont.get("classification") or "") in {"HELD_UNKNOWN", "UNKNOWN_HOLD", "RUPTURE"}:
            return _result("HOLD_CONTINUITY_GATE_REQUIRED", [*findings, "continuity_classification_not_promotable"], packet)
    if cont.get("uses_presentation_equivalence_as_authority"):
        return _result("QUARANTINE_PRESENTATION_AUTHORITY_LAUNDERING", [*findings, "presentation_equivalence_authority"], packet)

    if _mutation() != "MUT_IGNORE_RED_PATTERN":
        red = eb.get("red_patterns") or []
        adj = eb.get("adjacency_audit") or {}
        if red or (isinstance(adj, Mapping) and str(adj.get("status") or "") == "RED_FOUND"):
            return _result("HOLD_RED_PATTERN_DETECTED", [*findings, "red_pattern_detected"], packet)

    # Promotion class selection
    if any(s in {"S3_RETRIEVAL_MEMORY_INDEX", "S6_MEMORY_CORE"} for s in surfaces):
        return _result("PROMOTE_AS_CANDIDATE_MEMORY", [*findings, "promotion_candidate_memory_scope"], packet)
    if any(s in {"S4_POLICY_TUNING", "S5_MODEL_OR_ORACLE_ROUTE", "S9_L4_RESOURCE_PERIMETER", "S10_WITNESS_ROLLBACK_FREEZE"} for s in surfaces):
        return _result("PROMOTE_WITH_REDUCED_AUTHORITY", [*findings, "promotion_reduced_authority_scope"], packet)
    return _result("PROMOTE_LOW_RISK", [*findings, "promotion_low_risk_scope"], packet)


def _result(decision: str, findings: List[str], packet: Mapping[str, Any]) -> Dict[str, Any]:
    proposal = packet.get("proposal") if isinstance(packet.get("proposal"), Mapping) else {}
    surfaces = list(proposal.get("touched_surfaces") or []) if isinstance(proposal, Mapping) else []
    return {
        "ok": decision.startswith("ADMIT") or decision.startswith("PROMOTE"),
        "decision": decision,
        "findings": list(findings),
        "packet_id": packet.get("packet_id", ""),
        "proposal_id": proposal.get("proposal_id", "") if isinstance(proposal, Mapping) else "",
        "stage": packet.get("stage", ""),
        "touched_surfaces": surfaces,
        "required_risk": _max_required_risk([str(x) for x in surfaces]) if surfaces else "R0",
        "risk_class": proposal.get("risk_class", "") if isinstance(proposal, Mapping) else "",
        "claim_force": proposal.get("claim_force_ceiling", "") if isinstance(proposal, Mapping) else "",
        "accepted_scope": surfaces if decision.startswith("ADMIT") or decision.startswith("PROMOTE") else [],
        "excluded_scope": [] if decision.startswith("ADMIT") or decision.startswith("PROMOTE") else surfaces,
        "non_claims": [
            "not_safety_certification",
            "not_deployment_authorization",
            "not_C_A1_ratification",
            "not_live_substrate_truth",
        ],
    }


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="05a self-evo proposal packet checker seed")
    ap.add_argument("path", nargs="?", help="JSON packet path")
    ap.add_argument("--pretty", action="store_true")
    args = ap.parse_args(argv)
    if not args.path:
        print(json.dumps({"ok": False, "error": "missing_path"}, sort_keys=True))
        return 2
    rep = evaluate(load_json(Path(args.path)))
    print(json.dumps(rep, ensure_ascii=False, indent=2 if args.pretty else None, sort_keys=True))
    return 0 if rep.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
