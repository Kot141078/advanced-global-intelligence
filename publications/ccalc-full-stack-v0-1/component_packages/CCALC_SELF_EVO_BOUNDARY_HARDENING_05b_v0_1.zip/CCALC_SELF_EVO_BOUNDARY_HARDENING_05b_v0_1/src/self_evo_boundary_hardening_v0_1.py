#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys, importlib.util
from pathlib import Path
from typing import Any, Mapping

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "src" / "self_evo_proposal_checker_v0_1.py"
_spec = importlib.util.spec_from_file_location("self_evo_proposal_checker_v0_1", str(CHECKER))
_checker = importlib.util.module_from_spec(_spec)
assert _spec and _spec.loader
_spec.loader.exec_module(_checker)

MUTATION_CASES = {
    "MUT_ALLOW_SELF_CERTIFICATION": "034_reviewer_collapse",
    "MUT_ALLOW_MODEL_SELF_SCORE_ONLY": "043_model_self_score_only",
    "MUT_IGNORE_RISK_UNDERSTATEMENT": "029_risk_understated_policy",
    "MUT_C_A10_PREFIX_FALSE_POSITIVE": "012_admit_c_a10_not_c_a1",
    "MUT_IGNORE_CONTINUITY_UNKNOWN": "050_continuity_unknown",
    "MUT_IGNORE_RED_PATTERN": "054_red_pattern_detected",
    "MUT_IGNORE_RESOURCE_GATE": "048_resource_promotion_no_gate",
}

def _load(path: Path) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def _run_checker(path: Path, mutation: str = "") -> Mapping[str, Any]:
    old = os.environ.get("SELF_EVO_CHECKER_MUTATION")
    try:
        if mutation:
            os.environ["SELF_EVO_CHECKER_MUTATION"] = mutation
        else:
            os.environ.pop("SELF_EVO_CHECKER_MUTATION", None)
        return _checker.evaluate(_load(path))
    finally:
        if old is None:
            os.environ.pop("SELF_EVO_CHECKER_MUTATION", None)
        else:
            os.environ["SELF_EVO_CHECKER_MUTATION"] = old

def run_fixtures(case_dir: Path) -> list[dict[str, Any]]:
    rows=[]
    for path in sorted(case_dir.glob("*.json")):
        pkt=_load(path)
        expected=str(pkt.get("_expected") or "")
        rep=_run_checker(path)
        got=str(rep.get("decision") or "")
        status="PASS" if got == expected else "FAIL"
        rows.append({"case": path.name, "expected": expected, "got": got, "status": status, "findings": ",".join(rep.get("findings") or [])})
    return rows

def run_mutations(case_dir: Path) -> list[dict[str, Any]]:
    rows=[]
    by_name={p.name:p for p in case_dir.glob("*.json")}
    for mut, stem in MUTATION_CASES.items():
        matches=[p for p in by_name.values() if stem in p.name]
        if not matches:
            rows.append({"mutation": mut, "case":"", "baseline":"", "mutated":"", "status":"MISSING_CASE"})
            continue
        path=matches[0]
        pkt=_load(path)
        expected=str(pkt.get("_expected") or "")
        base=_run_checker(path)
        mutated=_run_checker(path, mutation=mut)
        base_decision=str(base.get("decision") or "")
        mut_decision=str(mutated.get("decision") or "")
        caught = (base_decision == expected and mut_decision != expected)
        rows.append({"mutation": mut, "case": path.name, "baseline": base_decision, "mutated": mut_decision, "status": "CAUGHT" if caught else "MISSED"})
    return rows

def write_tsv(path: Path, rows: list[Mapping[str, Any]], columns: list[str]) -> None:
    lines=["\t".join(columns)]
    for r in rows:
        lines.append("\t".join(str(r.get(c, "")).replace("\t", " ").replace("\n", " ") for c in columns))
    path.write_text("\n".join(lines)+"\n", encoding="utf-8")

def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description="05b boundary hardening fixture/mutation harness")
    ap.add_argument("--cases", default=str(ROOT/"fixtures"/"cases"))
    ap.add_argument("--fixtures-out", default=str(ROOT/"FIXTURE_RESULTS.tsv"))
    ap.add_argument("--mutations-out", default=str(ROOT/"MUTATION_MATRIX.tsv"))
    args=ap.parse_args(argv)
    case_dir=Path(args.cases)
    fix=run_fixtures(case_dir)
    mut=run_mutations(case_dir)
    write_tsv(Path(args.fixtures_out), fix, ["case","expected","got","status","findings"])
    write_tsv(Path(args.mutations_out), mut, ["mutation","case","baseline","mutated","status"])
    ok = all(r["status"] == "PASS" for r in fix) and all(r["status"] == "CAUGHT" for r in mut)
    print(json.dumps({"ok": ok, "fixtures": len(fix), "fixture_pass": sum(1 for r in fix if r["status"]=="PASS"), "mutations": len(mut), "mutations_caught": sum(1 for r in mut if r["status"]=="CAUGHT")}, ensure_ascii=False, sort_keys=True))
    return 0 if ok else 2

if __name__ == "__main__":
    raise SystemExit(main())
