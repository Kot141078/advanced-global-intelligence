# 05b_SELF_EVO_BOUNDARY_FIXTURE_AND_MUTATION_HARDENING_v0_1

**Document class:** normative hardening companion / fixture pack / mutation test seed  
**Project:** Self-Evo / Ester / `c = a + b`  
**Layer:** self-evolution boundary hardening, fixture coverage, mutation discipline  
**Version:** `v0.1`  
**Status:** working hardening seed for `05` and `05a`  
**Authority:** advisory technical artifact only; not safety certification, not deployment authorization, not C-A1 ratification.

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are to be interpreted as in RFC 2119.

---

## 0. Purpose

`05` defines self-evolution as a governed transition class, not an autonomous right.

`05a` defines a proposal packet schema and checker seed.

`05b` hardens that boundary with fixtures and mutation tests.

Compact formula:

```text
A c may grow.
A c may not self-certify growth.
A checker that only passes happy paths is not a boundary.
```

The purpose of this package is to make the self-evolution gate fail in the right direction when pressure appears at high-risk seams:

```text
self-certification
risk understatement
anchor bypass
direct memory write
model self-score promotion
continuity UNKNOWN collapse
presentation-authority laundering
red-pattern suppression
resource-gate bypass
claim-force retagging
```

---

## 1. Dependency and source binding

This package binds to:

| Artifact | Role | SHA256 |
|---|---|---|
| `05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1.md` | Normative parent | `c4f73da9218780486362beb53a03c40cb4a845ea9f7c321e402441c3446be473` |
| `CCALC_SELF_EVO_PROPOSAL_PACKET_05a_v0_1.zip` | Schema/checker seed parent | `0ab68e8e35f43a8bb7dfa8f3ba7f6c6d7c7143ccfb66dd913be7f5cd674e8228` |
| `self_evo_proposal_checker_v0_1.py` | Copied checker under hardening | `f65d345117d1c4c12338b8eda9c71a9aa49a1f693eb89eadb0bade801e8e20af` |
| `CCALC_DOC04_CONTINUITY_STACK_UMBRELLA_v0_1.zip` | Continuity stack dependency | `6caeab8d489aaa6b26902db3bd3ece4c5169e5c8d5617b93aed6586ea900322d` |

---

## 2. Boundary classes

| ID | Boundary | Required behavior |
|---|---|---|
| `B0` | Shape completeness | Missing root/proposal/trial fields MUST hold. |
| `B1` | Self-certification | Proposer/executor/reviewer collapse MUST hold. |
| `B2` | Risk/surface honesty | Unknown, prohibited, or understated surfaces MUST deny/hold. |
| `B3` | Anchor gate | Identity, memory-core, authority, L4, witness/rollback surfaces MUST require fresh matching anchor approval. |
| `B4` | Memory gate | Direct memory write MUST deny; memory promotion MUST require memory gate. |
| `B5` | Evidence discipline | Model self-score alone MUST NOT support promotion. |
| `B6` | Continuity discipline | Missing/UNKNOWN/RUPTURE continuity evidence MUST hold. |
| `B7` | Presentation boundary | Presentation equivalence MUST NOT authorize promotion. |
| `B8` | Red-pattern dominance | Red local transitions MUST dominate global green metrics. |
| `B9` | L4 resource gate | Resource/perimeter expansion MUST require resource gate. |
| `B10` | Claim-force hygiene | C-A1 overreach MUST quarantine; C-A10 MUST NOT be misread as C-A1. |

---

## 3. Fixture requirements

A 05b fixture case MUST include `_expected`, so the runner checks semantic decision, not merely JSON shape.

A fixture suite MUST include:

```text
positive admission cases
positive promotion cases
required-field failure cases
risk and surface failure cases
anchor-gate failures
reviewer separation failures
memory-gate failures
evidence failures
continuity-gate failures
red-pattern failures
resource-gate failures
claim-force failures
```

This package includes 56 cases.

---

## 4. Mutation requirements

A mutation is considered caught only when:

```text
baseline decision == expected decision
mutated decision != expected decision
```

This prevents a broken baseline from pretending to catch a mutation.

The required mutation classes are:

```text
MUT_ALLOW_SELF_CERTIFICATION
MUT_ALLOW_MODEL_SELF_SCORE_ONLY
MUT_IGNORE_RISK_UNDERSTATEMENT
MUT_C_A10_PREFIX_FALSE_POSITIVE
MUT_IGNORE_CONTINUITY_UNKNOWN
MUT_IGNORE_RED_PATTERN
MUT_IGNORE_RESOURCE_GATE
```

---

## 5. Non-claims

This package does not certify a live self-evolution system.

It does not prove completeness.

It does not authorize deployment.

It does not ratify C-A1.

It does not extract raw ledger truth.

It hardens the seed boundary so the next implementation layer has fewer silent gaps.

---

## 6. Next layer

The next natural layer after 05b is:

```text
05c_SELF_EVO_PROMOTION_LEDGER_AND_ROLLBACK_DRILL_v0_1
```

That layer should define promotion ledger records, rollback drill records, frozen rejected-candidate records, and post-promotion witness replay.
