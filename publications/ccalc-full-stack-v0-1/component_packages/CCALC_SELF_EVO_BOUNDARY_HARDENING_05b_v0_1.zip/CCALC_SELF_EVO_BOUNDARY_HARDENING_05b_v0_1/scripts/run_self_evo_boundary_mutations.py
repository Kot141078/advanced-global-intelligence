#!/usr/bin/env python3
from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from self_evo_boundary_hardening_v0_1 import run_mutations, write_tsv
rows = run_mutations(ROOT/"fixtures"/"cases")
write_tsv(ROOT/"MUTATION_MATRIX.tsv", rows, ["mutation","case","baseline","mutated","status"])
ok = all(r["status"] == "CAUGHT" for r in rows)
print(json.dumps({"ok": ok, "mutations": len(rows), "caught": sum(1 for r in rows if r["status"] == "CAUGHT")}, sort_keys=True))
raise SystemExit(0 if ok else 2)
