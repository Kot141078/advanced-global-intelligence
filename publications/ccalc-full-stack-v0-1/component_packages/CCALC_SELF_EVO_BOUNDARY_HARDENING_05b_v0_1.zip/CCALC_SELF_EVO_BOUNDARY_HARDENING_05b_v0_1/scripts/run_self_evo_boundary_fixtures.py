#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from self_evo_boundary_hardening_v0_1 import main
raise SystemExit(main(["--cases", str(ROOT/"fixtures"/"cases"), "--fixtures-out", str(ROOT/"FIXTURE_RESULTS.tsv"), "--mutations-out", str(ROOT/"MUTATION_MATRIX.tsv")]))
