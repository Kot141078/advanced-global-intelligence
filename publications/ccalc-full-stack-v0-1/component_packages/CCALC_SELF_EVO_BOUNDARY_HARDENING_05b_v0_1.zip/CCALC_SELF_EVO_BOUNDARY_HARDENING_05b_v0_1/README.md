# CCALC Self-Evo Boundary Hardening 05b v0.1

Fixture and mutation hardening package for `05` and `05a`.

Run:

```bash
python scripts/run_self_evo_boundary_fixtures.py
python scripts/run_self_evo_boundary_mutations.py
sha256sum -c SHA256SUMS.txt
```

Status: working hardening seed. No deployment claim.
