# Open Issues and Next Steps

## Closed in this package

- Boundary fixtures cover all 05a decision classes used in the seed.
- Mutation tests cover seven known laundering classes.
- C-A10 prefix false positive is explicitly preserved as a regression target.

## Still open

- O5b-01: property-based generation is sampled by fixed fixtures only.
- O5b-02: live ledger extraction remains out of scope.
- O5b-03: promotion rollback drills need a dedicated ledger format.

## Next package

`05c_SELF_EVO_PROMOTION_LEDGER_AND_ROLLBACK_DRILL_v0_1`.
