# Reading Order

1. `05b_SELF_EVO_BOUNDARY_FIXTURE_AND_MUTATION_HARDENING_v0_1.md`
2. `registry/BOUNDARY_CLASS_REGISTRY.tsv`
3. `fixtures/cases/`
4. `src/self_evo_proposal_checker_v0_1.py`
5. `src/self_evo_boundary_hardening_v0_1.py`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
