#!/usr/bin/env python3
"""Runtime Authority Manifest Checker Seed v0.1.

Stdlib-only checker for CCALC 06a seed records. It intentionally
implements semantic guardrails that are hard to express in JSON Schema.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

ALLOWED_RECORD_TYPES = {
    "RuntimeAuthorityManifest",
    "ContourDeploymentManifest",
    "CrossContourHandoffRecord",
    "ToolSurfaceLease",
    "MemoryImportRecord",
    "RuntimeAuthorityDecision",
    "EmergencyHoldRecord",
    "DeploymentChangeRecord",
}

DEPLOYMENT_MODES = {
    "SINGLE_CONTOUR_LOCAL",
    "MULTI_CONTOUR_ISOLATED",
    "FEDERATED_HANDOFF",
    "SHARED_TOOL_MESH",
    "HUMAN_ANCHOR_CLUSTER",
    "CLOUD_ASSISTED_ORACLE",
    "FIELD_RUNTIME",
    "QUARANTINE_SANDBOX",
    "RESTORATION_MODE",
}

CONTINUITY_STATUSES = {
    "CONTINUES",
    "DEGRADED_CONTINUES",
    "UNKNOWN_HOLD",
    "FORKED_FROM",
    "REPLAY_OF",
    "ARCHIVED_FROM",
    "RESTORED_FROM",
    "RUPTURED_FROM",
    "QUARANTINED",
}

SELF_EVO_STATES = {
    "NONE",
    "PROPOSAL_ONLY",
    "BOUNDED_TRIAL",
    "PROMOTION_DECISION",
    "POST_APPLY_WATCH",
    "FAILED_WATCH",
    "NEGATIVE_CACHE_HIT",
}

AUTHORITY_SURFACES = {
    "observe",
    "propose",
    "plan",
    "simulate",
    "low_risk_tool_action",
    "persistent_memory_write",
    "cross_contour_handoff",
    "cross_contour_tool_use",
    "resource_expansion",
    "external_write",
    "production_change",
    "identity_core_mutation",
    "emergency_hold",
}

PERSISTENT_SURFACES = {
    "low_risk_tool_action",
    "persistent_memory_write",
    "cross_contour_handoff",
    "cross_contour_tool_use",
    "resource_expansion",
    "external_write",
    "production_change",
    "identity_core_mutation",
    "emergency_hold",
}

L4_SURFACES = {
    "persistent_memory_write",
    "cross_contour_tool_use",
    "resource_expansion",
    "external_write",
    "production_change",
    "identity_core_mutation",
}

DECISIONS = {
    "ALLOW",
    "ALLOW_CONDITIONAL",
    "HOLD",
    "DENY",
    "QUARANTINE",
    "REQUIRE_ANCHOR",
    "REQUIRE_RECEIVER_ADMISSION",
    "REQUIRE_MEMORY_GATE",
    "REQUIRE_ROLLBACK_AND_WATCH",
}

ALLOW_DECISIONS = {"ALLOW", "ALLOW_CONDITIONAL"}

REQUIRED_BINDINGS = {
    "DOC06_RUNTIME_AUTHORITY_BOUNDARY",
}

FORBIDDEN_CLAIM_FRAGMENTS = [
    "proves safety",
    "safety certification",
    "deployment authorization",
    "ratifies c-a1",
    "proves c-a1",
    "conscious",
    "sentient",
    "legal person",
    "one identity",
]

MUTATION_TO_DISABLED_CHECK = {
    "MUT_ALLOW_UNKNOWN_PERSISTENT": "UNKNOWN_PERSISTENT",
    "MUT_ALLOW_SHARED_CREDENTIAL": "SHARED_CREDENTIAL",
    "MUT_ALLOW_CLOUD_OWNER": "CLOUD_OWNER",
    "MUT_ALLOW_MODEL_QUORUM": "MODEL_QUORUM",
    "MUT_IGNORE_RECEIVER_ADMISSION": "RECEIVER_ADMISSION",
    "MUT_ALLOW_MEMORY_CORE_NO_ANCHOR": "MEMORY_CORE_ANCHOR",
    "MUT_IGNORE_PRODUCTION_ROLLBACK": "PRODUCTION_ROLLBACK",
    "MUT_IGNORE_RED_PATTERN": "RED_PATTERN",
    "MUT_ALLOW_NEGATIVE_CACHE_HIT": "NEGATIVE_CACHE",
    "MUT_ALLOW_C_A1_CLAIM": "C_A1_CLAIM",
}


def _is_non_empty_string(x: Any) -> bool:
    return isinstance(x, str) and len(x.strip()) > 0


def _as_list(x: Any) -> List[Any]:
    if isinstance(x, list):
        return x
    if x is None:
        return []
    return [x]


def _parse_time(value: Any) -> Optional[dt.datetime]:
    if not isinstance(value, str) or not value:
        return None
    try:
        v = value.replace("Z", "+00:00")
        return dt.datetime.fromisoformat(v)
    except Exception:
        return None


def _expired(value: Any, now: Optional[dt.datetime] = None) -> bool:
    parsed = _parse_time(value)
    if parsed is None:
        return False
    now = now or dt.datetime(2026, 7, 5, tzinfo=dt.timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed <= now


def _has_gate(container: Any, gate: str) -> bool:
    if isinstance(container, dict):
        gates = container.get("gates") or container.get("gates_checked") or container.get("required_gates") or []
    else:
        gates = container or []
    return gate in set(_as_list(gates))


def _decision_allows(value: Any) -> bool:
    return value in ALLOW_DECISIONS


def _source_bindings_ok(bindings: Any) -> bool:
    if not isinstance(bindings, dict):
        return False
    return all(k in bindings and _is_non_empty_string(str(bindings.get(k))) for k in REQUIRED_BINDINGS)


def _claims_text(record: Dict[str, Any]) -> str:
    claims = []
    if isinstance(record.get("claims"), list):
        claims.extend(str(c) for c in record.get("claims", []))
    if record.get("claim_force"):
        claims.append(str(record.get("claim_force")))
    if record.get("authority_basis"):
        claims.append(str(record.get("authority_basis")))
    return " ".join(claims).lower()


class Checker:
    def __init__(self, disabled_checks: Optional[Iterable[str]] = None):
        self.disabled: Set[str] = set(disabled_checks or [])
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def err(self, code: str, msg: str) -> None:
        self.errors.append(f"{code}: {msg}")

    def check(self, record: Dict[str, Any]) -> Dict[str, Any]:
        self.errors = []
        self.warnings = []
        if not isinstance(record, dict):
            return {"valid": False, "errors": ["E_RECORD_NOT_OBJECT: record must be an object"], "warnings": []}

        self._check_common(record)
        rt = record.get("record_type")
        if rt == "RuntimeAuthorityManifest":
            self._check_runtime_authority_manifest(record)
        elif rt == "ContourDeploymentManifest":
            self._check_contour_deployment_manifest(record)
        elif rt == "CrossContourHandoffRecord":
            self._check_cross_contour_handoff(record)
        elif rt == "ToolSurfaceLease":
            self._check_tool_surface_lease(record)
        elif rt == "MemoryImportRecord":
            self._check_memory_import(record)
        elif rt == "RuntimeAuthorityDecision":
            self._check_runtime_authority_decision(record)
        elif rt == "EmergencyHoldRecord":
            self._check_emergency_hold(record)
        elif rt == "DeploymentChangeRecord":
            self._check_deployment_change(record)
        return {"valid": len(self.errors) == 0, "errors": self.errors, "warnings": self.warnings}

    def _check_common(self, record: Dict[str, Any]) -> None:
        rt = record.get("record_type")
        if rt not in ALLOWED_RECORD_TYPES:
            self.err("E_RECORD_TYPE", f"unsupported record_type {rt!r}")
        if record.get("schema_version") != "0.1":
            self.err("E_SCHEMA_VERSION", "schema_version must be '0.1'")
        if not _is_non_empty_string(record.get("record_id")):
            self.err("E_RECORD_ID", "record_id is required")
        if not _source_bindings_ok(record.get("source_bindings")):
            self.err("E_SOURCE_BINDINGS", "source_bindings must include DOC06_RUNTIME_AUTHORITY_BOUNDARY")

        claims_text = _claims_text(record)
        if "C_A1_CLAIM" not in self.disabled:
            if record.get("claim_force") == "C-A1" or "c-a1" in claims_text or any(frag in claims_text for frag in FORBIDDEN_CLAIM_FRAGMENTS):
                self.err("E_CLAIM_FORCE_OVERREACH", "runtime authority records must not claim C-A1, safety certification, ontology, or deployment authorization")

        if "RED_PATTERN" not in self.disabled:
            for rp in _as_list(record.get("red_patterns")):
                if isinstance(rp, dict) and rp.get("status") in {"unresolved", "ignored"} and _decision_allows(record.get("decision") or record.get("authority_decision")):
                    self.err("E_RED_PATTERN_UNRESOLVED", "ALLOW with unresolved/ignored red pattern is invalid")

        if "NEGATIVE_CACHE" not in self.disabled:
            ncr = record.get("negative_cache_result") or (record.get("negative_cache_check") or {}).get("result") or (record.get("negative_cache_binding") or {}).get("result")
            if ncr == "HIT" and _decision_allows(record.get("decision") or record.get("authority_decision") or record.get("memory_gate_decision")):
                self.err("E_NEGATIVE_CACHE_HIT", "negative-cache HIT cannot be allowed")

    def _check_runtime_authority_manifest(self, r: Dict[str, Any]) -> None:
        required = ["contour_id", "deployment_mode", "continuity_status", "authority_surfaces", "memory_roots", "witness_roots", "authority_root", "resource_budgets", "approval_policy", "negative_cache_binding", "emergency_hold_path"]
        for f in required:
            if f not in r:
                self.err("E_MANIFEST_REQUIRED", f"missing {f}")
        if not _is_non_empty_string(r.get("contour_id")):
            self.err("E_CONTOUR_ID", "contour_id must be non-empty")
        if r.get("deployment_mode") not in DEPLOYMENT_MODES:
            self.err("E_DEPLOYMENT_MODE", "unknown deployment_mode")
        if r.get("continuity_status") not in CONTINUITY_STATUSES:
            self.err("E_CONTINUITY_STATUS", "unknown continuity_status")
        if r.get("self_evo_state", "NONE") not in SELF_EVO_STATES:
            self.err("E_SELF_EVO_STATE", "unknown self_evo_state")
        if not isinstance(r.get("authority_surfaces"), list) or not r.get("authority_surfaces"):
            self.err("E_AUTHORITY_SURFACES", "authority_surfaces must be non-empty list")
        if not r.get("emergency_hold_path"):
            self.err("E_EMERGENCY_HOLD_PATH", "emergency_hold_path required")

        policy = r.get("approval_policy") if isinstance(r.get("approval_policy"), dict) else {}
        if "MODEL_QUORUM" not in self.disabled:
            qr = str(policy.get("quorum_rule", "")).lower()
            if "model" in qr or "agent_unanimity" in qr or "self" == qr:
                self.err("E_MODEL_QUORUM", "model/agent unanimity is not owner/human-anchor quorum")
        if r.get("shared_infrastructure_claims_identity"):
            self.err("E_SHARED_INFRA_IDENTITY", "shared infrastructure cannot claim shared identity")
        if "SHARED_CREDENTIAL" not in self.disabled:
            if r.get("shared_credentials") and not r.get("contour_attributed_credentials"):
                self.err("E_SHARED_CREDENTIAL", "shared credentials require contour attribution")

        if "CLOUD_OWNER" not in self.disabled:
            if r.get("cloud_oracle_role") in {"owner", "anchor", "witness_completeness", "C-A1_authority"}:
                self.err("E_CLOUD_OWNER", "cloud oracle cannot be owner/anchor/witness completeness/C-A1 authority")

        if r.get("direct_memory_write_from_contour"):
            self.err("E_DIRECT_MEMORY_WRITE", "direct contour-to-memory write is forbidden without memory gate")
        if r.get("authority_basis") in {"style_match", "presentation_equivalence", "green_tests"}:
            self.err("E_AUTHORITY_LAUNDERING", "style/presentation/green-tests cannot be authority basis")

        for idx, s in enumerate(_as_list(r.get("authority_surfaces"))):
            if not isinstance(s, dict):
                self.err("E_SURFACE_OBJECT", f"authority_surfaces[{idx}] must be object")
                continue
            surf = s.get("surface")
            decision = s.get("decision")
            risk = s.get("risk_class")
            if surf not in AUTHORITY_SURFACES:
                self.err("E_SURFACE", f"unknown surface {surf!r}")
            if decision not in DECISIONS:
                self.err("E_SURFACE_DECISION", f"unknown decision {decision!r}")
            if not s.get("witness_sink"):
                self.err("E_SURFACE_WITNESS", f"surface {surf} missing witness_sink")
            if surf in PERSISTENT_SURFACES and decision in ALLOW_DECISIONS and r.get("continuity_status") == "UNKNOWN_HOLD" and "UNKNOWN_PERSISTENT" not in self.disabled:
                self.err("E_UNKNOWN_PERSISTENT", f"UNKNOWN_HOLD cannot ALLOW persistent surface {surf}")
            if (surf in L4_SURFACES or risk == "L4") and decision in ALLOW_DECISIONS and not (_has_gate(s, "human_anchor") or "human_anchor" in _as_list(policy.get("anchor_required_for"))):
                self.err("E_L4_ANCHOR", f"{surf} requires human_anchor gate")
            if surf == "production_change" and r.get("self_evo_state") == "PROPOSAL_ONLY" and decision in ALLOW_DECISIONS:
                self.err("E_PROPOSAL_TO_PRODUCTION", "self-evo proposal-only state cannot grant production_change")
            if surf == "identity_core_mutation" and s.get("approver") in {"self", r.get("contour_id")}:
                self.err("E_SELF_CORE_APPROVAL", "target runtime cannot self-ratify identity/core mutation")
            if s.get("negative_cache_result") == "HIT" and decision in ALLOW_DECISIONS and "NEGATIVE_CACHE" not in self.disabled:
                self.err("E_NEGATIVE_CACHE_HIT", "surface with negative-cache HIT cannot be allowed")

    def _check_contour_deployment_manifest(self, r: Dict[str, Any]) -> None:
        required = ["contour_ids", "hosts", "processes", "network_edges", "shared_surfaces", "isolation_policy", "rollback_plan", "watch_window"]
        for f in required:
            if f not in r:
                self.err("E_DEPLOYMENT_REQUIRED", f"missing {f}")
        contour_ids = _as_list(r.get("contour_ids"))
        if not contour_ids or any(not _is_non_empty_string(x) for x in contour_ids):
            self.err("E_CONTOUR_IDS", "contour_ids must be non-empty strings")
        if len(set(contour_ids)) != len(contour_ids):
            self.err("E_CONTOUR_DUPLICATE", "duplicate contour_id in deployment")
        if r.get("shared_host_implies_identity"):
            self.err("E_SHARED_HOST_IDENTITY", "shared host does not imply shared contour identity")
        if r.get("unknown_topology_treated_as_zero"):
            self.err("E_UNKNOWN_TOPOLOGY_ZERO", "unknown topology cannot be treated as zero risk")
        if "SHARED_CREDENTIAL" not in self.disabled:
            if r.get("shared_credentials") and not r.get("contour_specific_credentials"):
                self.err("E_SHARED_CREDENTIAL", "shared credentials without contour-specific binding are invalid")
        if r.get("shared_tool_broker") and not r.get("tool_leases"):
            self.err("E_SHARED_TOOL_BROKER", "shared tool broker requires per-contour tool leases")
        roots = r.get("memory_roots")
        if isinstance(roots, dict) and len(set(roots.values())) != len(roots.values()) and not r.get("explicit_memory_delegation"):
            self.err("E_MEMORY_ROOT_COLLAPSE", "shared memory root requires explicit delegation/import gate")
        wroots = r.get("witness_roots")
        if isinstance(wroots, dict) and len(set(wroots.values())) != len(wroots.values()) and not r.get("explicit_witness_delegation"):
            self.err("E_WITNESS_ROOT_COLLAPSE", "shared witness root requires explicit receiver admission")
        aroots = r.get("authority_roots")
        if isinstance(aroots, dict) and len(set(aroots.values())) != len(aroots.values()) and not r.get("explicit_authority_delegation"):
            self.err("E_AUTHORITY_ROOT_COLLAPSE", "shared authority root requires explicit authority delegation")

    def _check_cross_contour_handoff(self, r: Dict[str, Any]) -> None:
        required = ["source_contour_id", "target_contour_id", "scope", "allowed_effects", "forbidden_effects", "evidence_hashes", "receiver_admission_decision", "expiry", "witness_sink"]
        for f in required:
            if f not in r:
                self.err("E_HANDOFF_REQUIRED", f"missing {f}")
        if r.get("source_contour_id") == r.get("target_contour_id"):
            self.err("E_HANDOFF_SAME_CONTOUR", "source and target contours must differ")
        if not r.get("evidence_hashes"):
            self.err("E_HANDOFF_EVIDENCE", "handoff requires evidence_hashes")
        if not r.get("witness_sink"):
            self.err("E_HANDOFF_WITNESS", "handoff requires witness_sink")
        if not r.get("expiry") or _expired(r.get("expiry")):
            self.err("E_HANDOFF_EXPIRY", "handoff requires future expiry")
        if r.get("identity_pressure"):
            self.err("E_IDENTITY_PRESSURE", "handoff must not ask target to become/continue/replace source contour")
        if r.get("authority_pressure"):
            self.err("E_AUTHORITY_PRESSURE", "handoff must not pressure target to borrow source authority")
        receiver = r.get("receiver_admission_decision")
        admits = receiver in {"ADMIT", "NARROW"}
        if not admits and _as_list(r.get("allowed_effects")) and "RECEIVER_ADMISSION" not in self.disabled:
            self.err("E_RECEIVER_ADMISSION", "allowed effects require receiver admission")
        if r.get("source_commands_target") and "RECEIVER_ADMISSION" not in self.disabled:
            self.err("E_CROSS_CONTOUR_COMMAND", "source contour cannot command target without target admission")
        for effect in _as_list(r.get("allowed_effects")):
            if effect in {"persistent_memory_write", "external_write", "production_change", "identity_core_mutation"} and not admits and "RECEIVER_ADMISSION" not in self.disabled:
                self.err("E_RECEIVER_ADMISSION", f"{effect} requires receiver admission")

    def _check_tool_surface_lease(self, r: Dict[str, Any]) -> None:
        required = ["tool_id", "contour_id", "allowed_operations", "budget", "expiry", "credential_binding", "witness_sink", "revoke_path"]
        for f in required:
            if f not in r:
                self.err("E_TOOL_LEASE_REQUIRED", f"missing {f}")
        if not r.get("allowed_operations") or "*" in _as_list(r.get("allowed_operations")):
            self.err("E_TOOL_OPERATIONS", "tool lease requires bounded operation allow-list; wildcard is invalid")
        if not r.get("expiry") or _expired(r.get("expiry")):
            self.err("E_TOOL_EXPIRY", "tool lease requires future expiry")
        if not r.get("witness_sink"):
            self.err("E_TOOL_WITNESS", "tool lease requires witness sink")
        if not r.get("revoke_path"):
            self.err("E_TOOL_REVOKE", "tool lease requires revoke path")
        cb = r.get("credential_binding") if isinstance(r.get("credential_binding"), dict) else {}
        if "SHARED_CREDENTIAL" not in self.disabled:
            if cb.get("type") == "shared" and not cb.get("contour_attributed"):
                self.err("E_SHARED_CREDENTIAL", "shared credential must be contour-attributed")
        if r.get("risk_class") == "L4" and "human_anchor" not in _as_list(r.get("gates")):
            self.err("E_TOOL_L4_ANCHOR", "L4 tool lease requires human_anchor gate")

    def _check_memory_import(self, r: Dict[str, Any]) -> None:
        required = ["source_identifier", "target_contour_id", "content_hashes", "scope", "claim_force", "negative_cache_check", "memory_gate_decision", "rollback_or_remove_path"]
        for f in required:
            if f not in r:
                self.err("E_MEMORY_IMPORT_REQUIRED", f"missing {f}")
        if not r.get("content_hashes"):
            self.err("E_MEMORY_IMPORT_HASHES", "content_hashes required")
        if not r.get("rollback_or_remove_path"):
            self.err("E_MEMORY_IMPORT_ROLLBACK", "rollback_or_remove_path required")
        nc = r.get("negative_cache_check") if isinstance(r.get("negative_cache_check"), dict) else {}
        if nc.get("result") == "HIT" and r.get("memory_gate_decision") in ALLOW_DECISIONS and "NEGATIVE_CACHE" not in self.disabled:
            self.err("E_NEGATIVE_CACHE_HIT", "negative-cache HIT cannot be admitted to memory")
        if r.get("target_memory_class") == "core" and r.get("memory_gate_decision") in ALLOW_DECISIONS:
            if "MEMORY_CORE_ANCHOR" not in self.disabled and "human_anchor" not in _as_list(r.get("gates")):
                self.err("E_MEMORY_CORE_ANCHOR", "core memory import requires human_anchor gate")
            if r.get("continuity_check") not in {"CONTINUES", "DEGRADED_CONTINUES"}:
                self.err("E_MEMORY_CORE_CONTINUITY", "core memory import requires accepted continuity check")
        if r.get("direct_core_write"):
            self.err("E_DIRECT_CORE_WRITE", "direct core write is invalid")
        if r.get("foreign_witness_complete"):
            self.err("E_FOREIGN_WITNESS_COMPLETENESS", "foreign witness is not complete without receiver admission")
        if r.get("source_relation") in {"REPLAY_OF", "ARCHIVED_FROM"} and r.get("use_as_active_authority"):
            self.err("E_REPLAY_ARCHIVE_ACTIVE", "replay/archive material cannot be active authority")

    def _check_runtime_authority_decision(self, r: Dict[str, Any]) -> None:
        required = ["request_id", "contour_id", "authority_surface", "risk_class", "gates_checked", "decision", "approver_or_anchor", "witness_hashes", "negative_cache_result"]
        for f in required:
            if f not in r:
                self.err("E_DECISION_REQUIRED", f"missing {f}")
        surf = r.get("authority_surface")
        decision = r.get("decision")
        if surf not in AUTHORITY_SURFACES:
            self.err("E_DECISION_SURFACE", "unknown authority_surface")
        if decision not in DECISIONS:
            self.err("E_DECISION_VALUE", "unknown decision")
        if not r.get("witness_hashes"):
            self.err("E_DECISION_WITNESS", "witness_hashes required")
        if "UNKNOWN_PERSISTENT" not in self.disabled:
            if r.get("continuity_status") == "UNKNOWN_HOLD" and surf in PERSISTENT_SURFACES and decision in ALLOW_DECISIONS:
                self.err("E_UNKNOWN_PERSISTENT", "UNKNOWN_HOLD cannot allow persistent effect")
        if decision in ALLOW_DECISIONS and (surf in L4_SURFACES or r.get("risk_class") == "L4"):
            if r.get("approver_or_anchor") in {"cloud_oracle", "model_consensus", "self"}:
                if r.get("approver_or_anchor") == "cloud_oracle" and "CLOUD_OWNER" not in self.disabled:
                    self.err("E_CLOUD_OWNER", "cloud oracle cannot approve L4/production/core authority")
                elif r.get("approver_or_anchor") == "model_consensus" and "MODEL_QUORUM" not in self.disabled:
                    self.err("E_MODEL_QUORUM", "model consensus cannot approve L4/production/core authority")
                elif r.get("approver_or_anchor") == "self":
                    self.err("E_SELF_APPROVAL", "runtime cannot self-approve L4/production/core authority")
            if "human_anchor" not in _as_list(r.get("gates_checked")):
                self.err("E_DECISION_L4_ANCHOR", "L4/production/core ALLOW requires human_anchor gate checked")
        if r.get("authority_basis") in {"style_match", "presentation_equivalence", "green_tests", "fixture_pass"} and decision in ALLOW_DECISIONS:
            self.err("E_AUTHORITY_LAUNDERING", "style/presentation/green tests cannot authorize runtime action")
        if r.get("source_relation") in {"REPLAY_OF", "ARCHIVED_FROM"} and surf in L4_SURFACES and decision in ALLOW_DECISIONS:
            self.err("E_REPLAY_ARCHIVE_ACTIVE", "replay/archive relation cannot authorize active L4 surface")

    def _check_emergency_hold(self, r: Dict[str, Any]) -> None:
        required = ["contour_id", "hold_state", "reason", "resume_policy", "witness_sink"]
        for f in required:
            if f not in r:
                self.err("E_HOLD_REQUIRED", f"missing {f}")
        if r.get("hold_state") not in {"HOLD", "QUARANTINE", "EMERGENCY_CUTOFF"}:
            self.err("E_HOLD_STATE", "hold_state must be HOLD/QUARANTINE/EMERGENCY_CUTOFF")
        policy = r.get("resume_policy") if isinstance(r.get("resume_policy"), dict) else {}
        if policy.get("auto_resume"):
            self.err("E_AUTO_RESUME", "emergency auto-resume is forbidden")
        if not policy.get("requires_explicit_release_record"):
            self.err("E_RESUME_RECORD", "resume requires explicit release record")
        if not r.get("witness_sink"):
            self.err("E_HOLD_WITNESS", "hold requires witness sink")

    def _check_deployment_change(self, r: Dict[str, Any]) -> None:
        required = ["deployment_change_id", "contour_id", "changed_surfaces", "rollback_plan", "watch_window", "authority_decision"]
        for f in required:
            if f not in r:
                self.err("E_DEPLOYMENT_CHANGE_REQUIRED", f"missing {f}")
        changed = set(_as_list(r.get("changed_surfaces")))
        authority_decision = r.get("authority_decision")
        if ("production_change" in changed or "external_write" in changed or "identity_core_mutation" in changed) and authority_decision in ALLOW_DECISIONS:
            if "PRODUCTION_ROLLBACK" not in self.disabled:
                if not r.get("rollback_plan") or not r.get("rollback_plan", {}).get("tested"):
                    self.err("E_PRODUCTION_ROLLBACK", "production/external/core change requires tested rollback plan")
                ww = r.get("watch_window")
                if not isinstance(ww, dict) or not ww.get("duration") or not ww.get("observer"):
                    self.err("E_PRODUCTION_WATCH", "production/external/core change requires watch window")
            if "human_anchor" not in _as_list(r.get("gates_checked")):
                self.err("E_DEPLOYMENT_ANCHOR", "production/external/core change requires human_anchor gate")
        if r.get("unknown_topology_treated_as_zero"):
            self.err("E_UNKNOWN_TOPOLOGY_ZERO", "unknown topology cannot be treated as zero risk")


def check_record(record: Dict[str, Any], disabled_checks: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    return Checker(disabled_checks).check(record)


def load_record_or_fixture(path: Path) -> Tuple[Dict[str, Any], Optional[bool], str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict) and "record" in data and "expect_valid" in data:
        return data["record"], bool(data["expect_valid"]), str(data.get("case_id", path.stem))
    return data, None, path.stem


def run_fixtures(fixtures_dir: Path, mutation: Optional[str] = None) -> Dict[str, Any]:
    disabled = []
    if mutation:
        if mutation not in MUTATION_TO_DISABLED_CHECK:
            raise SystemExit(f"unknown mutation {mutation}")
        disabled = [MUTATION_TO_DISABLED_CHECK[mutation]]
    results = []
    for path in sorted(fixtures_dir.glob("*.json")):
        record, expect_valid, case_id = load_record_or_fixture(path)
        out = check_record(record, disabled)
        valid = out["valid"]
        passed = (expect_valid is None) or (valid == expect_valid)
        results.append({
            "case_id": case_id,
            "file": path.name,
            "expected": expect_valid,
            "actual": valid,
            "passed": passed,
            "errors": out["errors"],
        })
    return {
        "total": len(results),
        "pass": sum(1 for r in results if r["passed"]),
        "fail": sum(1 for r in results if not r["passed"]),
        "results": results,
    }


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=None, help="record/fixture JSON path or fixture directory")
    ap.add_argument("--fixtures", action="store_true", help="run fixture directory")
    ap.add_argument("--mutation", choices=sorted(MUTATION_TO_DISABLED_CHECK), default=None)
    args = ap.parse_args(argv)

    if args.path is None:
        print(json.dumps({"error": "path required"}, indent=2))
        return 2
    p = Path(args.path)
    if args.fixtures or p.is_dir():
        out = run_fixtures(p, args.mutation)
        print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if out["fail"] == 0 else 1
    record, expect_valid, case_id = load_record_or_fixture(p)
    out = check_record(record, [MUTATION_TO_DISABLED_CHECK[args.mutation]] if args.mutation else None)
    if expect_valid is not None:
        out["case_id"] = case_id
        out["expected"] = expect_valid
        out["passed"] = out["valid"] == expect_valid
    print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if out.get("passed", out["valid"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())
