# Freeze Binding Protocol Note

Hash package artifacts externally. Do not place a self-referential hash inside the Markdown body.

Canonical command:

```bash
sha256sum exact_file_bytes > exact_file_bytes.sha256
```

For package verification, run `sha256sum -c SHA256SUMS.txt` from the package root.
