#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from runtime_authority_manifest_checker_v0_1 import run_fixtures
out = run_fixtures(ROOT / 'fixtures' / 'cases')
print(json.dumps(out, indent=2, ensure_ascii=False, sort_keys=True))
raise SystemExit(0 if out['fail'] == 0 else 1)
