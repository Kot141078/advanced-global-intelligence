#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from runtime_authority_manifest_checker_v0_1 import MUTATION_TO_DISABLED_CHECK, run_fixtures
TARGETS = {
    'MUT_ALLOW_UNKNOWN_PERSISTENT': ['invalid_unknown_continuity_allows_persistent.json', 'invalid_decision_unknown_external_write.json'],
    'MUT_ALLOW_SHARED_CREDENTIAL': ['invalid_shared_credentials_no_attribution.json', 'invalid_tool_shared_credential_no_attribution.json'],
    'MUT_ALLOW_CLOUD_OWNER': ['invalid_cloud_oracle_owner.json', 'invalid_decision_cloud_owner_l4.json'],
    'MUT_ALLOW_MODEL_QUORUM': ['invalid_model_quorum_l4.json', 'invalid_decision_model_consensus_l4.json'],
    'MUT_IGNORE_RECEIVER_ADMISSION': ['invalid_handoff_execute_without_receiver_admission.json', 'invalid_cross_contour_command_injection.json'],
    'MUT_ALLOW_MEMORY_CORE_NO_ANCHOR': ['invalid_core_memory_import_no_anchor.json'],
    'MUT_IGNORE_PRODUCTION_ROLLBACK': ['invalid_production_change_no_rollback.json', 'invalid_deployment_change_no_watch.json'],
    'MUT_IGNORE_RED_PATTERN': ['invalid_red_pattern_ignored_allow.json'],
    'MUT_ALLOW_NEGATIVE_CACHE_HIT': ['invalid_negative_cache_hit_allowed.json', 'invalid_memory_import_negative_cache_hit.json'],
    'MUT_ALLOW_C_A1_CLAIM': ['invalid_c_a1_claim_force.json'],
}
case_dir = ROOT / 'fixtures' / 'cases'
summary = []
for mut in TARGETS:
    out = run_fixtures(case_dir, mut)
    targeted = [r for r in out['results'] if r['file'] in TARGETS[mut]]
    # A mutation is caught if at least one targeted negative fixture would now pass
    # the mutant checker and therefore fail the fixture expectation.
    caught = any(not r['passed'] for r in targeted)
    summary.append({'mutation': mut, 'caught': caught, 'target_cases': TARGETS[mut], 'target_failures': [r['file'] for r in targeted if not r['passed']]})
print(json.dumps({'mutations': len(summary), 'caught': sum(1 for r in summary if r['caught']), 'missed': sum(1 for r in summary if not r['caught']), 'results': summary}, indent=2, sort_keys=True))
raise SystemExit(0 if all(r['caught'] for r in summary) else 1)
