# CCALC Runtime Authority Manifest 06a v0.1

Executable checker seed and schema seed for `06_C_RUNTIME_AUTHORITY_AND_MULTI_CONTOUR_DEPLOYMENT_BOUNDARY_v0_1`.

## Run

```bash
python3 scripts/run_runtime_authority_fixtures.py
python3 scripts/run_runtime_authority_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Binding

Parent `06` package SHA-256:

```text
863d187d9631214bd891ffaf262d869305a111e52752944f8b110418b9d81dff
```

## Status

```text
checker seed
schema seed
fixture-bound
not deployment authorization
```
