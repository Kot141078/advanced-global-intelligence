# Open Issues and Next Steps — 06a v0.1

## Closed here

```text
RuntimeAuthorityManifest seed schema
ContourDeploymentManifest seed schema
CrossContourHandoffRecord seed schema
ToolSurfaceLease seed schema
MemoryImportRecord seed schema
RuntimeAuthorityDecision seed schema
EmergencyHoldRecord seed schema
DeploymentChangeRecord seed schema
stdlib checker seed
fixture pack
mutation harness
```

## Still open for 06b+

```text
larger handoff/tool-lease fixture expansion
credential lease scanner over real runtime logs
network edge scanner
hold/quarantine/resume drill runner
production watch integration with 05d live records
```
