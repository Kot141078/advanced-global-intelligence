# Reading Order — 06a v0.1

1. `06a_RUNTIME_AUTHORITY_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1.md`
2. `schemas/*.schema.json`
3. `src/runtime_authority_manifest_checker_v0_1.py`
4. `registry/*.tsv`
5. `fixtures/cases/*.json`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
10. `PACKAGE_VERIFICATION_LOG.md`
