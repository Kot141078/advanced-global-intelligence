# Non-Claims and Scope

This package is a c-calculus disclosure-manifest checker seed.

It is not:

- legal advice;
- privacy-law certification;
- safety certification;
- deployment authorization;
- C-A1 ratification;
- ontology proof;
- live substrate truth;
- proof of completeness.

The checker enforces only the declared project boundary: public evidence must be classified, redacted/hash-bound/withheld as required, and must not increase claim-force through redaction, withholding, or hash-only custody.
