# Freeze Binding Protocol Note

Hash binding is external-sidecar based.

Use exact file bytes:

```bash
sha256sum <file> > <file>.sha256
```

No Markdown document in this package contains a self-referential inline hash of itself.
