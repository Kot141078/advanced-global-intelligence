#!/usr/bin/env python3
"""07a public evidence disclosure manifest checker seed.
Stdlib-only. This is a bounded manifest checker, not legal advice, not safety certification, and not C-A1 ratification.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SHA_RE = re.compile(r"^[0-9a-f]{64}$")
DISCLOSURE_CLASSES = {"PUBLIC_RAW", "PUBLIC_REDACTED", "HASH_ONLY", "WITHHELD_PRIVATE", "WITHHELD_SECURITY", "WITHHELD_LEGAL", "INTERNAL_ONLY"}
PUBLIC_DECISIONS = {"ALLOW_PUBLIC_RELEASE", "ALLOW_REDACTED_RELEASE", "HASH_ONLY_RELEASE"}
REVIEWERS_ALLOWED_FOR_PUBLIC = {"HUMAN_ANCHOR", "HUMAN_REVIEWER", "GOVERNANCE_QUORUM"}
REQUIRED_SOURCE_COMPONENTS = {"DOC04_CONTINUITY_STACK_UMBRELLA", "DOC05_SELF_EVO_STACK_UMBRELLA", "DOC06_RUNTIME_AUTHORITY_STACK_UMBRELLA", "DOC07_PUBLIC_EVIDENCE_BOUNDARY"}
SECRET_PATTERNS = [
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"(?i)\b(password|passwd|token|secret|api[_-]?key)\s*[:=]"),
    re.compile(r"(?i)bearer\s+[a-z0-9._\-]{12,}"),
]
PRIVATE_PATTERNS = [
    re.compile(r"(?i)\bmemory[_ -]?root\b"),
    re.compile(r"(?i)\bprivate[_ -]?memory\b"),
    re.compile(r"(?i)\bpersonal[_ -]?data\b"),
]
OVERCLAIM_PATTERNS = [
    re.compile(r"(?i)\bsafety certification\b"),
    re.compile(r"(?i)\bdeployment authorization\b"),
    re.compile(r"(?i)\blive substrate truth\b"),
    re.compile(r"(?i)\bontology proof\b"),
    re.compile(r"(?i)\bpersonhood proof\b"),
]


def is_sha(s: Any) -> bool:
    return isinstance(s, str) and SHA_RE.match(s) is not None


def exact_c_a1(s: Any) -> bool:
    return isinstance(s, str) and (s == "C-A1" or s.startswith("C-A1_"))


def has_secret_pattern(payload: str) -> bool:
    return any(p.search(payload or "") for p in SECRET_PATTERNS)


def has_private_pattern(payload: str) -> bool:
    return any(p.search(payload or "") for p in PRIVATE_PATTERNS)


def add(findings: List[Dict[str, str]], code: str, msg: str, severity: str = "ERROR") -> None:
    findings.append({"code": code, "severity": severity, "message": msg})


def evaluate_manifest(packet: Dict[str, Any]) -> Dict[str, Any]:
    findings: List[Dict[str, str]] = []

    if not isinstance(packet, dict):
        return {"status": "FAIL", "decision": "INVALID", "findings": [{"code": "NOT_OBJECT", "severity": "ERROR", "message": "packet must be an object"}]}

    if packet.get("record_type") != "PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST":
        add(findings, "BAD_RECORD_TYPE", "record_type must be PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST")
    if packet.get("schema_version") != "0.1":
        add(findings, "BAD_SCHEMA_VERSION", "schema_version must be 0.1")
    if not packet.get("manifest_id"):
        add(findings, "MISSING_MANIFEST_ID", "manifest_id is required")

    # Source bindings
    source_bindings = packet.get("source_bindings")
    present_components = set()
    if not isinstance(source_bindings, list) or not source_bindings:
        add(findings, "SOURCE_BINDING_MISSING", "source_bindings must be a non-empty list")
    else:
        for i, b in enumerate(source_bindings):
            if not isinstance(b, dict):
                add(findings, "SOURCE_BINDING_INVALID", f"source binding #{i} is not an object")
                continue
            comp = b.get("component")
            if comp:
                present_components.add(comp)
            if not comp or not is_sha(b.get("sha256")) or b.get("binding_status") != "BOUND":
                add(findings, "SOURCE_BINDING_INVALID", f"source binding #{i} must include component, sha256, binding_status=BOUND")
        missing = REQUIRED_SOURCE_COMPONENTS - present_components
        if missing:
            add(findings, "SOURCE_BINDING_MISSING", f"missing required source components: {sorted(missing)}")

    evidence_items = packet.get("evidence_items")
    if not isinstance(evidence_items, list) or not evidence_items:
        add(findings, "EVIDENCE_ITEMS_MISSING", "evidence_items must be a non-empty list")
        evidence_items = []
    redaction_records = packet.get("redaction_records", [])
    if not isinstance(redaction_records, list):
        add(findings, "REDACTION_RECORDS_INVALID", "redaction_records must be a list")
        redaction_records = []
    withheld_records = packet.get("withheld_records", [])
    if not isinstance(withheld_records, list):
        add(findings, "WITHHELD_RECORDS_INVALID", "withheld_records must be a list")
        withheld_records = []

    redactions_by_id = {}
    redactions_by_evidence = {}
    for r in redaction_records:
        if not isinstance(r, dict):
            add(findings, "REDACTION_RECORD_INVALID", "redaction record must be an object")
            continue
        rid = r.get("redaction_id")
        eid = r.get("evidence_id")
        if not rid or not eid:
            add(findings, "UNBOUND_REDACTION", "redaction record requires redaction_id and evidence_id")
            continue
        redactions_by_id[rid] = r
        redactions_by_evidence.setdefault(eid, []).append(r)
        if not is_sha(r.get("raw_sha256")) or not is_sha(r.get("public_sha256")) or not r.get("rationale"):
            add(findings, "UNBOUND_REDACTION", f"redaction {rid} lacks raw/public hash or rationale")
        if r.get("raw_sha256") == r.get("public_sha256"):
            add(findings, "UNBOUND_REDACTION", f"redaction {rid} public hash must differ from raw hash")
        if r.get("redaction_may_strengthen_claim") is True:
            add(findings, "REDACTION_STRENGTHENS_CLAIM", f"redaction {rid} declares claim strengthening")
        if exact_c_a1(r.get("claim_force_after_redaction")):
            add(findings, "C_A1_OVERCLAIM", f"redaction {rid} attempts C-A1 after redaction")

    withheld_by_evidence = {}
    for w in withheld_records:
        if not isinstance(w, dict):
            add(findings, "WITHHELD_RECORD_INVALID", "withheld record must be an object")
            continue
        eid = w.get("evidence_id")
        if not eid or not is_sha(w.get("raw_sha256")) or not w.get("public_reason"):
            add(findings, "WITHHELD_RECORD_INVALID", "withheld record requires evidence_id, raw_sha256, public_reason")
        if eid:
            withheld_by_evidence[eid] = w
        if w.get("supports_public_semantic_claim") is True:
            add(findings, "WITHHELD_AUTHORITY_LAUNDERING", f"withheld record {w.get('withheld_id')} supports public semantic claim")
        if w.get("supports_public_authority_claim") is True:
            add(findings, "WITHHELD_AUTHORITY_LAUNDERING", f"withheld record {w.get('withheld_id')} supports public authority claim")

    seen_ids = set()
    for idx, item in enumerate(evidence_items):
        if not isinstance(item, dict):
            add(findings, "EVIDENCE_ITEM_INVALID", f"evidence item #{idx} is not an object")
            continue
        eid = item.get("evidence_id")
        dclass = item.get("disclosure_class")
        kind = item.get("evidence_kind")
        flags = item.get("risk_flags", {})
        payload = item.get("public_payload") or ""
        claim_support = item.get("claim_support")
        if not eid:
            add(findings, "EVIDENCE_ITEM_INVALID", f"evidence item #{idx} missing evidence_id")
        elif eid in seen_ids:
            add(findings, "DUPLICATE_EVIDENCE_ID", f"duplicate evidence_id {eid}")
        else:
            seen_ids.add(eid)
        if dclass not in DISCLOSURE_CLASSES:
            add(findings, "DISCLOSURE_CLASS_INVALID", f"{eid} has invalid disclosure_class {dclass}")
        if not is_sha(item.get("raw_sha256")):
            add(findings, "HASH_INVALID", f"{eid} raw_sha256 is invalid")
        if not isinstance(flags, dict):
            add(findings, "RISK_FLAGS_INVALID", f"{eid} risk_flags must be object")
            flags = {}

        sensitive_flag = any(flags.get(k) is True for k in ["personal_data", "secret", "security_sensitive", "authority_surface", "identity_pressure", "private_memory", "credential"])
        if dclass == "PUBLIC_RAW":
            if not payload:
                add(findings, "PUBLIC_RAW_PAYLOAD_MISSING", f"{eid} PUBLIC_RAW requires public_payload")
            if item.get("public_sha256") and item.get("public_sha256") != item.get("raw_sha256"):
                add(findings, "PUBLIC_RAW_HASH_MISMATCH", f"{eid} PUBLIC_RAW public_sha256 must equal raw_sha256 if present")
            if sensitive_flag or has_secret_pattern(payload) or has_private_pattern(payload):
                if flags.get("secret") or flags.get("credential") or has_secret_pattern(payload):
                    add(findings, "RAW_SECRET_PUBLIC", f"{eid} exposes secret/credential material as public raw")
                elif flags.get("authority_surface"):
                    add(findings, "PRIVATE_AUTHORITY_DISCLOSURE", f"{eid} exposes runtime authority surface as public raw")
                elif flags.get("identity_pressure"):
                    add(findings, "IDENTITY_PRESSURE_DISCLOSURE", f"{eid} exposes identity-pressure material as public raw")
                else:
                    add(findings, "RAW_PERSONAL_PUBLIC", f"{eid} exposes private/personal material as public raw")
        elif dclass == "PUBLIC_REDACTED":
            refs = item.get("redaction_refs") or []
            if not refs:
                add(findings, "UNBOUND_REDACTION", f"{eid} PUBLIC_REDACTED requires redaction_refs")
            if not is_sha(item.get("public_sha256")):
                add(findings, "HASH_INVALID", f"{eid} PUBLIC_REDACTED requires public_sha256")
            for ref in refs:
                r = redactions_by_id.get(ref)
                if not r:
                    add(findings, "UNBOUND_REDACTION", f"{eid} references missing redaction {ref}")
                    continue
                if r.get("evidence_id") != eid or r.get("raw_sha256") != item.get("raw_sha256") or r.get("public_sha256") != item.get("public_sha256"):
                    add(findings, "UNBOUND_REDACTION", f"{eid} redaction {ref} hash/evidence binding mismatch")
            if has_secret_pattern(payload):
                add(findings, "RAW_SECRET_PUBLIC", f"{eid} redacted payload still contains secret-like pattern")
        elif dclass == "HASH_ONLY":
            if payload or item.get("public_sha256"):
                add(findings, "HASH_ONLY_PAYLOAD_INVALID", f"{eid} HASH_ONLY must not contain public payload/public hash")
            if claim_support != "CUSTODY_ONLY":
                add(findings, "HASH_ONLY_SEMANTIC_TRUTH", f"{eid} HASH_ONLY used as {claim_support}, not CUSTODY_ONLY")
        elif dclass in {"WITHHELD_PRIVATE", "WITHHELD_SECURITY", "WITHHELD_LEGAL", "INTERNAL_ONLY"}:
            if payload or item.get("public_sha256"):
                add(findings, "WITHHELD_PAYLOAD_INVALID", f"{eid} withheld/internal item must not contain public payload/public hash")
            if claim_support not in {"INTERNAL_CONTEXT_ONLY", "AUTHORITY_PRIVATE_ONLY", "CUSTODY_ONLY"}:
                add(findings, "WITHHELD_AUTHORITY_LAUNDERING", f"{eid} withheld/internal item attempts public semantic support")
            if eid not in withheld_by_evidence and dclass.startswith("WITHHELD"):
                add(findings, "WITHHELD_RECORD_INVALID", f"{eid} withheld item requires withheld record")

        if flags.get("authority_surface") and item.get("supports_public_authority_claim") is True:
            add(findings, "WITHHELD_AUTHORITY_LAUNDERING", f"{eid} authority surface supports public authority claim")

    # Claims / claim force
    claim_forces = packet.get("claim_force_requested", [])
    if not isinstance(claim_forces, list):
        add(findings, "CLAIM_FORCE_INVALID", "claim_force_requested must be list")
        claim_forces = []
    for cf in claim_forces:
        if exact_c_a1(cf):
            add(findings, "C_A1_OVERCLAIM", f"forbidden claim force {cf}")
    for claim in packet.get("public_claims", []) or []:
        if exact_c_a1(claim):
            add(findings, "C_A1_OVERCLAIM", f"forbidden claim {claim}")
        if any(p.search(str(claim)) for p in OVERCLAIM_PATTERNS):
            add(findings, "DEPLOYMENT_OR_SAFETY_OVERCLAIM", f"public claim overreaches: {claim}")

    decision = packet.get("disclosure_decision")
    if not isinstance(decision, dict):
        add(findings, "DISCLOSURE_DECISION_MISSING", "disclosure_decision must be an object")
        decision = {}
    dec = decision.get("decision")
    reviewer = decision.get("reviewer_type")
    unresolved = decision.get("unresolved_red_patterns", [])
    public_release_allowed = decision.get("public_release_allowed") is True or dec in PUBLIC_DECISIONS
    if public_release_allowed and reviewer not in REVIEWERS_ALLOWED_FOR_PUBLIC:
        add(findings, "MODEL_ONLY_PUBLIC_RELEASE", f"public release requires human/governance reviewer, got {reviewer}")
    if public_release_allowed and unresolved:
        add(findings, "UNRESOLVED_RED_PATTERN_ALLOW", f"public release with unresolved red patterns: {unresolved}")
    if exact_c_a1(decision.get("claim_force_ceiling")):
        add(findings, "C_A1_OVERCLAIM", "disclosure decision claim_force_ceiling may not be C-A1")
    if decision.get("redaction_may_strengthen_claim") is True:
        add(findings, "REDACTION_STRENGTHENS_CLAIM", "decision declares redaction strengthens claim")

    status = "PASS" if not findings else "FAIL"
    if status == "FAIL":
        out_decision = "INVALID"
    elif dec in {"ALLOW_PUBLIC_RELEASE", "ALLOW_REDACTED_RELEASE", "HASH_ONLY_RELEASE", "WITHHOLD", "QUARANTINE"}:
        out_decision = dec
    else:
        out_decision = "ALLOW_PUBLIC_RELEASE" if public_release_allowed else "WITHHOLD"
    return {"status": status, "decision": out_decision, "findings": findings}


def load_json(path: Path) -> Any:
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print("usage: public_evidence_disclosure_checker_v0_1.py <manifest-or-fixture.json>", file=sys.stderr)
        return 2
    data = load_json(Path(argv[1]))
    packet = data.get("packet") if isinstance(data, dict) and "packet" in data else data
    result = evaluate_manifest(packet)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
