# CCALC_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST_07a_v0_1

`07a` provides public evidence disclosure manifest schemas, a stdlib checker seed, fixtures, mutation probes, and source bindings to the `04`/`05`/`06`/`07` stacks.

## Run

```bash
python3 scripts/run_public_evidence_fixtures.py
python3 scripts/run_public_evidence_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Status

Normative-supporting checker seed. Not legal advice, not safety certification, not deployment authorization, not C-A1 ratification.
