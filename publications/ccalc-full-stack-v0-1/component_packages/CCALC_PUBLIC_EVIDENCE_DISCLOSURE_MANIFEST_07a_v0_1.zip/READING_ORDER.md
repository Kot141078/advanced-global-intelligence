# Reading Order

1. `07_C_PUBLIC_EVIDENCE_DISCLOSURE_AND_REDACTION_BOUNDARY_v0_1.md`
2. `07a_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1.md`
3. `schemas/*.schema.json`
4. `src/public_evidence_disclosure_checker_v0_1.py`
5. `fixtures/cases/*.json`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
