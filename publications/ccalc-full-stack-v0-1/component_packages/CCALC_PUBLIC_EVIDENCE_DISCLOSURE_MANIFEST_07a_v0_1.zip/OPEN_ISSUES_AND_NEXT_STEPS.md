# Open Issues and Next Steps

## Open

1. Jurisdiction-specific legal/privacy review remains external to this checker.
2. Automated semantic redaction quality is not certified by this seed.
3. Image/audio/video redaction requires media-specific future fixtures.
4. Public website/repository release pipeline integration remains a later layer.

## Next natural layer

`07b_PUBLIC_RELEASE_BUNDLE_AND_HASH_CUSTODY_AUDIT_v0_1`

Purpose: bind the disclosure manifest to an actual public release bundle and verify that every public file, redacted derivative, withheld placeholder, and hash-only record is consistently represented in the released archive/site/repository surface.
