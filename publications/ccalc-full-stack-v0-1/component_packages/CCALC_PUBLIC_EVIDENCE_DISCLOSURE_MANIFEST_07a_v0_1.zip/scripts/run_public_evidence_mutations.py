#!/usr/bin/env python3
from __future__ import annotations
import csv, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from public_evidence_disclosure_checker_v0_1 import evaluate_manifest

def main() -> int:
    probes_dir = ROOT/'fixtures'/'mutation_probes'
    rows=[]; missed=0
    for path in sorted(probes_dir.glob('*.json')):
        data=json.loads(path.read_text(encoding='utf-8'))
        res=evaluate_manifest(data['packet'])
        expected=data['expected_status']
        code=data.get('expected_finding','')
        codes=','.join(f['code'] for f in res['findings'])
        caught = (res['status']==expected) and (not code or code in codes)
        rows.append({
            'mutation_id': data['mutation_id'],
            'file': path.name,
            'expected_status': expected,
            'actual_status': res['status'],
            'expected_finding': code,
            'finding_codes': codes,
            'result': 'CAUGHT' if caught else 'MISSED'
        })
        if not caught: missed += 1
    out=ROOT/'MUTATION_MATRIX.tsv'
    with out.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter='\t')
        writer.writeheader(); writer.writerows(rows)
    print(f"mutations: {len(rows)}  CAUGHT: {len(rows)-missed}  MISSED: {missed}")
    return 1 if missed else 0
if __name__=='__main__':
    raise SystemExit(main())
