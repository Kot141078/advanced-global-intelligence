#!/usr/bin/env python3
from __future__ import annotations
import csv, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from public_evidence_disclosure_checker_v0_1 import evaluate_manifest

def main() -> int:
    cases_dir = ROOT/'fixtures'/'cases'
    rows = []
    failed = 0
    for path in sorted(cases_dir.glob('*.json')):
        data = json.loads(path.read_text(encoding='utf-8'))
        result = evaluate_manifest(data['packet'])
        exp_status = data['expected_status']
        exp_decision = data.get('expected_decision')
        ok = (result['status'] == exp_status) and (exp_decision is None or result['decision'] == exp_decision)
        codes = ','.join(f['code'] for f in result['findings'])
        if data.get('expected_finding') and data['expected_finding'] not in codes:
            ok = False
        rows.append({
            'case_id': data['case_id'],
            'file': path.name,
            'expected_status': exp_status,
            'actual_status': result['status'],
            'expected_decision': exp_decision or '',
            'actual_decision': result['decision'],
            'expected_finding': data.get('expected_finding',''),
            'finding_codes': codes,
            'result': 'PASS' if ok else 'FAIL',
        })
        if not ok:
            failed += 1
    out = ROOT/'FIXTURE_RESULTS.tsv'
    with out.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter='\t')
        writer.writeheader(); writer.writerows(rows)
    print(f"fixtures: {len(rows)}  PASS: {len(rows)-failed}  FAIL: {failed}")
    return 1 if failed else 0
if __name__ == '__main__':
    raise SystemExit(main())
