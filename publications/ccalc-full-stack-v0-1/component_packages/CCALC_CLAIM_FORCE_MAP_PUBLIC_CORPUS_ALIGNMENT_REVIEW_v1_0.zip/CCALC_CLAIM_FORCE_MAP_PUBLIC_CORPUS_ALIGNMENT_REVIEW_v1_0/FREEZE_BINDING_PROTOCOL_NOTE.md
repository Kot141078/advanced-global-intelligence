# Freeze Binding Protocol Note

Sidecar SHA-256 files bind each Markdown / JSON / TSV artifact by hashing the exact UTF-8 bytes of the file. This avoids self-referential inline-hash instability.
