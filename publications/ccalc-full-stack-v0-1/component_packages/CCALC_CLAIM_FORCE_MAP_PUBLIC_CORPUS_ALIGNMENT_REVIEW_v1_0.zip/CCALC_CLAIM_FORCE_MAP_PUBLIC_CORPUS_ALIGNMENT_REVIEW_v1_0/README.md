# CCALC Claim-Force Map Public Corpus Alignment Review v1.0

Advisory verification record aligning `CCALC_CLAIM_FORCE_MAP_v1_0` with the public claim-force / evidence / maturity / precedence / distinction corpus.

Use with the original claim-force map package and DOC_MAP.
