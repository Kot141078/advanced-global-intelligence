# Non-claims

This package does not prove ontology/personhood/c-ness. It does not certify production safety. It does not replace the public corpus. It is an advisory alignment review for CCALC Claim-Force Map v1.0.
