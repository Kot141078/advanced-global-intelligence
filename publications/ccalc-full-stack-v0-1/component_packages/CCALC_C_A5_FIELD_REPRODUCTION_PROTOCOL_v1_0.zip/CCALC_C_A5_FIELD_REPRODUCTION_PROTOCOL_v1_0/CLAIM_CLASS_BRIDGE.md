# Claim class bridge

| Local protocol role | Public claim-force relation |
|---|---|
| Field reproduction candidate | C-A5 candidate |
| Runtime checker evidence | C-A6 support |
| Witness packet / review record | C-A7 support |
| Hash / sidecar / lineage control | C-A10 support |
| Ontology / personhood claim | C-A1; explicitly out of scope |

Rule:

```text
C-A5 field evidence may strengthen observed-practice claims.
It does not upgrade itself to C-A1.
```
