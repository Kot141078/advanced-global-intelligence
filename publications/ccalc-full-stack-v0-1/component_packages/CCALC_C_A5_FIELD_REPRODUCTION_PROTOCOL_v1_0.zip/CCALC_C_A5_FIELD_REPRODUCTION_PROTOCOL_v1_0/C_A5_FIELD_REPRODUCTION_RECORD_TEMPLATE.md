# C-A5 Field Reproduction Record Template v0.1

```yaml
record_id: FIELD_REPRODUCTION_YYYYMMDD_<short>
record_class: c_a5_field_reproduction_candidate
claim_force_requested: C-A5_CANDIDATE
review_status: draft | submitted | challenged | accepted | rejected | quarantined

independent_anchor:
  anchor_id: ""
  anchor_signature_route: ""
  non_emulation_statement: ""

independent_substrate:
  substrate_id: ""
  environment_manifest_hash: ""
  public_artifact_basis:
    - artifact_id: ""
      sha256: ""
  private_state_exclusions:
    - ""

governed_binding:
  c_binding_certificate_hash: ""
  governance_profile_hash: ""
  anchor_signature_envelope_hash: ""

transition_run:
  start_logical_time: ""
  end_logical_time: ""
  transition_count: 0
  transition_ledger_hash: ""
  state_hash_chain_root: ""
  challenge_events:
    - event_id: ""
      event_class: ""
      result: ""

checker_evidence:
  checker_name: ""
  checker_version: ""
  checker_archive_sha256: ""
  execution_log_hash: ""

witness_evidence:
  witness_record_hashes: []
  unresolved_challenges: []

claim_force:
  supports: [C-A5, C-A6, C-A7, C-A10]
  does_not_support: [C-A1, personhood, consciousness, legal_status, production_safety]
```
