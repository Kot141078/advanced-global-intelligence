# Public registration statement template

Use this when publishing a C-A5 candidate record.

```text
We submit this package as a C-A5 field reproduction candidate for the c=a+b governance architecture.

The package contains independent anchor, substrate, binding, transition, checker, and witness records.

The claim is limited:
- it supports an observed-protocol / practice-derived stability candidate within declared conditions;
- it does not prove personhood, consciousness, legal status, ontology, or production safety;
- it remains challengeable by provenance, hash, independence, replay, or claim-overreach review.
```
