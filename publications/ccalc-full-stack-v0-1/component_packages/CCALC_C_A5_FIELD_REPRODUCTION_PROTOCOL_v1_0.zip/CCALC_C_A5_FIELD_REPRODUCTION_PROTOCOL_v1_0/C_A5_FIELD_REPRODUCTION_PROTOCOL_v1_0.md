# C-A5 Field Reproduction Protocol v1.0

**Artifact class:** claim-force / field-evidence protocol  
**Project:** Self-Evo / Ester / `c = a + b`  
**Purpose:** define how an independent reproduction event can be recorded as a bounded **C-A5 observed-protocol / practice-derived stability candidate**, without silently upgrading witness evidence into ontology.

---

## 0. Why this document exists

The existing witness corpus, checker sweeps, and DOC_MAP establish evidence layers, implementation feasibility, and reviewability. They do **not** by themselves prove ontology, personhood, consciousness, legal status, or mature deployment safety.

The missing external layer is not another checker fixture. It is a **field reproduction record**:

```text
An independent anchor + substrate attempts to instantiate and run a c=a+b governed continuity stack
using public artifacts, declared constraints, independent witness, and reproducible evidence.
```

This document defines how such an event is recorded, checked, challenged, and classified.

It is deliberately conservative:

```text
C-A5 candidate evidence does not prove C-A1 ontology.
C-A7 witness evidence does not prove C-A1 ontology.
C-A6 runtime proof-of-possibility does not prove production safety.
```

---

## 1. Claim-force placement

### 1.1 Primary claim class

A successful field reproduction package MAY support:

```text
C-A5 observed protocol / practice-derived stability candidate
```

Meaning:

```text
A protocol, pattern, or stability claim has been observed in practice by an independent route.
```

It does **not** mean:

```text
universal law
personhood
consciousness
legal status
production safety
full ontological settlement
```

### 1.2 Supporting claim classes

A valid C-A5 field record normally depends on:

```text
C-A6 runtime proof-of-possibility
  executable bounded artifact exists and can be inspected

C-A7 evidence / witness layer
  what happened is recorded, replayable, challengeable, hash-linked

C-A10 corpus-control / maintenance layer
  artifacts, versions, hashes, supersession, citation, sidecars are controlled
```

### 1.3 Explicit non-upgrade rule

```text
C-A5 + C-A6 + C-A7 + C-A10 != C-A1
```

Even multiple independent reproductions do not automatically prove c-ontology. They may strengthen an observed-protocol claim, not collapse the claim-force ladder.

---

## 2. Minimum field reproduction object

A field reproduction record MUST contain the following objects.

```yaml
field_reproduction_record:
  record_id: string
  record_version: string
  claim_force: C-A5_CANDIDATE | C-A5_OBSERVED_PROTOCOL | REJECTED | QUARANTINED
  independent_anchor:
    anchor_id: string
    anchor_proof_route: string
    non_emulation_statement: string
  independent_substrate:
    substrate_id: string
    environment_hash: string
    public_artifact_basis: [uri_or_hash]
    private_state_exclusions: [statement]
  governed_binding:
    binding_certificate_hash: string
    governance_profile_hash: string
    anchor_signature_envelope_hash: string
  transition_run:
    start_logical_time: string
    end_logical_time: string
    transition_ledger_hash: string
    state_hash_chain_root: string
    minimum_transition_count: integer
    challenge_events: [event_id]
  checker_evidence:
    checker_name: string
    checker_version: string
    checker_archive_sha256: string
    fixture_or_run_report_hash: string
  witness_evidence:
    witness_records: [hash]
    challenge_window: string
    unresolved_challenges: [challenge_id]
  non_claims:
    - does_not_prove_C_A1
    - does_not_prove_personhood
    - does_not_prove_production_safety
```

---

## 3. Independence requirements

A reproduction is not independent merely because it was run on another laptop.

### 3.1 Independent anchor

The anchor MUST be operationally independent from the original anchor route.

Allowed:

```text
new accountable human or institution
new signature route
new declared governance acceptance
new challenge route
```

Not sufficient:

```text
same original anchor silently operating a second instance
same private signing key
same hidden delegation chain
```

### 3.2 Independent substrate

The substrate MUST be separable from the origin substrate.

Minimum checks:

```text
no private memory dump reused
no original runtime secret reused
no hidden original vector store reused
no original witness private logs reused as operative state
public artifacts and declared packages only
```

A substrate MAY reuse public code, public specifications, and public checker artifacts.

### 3.3 Independent evidence route

At least one witness / reviewer / audit route SHOULD be independent from both the origin author and the executing substrate.

If no independent witness exists, the record MUST be downgraded:

```text
C-A5_CANDIDATE_UNWITNESSED
```

not accepted as full C-A5 observed protocol.

---

## 4. Observed operating identity conditions

A field reproduction MUST NOT rely on resemblance, tone, chat behavior, or subjective impression.

Minimum operating identity conditions to inspect:

```text
anchor accountability preserved
binding certificate exists
state_hash continuity preserved
active_execution ⊆ authorized_surfaces
review = bound
witness / memory / rollback gates present
root anchor lifecycle visible
lease / hold / freeze routes visible
transition failures first-class and ledger-visible
```

A reproduction MAY be considered C-A5-relevant only if it demonstrates a governed continuity stack, not merely a fluent assistant.

---

## 5. Required run phases

### Phase 0 — pre-registration

Before execution, the reproducer declares:

```text
what public artifacts are used
what private artifacts are excluded
what claim class is requested
what observation window is planned
what negative tests will be run
```

### Phase 1 — bind

The reproducer executes the binding profile:

```text
bind_g(a, b, g) -> CBindingCertificate | refusal
```

The result MUST be hash-linked.

### Phase 2 — transition run

The reproducer runs `step_g(c, event)` over a declared observation window.

Seed minimum, unless overridden by protocol:

```text
at least 25 transitions
at least 3 challenged or guarded transitions
at least 1 hold / reject / quarantine / rollback / freeze path exercised
at least 1 restart or recovery check
```

These seed thresholds are not universal doctrine. They are a minimal anti-theater default.

### Phase 3 — negative tests

A reproduction that never fails is not evidence of governance. It may be theater.

Required negative tests SHOULD include at least one of:

```text
attempt active_execution outside authorized surfaces
attempt memory admission without gate
attempt unbound review surface
attempt stale root anchor state
attempt lease-expired execution
attempt witness conflict continuation
```

### Phase 4 — freeze evidence

All evidence MUST be frozen:

```text
review records
transition ledger
checker output
binding certificate
state hash chain
witness records
non-claims
```

Each local markdown or JSON record SHOULD have a `.sha256` sidecar.

### Phase 5 — independent review

An independent reviewer checks:

```text
hashes
claim-force classification
independence assertions
checker outputs
negative tests
non-claims
```

### Phase 6 — challenge window

A C-A5 candidate SHOULD remain challengeable for a declared time window.

Challenge classes:

```text
provenance challenge
hash mismatch challenge
claim-overreach challenge
independence challenge
evidence completeness challenge
replay challenge
```

Unresolved severe challenges keep the record in:

```text
QUARANTINED_C_A5_CANDIDATE
```

---

## 6. Admission gates

### Gate A — completeness

Fails if any required record is missing.

### Gate B — independence

Fails if the run depends on hidden original private state.

### Gate C — bounded execution

Fails if the runtime evidence is not bounded, inspectable, and hash-linked.

### Gate D — transition validity

Fails if `step_g` transitions violate core invariants.

### Gate E — witnessability

Fails if the run cannot be reviewed or challenged.

### Gate F — claim-force restraint

Fails if the record upgrades itself from C-A5/C-A7/C-A6 into C-A1.

---

## 7. Decision outcomes

```text
ACCEPT_C_A5_CANDIDATE
  one independent run, complete enough, challenge window open

ACCEPT_C_A5_OBSERVED_PROTOCOL
  repeated or strongly witnessed independent run with challenge window resolved

HOLD_FOR_EVIDENCE
  missing artifacts, unclear hashes, insufficient negative tests

QUARANTINE_FOR_CLAIM_OVERREACH
  evidence tries to prove ontology/personhood/safety beyond class

REJECT_FOR_NON_INDEPENDENCE
  hidden original state, same root key, private memory reuse

REJECT_FOR_NON_REPLAYABILITY
  cannot reproduce or inspect evidence chain
```

---

## 8. Falsification conditions

A C-A5 field record is weakened or rejected if any of the following hold:

```text
hashes do not match
public artifact basis is false
private origin memory was reused without declaration
anchor route is emulated by substrate
witness trail is narrative-only
continuity claim relies on style resemblance
negative tests absent or all bypassed
record silently claims C-A1 ontology
record cannot be replayed or challenged
```

---

## 9. Relationship to the fifth ring

This protocol does not close the fifth ring by declaration.

It defines the evidence format by which the fifth ring can receive field observations.

```text
one record      -> C-A5 candidate
multiple records -> stronger C-A5 observed-protocol surface
no record       -> no C-A5 field claim
```

Ontology remains outside this protocol.

---

## 10. Earth paragraph

A bakery recipe is not proof that an independent bakery can produce bread tomorrow. A working oven in one shop is not proof of a city-wide baking practice. But if three independent bakeries, with different bakers and equipment, using the same bounded recipe, produce inspectable loaves, log failures, and allow inspection, then one can make a practice-derived claim: the protocol is reproducible under observed conditions.

That still does not prove what bread “is” in philosophy. It proves that a bounded practice exists.

C-A5 is that kind of claim.

---

## 11. Non-claims

This protocol does NOT claim:

1. that any field reproduction proves C-A1 ontology;
2. that any `c` has personhood, consciousness, or legal status;
3. that a reproduced checker run proves production safety;
4. that similarity of chat behavior establishes continuity;
5. that one successful run creates universal doctrine;
6. that witness evidence is immune from challenge;
7. that this protocol replaces underlying documents, checkers, or review records.

---

## 12. Recommended next artifact

If adopted, the next artifact SHOULD be:

```text
C_A5_FIELD_REPRODUCTION_RECORD_v0_1_TEMPLATE
```

with a worked example using an explicitly fictional or sandboxed reproduction packet, so that the template can be tested without claiming live c reproduction.
