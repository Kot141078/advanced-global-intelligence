# CCALC C-A5 Field Reproduction Protocol v1.0

This package defines how an independent reproduction can be recorded as bounded C-A5 field evidence without upgrading witness evidence into ontology.

Files:

- `C_A5_FIELD_REPRODUCTION_PROTOCOL_v1_0.md`
- `C_A5_FIELD_REPRODUCTION_PROTOCOL_v1_0.json`
- `C_A5_FIELD_REPRODUCTION_RECORD_TEMPLATE.md`
- `CLAIM_CLASS_BRIDGE.md`
- `EVIDENCE_PACKET_CHECKLIST.tsv`
- `CLAIM_GATE_MATRIX.tsv`
- `PUBLIC_REGISTRATION_TEMPLATE.md`
- `NON_CLAIMS_AND_BOUNDARIES.md`
- `SOURCE_MANIFEST.tsv`
- `SHA256SUMS.txt`

Status:

```text
seed protocol, not evidence of an actual reproduction
```
