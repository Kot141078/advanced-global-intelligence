# Freeze Binding Protocol Note

Hashes are external sidecars over exact file bytes.

Recommended command:

```bash
sha256sum exact_file > exact_file.sha256
```

A Markdown file must not contain its own final self-hash as normative content. Package-level hashes are recorded in `SHA256SUMS.txt` and the external ZIP sidecar.
