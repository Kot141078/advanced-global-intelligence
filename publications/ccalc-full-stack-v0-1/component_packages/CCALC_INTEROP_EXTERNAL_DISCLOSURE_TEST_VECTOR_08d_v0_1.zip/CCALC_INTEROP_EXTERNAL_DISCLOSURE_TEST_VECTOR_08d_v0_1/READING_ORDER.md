# Reading Order

1. `08d_INTEROP_EXTERNAL_IMPLEMENTATION_DISCLOSURE_AND_TEST_VECTOR_REGISTRY_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `registry/*.tsv`
4. `schemas/*.schema.json`
5. `src/interop_external_disclosure_test_vector_checker_v0_1.py`
6. `fixtures/cases/*.json`
7. `FIXTURE_RESULTS.tsv`, `MUTATION_MATRIX.tsv`, `COVERAGE_MATRIX.tsv`
8. `NON_CLAIMS_AND_SCOPE.md`
