# Freeze Binding Protocol Note

All files are bound by external SHA-256 sidecars and `SHA256SUMS.txt`.

Do not embed self-referential hashes inside Markdown bodies. Bind exact file bytes by sidecar and manifest.
