# Open Issues and Next Steps

- External institutional review profiles may require a separate jurisdiction-specific intake supplement.
- Real public test vectors need human redaction review before public release.
- The 08 stack can be closed by umbrella package after this 08d layer.
