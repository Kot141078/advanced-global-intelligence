# CCALC Interop External Disclosure / Test Vector Registry 08d v0.1

This package defines a conservative record and checker seed for public external implementation disclosures and test-vector registries.

Run:

```bash
python3 scripts/run_external_disclosure_test_vector_fixtures.py
python3 scripts/run_external_disclosure_test_vector_mutations.py
sha256sum -c SHA256SUMS.txt
```
