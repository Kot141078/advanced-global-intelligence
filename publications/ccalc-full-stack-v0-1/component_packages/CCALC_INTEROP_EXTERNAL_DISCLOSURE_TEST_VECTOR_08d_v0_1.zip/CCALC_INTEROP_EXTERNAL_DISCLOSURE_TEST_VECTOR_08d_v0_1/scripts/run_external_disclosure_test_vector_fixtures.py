#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from interop_external_disclosure_test_vector_checker_v0_1 import run_fixtures
passed, total, rows = run_fixtures(ROOT)
print("case\texpected\tgot\tstatus\terrors")
for name, expected, got, errors in rows:
    status = "PASS" if expected == got else "FAIL"
    print(f"{name}\t{expected}\t{got}\t{status}\t{' | '.join(errors)}")
print(f"SUMMARY\tfixtures={total}\tpass={passed}\tfail={total-passed}")
raise SystemExit(0 if passed == total else 1)
