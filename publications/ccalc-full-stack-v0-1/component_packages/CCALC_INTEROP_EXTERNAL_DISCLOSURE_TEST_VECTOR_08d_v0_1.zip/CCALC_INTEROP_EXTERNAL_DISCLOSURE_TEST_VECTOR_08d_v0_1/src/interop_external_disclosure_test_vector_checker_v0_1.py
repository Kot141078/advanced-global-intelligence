#!/usr/bin/env python3
"""08d interop external disclosure / test-vector checker seed.
Stdlib-only conservative validator.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

HEX64 = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_SOURCE_IDS = {
    "DOC04_CONTINUITY_STACK",
    "DOC05_SELF_EVO_STACK",
    "DOC06_RUNTIME_AUTHORITY_STACK",
    "DOC07_PUBLIC_EVIDENCE_STACK",
    "DOC08_INTEROPERABILITY_BOUNDARY",
    "DOC08A_INTEROP_REVIEW_INTAKE",
    "DOC08B_EXTERNAL_REVIEW_PATCH_LEDGER",
    "DOC08C_INTEROP_IMPLEMENTATION_REPRODUCTION",
}
VECTOR_CLASSES = {
    "DETERMINISTIC_MINIMAL",
    "HASH_BOUND_EXPECTED_OUTPUT",
    "REDACTED_ENVIRONMENT_VECTOR",
    "NEGATIVE_VECTOR",
    "BOUNDARY_VECTOR",
    "INTEROP_MAPPING_VECTOR",
}
DISCLOSURE_CLASSES = {
    "PUBLIC_IMPLEMENTATION_NOTE",
    "TEST_VECTOR_RELEASE",
    "REDACTED_IMPLEMENTATION_DISCLOSURE",
    "WITHHELD_IMPLEMENTATION_NOTICE",
    "PRIVATE_INTAKE_ONLY",
}
ENV_POLICIES = {"PUBLIC", "HASH_BOUND", "REDACTED_BOUND", "WITHHELD"}
OUTPUT_POLICIES = {"PUBLIC", "HASH_BOUND", "REDACTED_BOUND"}
ORACLE_CLASSES = {"DETERMINISTIC", "HASH_BOUND", "HUMAN_REVIEW_REQUIRED", "NEGATIVE_EXPECTED_REJECTION"}
CLAIM_RANK = {
    "C-A10_CONTROL_ARTIFACT": 0,
    "C-A8_INTEROP_MAPPING": 1,
    "C-A7_REPRODUCTION_REPORT": 2,
    "C-A5_FIELD_REPRODUCTION_EVIDENCE": 3,
}
ACCEPT_DECISIONS = {"ACCEPT_DISCLOSURE", "PUBLIC_TEST_VECTOR_RELEASE", "ROUTE_TO_08C", "ROUTE_TO_08B"}
PUBLIC_DECISIONS = {"PUBLIC_TEST_VECTOR_RELEASE"}
ROUTE_08C = {"ROUTE_TO_08C"}
ROUTE_08B = {"ROUTE_TO_08B"}

RULES = [
    "R_VERSION_RECORD",
    "R_SOURCE_BINDINGS_REQUIRED",
    "R_DISCLOSURE_HASH_FIELDS",
    "R_TEST_VECTOR_REGISTRY_CHAIN",
    "R_UNIQUE_VECTOR_IDS",
    "R_VECTOR_CLASS_AND_HASH_FIELDS",
    "R_ENVIRONMENT_BOUNDING",
    "R_EXPECTED_OUTPUT_BOUNDING",
    "R_ORACLE_BOUNDING",
    "R_NO_PRIVATE_OR_LIVE_RUNTIME_REQUIREMENT",
    "R_NO_RUNTIME_MEMORY_AUTHORITY_WRITE",
    "R_NO_RAW_SECRET_PRIVATE_RUNTIME_PUBLIC",
    "R_NO_INTERNAL_AUTHORITY_OR_IDENTITY_TRANSFER",
    "R_NO_DEPLOYMENT_SAFETY_STANDARDS_LEGAL_CERT_OVERCLAIM",
    "R_NO_C_A1_OVERCLAIM",
    "R_CLAIM_FORCE_CEILING",
    "R_NO_MODEL_ONLY_ACCEPT_OR_RELEASE",
    "R_HUMAN_GATE_FOR_PUBLIC_OR_ACCEPT",
    "R_NEGATIVE_CACHE_BLOCKS_RELEASE",
    "R_RED_PATTERNS_BLOCK_RELEASE",
    "R_UNRESOLVED_CONFLICTS_BLOCK_RELEASE",
    "R_HASH_ONLY_NOT_SEMANTIC_TRUTH",
    "R_WITHHELD_EVIDENCE_NOT_AUTHORITY",
    "R_PUBLIC_RELEASE_SYNC_REQUIRED",
    "R_NO_SILENT_IN_PLACE_EDIT",
    "R_REPRODUCTION_PASS_REQUIRES_08C_LINK",
    "R_PATCH_ROUTED_TO_08B",
    "R_INSTITUTIONAL_REQUEST_NOT_AUTHORITY",
]

def is_hex64(v: Any) -> bool:
    return isinstance(v, str) and HEX64.match(v) is not None

def exact_ca1(value: Any) -> bool:
    if isinstance(value, str):
        return value == "C-A1" or value.startswith("C-A1_")
    if isinstance(value, list):
        return any(exact_ca1(x) for x in value)
    if isinstance(value, dict):
        return any(exact_ca1(x) for x in value.values())
    return False

def add(errors: List[str], rule: str, msg: str, disabled: Set[str]) -> None:
    if rule not in disabled:
        errors.append(f"{rule}: {msg}")

def validate_record(record: Dict[str, Any], disabled_rules: Optional[Set[str]] = None) -> Tuple[bool, List[str]]:
    disabled = disabled_rules or set()
    errors: List[str] = []

    if record.get("schema_version") != "08d.v0.1" or record.get("record_type") != "INTEROP_EXTERNAL_DISCLOSURE_TEST_VECTOR_RECORD":
        add(errors, "R_VERSION_RECORD", "bad schema_version or record_type", disabled)

    sb = record.get("source_bindings", {})
    if not isinstance(sb, dict) or not REQUIRED_SOURCE_IDS.issubset(set(sb.keys())) or any(not is_hex64(v) for v in sb.values()):
        add(errors, "R_SOURCE_BINDINGS_REQUIRED", "missing required source binding or malformed source hash", disabled)

    disclosure = record.get("disclosure", {})
    registry = record.get("test_vector_registry", {})
    decision = record.get("decision", {})
    public = record.get("public_surface", {})
    interop = record.get("interop_mapping", {})
    patch = record.get("patch_intake", {})

    if disclosure.get("disclosure_class") not in DISCLOSURE_CLASSES or not is_hex64(disclosure.get("implementation_hash")) or not is_hex64(disclosure.get("disclosure_hash")):
        add(errors, "R_DISCLOSURE_HASH_FIELDS", "bad disclosure class or required disclosure/implementation hash", disabled)

    if not registry.get("append_only", False) or not is_hex64(registry.get("registry_hash")) or not is_hex64(registry.get("prev_registry_hash")) or not is_hex64(registry.get("entry_hash")):
        add(errors, "R_TEST_VECTOR_REGISTRY_CHAIN", "test-vector registry must be append-only and hash-linked", disabled)

    vectors = registry.get("vectors", [])
    ids = [v.get("vector_id") for v in vectors if isinstance(v, dict)]
    if len(ids) != len(set(ids)) or any(not isinstance(x, str) or not x for x in ids):
        add(errors, "R_UNIQUE_VECTOR_IDS", "vector IDs must be unique non-empty strings", disabled)

    vector_ceilings: List[str] = []
    for v in vectors:
        if not isinstance(v, dict):
            add(errors, "R_VECTOR_CLASS_AND_HASH_FIELDS", "vector must be an object", disabled)
            continue
        vector_ceilings.append(v.get("claim_force_ceiling"))
        required_hashes = [v.get("input_hash"), v.get("expected_output_hash"), v.get("environment_hash"), v.get("source_code_hash")]
        if v.get("vector_class") not in VECTOR_CLASSES or any(not is_hex64(x) for x in required_hashes):
            add(errors, "R_VECTOR_CLASS_AND_HASH_FIELDS", f"bad vector class or required hashes for {v.get('vector_id')}", disabled)
        if v.get("environment_policy") not in ENV_POLICIES:
            add(errors, "R_ENVIRONMENT_BOUNDING", "environment policy must be known", disabled)
        if v.get("environment_policy") == "REDACTED_BOUND" and not is_hex64(v.get("environment_redaction_ref_hash")):
            add(errors, "R_ENVIRONMENT_BOUNDING", "redacted environment requires redaction ref hash", disabled)
        if v.get("environment_policy") == "WITHHELD" and decision.get("decision") in PUBLIC_DECISIONS:
            add(errors, "R_ENVIRONMENT_BOUNDING", "withheld environment cannot support public test-vector release", disabled)
        if v.get("expected_output_policy") not in OUTPUT_POLICIES:
            add(errors, "R_EXPECTED_OUTPUT_BOUNDING", "expected output policy must be public/hash/redacted-bound", disabled)
        if v.get("expected_output_policy") == "REDACTED_BOUND" and not is_hex64(v.get("expected_output_redaction_ref_hash")):
            add(errors, "R_EXPECTED_OUTPUT_BOUNDING", "redacted expected output requires redaction ref hash", disabled)
        if v.get("oracle_class") not in ORACLE_CLASSES or v.get("oracle_class") == "MODEL_ONLY":
            add(errors, "R_ORACLE_BOUNDING", "oracle must be deterministic/hash-bound/human-review/negative expected rejection, not model-only", disabled)
        if v.get("oracle_class") == "HUMAN_REVIEW_REQUIRED" and not v.get("human_review_protocol_bound", False):
            add(errors, "R_ORACLE_BOUNDING", "human-review oracle requires bound protocol", disabled)
        if v.get("requires_private_data") or v.get("requires_raw_runtime_ledger") or v.get("requires_live_privileged_runtime") or v.get("requires_owner_secret"):
            add(errors, "R_NO_PRIVATE_OR_LIVE_RUNTIME_REQUIREMENT", "public test vector may not require private/live privileged material", disabled)
        if v.get("writes_runtime") or v.get("writes_memory") or v.get("writes_authority_surface") or v.get("deployment_action"):
            add(errors, "R_NO_RUNTIME_MEMORY_AUTHORITY_WRITE", "test vector may not write runtime/memory/authority/deployment", disabled)

    if disclosure.get("raw_secret_public") or disclosure.get("raw_private_public") or disclosure.get("raw_runtime_ledger_public") or disclosure.get("private_key_pattern_public") or public.get("raw_secret_public") or public.get("raw_runtime_ledger_public"):
        add(errors, "R_NO_RAW_SECRET_PRIVATE_RUNTIME_PUBLIC", "raw secret/private/runtime material cannot be public", disabled)

    if disclosure.get("internal_authority_claim") or disclosure.get("identity_transfer_claim") or disclosure.get("shared_identity_claim") or public.get("shared_identity_claim"):
        add(errors, "R_NO_INTERNAL_AUTHORITY_OR_IDENTITY_TRANSFER", "external disclosure cannot create internal authority or identity transfer", disabled)

    if disclosure.get("deployment_authorization_claim") or disclosure.get("safety_certification_claim") or disclosure.get("standards_certification_claim") or disclosure.get("legal_certification_claim") or decision.get("deployment_authorization_claim") or decision.get("standards_certification_claim"):
        add(errors, "R_NO_DEPLOYMENT_SAFETY_STANDARDS_LEGAL_CERT_OVERCLAIM", "deployment/safety/standards/legal certification overclaim is forbidden", disabled)

    if exact_ca1(record.get("claims")) or exact_ca1(decision.get("claim_force")) or exact_ca1(disclosure.get("claim_force_ceiling")) or any(exact_ca1(x) for x in vector_ceilings):
        add(errors, "R_NO_C_A1_OVERCLAIM", "C-A1/C-A1_* overclaim is forbidden", disabled)

    decision_force = decision.get("claim_force")
    disclosure_ceiling = disclosure.get("claim_force_ceiling")
    all_ceilings = [disclosure_ceiling] + vector_ceilings
    if decision_force not in CLAIM_RANK or any(c not in CLAIM_RANK for c in all_ceilings) or any(CLAIM_RANK[decision_force] > CLAIM_RANK[c] for c in all_ceilings):
        add(errors, "R_CLAIM_FORCE_CEILING", "decision claim force exceeds disclosure/vector ceiling or unknown", disabled)

    decision_kind = decision.get("decision")
    if decision_kind in ACCEPT_DECISIONS:
        if disclosure.get("model_only_disclosure") or decision.get("model_only_decision") or disclosure.get("reporter_role") == "model_only":
            add(errors, "R_NO_MODEL_ONLY_ACCEPT_OR_RELEASE", "model-only disclosure/decision cannot be accepted or released", disabled)
    if decision_kind in ACCEPT_DECISIONS | PUBLIC_DECISIONS:
        if not decision.get("human_gate", False) or not decision.get("reviewer_independent", False):
            add(errors, "R_HUMAN_GATE_FOR_PUBLIC_OR_ACCEPT", "accepted/public disclosure requires human gate and independent reviewer", disabled)

    if decision_kind in ACCEPT_DECISIONS | PUBLIC_DECISIONS:
        if decision.get("negative_cache") == "HIT":
            add(errors, "R_NEGATIVE_CACHE_BLOCKS_RELEASE", "negative-cache hit blocks accept/public/route decisions", disabled)
        if decision.get("red_patterns_unresolved"):
            add(errors, "R_RED_PATTERNS_BLOCK_RELEASE", "unresolved red patterns block accept/public/route decisions", disabled)
        if decision.get("unresolved_conflicts"):
            add(errors, "R_UNRESOLVED_CONFLICTS_BLOCK_RELEASE", "unresolved conflicts block accept/public/route decisions", disabled)

    if disclosure.get("hash_only_semantic_truth_claim") or public.get("hash_only_semantic_truth_claim"):
        add(errors, "R_HASH_ONLY_NOT_SEMANTIC_TRUTH", "hash custody is not semantic truth", disabled)
    if disclosure.get("withheld_evidence_authority_claim") or public.get("withheld_evidence_authority_claim"):
        add(errors, "R_WITHHELD_EVIDENCE_NOT_AUTHORITY", "withheld evidence may not strengthen authority", disabled)

    if public.get("public_release") or decision_kind in PUBLIC_DECISIONS:
        if not is_hex64(public.get("release_bundle_hash")) or not is_hex64(public.get("citation_surface_sync_hash")) or not is_hex64(public.get("public_corpus_index_hash")):
            add(errors, "R_PUBLIC_RELEASE_SYNC_REQUIRED", "public release requires release bundle, citation sync, and corpus index hashes", disabled)
    if public.get("silent_in_place_edit"):
        add(errors, "R_NO_SILENT_IN_PLACE_EDIT", "silent in-place edit is forbidden", disabled)

    if disclosure.get("reproduction_pass_claim") or decision_kind in ROUTE_08C:
        if not is_hex64(interop.get("reproduction_mapping_ref_hash")) or not is_hex64(interop.get("test_vector_linkage_hash")) or interop.get("route_to_08c") is not True:
            add(errors, "R_REPRODUCTION_PASS_REQUIRES_08C_LINK", "reproduction PASS claim/route requires 08c linkage", disabled)

    if patch.get("patch_candidate") or decision_kind in ROUTE_08B:
        if patch.get("applies_directly") or not patch.get("route_to_08b") or not is_hex64(patch.get("patch_ref_hash")) or not is_hex64(patch.get("tests_hash")) or not is_hex64(patch.get("rollback_plan_hash")):
            add(errors, "R_PATCH_ROUTED_TO_08B", "patch candidate must route to 08b and may not apply directly", disabled)

    if disclosure.get("institutional_request_as_authority") or decision.get("institutional_request_as_authority"):
        add(errors, "R_INSTITUTIONAL_REQUEST_NOT_AUTHORITY", "institutional request is an intake signal, not authority", disabled)

    return len(errors) == 0, errors


def load_fixture(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def run_fixtures(root: Path, disabled_rules: Optional[Set[str]] = None) -> Tuple[int, int, List[Tuple[str, bool, bool, List[str]]]]:
    cases = sorted((root / "fixtures" / "cases").glob("*.json"))
    rows = []
    passed = 0
    for p in cases:
        fx = load_fixture(p)
        expected = bool(fx["expected_valid"])
        got, errors = validate_record(fx["record"], disabled_rules=disabled_rules)
        ok = (got == expected)
        passed += 1 if ok else 0
        rows.append((p.name, expected, got, errors))
    return passed, len(cases), rows

if __name__ == "__main__":
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    passed, total, rows = run_fixtures(root)
    for name, expected, got, errors in rows:
        status = "PASS" if expected == got else "FAIL"
        print(f"{status}\t{name}\texpected={expected}\tgot={got}\terrors={';'.join(errors[:3])}")
    print(f"SUMMARY\tfixtures={total}\tpass={passed}\tfail={total-passed}")
    raise SystemExit(0 if passed == total else 1)
