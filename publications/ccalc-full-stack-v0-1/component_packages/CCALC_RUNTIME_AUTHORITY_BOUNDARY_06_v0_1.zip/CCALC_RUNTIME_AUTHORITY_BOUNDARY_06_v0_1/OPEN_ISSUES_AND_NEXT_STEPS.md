# Open Issues and Next Steps

## Immediate next package

`06a_RUNTIME_AUTHORITY_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1`

Purpose:

```text
turn 06 authority/deployment records into JSON schemas and a stdlib checker seed
```

## Required 06a records

```text
RuntimeAuthorityManifest
ContourDeploymentManifest
CrossContourHandoffRecord
ToolSurfaceLease
MemoryImportRecord
RuntimeAuthorityDecision
QuorumRecord
EmergencyHoldRecord
DeploymentChangeRecord
```

## Required hardening classes

```text
shared token authority leak
source contour commands target contour
foreign memory direct write
cloud oracle as owner approval
fixture pass as deployment authorization
style match as continuity authority
quarantine auto-resume
unknown topology collapsed to zero risk
replay/archive active-promotion laundering
self-certifying model quorum
```

## Later packages

```text
06b multi-contour handoff/tool lease fixture pack
06c deployment hold/quarantine/emergency-resume drill
06d runtime authority stack umbrella
```
