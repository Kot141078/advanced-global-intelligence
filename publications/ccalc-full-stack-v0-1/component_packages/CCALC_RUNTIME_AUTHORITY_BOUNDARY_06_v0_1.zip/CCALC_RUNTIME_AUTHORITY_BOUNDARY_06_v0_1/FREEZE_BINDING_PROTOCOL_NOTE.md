# Freeze Binding Protocol Note

Files are bound by exact-byte SHA-256 sidecars and by package-level `SHA256SUMS.txt`.

No file includes its own self-hash inside its content. Self-referential hashes are avoided.

To verify:

```bash
sha256sum -c SHA256SUMS.txt
```
