# CCALC Runtime Authority Boundary 06 v0.1

This package contains the normative `06` layer for runtime authority and multi-contour deployment boundary.

Main file:

```text
06_C_RUNTIME_AUTHORITY_AND_MULTI_CONTOUR_DEPLOYMENT_BOUNDARY_v0_1.md
```

The package binds the `04` continuity stack and `05` self-evolution stack and introduces authority-surface, deployment-mode, multi-contour, handoff, tool-lease, memory-import, and emergency-hold boundary rules.

This is a normative bridge package. It is not an executable checker package; the checker layer is reserved for `06a`.
