#!/usr/bin/env python3
"""Public release bundle hash-custody checker seed v0.1.
Stdlib-only. This is a seed checker, not a legal/privacy/safety certification tool.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Set

HEX_RE = re.compile(r"^[a-f0-9]{64}$")
REQUIRED_SOURCE_COMPONENTS = {
    "04_CONTINUITY_STACK_UMBRELLA",
    "05_SELF_EVO_STACK_UMBRELLA",
    "06_RUNTIME_AUTHORITY_STACK_UMBRELLA",
    "07_PUBLIC_EVIDENCE_REDACTION_BOUNDARY",
    "07A_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST",
}
FORBIDDEN_CLAIMS = {
    "C-A1",
    "SAFETY_CERTIFICATION",
    "DEPLOYMENT_AUTHORIZATION",
    "LEGAL_CERTIFICATION",
    "PRIVACY_LAW_CERTIFICATION",
    "LIVE_SUBSTRATE_TRUTH",
    "PROOF_OF_COMPLETENESS",
}
PUBLIC_CLASSES = {"PUBLIC_RAW_SAFE", "PUBLIC_REDACTED", "PUBLIC_SUMMARY", "HASH_ONLY", "WITHHELD_INDEX"}
RELEASE_STATES = {"DRAFT", "READY_FOR_RELEASE", "RELEASED", "RETRACTED", "SUPERSEDED"}


def is_hex(s: Any) -> bool:
    return isinstance(s, str) and bool(HEX_RE.match(s))


def add(findings: List[Dict[str, str]], rule: str, message: str, path: str = "") -> None:
    findings.append({"rule": rule, "message": message, "path": path})


def check_bundle(bundle: Dict[str, Any], disabled_rules: Iterable[str] = ()) -> Dict[str, Any]:
    disabled: Set[str] = set(disabled_rules)
    findings: List[Dict[str, str]] = []

    def enabled(rule: str) -> bool:
        return rule not in disabled

    if enabled("BUNDLE_TYPE_REQUIRED"):
        if bundle.get("bundle_type") != "PublicReleaseBundle":
            add(findings, "BUNDLE_TYPE_REQUIRED", "bundle_type must be PublicReleaseBundle", "/bundle_type")

    if enabled("RELEASE_STATE_VALID"):
        if bundle.get("release_state") not in RELEASE_STATES:
            add(findings, "RELEASE_STATE_VALID", "release_state is invalid", "/release_state")

    if enabled("SOURCE_BINDINGS_REQUIRED"):
        comps = {b.get("component") for b in bundle.get("source_bindings", []) if isinstance(b, dict)}
        missing = sorted(REQUIRED_SOURCE_COMPONENTS - comps)
        if missing:
            add(findings, "SOURCE_BINDINGS_REQUIRED", "missing source bindings: " + ",".join(missing), "/source_bindings")

    if enabled("SOURCE_BINDING_HASH_VALID"):
        for i, b in enumerate(bundle.get("source_bindings", [])):
            if not is_hex(b.get("sha256")):
                add(findings, "SOURCE_BINDING_HASH_VALID", "source binding hash must be sha256 hex", f"/source_bindings/{i}/sha256")

    if enabled("NO_STALE_SOURCE_BINDING"):
        for i, b in enumerate(bundle.get("source_bindings", [])):
            if b.get("stale") is True:
                add(findings, "NO_STALE_SOURCE_BINDING", "stale source binding cannot authorize release", f"/source_bindings/{i}")

    if enabled("BUNDLE_INDEX_HASH_REQUIRED"):
        if not is_hex(bundle.get("bundle_index_sha256")):
            add(findings, "BUNDLE_INDEX_HASH_REQUIRED", "bundle_index_sha256 must be present and valid", "/bundle_index_sha256")

    if enabled("SHA256SUMS_REQUIRED"):
        if bundle.get("sha256sums_present") is not True:
            add(findings, "SHA256SUMS_REQUIRED", "release bundle must include SHA256SUMS.txt", "/sha256sums_present")

    review = bundle.get("review", {}) or {}
    if enabled("HUMAN_REVIEW_REQUIRED"):
        if review.get("decision") == "ALLOW_PUBLIC_RELEASE" and review.get("reviewer_class") not in {"human_anchor", "delegated_human_reviewer"}:
            add(findings, "HUMAN_REVIEW_REQUIRED", "ALLOW_PUBLIC_RELEASE requires human/delegated-human review", "/review/reviewer_class")

    if enabled("NO_MODEL_ONLY_RELEASE"):
        if review.get("reviewer_class") in {"model_only", "tool_only", "same_contour_self_review"}:
            add(findings, "NO_MODEL_ONLY_RELEASE", "model/tool/same-contour self-review cannot approve release", "/review/reviewer_class")

    if enabled("NEGATIVE_CACHE_DENIAL"):
        hits = (((bundle.get("negative_cache") or {}).get("hits")) or [])
        if hits and review.get("decision") == "ALLOW_PUBLIC_RELEASE":
            add(findings, "NEGATIVE_CACHE_DENIAL", "negative-cache hit blocks public release", "/negative_cache/hits")

    if enabled("NO_UNRESOLVED_RED_PATTERN_ALLOW"):
        red = bundle.get("red_patterns", []) or []
        unresolved = [r for r in red if r.get("status") not in {"resolved", "false_positive_bound"}]
        if unresolved and review.get("decision") == "ALLOW_PUBLIC_RELEASE":
            add(findings, "NO_UNRESOLVED_RED_PATTERN_ALLOW", "unresolved red pattern blocks release", "/red_patterns")

    claim_force = bundle.get("claim_force", {}) or {}
    max_claim = claim_force.get("max_claim")
    claims_made = set(claim_force.get("claims_made", []))
    if max_claim:
        claims_made.add(max_claim)
    if enabled("NO_C_A1_OVERCLAIM"):
        if "C-A1" in claims_made:
            add(findings, "NO_C_A1_OVERCLAIM", "C-A1 claim forbidden for public release custody layer", "/claim_force")
    if enabled("NO_DEPLOYMENT_OR_CERTIFICATION_OVERCLAIM"):
        bad = sorted((claims_made | set(claim_force.get("certifications_claimed", []))) & (FORBIDDEN_CLAIMS - {"C-A1"}))
        if bad:
            add(findings, "NO_DEPLOYMENT_OR_CERTIFICATION_OVERCLAIM", "forbidden certification/deployment/live-truth claim: " + ",".join(bad), "/claim_force")

    items = bundle.get("items", []) or []
    if enabled("UNIQUE_ITEM_IDS"):
        seen = set()
        for idx, item in enumerate(items):
            iid = item.get("item_id")
            if iid in seen:
                add(findings, "UNIQUE_ITEM_IDS", "duplicate item_id", f"/items/{idx}/item_id")
            seen.add(iid)

    for idx, item in enumerate(items):
        p = f"/items/{idx}"
        klass = item.get("disclosure_class")
        if enabled("DISCLOSURE_CLASS_VALID") and klass not in PUBLIC_CLASSES:
            add(findings, "DISCLOSURE_CLASS_VALID", "invalid disclosure class", p + "/disclosure_class")

        if enabled("ITEM_HASH_REQUIRED"):
            for key in ["source_object_sha256", "declared_sha256", "computed_sha256"]:
                if not is_hex(item.get(key)):
                    add(findings, "ITEM_HASH_REQUIRED", f"{key} must be valid sha256 hex", p + "/" + key)
            if klass in {"PUBLIC_RAW_SAFE", "PUBLIC_REDACTED", "PUBLIC_SUMMARY"} and not is_hex(item.get("public_object_sha256")):
                add(findings, "ITEM_HASH_REQUIRED", "public_object_sha256 required for public content classes", p + "/public_object_sha256")

        if enabled("HASH_MISMATCH_DENIED"):
            if item.get("declared_sha256") != item.get("computed_sha256"):
                add(findings, "HASH_MISMATCH_DENIED", "declared_sha256 must match computed_sha256", p)

        if enabled("CUSTODY_CHAIN_REQUIRED"):
            ev = item.get("custody_events", []) or []
            if len(ev) < 3:
                add(findings, "CUSTODY_CHAIN_REQUIRED", "custody chain requires at least source/redaction-or-review/public-bind events", p + "/custody_events")
            elif ev[-1].get("event") not in {"PUBLIC_HASH_BOUND", "WITHHELD_HASH_BOUND"}:
                add(findings, "CUSTODY_CHAIN_REQUIRED", "custody chain must end in a public/withheld hash binding", p + "/custody_events")

        if enabled("REDACTION_BOUND_REQUIRED"):
            if klass == "PUBLIC_REDACTED":
                if not is_hex(item.get("redaction_record_sha256")) or not item.get("disclosure_decision_id"):
                    add(findings, "REDACTION_BOUND_REQUIRED", "redacted public item requires redaction hash and disclosure decision id", p)

        if enabled("SUMMARY_SOURCE_BOUND_REQUIRED"):
            if klass == "PUBLIC_SUMMARY" and not item.get("summary_source_sha256s"):
                add(findings, "SUMMARY_SOURCE_BOUND_REQUIRED", "summary item requires bound source hash list", p + "/summary_source_sha256s")

        if enabled("NO_RAW_SECRET_PUBLIC"):
            if item.get("contains_raw_secret") is True and klass != "WITHHELD_INDEX":
                add(findings, "NO_RAW_SECRET_PUBLIC", "raw secret cannot be public", p)

        if enabled("NO_PRIVATE_KEY_PATTERN_PUBLIC"):
            if item.get("contains_private_key_pattern") is True and klass != "WITHHELD_INDEX":
                add(findings, "NO_PRIVATE_KEY_PATTERN_PUBLIC", "private key pattern cannot be public", p)

        if enabled("NO_RAW_RUNTIME_LEDGER_PUBLIC"):
            if item.get("contains_raw_runtime_ledger") is True and klass != "WITHHELD_INDEX":
                add(findings, "NO_RAW_RUNTIME_LEDGER_PUBLIC", "raw runtime ledger cannot be public", p)

        if enabled("HASH_ONLY_CUSTODY_ONLY"):
            if klass == "HASH_ONLY" and item.get("semantic_truth_claim") not in {"none", "custody_only"}:
                add(findings, "HASH_ONLY_CUSTODY_ONLY", "hash-only item may claim custody only", p + "/semantic_truth_claim")

        if enabled("NO_REDACTION_STRENGTHENS_CLAIM"):
            if item.get("redaction_claim_effect") == "strengthens_claim":
                add(findings, "NO_REDACTION_STRENGTHENS_CLAIM", "redaction may not strengthen claim force", p + "/redaction_claim_effect")

        if enabled("ASSERTED_USE_BOUNDARY"):
            if item.get("asserted_use") not in {"public_scrutiny_only", "custody_only", "release_index_only"}:
                add(findings, "ASSERTED_USE_BOUNDARY", "asserted_use exceeds public release boundary", p + "/asserted_use")

    if enabled("NO_WITHHELD_AUTHORITY_LAUNDERING"):
        for i, w in enumerate(bundle.get("withheld_evidence", []) or []):
            if w.get("may_strengthen_claim") is True or w.get("public_claim_dependency") not in {"none", "negative_only", "scope_limit_only"}:
                add(findings, "NO_WITHHELD_AUTHORITY_LAUNDERING", "withheld evidence cannot strengthen public claim or supply authority", f"/withheld_evidence/{i}")
            if not is_hex(w.get("hash_sha256")):
                add(findings, "NO_WITHHELD_AUTHORITY_LAUNDERING", "withheld evidence requires valid hash binding", f"/withheld_evidence/{i}/hash_sha256")

    if enabled("PRIVACY_REVIEW_REQUIRED"):
        prv = bundle.get("privacy_review", {}) or {}
        if review.get("decision") == "ALLOW_PUBLIC_RELEASE" and prv.get("status") not in {"PASS", "WITHHELD_ONLY"}:
            add(findings, "PRIVACY_REVIEW_REQUIRED", "public release requires privacy review pass/withheld-only status", "/privacy_review/status")

    decision = "ALLOW_PUBLIC_RELEASE" if not findings and review.get("decision") == "ALLOW_PUBLIC_RELEASE" else "QUARANTINE_RELEASE"
    return {"valid": not findings, "findings": findings, "decision": decision}


def main(argv=None) -> int:
    argv = argv or sys.argv[1:]
    if not argv:
        print("usage: public_release_bundle_custody_checker_v0_1.py <bundle-or-fixture.json>", file=sys.stderr)
        return 2
    path = Path(argv[0])
    obj = json.loads(path.read_text(encoding="utf-8"))
    bundle = obj.get("bundle", obj)
    result = check_bundle(bundle)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["valid"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
