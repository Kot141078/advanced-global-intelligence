# Reading order — 07b

1. `07b_PUBLIC_RELEASE_BUNDLE_AND_HASH_CUSTODY_AUDIT_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `schemas/public_release_bundle.schema.json`
4. `src/public_release_bundle_custody_checker_v0_1.py`
5. `fixtures/cases/`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
