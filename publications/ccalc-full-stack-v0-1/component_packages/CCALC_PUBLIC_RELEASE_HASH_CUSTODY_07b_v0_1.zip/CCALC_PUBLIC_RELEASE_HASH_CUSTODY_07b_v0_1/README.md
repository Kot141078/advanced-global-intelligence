# CCALC_PUBLIC_RELEASE_HASH_CUSTODY_07b_v0_1

Public release bundle and hash custody audit seed for c-calculus doc-07b.

## Verify

```bash
sha256sum -c SHA256SUMS.txt
python3 scripts/run_release_bundle_fixtures.py
python3 scripts/run_release_bundle_mutations.py
```

## Status

`checker-seed-and-fixture-pack`
