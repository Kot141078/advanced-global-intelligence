# Freeze binding protocol note

Use external sidecar binding for frozen files:

```text
sha256sum exact_file_bytes > filename.sha256
```

Do not put a file's own hash inside the file being hashed. Package-level `SHA256SUMS.txt` excludes itself.
