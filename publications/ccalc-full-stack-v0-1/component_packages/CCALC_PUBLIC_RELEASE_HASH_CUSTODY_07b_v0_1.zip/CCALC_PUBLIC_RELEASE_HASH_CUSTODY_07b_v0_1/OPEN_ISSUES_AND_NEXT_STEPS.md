# Open issues and next steps — 07b

Closed in this package:

- Public release bundle schema seed.
- Hash custody checker seed.
- Redaction-to-release binding fixtures.
- Hash-only semantic-truth boundary fixtures.
- Withheld-evidence authority laundering fixtures.
- Mutation hardening for common release/custody bypasses.

Next natural layer:

```text
07c_PUBLIC_RETRACTION_SUPERSESSION_AND_ERRATA_LEDGER_v0_1
```

Reason: after public release, the corpus needs a governed correction path for retraction, supersession, errata, hash replacement, and public index consistency.
