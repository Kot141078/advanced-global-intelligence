#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from public_release_bundle_custody_checker_v0_1 import check_bundle


def main() -> int:
    targets = json.loads((ROOT / "mutation_targets.json").read_text(encoding="utf-8"))
    rows = ["mutation_id\tdisabled_rule\ttarget_fixture\toriginal_valid\tmutant_valid\tstatus"]
    caught = missed = 0
    for mutation_id, disabled_rule, fixture_id in targets:
        path = ROOT / "fixtures" / "cases" / f"{fixture_id}.json"
        fx = json.loads(path.read_text(encoding="utf-8"))
        original = check_bundle(fx["bundle"])
        mutant = check_bundle(fx["bundle"], disabled_rules={disabled_rule})
        status = "CAUGHT" if (original["valid"] is False and mutant["valid"] is True) else "MISSED"
        caught += status == "CAUGHT"
        missed += status == "MISSED"
        rows.append(f"{mutation_id}\t{disabled_rule}\t{fixture_id}\t{str(original['valid']).lower()}\t{str(mutant['valid']).lower()}\t{status}")
    (ROOT / "MUTATION_MATRIX.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"mutations: {len(targets)}  CAUGHT: {caught}  MISSED: {missed}")
    return 0 if missed == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
