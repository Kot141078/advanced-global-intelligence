#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from public_release_bundle_custody_checker_v0_1 import check_bundle


def main() -> int:
    rows = ["case_id\texpected_valid\tactual_valid\tstatus\tprimary_rule\tfinding_rules"]
    total = passed = failed = 0
    for path in sorted((ROOT / "fixtures" / "cases").glob("*.json")):
        fx = json.loads(path.read_text(encoding="utf-8"))
        res = check_bundle(fx["bundle"])
        actual = bool(res["valid"])
        expected = bool(fx["expected_valid"])
        status = "PASS" if actual == expected else "FAIL"
        total += 1
        passed += status == "PASS"
        failed += status == "FAIL"
        rules = ",".join(sorted({f["rule"] for f in res["findings"]}))
        rows.append(f"{fx['case_id']}\t{str(expected).lower()}\t{str(actual).lower()}\t{status}\t{fx.get('expected_primary_rule','')}\t{rules}")
    (ROOT / "FIXTURE_RESULTS.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"fixtures: {total}  PASS: {passed}  FAIL: {failed}")
    return 0 if failed == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
