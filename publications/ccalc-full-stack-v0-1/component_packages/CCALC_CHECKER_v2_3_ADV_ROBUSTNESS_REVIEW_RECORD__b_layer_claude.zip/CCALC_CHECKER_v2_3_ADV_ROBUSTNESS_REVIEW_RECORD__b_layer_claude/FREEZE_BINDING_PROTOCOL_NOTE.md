# Freeze Binding Protocol Note

This package uses the sidecar freeze-binding protocol established in the CCALC DOC_MAP line.

- The Markdown review record is the canonical human-readable witness text.
- The `.md.sha256` sidecar contains `SHA256(markdown_file_bytes)` and the canonical filename.
- The sidecar hash is computed over the exact packaged Markdown bytes, UTF-8 with LF line endings.
- The Markdown record itself uses `record_sha256: "SIDE_CAR_BOUND"` rather than embedding a self-referential hash.

This avoids self-referential instability while keeping the record independently reproducible.
