# Execution Log — Continuity Checker Seed v0.1

Date: 2026-07-03 16:43 UTC
Environment: Python 3 (stdlib only), closed-box container.
Normative source: doc-04 v0.1.2, sha256 35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9 (accepted current per anchor record).

## Sealed run

```text
fixtures: 42  PASS: 42  FAIL: 0
families: metric 13 + coverage-bearing trace 17 + adversarial 10 + property 2
```

## Mutation testing (fixture non-vacuity evidence)

Four deliberate regressions were injected one at a time, each mapping to a
D4-finding class from the v0.1.1 review; the suite was run after each and the
checker restored from backup before the next. All four caught; see
MUTATION_MATRIX.tsv. Notable: under MUT-3 the composed classifier additionally
failed closed (unrecognized fragment status -> UNKNOWN_HOLD), i.e. the second
guard held even with the first deliberately broken.

The sealed SHA256SUMS binds the RESTORED (clean) checker; mutated variants were
never written into the package tree outside src/ and were reverted byte-exact
from backup before sealing (verified by the final clean 42/42 run).

## Post-seal defect and correction (logged)

The initial seal placed `.sha256` sidecars inside `cases/`, and the runner
iterated all directory entries, crashing on sidecar files (JSONDecodeError)
during the post-seal verification rerun. Corrected by filtering `*.json` in
both case loaders; suite rerun clean 42/42; package resealed. Reviewer error
class: packaging step changed the runtime input set of the sealed artifact —
the post-seal verification rerun existed precisely to catch this, and did.
