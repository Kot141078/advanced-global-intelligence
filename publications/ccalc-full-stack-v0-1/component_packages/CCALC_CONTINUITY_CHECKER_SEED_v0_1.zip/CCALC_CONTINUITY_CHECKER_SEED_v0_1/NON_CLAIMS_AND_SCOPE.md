# Non-Claims and Scope — Continuity Checker Seed v0.1

This package does NOT claim:

1. that any live system is continuous, a person, or conscious;
2. C-A1 ontology; a checker pass is C-A6/C-A7 material only;
3. deployment safety or production readiness;
4. completeness of the fixture set beyond the mechanisms listed in README;
5. that d_U or any scalar may act as an authority gate — the checker
   mechanically refuses this (SCALAR_AUTHORITY_GATE_FORBIDDEN);
6. extraction of trace facts from raw ledgers — the seed consumes classified,
   hash-bound facts; extraction/verification belongs to the transition-checker
   lineage (doc-03 / step_g), not to this layer;
7. that the equivalence-property probes are exhaustive — they sample
   reflexivity/symmetry/transitivity over fixture states, they do not prove
   the properties universally (open issue O0/O6 territory: formal proof layer).

Scope boundary: this is a seed (04a). Fork/replay/archive record-schema
validation (10-13), memory/witness continuity detail (14-15), and the
continuity matrix / transition adjacency audit (17-18) are follow-on themes.
