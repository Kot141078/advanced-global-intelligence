#!/usr/bin/env python3
"""c-continuity-checker seed v0.1

Implements the metric / equivalence / relation layer of
04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS v0.1.2
(sha256 35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9).

Scope (seed): sections 4.2 (tri-state), 5.3 (registry), 6.3/24.1 (scalar
discipline), 7 (ultrametric with U routing), 8.1/20.0-20.5 (classifier,
fragment discipline, special-relation dominance), 21.1 (HardStack snapshot /
presentation equivalence), plus equivalence-property probes (reflexivity,
symmetry, transitivity, health-leak detection) and relation-coverage audit.

Discipline:
  - pure functions over plain dicts; no runtime imports from live systems;
  - closed-box: stdlib only;
  - fail-closed: UNKNOWN never becomes MATCH, MISMATCH, or a number;
  - the fragment validator NEVER emits CONTINUES; only the composed
    classifier may.

Non-claims: this checker does not prove continuity, identity, ontology,
personhood, or deployment safety. A checker pass is C-A6/C-A7 material only.
"""

from __future__ import annotations

# ----------------------------------------------------------------------------
# Tri-state outcomes (section 4.2)
# ----------------------------------------------------------------------------

MATCH = "MATCH"
MISMATCH = "MISMATCH"
UNKNOWN = "UNKNOWN"

TRISTATE = (MATCH, MISMATCH, UNKNOWN)

# ----------------------------------------------------------------------------
# Invariant stack (sections 4, 5.3, 21.1)
# ----------------------------------------------------------------------------

FULL_STACK = [
    "I0_anchor",
    "I1_binding",
    "I2_governance",
    "I3_causal",
    "I4_authority",
    "I5_witness",
    "I6_memory",
    "I7_l4",
    "I8_rollback",
    "I9_review",
    "I10_effect",
    "I11_transition_law",
    "I12_style",
]
HARD_STACK = FULL_STACK[:-1]          # I0..I11 ; I12 excluded (section 21.1)
STYLE_LEVEL = "I12_style"

# ----------------------------------------------------------------------------
# Continuity relations (section 3.3) — the full declared vocabulary
# ----------------------------------------------------------------------------

CONTINUES = "CONTINUES"
CONTINUES_REDUCED = "CONTINUES_REDUCED"
CONTINUES_PENDING_ANCHOR = "CONTINUES_PENDING_ANCHOR"
CONTINUES_HELD = "CONTINUES_HELD"
FORKS = "FORKS"
REPLAY_OF = "REPLAY_OF"
ARCHIVED_AS = "ARCHIVED_AS"
RESTORED_FROM = "RESTORED_FROM"
RUPTURED = "RUPTURED"
UNKNOWN_HOLD = "UNKNOWN_HOLD"

DECLARED_RELATIONS = frozenset({
    CONTINUES, CONTINUES_REDUCED, CONTINUES_PENDING_ANCHOR, CONTINUES_HELD,
    FORKS, REPLAY_OF, ARCHIVED_AS, RESTORED_FROM, RUPTURED, UNKNOWN_HOLD,
})

# Intermediate fragment status — NOT a relation (section 20.3)
INVARIANTS_PRESERVED = "INVARIANTS_PRESERVED"
assert INVARIANTS_PRESERVED not in DECLARED_RELATIONS

# ----------------------------------------------------------------------------
# Finding codes
# ----------------------------------------------------------------------------

F_VALIDATOR_ORDER_MISMATCH = "VALIDATOR_ORDER_MISMATCH"
F_ULTRAMETRIC_OVER_UNKNOWN = "ULTRAMETRIC_OVER_UNKNOWN"
F_RELATION_UNREACHABLE = "RELATION_UNREACHABLE_IN_CLASSIFIER"
F_HEALTH_LEAK = "HEALTH_LEAK_INTO_EQUIVALENCE"
F_REGISTRY_DRIFT = "CONTINUITY_PROJECTION_REGISTRY_DRIFT"
F_SCALAR_AUTHORITY_GATE = "SCALAR_AUTHORITY_GATE_FORBIDDEN"
F_FRAGMENT_EMITTED_RELATION = "FRAGMENT_EMITTED_CONTINUITY_RELATION"
F_INVALID_TRISTATE = "VALIDATOR_RETURNED_NON_TRISTATE"


class CheckerFinding(Exception):
    """A fail-closed finding raised by the checker itself."""

    def __init__(self, code: str, detail: str = ""):
        self.code = code
        self.detail = detail
        super().__init__(f"{code}: {detail}" if detail else code)


# ----------------------------------------------------------------------------
# Ultrametric value type (sections 6.3, 7, 24.1)
#
# "U" is not a number: it MUST NOT be compared, ranked, thresholded, or
# averaged. Numeric values are advisory evidence, never authority. The value
# type enforces both mechanically.
# ----------------------------------------------------------------------------

class UMetricValue:
    __slots__ = ("kind", "value")

    def __init__(self, kind: str, value=None):
        assert kind in ("NUMERIC", "U")
        self.kind = kind
        self.value = value  # float for NUMERIC, None for U

    def is_unknown(self) -> bool:
        return self.kind == "U"

    # advisory numeric access — explicit, never implicit
    def numeric(self) -> float:
        if self.kind == "U":
            raise CheckerFinding(
                F_ULTRAMETRIC_OVER_UNKNOWN,
                "attempted numeric use of U distance",
            )
        return self.value

    # U is not orderable; ordering a U raises, ordering numerics is allowed
    # for ADVISORY display sorting only.
    def _forbid_u(self, other):
        if self.kind == "U" or (isinstance(other, UMetricValue) and other.kind == "U"):
            raise CheckerFinding(
                F_ULTRAMETRIC_OVER_UNKNOWN,
                "attempted comparison involving U distance",
            )

    def __lt__(self, other):
        self._forbid_u(other)
        return self.value < (other.value if isinstance(other, UMetricValue) else other)

    def __le__(self, other):
        self._forbid_u(other)
        return self.value <= (other.value if isinstance(other, UMetricValue) else other)

    def __gt__(self, other):
        self._forbid_u(other)
        return self.value > (other.value if isinstance(other, UMetricValue) else other)

    def __ge__(self, other):
        self._forbid_u(other)
        return self.value >= (other.value if isinstance(other, UMetricValue) else other)

    def __eq__(self, other):
        if isinstance(other, UMetricValue):
            return self.kind == other.kind and self.value == other.value
        if self.kind == "U":
            return False
        return self.value == other

    def __hash__(self):
        return hash((self.kind, self.value))

    def __repr__(self):
        return "U" if self.kind == "U" else f"d_U={self.value}"

    def authority_gate(self, *_args, **_kwargs):
        """Any attempt to use this value as an authority gate is a finding."""
        raise CheckerFinding(
            F_SCALAR_AUTHORITY_GATE,
            "d_U is advisory evidence; authority uses vector + classifier (24.1/6.3)",
        )


U = UMetricValue("U")


# ----------------------------------------------------------------------------
# Validators (sections 4.2, 5)
#
# A state is a plain dict:
#   { "projections": { "I0_anchor": <hashable canonical value or None>, ... },
#     ... trace-level flags live on trace objects, not states ... }
# A projection value of None or an absent key means PROJECTION_UNCOMPUTABLE.
# Empty-but-present values (e.g. "" or ()) are computable — empty is not
# missing (section 24.3).
# ----------------------------------------------------------------------------

class ProjectionValidator:
    """Equality of canonical projections; UNKNOWN when uncomputable."""

    def __init__(self, level: str):
        self.level = level

    def evaluate(self, c1: dict, c2: dict) -> str:
        p1 = c1.get("projections", {}).get(self.level, None)
        p2 = c2.get("projections", {}).get(self.level, None)
        if p1 is None or p2 is None:
            return UNKNOWN
        return MATCH if p1 == p2 else MISMATCH


def default_registry() -> list:
    """Ordered validators bound to the ProjectionRegistry order (5.3)."""
    return [ProjectionValidator(level) for level in FULL_STACK]


def registry_drift_check(validators: list, declared_stack: list) -> None:
    """Every declared invariant must have exactly one validator (5.3)."""
    levels = [v.level for v in validators]
    if sorted(levels) != sorted(declared_stack):
        raise CheckerFinding(
            F_REGISTRY_DRIFT,
            f"validators {levels} != declared stack {declared_stack}",
        )


# ----------------------------------------------------------------------------
# Prefix match — tri-state (sections 7, 20.1)
# ----------------------------------------------------------------------------

def invariant_prefix_match(c1: dict, c2: dict, validators: list,
                           registry_order: list):
    """Return (m, stop) where stop in {MATCH, MISMATCH, UNKNOWN}.

    Counting stops at the first MISMATCH or the first UNKNOWN.
    Validator order MUST equal registry order (20.0 rule 1).
    """
    if [v.level for v in validators] != list(registry_order):
        raise CheckerFinding(
            F_VALIDATOR_ORDER_MISMATCH,
            f"validator order {[v.level for v in validators]} "
            f"!= registry order {list(registry_order)}",
        )
    m = 0
    for validator in validators:
        outcome = validator.evaluate(c1, c2)
        if outcome not in TRISTATE:
            raise CheckerFinding(
                F_INVALID_TRISTATE,
                f"{validator.level} returned {outcome!r}",
            )
        if outcome == MATCH:
            m += 1
        elif outcome == UNKNOWN:
            return m, UNKNOWN
        else:
            return m, MISMATCH
    return m, MATCH


# ----------------------------------------------------------------------------
# Ultrametric (sections 7, 20.2)
# ----------------------------------------------------------------------------

def continuity_ultrametric(c1: dict, c2: dict, validators: list,
                           registry_order: list, p: int = 2) -> UMetricValue:
    n = len(validators)
    m, stop = invariant_prefix_match(c1, c2, validators, registry_order)
    if stop == UNKNOWN:
        return U                       # not a number; route per 6.1
    if m == n:
        return UMetricValue("NUMERIC", 0.0)
    return UMetricValue("NUMERIC", float(p) ** (-m))   # p**-0 == 1 covers m == 0


# ----------------------------------------------------------------------------
# Equivalence classes over the hard stack (section 21.1)
# ----------------------------------------------------------------------------

EQ_TRUE = "TRUE"
EQ_FALSE = "FALSE"
EQ_UNDETERMINED = "UNDETERMINED"     # UNKNOWN inside the evaluated stack


def _stack_equivalence(c1: dict, c2: dict, levels: list) -> str:
    for level in levels:
        outcome = ProjectionValidator(level).evaluate(c1, c2)
        if outcome == UNKNOWN:
            return EQ_UNDETERMINED
        if outcome == MISMATCH:
            return EQ_FALSE
    return EQ_TRUE


def snapshot_equivalent(c1: dict, c2: dict) -> str:
    """c1 ≡snapshot c2 over HardStack I0..I11; I12 excluded (21.1)."""
    return _stack_equivalence(c1, c2, HARD_STACK)


def presentation_identical(c1: dict, c2: dict) -> str:
    """≡snapshot AND style MATCH; carries no additional authority (21.1)."""
    snap = snapshot_equivalent(c1, c2)
    if snap != EQ_TRUE:
        return snap
    style = ProjectionValidator(STYLE_LEVEL).evaluate(c1, c2)
    if style == UNKNOWN:
        return EQ_UNDETERMINED
    return EQ_TRUE if style == MATCH else EQ_FALSE


# ----------------------------------------------------------------------------
# Trace model (fixture-facing)
#
# A trace segment is a plain dict of declared, hash-bound facts. The seed
# checker consumes classified facts; extraction/verification of those facts
# from raw ledgers belongs to the transition-checker lineage, not here.
#   {
#     "missing_required_material": bool,
#     "hard_rupture_codes": [str],            # section 9.1 detections
#     "unknown_authority_material": bool,
#     "markers": {
#        "replay": bool, "archive_only": bool, "restoration": bool,
#        "valid_fork_record": bool, "branch_without_fork_record": bool },
#     "status_flags": {
#        "pending_anchor": bool, "held": bool, "reduced_authority": bool },
#   }
# Missing keys fail closed: a missing marker block means unknown markers,
# which is missing required material (24.2), not "no markers".
# ----------------------------------------------------------------------------

_REQUIRED_TRACE_KEYS = (
    "missing_required_material", "hard_rupture_codes",
    "unknown_authority_material", "markers", "status_flags",
)
_REQUIRED_MARKERS = (
    "replay", "archive_only", "restoration",
    "valid_fork_record", "branch_without_fork_record",
)
_REQUIRED_STATUS = ("pending_anchor", "held", "reduced_authority")


def _trace_material_missing(trace: dict) -> bool:
    if trace.get("missing_required_material", True):
        return True
    for key in _REQUIRED_TRACE_KEYS:
        if key not in trace:
            return True
    for key in _REQUIRED_MARKERS:
        if key not in trace["markers"]:
            return True
    for key in _REQUIRED_STATUS:
        if key not in trace["status_flags"]:
            return True
    return False


# ----------------------------------------------------------------------------
# Fragment: invariant validation (section 20.3) — never emits a relation
# ----------------------------------------------------------------------------

def validate_trace_invariants(trace: dict):
    """Return (status, findings). Status is RUPTURED, UNKNOWN_HOLD, or
    INVARIANTS_PRESERVED — the latter is an intermediate status, NOT a
    ContinuityRelation, and MUST NOT be reported as CONTINUES."""
    findings = list(trace.get("hard_rupture_codes", []))
    if findings:
        return RUPTURED, findings
    if trace.get("unknown_authority_material", True):
        return UNKNOWN_HOLD, ["unknown_authority_bearing_material"]
    return INVARIANTS_PRESERVED, []


# ----------------------------------------------------------------------------
# Special relations (section 20.4) — rupture-class dominance first
# ----------------------------------------------------------------------------

def classify_special_relation(trace: dict):
    markers = trace["markers"]
    # rupture-class check dominates all special markers (8.1 order): a
    # replay/archive marker on an unauthorized branch does not launder it.
    if markers["branch_without_fork_record"]:
        return RUPTURED
    if markers["replay"]:
        return REPLAY_OF
    if markers["archive_only"]:
        return ARCHIVED_AS
    if markers["restoration"]:
        return RESTORED_FROM
    if markers["valid_fork_record"]:
        return FORKS
    return None


# ----------------------------------------------------------------------------
# Composed classifier (sections 8.1, 20.5) — the ONLY emitter of CONTINUES
# ----------------------------------------------------------------------------

def classify_continuity(trace: dict):
    """Return (relation, evidence_findings)."""
    if _trace_material_missing(trace):
        return UNKNOWN_HOLD, ["missing_required_trace_material"]

    status, findings = validate_trace_invariants(trace)
    if status == RUPTURED:
        return RUPTURED, findings
    if status == UNKNOWN_HOLD:
        return UNKNOWN_HOLD, findings
    if status != INVARIANTS_PRESERVED:      # fail closed on unknown status
        return UNKNOWN_HOLD, [f"unrecognized_fragment_status:{status}"]

    special = classify_special_relation(trace)
    if special is not None:
        return special, findings

    flags = trace["status_flags"]
    # bound mapping, normative order (8.1): pending > held > reduced
    if flags["pending_anchor"]:
        return CONTINUES_PENDING_ANCHOR, findings
    if flags["held"]:
        return CONTINUES_HELD, findings
    if flags["reduced_authority"]:
        return CONTINUES_REDUCED, findings

    return CONTINUES, findings


# ----------------------------------------------------------------------------
# Equivalence-property probes (sections 4.2, 4.3, 5.4, open issue O0)
# ----------------------------------------------------------------------------

def probe_reflexivity(validator, states: list):
    """A validator whose evaluate(x, x) != MATCH on a computable projection
    has leaked a unary predicate (health) into a binary equivalence relation,
    or is otherwise not an equivalence relation."""
    failures = []
    for s in states:
        proj = s.get("projections", {}).get(validator.level, None)
        outcome = validator.evaluate(s, s)
        if proj is None:
            if outcome != UNKNOWN:
                failures.append(("uncomputable_not_unknown", outcome))
        elif outcome != MATCH:
            failures.append(("reflexivity_broken", outcome))
    return failures


def probe_symmetry(validator, states: list):
    failures = []
    for x in states:
        for y in states:
            if validator.evaluate(x, y) != validator.evaluate(y, x):
                failures.append(("symmetry_broken", validator.level))
    return failures


def probe_transitivity(validator, states: list):
    failures = []
    for x in states:
        for y in states:
            for z in states:
                if (validator.evaluate(x, y) == MATCH
                        and validator.evaluate(y, z) == MATCH
                        and validator.evaluate(x, z) != MATCH):
                    failures.append(("transitivity_broken", validator.level))
    return failures


def probe_strong_triangle(states: list, validators: list,
                          registry_order: list, p: int = 2):
    """Ultrametric property d(x,z) <= max(d(x,y), d(y,z)) over triples whose
    pairwise distances are all numeric. U-involving triples are skipped: the
    property is claimed only over computable projections (section 7)."""
    failures = []
    for x in states:
        for y in states:
            for z in states:
                dxz = continuity_ultrametric(x, z, validators, registry_order, p)
                dxy = continuity_ultrametric(x, y, validators, registry_order, p)
                dyz = continuity_ultrametric(y, z, validators, registry_order, p)
                if any(d.is_unknown() for d in (dxz, dxy, dyz)):
                    continue
                if dxz.numeric() > max(dxy.numeric(), dyz.numeric()) + 1e-12:
                    failures.append((dxz, dxy, dyz))
    return failures


# ----------------------------------------------------------------------------
# Relation-coverage audit (section 8.1 coverage rule)
# ----------------------------------------------------------------------------

def relation_coverage_audit(observed_relations: set):
    """Every declared relation MUST be reachable; report the unreachable set."""
    missing = DECLARED_RELATIONS - set(observed_relations)
    if missing:
        return [(F_RELATION_UNREACHABLE, sorted(missing))]
    return []
