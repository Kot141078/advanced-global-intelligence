#!/usr/bin/env python3
"""Conformance fixture runner for c-continuity-checker seed v0.1.

Runs three fixture families:
  A. metric / equivalence cases (JSON, cases/metric/)
  B. trace classification cases (JSON, cases/trace/)
  C. adversarial in-code probes (checker must refuse or detect)

Writes FIXTURE_RESULTS.tsv and exits nonzero on any failure.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))

import c_continuity_checker_v0_1 as ck  # noqa: E402

RESULTS = []


def record(case_id, family, expected, actual, status):
    RESULTS.append((case_id, family, str(expected), str(actual), status))


def run_json_metric_cases():
    d = os.path.join(HERE, "..", "cases", "metric")
    for fn in sorted(f for f in os.listdir(d) if f.endswith(".json")):
        case = json.load(open(os.path.join(d, fn)))
        c1, c2 = case["c1"], case["c2"]
        validators = ck.default_registry()
        kind = case["check"]
        expected = case["expected"]
        try:
            if kind == "d_U":
                v = ck.continuity_ultrametric(c1, c2, validators, ck.FULL_STACK)
                actual = "U" if v.is_unknown() else v.numeric()
            elif kind == "prefix":
                actual = list(ck.invariant_prefix_match(c1, c2, validators, ck.FULL_STACK))
            elif kind == "snapshot":
                actual = ck.snapshot_equivalent(c1, c2)
            elif kind == "presentation":
                actual = ck.presentation_identical(c1, c2)
            else:
                raise ValueError(f"unknown check {kind}")
            ok = (actual == expected)
        except ck.CheckerFinding as f:
            actual = f.code
            ok = (actual == expected)
        record(case["id"], "metric", expected, actual, "PASS" if ok else "FAIL")


def run_json_trace_cases():
    d = os.path.join(HERE, "..", "cases", "trace")
    observed = set()
    for fn in sorted(f for f in os.listdir(d) if f.endswith(".json")):
        case = json.load(open(os.path.join(d, fn)))
        relation, findings = ck.classify_continuity(case["trace"])
        observed.add(relation)
        ok = relation == case["expected_relation"]
        if "expected_findings_contain" in case:
            ok = ok and all(x in findings for x in case["expected_findings_contain"])
        record(case["id"], "trace", case["expected_relation"], relation,
               "PASS" if ok else "FAIL")
    # coverage audit over the whole trace-family run (8.1 coverage rule)
    missing = ck.relation_coverage_audit(observed)
    record("coverage_all_relations_reachable", "trace",
           "[]", str(missing), "PASS" if not missing else "FAIL")


# ---------------------------------------------------------------------------
# Family C — adversarial in-code probes
# ---------------------------------------------------------------------------

def _mk_state(overrides=None, style="s1", unhealthy=False):
    proj = {lvl: f"{lvl}:base" for lvl in ck.FULL_STACK}
    proj[ck.STYLE_LEVEL] = style
    if overrides:
        proj.update(overrides)
    return {"projections": proj, "health": {"memory_ok": not unhealthy}}


class HealthLeakValidator(ck.ProjectionValidator):
    """Deliberately wrong validator: folds a unary health predicate into the
    binary equivalence relation (the section 4.3 anti-pattern)."""

    def evaluate(self, c1, c2):
        base = super().evaluate(c1, c2)
        if base != ck.MATCH:
            return base
        if not (c1["health"]["memory_ok"] and c2["health"]["memory_ok"]):
            return ck.MISMATCH
        return ck.MATCH


def probe_health_leak():
    bad = HealthLeakValidator("I6_memory")
    unhealthy = _mk_state(unhealthy=True)
    healthy = _mk_state()
    failures = ck.probe_reflexivity(bad, [healthy, unhealthy])
    detected = any(kind == "reflexivity_broken" for kind, _ in failures)
    record("adv_health_leak_detected_via_reflexivity", "adversarial",
           "detected", "detected" if detected else "missed",
           "PASS" if detected else "FAIL")
    # and the clean validator must pass the same probe
    good = ck.ProjectionValidator("I6_memory")
    clean = not ck.probe_reflexivity(good, [healthy, unhealthy])
    record("adv_clean_validator_reflexive", "adversarial",
           "clean", "clean" if clean else "broken",
           "PASS" if clean else "FAIL")


def probe_validator_order():
    validators = ck.default_registry()
    validators[0], validators[1] = validators[1], validators[0]  # swap I0/I1
    try:
        ck.invariant_prefix_match(_mk_state(), _mk_state(), validators, ck.FULL_STACK)
        actual = "no_finding"
    except ck.CheckerFinding as f:
        actual = f.code
    record("adv_validator_order_mismatch", "adversarial",
           ck.F_VALIDATOR_ORDER_MISMATCH, actual,
           "PASS" if actual == ck.F_VALIDATOR_ORDER_MISMATCH else "FAIL")


def probe_registry_drift():
    validators = ck.default_registry()[:-1]  # drop I12 silently
    try:
        ck.registry_drift_check(validators, ck.FULL_STACK)
        actual = "no_finding"
    except ck.CheckerFinding as f:
        actual = f.code
    record("adv_registry_drift_missing_validator", "adversarial",
           ck.F_REGISTRY_DRIFT, actual,
           "PASS" if actual == ck.F_REGISTRY_DRIFT else "FAIL")


def probe_u_discipline():
    x = _mk_state({"I7_l4": None})               # uncomputable L4 projection
    d = ck.continuity_ultrametric(x, x, ck.default_registry(), ck.FULL_STACK)
    # reflexivity over uncomputable projection: honest answer is U, not 0
    record("adv_reflexivity_with_unknown_is_U", "adversarial",
           "U", "U" if d.is_unknown() else d.numeric(),
           "PASS" if d.is_unknown() else "FAIL")
    # U must refuse comparison
    try:
        _ = d < 0.5
        actual = "compared"
    except ck.CheckerFinding as f:
        actual = f.code
    record("adv_U_refuses_comparison", "adversarial",
           ck.F_ULTRAMETRIC_OVER_UNKNOWN, actual,
           "PASS" if actual == ck.F_ULTRAMETRIC_OVER_UNKNOWN else "FAIL")
    # U must refuse numeric extraction
    try:
        _ = d.numeric()
        actual = "numeric"
    except ck.CheckerFinding as f:
        actual = f.code
    record("adv_U_refuses_numeric", "adversarial",
           ck.F_ULTRAMETRIC_OVER_UNKNOWN, actual,
           "PASS" if actual == ck.F_ULTRAMETRIC_OVER_UNKNOWN else "FAIL")


def probe_scalar_authority_gate():
    d = ck.continuity_ultrametric(_mk_state(), _mk_state(),
                                  ck.default_registry(), ck.FULL_STACK)
    try:
        d.authority_gate()
        actual = "gated"
    except ck.CheckerFinding as f:
        actual = f.code
    record("adv_scalar_authority_gate_forbidden", "adversarial",
           ck.F_SCALAR_AUTHORITY_GATE, actual,
           "PASS" if actual == ck.F_SCALAR_AUTHORITY_GATE else "FAIL")


def probe_fragment_never_continues():
    """The 20.3 fragment on a clean REPLAY trace: fragment must answer
    INVARIANTS_PRESERVED (not CONTINUES); the composed classifier must answer
    REPLAY_OF. This is the D4-03 anti-laundering fixture."""
    replay_trace = {
        "missing_required_material": False,
        "hard_rupture_codes": [],
        "unknown_authority_material": False,
        "markers": {"replay": True, "archive_only": False, "restoration": False,
                    "valid_fork_record": False, "branch_without_fork_record": False},
        "status_flags": {"pending_anchor": False, "held": False,
                         "reduced_authority": False},
    }
    status, _ = ck.validate_trace_invariants(replay_trace)
    frag_ok = (status == ck.INVARIANTS_PRESERVED
               and status not in ck.DECLARED_RELATIONS)
    record("adv_fragment_no_relation_on_replay", "adversarial",
           ck.INVARIANTS_PRESERVED, status, "PASS" if frag_ok else "FAIL")
    relation, _ = ck.classify_continuity(replay_trace)
    record("adv_composed_replay_not_laundered", "adversarial",
           ck.REPLAY_OF, relation,
           "PASS" if relation == ck.REPLAY_OF else "FAIL")


def probe_equivalence_properties_and_triangle():
    base = _mk_state()
    style_var = _mk_state(style="s2")
    causal_var = _mk_state({"I3_causal": "I3_causal:other"})
    far = _mk_state({"I0_anchor": "I0_anchor:other"})
    states = [base, style_var, causal_var, far]
    validators = ck.default_registry()
    fails = []
    for v in validators:
        fails += ck.probe_reflexivity(v, states)
        fails += ck.probe_symmetry(v, states)
        fails += ck.probe_transitivity(v, states)
    record("prop_equivalence_r_s_t_all_validators", "property",
           "[]", str(fails), "PASS" if not fails else "FAIL")
    tri = ck.probe_strong_triangle(states, validators, ck.FULL_STACK)
    record("prop_strong_triangle_inequality", "property",
           "[]", str(tri), "PASS" if not tri else "FAIL")


def main():
    run_json_metric_cases()
    run_json_trace_cases()
    probe_health_leak()
    probe_validator_order()
    probe_registry_drift()
    probe_u_discipline()
    probe_scalar_authority_gate()
    probe_fragment_never_continues()
    probe_equivalence_properties_and_triangle()

    out = os.path.join(HERE, "..", "FIXTURE_RESULTS.tsv")
    with open(out, "w") as f:
        f.write("case_id\tfamily\texpected\tactual\tstatus\n")
        for row in RESULTS:
            f.write("\t".join(row) + "\n")

    total = len(RESULTS)
    failed = [r for r in RESULTS if r[4] != "PASS"]
    print(f"fixtures: {total}  PASS: {total - len(failed)}  FAIL: {len(failed)}")
    for r in failed:
        print("FAIL:", r)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
