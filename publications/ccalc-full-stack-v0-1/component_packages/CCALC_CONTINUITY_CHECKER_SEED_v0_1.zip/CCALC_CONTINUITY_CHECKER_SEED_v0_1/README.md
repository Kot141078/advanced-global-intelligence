# CCALC Continuity Checker Seed v0.1 (04a)

Seed implementation + conformance fixture pack for the metric / equivalence /
relation layer of `04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS_v0_1_2.md`
(accepted current; sha256 `35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9`).

Covers: tri-state match (4.2), registry-order binding (20.0/20.1), ultrametric
`d_U` with `U` routing and comparison refusal (6.3/7/20.2), HardStack snapshot /
presentation equivalence (21.1), special-relation dominance (20.4), composed
classifier as sole `CONTINUES` emitter (20.3/20.5), relation-coverage audit
(8.1), equivalence-property probes incl. health-leak detection via reflexivity
(4.3/O0), and strong-triangle-inequality property test (7).

Layout:

```text
src/c_continuity_checker_v0_1.py       pure-function checker, stdlib only
scripts/run_continuity_fixtures.py     runner; writes FIXTURE_RESULTS.tsv
cases/metric/  (13)                    d_U / prefix / equivalence cases
cases/trace/   (16)                    classifier cases incl. dominance + coverage
FIXTURE_RESULTS.tsv                    42 fixtures, all PASS on sealed run
MUTATION_MATRIX.tsv                    4 deliberate regressions, all caught
EXECUTION_LOG.md                       run + mutation evidence
NON_CLAIMS_AND_SCOPE.md
SHA256SUMS.txt
```

Run:

```bash
python3 scripts/run_continuity_fixtures.py
sha256sum -c SHA256SUMS.txt
```
