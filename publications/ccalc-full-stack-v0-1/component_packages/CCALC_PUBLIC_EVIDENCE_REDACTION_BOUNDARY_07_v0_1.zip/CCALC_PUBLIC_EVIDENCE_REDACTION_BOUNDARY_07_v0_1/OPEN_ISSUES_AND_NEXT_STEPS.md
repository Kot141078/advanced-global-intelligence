# Open Issues and Next Steps — 07

## Closed in this package

- Normative public evidence / redaction boundary.
- Disclosure class registry.
- Redaction requirements registry.
- Public surface map.
- Disclosure decision registry.
- Claim-force ceiling discipline.
- Red-pattern registry for disclosure laundering.

## Open for 07a

`07a_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1` should define machine-checkable records:

- `DisclosureManifest`
- `EvidenceItemRecord`
- `RedactionMap`
- `HashBindingMap`
- `KnownOmissionRecord`
- `ReleaseDecisionRecord`
- `PublicClaimRecord`

It should include fixture and mutation hardening for:

- hash-only semantic overclaim;
- silent redaction;
- credential leak;
- private memory leak;
- raw witness leak;
- missing known-omissions record;
- claim-force escalation;
- model-only approval;
- disclosure class mismatch;
- public authority laundering.

## Open for later layers

- 07b: fixture pack and mutation hardening.
- 07c: public release ledger / DOI bridge / website index binding.
- 07 umbrella after 07a–07c are complete.
