# Freeze Binding Protocol Note

Use external sidecar binding only.

```bash
sha256sum exact_file_bytes > filename.sha256
```

Do not place a file's own final digest inside the Markdown body that is being hashed.

For release packages, bind:

- exact source bytes;
- package ZIP bytes;
- source manifest;
- redaction/disclosure records;
- non-claims and scope files.
