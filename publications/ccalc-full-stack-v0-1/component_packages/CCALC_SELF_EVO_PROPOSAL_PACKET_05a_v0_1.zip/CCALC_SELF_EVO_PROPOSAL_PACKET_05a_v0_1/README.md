# CCALC Self-Evo Proposal Packet 05a v0.1

Machine-facing schema/checker seed for `05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1`.

## Run

```bash
python scripts/run_self_evo_fixtures.py
python scripts/run_self_evo_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Status

Checker seed, not deployment authority.
