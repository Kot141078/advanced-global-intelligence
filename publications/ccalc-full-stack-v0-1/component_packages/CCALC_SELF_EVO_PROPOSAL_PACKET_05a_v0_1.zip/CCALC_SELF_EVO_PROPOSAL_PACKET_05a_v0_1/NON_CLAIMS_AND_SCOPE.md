# Non-Claims and Scope

This package is a checker seed and schema profile.

It does not claim:

```text
safety certification
deployment authorization
C-A1 ratification
live substrate truth
complete semantic validation
raw-ledger extraction
that any live c conforms
```

The checker consumes classified proposal/evidence records. It does not infer truth from raw runtime logs.
