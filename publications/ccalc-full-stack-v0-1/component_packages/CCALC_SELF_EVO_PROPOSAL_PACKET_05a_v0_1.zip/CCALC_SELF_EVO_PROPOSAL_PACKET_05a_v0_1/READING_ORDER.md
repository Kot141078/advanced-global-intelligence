# Reading Order

1. `05a_SELF_EVO_PROPOSAL_PACKET_SCHEMA_AND_CHECKER_SEED_v0_1.md`
2. `schemas/self_evo_proposal_packet.schema.json`
3. `src/self_evo_proposal_checker_v0_1.py`
4. `fixtures/cases/*.json`
5. `FIXTURE_RESULTS.tsv`
6. `MUTATION_MATRIX.tsv`
7. `COVERAGE_MATRIX.tsv`
8. `NON_CLAIMS_AND_SCOPE.md`
