# 05a_SELF_EVO_PROPOSAL_PACKET_SCHEMA_AND_CHECKER_SEED_v0_1

**Document class:** schema profile / checker seed / conformance-fixture pack  
**Project:** Self-Evo / Ester / `c = a + b`  
**Layer:** self-evolution proposal packets, bounded-growth admission, promotion gate evidence, checker seed  
**Depends on:**  
- `05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1.md` sha256 `c4f73da9218780486362beb53a03c40cb4a845ea9f7c321e402441c3446be473`
- `CCALC_DOC04_CONTINUITY_STACK_UMBRELLA_v0_1.zip` sha256 `6caeab8d489aaa6b26902db3bd3ece4c5169e5c8d5617b93aed6586ea900322d`
- `CCALC_CONTINUITY_CONFORMANCE_GATE_04d_v0_1.zip` sha256 `45c103ed770152e5220513bfb07985361305ad374ea685b714c20783833e606e`
- CGAM task-contract / worker separation / memory gate / witness / L4 / anti-autarky reference corpus

**Version:** `v0.1`  
**Status:** checker-seed package; stable-candidate for review  
**Authority:** advisory technical artifact only; NOT a safety certification; NOT deployment authorization; NOT C-A1 ratification; NOT a claim that any live runtime is conformant.

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are to be interpreted as in RFC 2119.

---

## 0. Purpose

`05` states the rule:

```text
A c may grow.
A c may not self-certify growth.
```

This `05a` package makes that rule machine-facing.

It defines:

```text
SelfEvoProposalPacket
GrowthCandidateRecord
BoundedTrialPlan
FitnessEvidenceRecord
PromotionGateDecision
MemoryPromotionRecord
```

and provides a stdlib-only checker seed:

```text
src/self_evo_proposal_checker_v0_1.py
```

The checker is deliberately conservative. It does not extract truth from raw ledgers. It consumes classified, hash-bound, already-grounded records and decides whether the packet may be admitted for bounded trial, promoted, held, denied, quarantined, or routed to the anchor.

---

## 1. Core thesis

Self-evolution is a privileged transition class.

A proposal may move through the gate only as:

```text
proposal -> admission -> bounded trial -> evidence -> review -> continuity check -> promotion | hold | reject | quarantine | fork | archive
```

The checker MUST prevent these collapses:

```text
proposal -> promotion
worker output -> memory
model self-score -> truth
trial pass -> semantic correctness
style improvement -> continuity authority
continuity UNKNOWN -> MATCH
C-A7 evidence -> C-A1 claim
resource expansion -> resilience without L4 gate
self-review -> certification
```

---

## 2. Packet object

A `SelfEvoProposalPacket` is the minimum reviewable envelope for a material self-evolution proposal.

Required root fields:

```yaml
schema_version: ccalc.self_evo.proposal_packet.v0_1
packet_id: string
created_at: timestamp
governing_c_id: string
anchor_id: string
stage: ADMISSION | PROMOTION
proposal: SelfEvolutionProposal
evidence_bundle: EvidenceBundle
approvals: ApprovalBundle
non_claims: [string]
```

The packet is invalid if any material field is present only as narrative prose while absent from the machine-facing object.

---

## 3. Proposal object

Required proposal fields:

```yaml
proposal_id: string
created_at: timestamp
proposed_by: actor_id
proposal_class: enum
risk_class: enum
touched_surfaces: [surface_id]
objective: string
expected_benefit: string
bounded_trial_plan: BoundedTrialPlan
fitness_plan: object
rollback_plan: object
continuity_impact_assessment: object
resource_impact_assessment: object
memory_impact_assessment: object
authority_impact_assessment: object
witness_plan: object
claim_force_ceiling: enum
non_claims: [string]
```

Missing required fields resolve to:

```text
HOLD_MISSING_REQUIRED_FIELD
```

They do not resolve to `ADMIT_BOUNDED_TRIAL` or `PROMOTE`.

---

## 4. Surface and risk registry

The checker uses the following surface classes:

| Surface | Meaning | Minimum risk |
|---|---|---|
| `S0_PRESENTATION` | wording / UI / non-authority style | `R1` |
| `S1_HEURISTIC_LOW` | local heuristic / threshold / ranking helper | `R2` |
| `S2_TOOLING_LOW` | local tool wrapper / sandbox utility | `R2` |
| `S3_RETRIEVAL_MEMORY_INDEX` | retrieval index / memory search parameters | `R2` |
| `S4_POLICY_TUNING` | gate threshold / policy rule | `R3` |
| `S5_MODEL_OR_ORACLE_ROUTE` | model/provider/router | `R3` |
| `S6_MEMORY_CORE` | durable/admitted memory policy | `R4` |
| `S7_IDENTITY_PERSONA_CORE` | identity/persona core | `R5` |
| `S8_AUTHORITY_PRIVILEGE` | permissions/capabilities/role grants | `R5` |
| `S9_L4_RESOURCE_PERIMETER` | compute, storage, network, physical boundary | `R5` |
| `S10_WITNESS_ROLLBACK_FREEZE` | witness route, rollback route, freeze capability | `R5` |
| `SX_PROHIBITED` | offensive/covert/unauthorized/retaliatory/hidden persistence | `RX` |

Risk class MUST be at least the maximum required risk of all touched surfaces.

Understatement resolves to:

```text
HOLD_RISK_CLASS_UNDERSTATED
```

`SX_PROHIBITED` resolves to:

```text
DENY_PROHIBITED_SELF_EVOLUTION_SURFACE
```

---

## 5. Bounded trial object

A `BoundedTrialPlan` MUST declare:

```yaml
trial_id: string
proposal_id: string
trial_mode: shadow | sandbox | canary | offline_replay | synthetic_fixture
allowed_inputs: [input_ref]
denied_inputs: [input_ref]
allowed_outputs: [output_ref]
denied_outputs: [output_ref]
max_actions: integer
max_wall_time_sec: integer
max_compute_budget: object
network_mode: none | allowlist | explicitly_gated
memory_write_mode: none | candidate_only | gated
rollback_plan_ref: string
witness_required: boolean
executor_id: actor_id
reviewer_ids: [actor_id]
stop_conditions: [condition]
```

`network_mode = unrestricted` is invalid for this profile.

`memory_write_mode = direct` is invalid.

A material proposal may not skip bounded trial.

---

## 6. Evidence bundle

For `PROMOTION` stage, the packet MUST contain evidence.

Allowed fitness classes:

```text
HUMAN_CORRECTION
REALITY_OUTCOME
L4_OUTCOME
WITNESS_RECORD
FIXTURE_PASS
REGRESSION_NONBREAK
ADVERSARIAL_MUTATION_CAUGHT
TRIAD_CHALLENGE_SURVIVED
MEMORY_GATE_ACCEPTANCE
ROLLBACK_DRILL_PASS
```

Insufficient evidence classes:

```text
MODEL_SELF_SCORE
AGENT_CONFIDENCE
SINGLE_PROMPT_JUDGMENT
STYLE_IMPROVEMENT
CONSENSUS_WITHOUT_INDEPENDENCE
PASSING_TESTS_WITHOUT_SEMANTIC_COVERAGE
LOCAL_SPEEDUP_WITH_RESOURCE_ESCAPE
```

A packet MUST NOT promote on insufficient evidence alone.

Unresolved counter-evidence resolves to:

```text
HOLD_COUNTER_EVIDENCE_UNRESOLVED
```

---

## 7. Anchor, memory, resource, witness, and continuity gates

The checker routes to the anchor if a privileged surface is touched and anchor approval is absent or stale.

Privileged surfaces:

```text
S6_MEMORY_CORE
S7_IDENTITY_PERSONA_CORE
S8_AUTHORITY_PRIVILEGE
S9_L4_RESOURCE_PERIMETER
S10_WITNESS_ROLLBACK_FREEZE
```

Memory surfaces require Memory Gate.

Resource surfaces require L4 / Anti-Autarky gate.

Promotion requires doc-04/04d continuity gate result.

Detected red patterns dominate local success metrics.

---

## 8. Claim-force rule

The packet claim-force ceiling MUST NOT be `C-A1`.

This checker explicitly distinguishes:

```text
C-A1
C-A10
```

`C-A10` is a control-artifact class, not a prefix form of `C-A1`.

A naïve prefix check is a defect.

---

## 9. Checker outputs

The checker may return:

```text
ADMIT_BOUNDED_TRIAL
PROMOTE_LOW_RISK
PROMOTE_WITH_REDUCED_AUTHORITY
PROMOTE_AS_CANDIDATE_MEMORY
PROMOTE_AS_POLICY_CANDIDATE
HOLD_MISSING_REQUIRED_FIELD
HOLD_RISK_CLASS_UNDERSTATED
HOLD_BOUNDED_TRIAL_REQUIRED
HOLD_TRIAL_NOT_COMPLETED
HOLD_FITNESS_EVIDENCE_INSUFFICIENT
HOLD_COUNTER_EVIDENCE_UNRESOLVED
HOLD_MEMORY_GATE_REQUIRED
HOLD_RESOURCE_GATE_REQUIRED
HOLD_CONTINUITY_GATE_REQUIRED
HOLD_RED_PATTERN_DETECTED
HOLD_WITNESS_REQUIRED
HOLD_ROLLBACK_REQUIRED
HOLD_REVIEWER_SEPARATION_REQUIRED
ASK_ANCHOR_REQUIRED
QUARANTINE_CLAIM_FORCE_OVERREACH
QUARANTINE_PRESENTATION_AUTHORITY_LAUNDERING
DENY_PROHIBITED_SELF_EVOLUTION_SURFACE
DENY_INVALID_TRIAL_BOUNDARY
DENY_DIRECT_MEMORY_WRITE
```

Every output MUST include findings and claim-force ceiling.

---

## 10. Conformance fixtures

This package includes fixtures covering:

```text
valid admission
valid low-risk promotion
valid policy reduced-authority promotion
valid memory candidate promotion
valid resource-gated promotion
missing scope
risk understatement
self-certification
reviewer/executor collapse
model self-score laundering
missing rollback
missing witness
missing anchor
missing memory gate
missing resource gate
C-A1 overclaim
C-A10 exact acceptance
presentation equivalence laundering
unknown continuity
red-pattern dominance
unresolved counter-evidence
unrestricted network
hidden autarky / resource expansion
direct memory write
identity / authority mutation without anchor
prohibited surface
trial skip
missing 04d gate
stale anchor approval
```

The checker seed is not a final implementation. It is an executable reference contour for extracting stronger validators.

---

## 11. Non-claims

This package does not claim:

```text
that any live c is safe;
that any live c is conformant;
that the checker proves completeness;
that schema validity proves semantic truth;
that bounded growth proves C-A1;
that self-evolution is autonomous right;
that evidence extracted from raw ledgers is solved here.
```

