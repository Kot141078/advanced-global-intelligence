# Open Issues and Next Steps

## Open

- O5a-01: This seed does not parse raw ledgers. It expects classified evidence objects.
- O5a-02: The JSON schemas are structural; semantic gates are in the Python checker.
- O5a-03: Future versions should bind directly to 04d evidence-bundle objects by schema hash.
- O5a-04: Future versions should add a deterministic proposal-diff canonicalizer.

## Next natural layer

```text
05b_SELF_EVO_BOUNDARY_FIXTURE_AND_MUTATION_HARDENING_v0_1
```
