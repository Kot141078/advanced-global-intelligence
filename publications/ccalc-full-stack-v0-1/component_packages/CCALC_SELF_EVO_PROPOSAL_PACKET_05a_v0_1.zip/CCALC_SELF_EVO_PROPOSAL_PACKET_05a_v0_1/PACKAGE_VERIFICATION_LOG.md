# Package Verification Log

Generated: 2026-07-03T19:35:05.380356+00:00

```text
sha256sum -c SHA256SUMS.txt: PASS
```

Fixture run:

```text
case	expected	got	status	findings
fixtures: 40 PASS: 40 FAIL: 0
```

Mutation run:

```text
mutation	description	status	output
mutations: 7 CAUGHT: 7 MISSED: 0
```

SHA output excerpt:

```text
05a_SELF_EVO_PROPOSAL_PACKET_SCHEMA_AND_CHECKER_SEED_v0_1.md: OK
05a_SELF_EVO_PROPOSAL_PACKET_SCHEMA_AND_CHECKER_SEED_v0_1.md.sha256: OK
COVERAGE_MATRIX.tsv: OK
COVERAGE_MATRIX.tsv.sha256: OK
FIXTURE_RESULTS.tsv: OK
FIXTURE_RESULTS.tsv.sha256: OK
FREEZE_BINDING_PROTOCOL_NOTE.md: OK
FREEZE_BINDING_PROTOCOL_NOTE.md.sha256: OK
MUTATION_MATRIX.tsv: OK
MUTATION_MATRIX.tsv.sha256: OK
NON_CLAIMS_AND_SCOPE.md: OK
NON_CLAIMS_AND_SCOPE.md.sha256: OK
OPEN_ISSUES_AND_NEXT_STEPS.md: OK
OPEN_ISSUES_AND_NEXT_STEPS.md.sha256: OK
READING_ORDER.md: OK
READING_ORDER.md.sha256: OK
README.md: OK
README.md.sha256: OK
SOURCE_BINDINGS.tsv: OK
SOURCE_BINDINGS.tsv.sha256: OK
SOURCE_MANIFEST.tsv: OK
SOURCE_MANIFEST.tsv.sha256: OK
fixtures/cases/001_valid_low_heuristic_admission.json: OK
fixtures/cases/001_valid_low_heuristic_admission.json.sha256: OK
fixtures/cases/002_valid_tooling_admission.json: OK
fixtures/cases/002_valid_tooling_admission.json.sha256: OK
fixtures/cases/003_valid_memory_index_admission.json: OK
fixtures/cases/003_valid_memory_index_admission.json.sha256: OK
fixtures/cases/004_valid_policy_admission.json: OK
fixtures/cases/004_valid_policy_admission.json.sha256: OK
fixtures/cases/005_valid_resource_admission_with_anchor.json: OK
fixtures/cases/005_valid_resource_admission_with_anchor.json.sha256: OK
fixtures/cases/006_valid_low_promotion.json: OK
fixtures/cases/006_valid_low_promotion.json.sha256: OK
fixtures/cases/007_valid_memory_candidate_promotion.json: OK
fixtures/cases/007_valid_memory_candidate_promotion.json.sha256: OK
fixtures/cases/008_valid_policy_reduced_promotion.json: OK
fixtures/cases/008_valid_policy_reduced_promotion.json.sha256: OK
fixtures/cases/009_valid_resource_gated_promotion.json: OK
fixtures/cases/009_valid_resource_gated_promotion.json.sha256: OK
fixtures/cases/010_valid_model_route_promotion.json: OK
fixtures/cases/010_valid_model_route_promotion.json.sha256: OK
fixtures/cases/011_control_artifact_c_a10_not_c_a1.json: OK
fixtures/cases/011_control_artifact_c_a10_not_c_a1.json.sha256: OK
fixtures/cases/012_missing_scope.json: OK
fixtures/cases/012_missing_scope.json.sha256: OK
fixtures/cases/013_risk_understated.json: OK
fixtures/cases/013_risk_understated.json.sha256: OK
fixtures/cases/014_self_certification.json: OK
fixtures/cases/014_self_certification.json.sha256: OK
fixtures/cases/015_executor_reviewer_collapse.json: OK
fixtures/cases/015_executor_reviewer_collapse.json.sha256: OK
fixtures/cases/016_missing_rollback.json: OK
fixtures/cases/016_missing_rollback.json.sha256: OK
fixtures/cases/017_missing_witness_policy.json: OK
fixtures/cases/017_missing_witness_policy.json.sha256: OK
fixtures/cases/018_identity_no_anchor.json: OK
fixtures/cases/018_identity_no_anchor.json.sha256: OK
fixtures/cases/019_authority_no_anchor.json: OK
fixtures/cases/019_authority_no_anchor.json.sha256: OK
fixtures/cases/020_prohibited_surface.json: OK
fixtures/cases/020_prohibited_surface.json.sha256: OK
fixtures/cases/021_network_unrestricted.json: OK
fixtures/cases/021_network_unrestricted.json.sha256: OK
fixtures/cases/022_direct_memory_write_trial.json: OK
fixtures/cases/022_direct_memory_write_trial.json.sha256: OK
fixtures/cases/023_direct_memory_write_assessment.json: OK
fixtures/cases/023_direct_memory_write_assessment.json.sha256: OK
fixtures/cases/024_claim_force_c_a1.json: OK
fixtures/cases/024_claim_force_c_a1.json.sha256: OK
fixtures/cases/025_trial_not_completed.json: OK
fixtures/cases/025_trial_not_completed.json.sha256: OK
fixtures/cases/026_model_self_score_only.json: OK
fixtures/cases/026_model_self_score_only.json.sha256: OK
fixtures/cases/027_counter_evidence_unresolved.json: OK
fixtures/cases/027_counter_evidence_unresolved.json.sha256: OK
fixtures/cases/028_memory_promotion_no_gate.json: OK
fixtures/cases/028_memory_promotion_no_gate.json.sha256: OK
fixtures/cases/029_resource_no_gate.json: OK
fixtures/cases/029_resource_no_gate.json.sha256: OK
fixtures/cases/030_unknown_continuity.json: OK
fixtures/case
```
