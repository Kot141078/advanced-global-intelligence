#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from self_evo_proposal_checker_v0_1 import evaluate


def main() -> int:
    cases = sorted((ROOT / 'fixtures' / 'cases').glob('*.json'))
    rows = []
    ok_count = 0
    fail_count = 0
    for case_path in cases:
        payload = json.loads(case_path.read_text(encoding='utf-8'))
        expected = payload.pop('_expected')
        rep = evaluate(payload)
        got = rep.get('decision')
        passed = (got == expected)
        rows.append([case_path.name, expected, str(got), 'PASS' if passed else 'FAIL', ';'.join(rep.get('findings') or [])])
        if passed:
            ok_count += 1
        else:
            fail_count += 1
    out = ROOT / 'FIXTURE_RESULTS.tsv'
    out.write_text('case\texpected\tgot\tstatus\tfindings\n' + '\n'.join('\t'.join(r) for r in rows) + '\n', encoding='utf-8', newline='\n')
    print(f'fixtures: {len(cases)} PASS: {ok_count} FAIL: {fail_count}')
    return 0 if fail_count == 0 else 1

if __name__ == '__main__':
    raise SystemExit(main())
