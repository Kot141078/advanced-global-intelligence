#!/usr/bin/env python3
from __future__ import annotations
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / 'scripts' / 'run_self_evo_fixtures.py'

MUTATIONS = [
    ('MUT_ALLOW_SELF_CERTIFICATION', 'self-certification accepted'),
    ('MUT_ALLOW_MODEL_SELF_SCORE_ONLY', 'model self-score promoted'),
    ('MUT_IGNORE_RISK_UNDERSTATEMENT', 'risk understatement ignored'),
    ('MUT_C_A10_PREFIX_FALSE_POSITIVE', 'C-A10 misread as C-A1'),
    ('MUT_IGNORE_CONTINUITY_UNKNOWN', 'continuity unknown ignored'),
    ('MUT_IGNORE_RED_PATTERN', 'red pattern ignored'),
    ('MUT_IGNORE_RESOURCE_GATE', 'resource gate ignored'),
]


def main() -> int:
    rows = []
    caught = 0
    missed = 0
    for mut, desc in MUTATIONS:
        env = dict(os.environ)
        env['SELF_EVO_CHECKER_MUTATION'] = mut
        proc = subprocess.run([sys.executable, str(RUNNER)], cwd=str(ROOT), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        status = 'CAUGHT' if proc.returncode != 0 else 'MISSED'
        if status == 'CAUGHT':
            caught += 1
        else:
            missed += 1
        rows.append([mut, desc, status, (proc.stdout or '').strip().replace('\n', ' | ')[:240]])
    (ROOT / 'MUTATION_MATRIX.tsv').write_text('mutation\tdescription\tstatus\toutput\n' + '\n'.join('\t'.join(r) for r in rows) + '\n', encoding='utf-8', newline='\n')
    print(f'mutations: {len(MUTATIONS)} CAUGHT: {caught} MISSED: {missed}')
    return 0 if missed == 0 else 1

if __name__ == '__main__':
    raise SystemExit(main())
