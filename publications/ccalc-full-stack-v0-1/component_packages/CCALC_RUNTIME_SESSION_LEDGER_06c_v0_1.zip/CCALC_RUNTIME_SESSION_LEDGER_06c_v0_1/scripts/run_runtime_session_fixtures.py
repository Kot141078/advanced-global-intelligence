#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from runtime_session_ledger_emergency_hold_checker_v0_1 import evaluate_session

cases = sorted((ROOT / "fixtures" / "cases").glob("*.json"))
rows = ["case_id\texpected_valid\tactual_valid\tdecision\tfinding_count\tstatus"]
pass_count = fail_count = 0
for path in cases:
    rec = json.loads(path.read_text(encoding="utf-8"))
    result = evaluate_session(rec)
    expected = rec.get("expected", {}).get("valid")
    ok = (result["valid"] == expected)
    code_expect = rec.get("expected", {}).get("finding_code_contains")
    if ok and code_expect:
        ok = any(code_expect in f["code"] for f in result["findings"])
    if ok: pass_count += 1
    else: fail_count += 1
    rows.append(f"{rec.get('case_id')}\t{expected}\t{result['valid']}\t{result['decision']}\t{len(result['findings'])}\t{'PASS' if ok else 'FAIL'}")
(ROOT / "FIXTURE_RESULTS.tsv").write_text("\n".join(rows)+"\n", encoding="utf-8")
print(f"fixtures: {len(cases)}  PASS: {pass_count}  FAIL: {fail_count}")
raise SystemExit(0 if fail_count == 0 else 1)
