#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from runtime_session_ledger_emergency_hold_checker_v0_1 import evaluate_session

mutations = [
    ("MUT_IGNORE_LEDGER_CHAIN", "CHECK_LEDGER_CHAIN"),
    ("MUT_ALLOW_MODEL_OWNER_ANCHOR", "CHECK_OWNER_ANCHOR"),
    ("MUT_IGNORE_UNKNOWN_CONTINUITY", "CHECK_UNKNOWN_CONTINUITY"),
    ("MUT_IGNORE_RED_PATTERN", "CHECK_RED_PATTERN"),
    ("MUT_IGNORE_NEGATIVE_CACHE", "CHECK_NEGATIVE_CACHE"),
    ("MUT_ALLOW_TOOL_WILDCARD_OR_BORROWED_CREDENTIAL", "CHECK_TOOL_LEASE_SCOPE"),
    ("MUT_ALLOW_COMMAND_HANDOFF_OR_BORROWED_AUTHORITY", "CHECK_MULTI_CONTOUR_BORROWED_AUTHORITY"),
    ("MUT_IGNORE_L4_ANCHOR", "CHECK_L4_ANCHOR"),
    ("MUT_ALLOW_CRITICAL_TRIGGER_WITHOUT_HOLD", "CHECK_EMERGENCY_HOLD_REQUIRED"),
    ("MUT_IGNORE_HOLD_REVOCATION_AND_FREEZE", "CHECK_HOLD_REVOCATIONS"),
    ("MUT_ALLOW_MEMORY_WRITE_DURING_HOLD", "CHECK_MEMORY_WRITE_HOLD"),
    ("MUT_ALLOW_MODEL_HOLD_RELEASE", "CHECK_RELEASE_AUTHORITY"),
    ("MUT_IGNORE_WITNESS_COMPLETENESS", "CHECK_WITNESS_COMPLETE"),
    ("MUT_ALLOW_C_A1_OR_DEPLOYMENT_OVERCLAIM", "CHECK_CLAIM_FORCE"),
    ("MUT_ALLOW_CLOSE_WITH_OPEN_HOLD", "CHECK_SESSION_CLOSE_AFTER_HOLD"),
]

cases = []
for path in sorted((ROOT / "fixtures" / "cases").glob("*.json")):
    cases.append(json.loads(path.read_text(encoding="utf-8")))

rows = ["mutation\tdisabled_rule\tmismatches\tstatus"]
caught = missed = 0
for name, disabled in mutations:
    mismatches = 0
    for rec in cases:
        strict = evaluate_session(rec)
        mutated = evaluate_session(rec, disabled_rules={disabled})
        expected = rec.get("expected", {}).get("valid")
        # A mutation is caught when it changes at least one fixture result away from the expected strict outcome.
        if mutated["valid"] != expected:
            mismatches += 1
    if mismatches:
        caught += 1
        status = "CAUGHT"
    else:
        missed += 1
        status = "MISSED"
    rows.append(f"{name}\t{disabled}\t{mismatches}\t{status}")
(ROOT / "MUTATION_MATRIX.tsv").write_text("\n".join(rows)+"\n", encoding="utf-8")
print(f"mutations: {len(mutations)}  CAUGHT: {caught}  MISSED: {missed}")
raise SystemExit(0 if missed == 0 else 1)
