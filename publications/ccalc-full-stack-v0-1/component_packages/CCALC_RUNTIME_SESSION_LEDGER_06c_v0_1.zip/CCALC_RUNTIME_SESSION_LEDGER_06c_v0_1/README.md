# CCALC Runtime Session Ledger 06c v0.1

This package contains `06c_RUNTIME_SESSION_LEDGER_AND_EMERGENCY_HOLD_DRILL_v0_1` plus schemas, checker seed, fixtures, mutation runner, registries, and verification logs.

## Run

```bash
python3 scripts/run_runtime_session_fixtures.py
python3 scripts/run_runtime_session_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Scope

Runtime session ledger + emergency hold drill. Record-shape and boundary checker only.

## Non-claims

Not safety certification. Not deployment authorization. Not C-A1 ratification. Not live substrate truth.
