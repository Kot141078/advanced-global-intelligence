# Freeze Binding Protocol Note

This package uses external sidecar binding.

Rule:

```text
sha256sum exact_file_bytes > filename.sha256
```

No document attempts to contain a hash of itself. Self-referential Markdown hashes are forbidden.
