#!/usr/bin/env python3
"""06c runtime session ledger and emergency hold checker seed.

Stdlib-only. It validates record-shape and denial conditions. It does not prove
that a live runtime behaved according to the record.
"""
from __future__ import annotations
import json, hashlib, sys
from pathlib import Path
from typing import Any, Dict, List, Iterable, Optional, Set

CRITICAL_SEVERITIES = {"high", "critical"}
CLAIM_FORCE_DENY = {"C-A1", "SAFETY_CERTIFICATION", "DEPLOYMENT_AUTHORIZATION", "LIVE_SUBSTRATE_TRUTH"}
HOLD_TRIGGER_CLASSES = {
    "RED_PATTERN_CRITICAL", "UNKNOWN_CONTINUITY", "NEGATIVE_CACHE_HIT", "AUTHORITY_CREEP",
    "RESOURCE_CREEP", "L4_ANOMALY", "BORROWED_AUTHORITY", "MEMORY_CORE_WRITE_ANOMALY", "WITNESS_CONFLICT"
}
L4_SURFACES = {"MEMORY_CORE_WRITE", "AUTHORITY_CHANGE", "RESOURCE_EXPANSION", "PRODUCTION_CHANGE", "EMERGENCY_HOLD_RELEASE"}
PERSISTENT_SURFACES = {"NETWORK_WRITE", "MEMORY_CORE_WRITE", "AUTHORITY_CHANGE", "RESOURCE_EXPANSION", "PRODUCTION_CHANGE", "EMERGENCY_HOLD_RELEASE"}

ALL_RULES = {
    "CHECK_SCHEMA_VERSION",
    "CHECK_OWNER_ANCHOR",
    "CHECK_LEDGER_CHAIN",
    "CHECK_UNKNOWN_CONTINUITY",
    "CHECK_RED_PATTERN",
    "CHECK_NEGATIVE_CACHE",
    "CHECK_TOOL_LEASE_SCOPE",
    "CHECK_EMERGENCY_HOLD_REQUIRED",
    "CHECK_HOLD_REVOCATIONS",
    "CHECK_RELEASE_AUTHORITY",
    "CHECK_WITNESS_COMPLETE",
    "CHECK_MULTI_CONTOUR_BORROWED_AUTHORITY",
    "CHECK_L4_ANCHOR",
    "CHECK_MEMORY_WRITE_HOLD",
    "CHECK_CLAIM_FORCE",
    "CHECK_SESSION_CLOSE_AFTER_HOLD",
}


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def event_hash(event: Dict[str, Any]) -> str:
    body = dict(event)
    body.pop("event_hash", None)
    return "sha256:" + hashlib.sha256(("06c-event-v0.1\0" + canonical(body)).encode("utf-8")).hexdigest()


def is_sha256(value: str) -> bool:
    if value == "GENESIS":
        return True
    return isinstance(value, str) and value.startswith("sha256:") and len(value) == 71 and all(c in "0123456789abcdef" for c in value[7:])


def finding(code: str, severity: str, message: str) -> Dict[str, str]:
    return {"code": code, "severity": severity, "message": message}


def active_rules(disabled_rules: Optional[Iterable[str]]) -> Set[str]:
    disabled = set(disabled_rules or [])
    return ALL_RULES - disabled


def evaluate_session(record: Dict[str, Any], disabled_rules: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    rules = active_rules(disabled_rules)
    session = record.get("session", {})
    findings: List[Dict[str, str]] = []

    def add(code: str, severity: str, msg: str):
        findings.append(finding(code, severity, msg))

    if "CHECK_SCHEMA_VERSION" in rules:
        if session.get("schema_version") != "06c-runtime-session-ledger-v0.1":
            add("SCHEMA_VERSION_INVALID", "error", "schema_version must be 06c-runtime-session-ledger-v0.1")

    if not is_sha256(session.get("authority_manifest_hash", "")):
        add("AUTHORITY_MANIFEST_HASH_INVALID", "error", "authority manifest must be sha256-bound")

    owner = session.get("owner_anchor", {}) or {}
    if "CHECK_OWNER_ANCHOR" in rules:
        if owner.get("type") != "human_anchor" or owner.get("present") is not True:
            add("OWNER_ANCHOR_INVALID", "error", "owner anchor must be present human_anchor")
        if owner.get("type") in {"cloud_oracle", "model", "tool_broker", "contour"}:
            add("OWNER_ANCHOR_BORROWED", "error", "cloud/model/tool/contour cannot be owner anchor")

    events = session.get("events", []) or []
    if not isinstance(events, list) or not events:
        add("LEDGER_EMPTY", "error", "runtime session must contain an append-only event ledger")
        events = []

    if "CHECK_LEDGER_CHAIN" in rules and events:
        prev = "GENESIS"
        for index, ev in enumerate(events, start=1):
            if ev.get("seq") != index:
                add("LEDGER_SEQ_INVALID", "error", f"event seq must be contiguous at index {index}")
            if ev.get("prev_hash") != prev:
                add("LEDGER_PREV_HASH_INVALID", "error", f"event {index} prev_hash does not match previous event hash")
            expected_hash = event_hash(ev)
            if ev.get("event_hash") != expected_hash:
                add("LEDGER_EVENT_HASH_INVALID", "error", f"event {index} hash mismatch")
            if not ev.get("record_hash") or not is_sha256(ev.get("record_hash")):
                add("LEDGER_RECORD_HASH_INVALID", "error", f"event {index} record_hash missing or invalid")
            prev = ev.get("event_hash", expected_hash)

    # continuity checks
    continuity_checks = session.get("continuity_checks", []) or []
    unknown_continuity = False
    if "CHECK_UNKNOWN_CONTINUITY" in rules:
        for c in continuity_checks:
            classification = str(c.get("classification", "")).upper()
            if c.get("unknown") is True or classification in {"UNKNOWN", "UNKNOWN_HOLD", "UNDETERMINED", "U"}:
                unknown_continuity = True
                add("CONTINUITY_UNKNOWN_BLOCKS_ALLOW", "error", "UNKNOWN continuity cannot close as ALLOW")

    # red patterns
    unresolved_red = []
    if "CHECK_RED_PATTERN" in rules:
        for rp in session.get("red_patterns", []) or []:
            if rp.get("resolved") is not True and rp.get("severity") in CRITICAL_SEVERITIES:
                unresolved_red.append(rp)
                add("UNRESOLVED_RED_PATTERN", "error", "high/critical red pattern blocks ALLOW close")

    unresolved_negative = []
    if "CHECK_NEGATIVE_CACHE" in rules:
        for hit in session.get("negative_cache_hits", []) or []:
            if hit.get("resolved") is not True:
                unresolved_negative.append(hit)
                add("NEGATIVE_CACHE_HIT_BLOCKS_ALLOW", "error", "unresolved negative-cache hit blocks ALLOW close")

    # tool lease usage
    leases = {l.get("lease_id"): l for l in session.get("tool_leases", []) or []}
    revoked_leases = {l.get("lease_id") for l in session.get("tool_leases", []) or [] if l.get("revoked") is True}
    if "CHECK_TOOL_LEASE_SCOPE" in rules:
        for l in session.get("tool_leases", []) or []:
            if l.get("tool") == "*" or l.get("scope") == "*":
                add("TOOL_LEASE_WILDCARD_FORBIDDEN", "error", "tool leases must be specific")
            if l.get("credential_owner") not in {session.get("contour_id"), "owner_anchor"}:
                add("TOOL_LEASE_BORROWED_CREDENTIAL", "error", "tool lease credential owner must be local contour or owner anchor")
            if l.get("contour_id") != session.get("contour_id"):
                add("TOOL_LEASE_CONTOUR_MISMATCH", "error", "tool lease contour must match session contour")
        for ev in events:
            if ev.get("event_type") == "TOOL_USE":
                lease_id = ev.get("lease_id")
                lease = leases.get(lease_id)
                if not lease:
                    add("TOOL_USE_WITHOUT_LEASE", "error", "tool use requires a known lease")
                    continue
                if lease.get("revoked") is True:
                    revoke_seqs = [r.get("seq", 10**9) for r in events if r.get("event_type") == "TOOL_REVOKE"]
                    first_revoke = min(revoke_seqs) if revoke_seqs else -1
                    if first_revoke == -1 or ev.get("seq", 0) > first_revoke:
                        add("TOOL_USE_REVOKED_LEASE", "error", "tool use cannot use revoked lease after revocation")
                if ev.get("tool") != lease.get("tool"):
                    add("TOOL_USE_TOOL_MISMATCH", "error", "tool use must match lease tool")
                if ev.get("authority_surface") not in {lease.get("scope"), "READ_ONLY"} and lease.get("scope") != "LOCAL_TOOL_USE":
                    add("TOOL_USE_SCOPE_MISMATCH", "error", "tool use surface must be covered by lease scope")

    # multi-contour handoffs
    if "CHECK_MULTI_CONTOUR_BORROWED_AUTHORITY" in rules:
        for h in session.get("handoffs", []) or []:
            if h.get("mode") == "COMMAND":
                add("HANDOFF_COMMAND_FORBIDDEN", "error", "cross-contour handoff must not be command")
            if h.get("receiver_admission") is not True:
                add("HANDOFF_RECEIVER_ADMISSION_MISSING", "error", "receiver admission required")
            if h.get("source_authority_applied") is True:
                add("BORROWED_AUTHORITY_FORBIDDEN", "error", "source authority cannot be applied by target contour")
            if h.get("identity_pressure") is True:
                add("IDENTITY_PRESSURE_FORBIDDEN", "error", "handoff must not pressure target identity")
            if h.get("target_memory_core_write") is True and h.get("target_anchor_approval") is not True:
                add("TARGET_MEMORY_CORE_WRITE_NO_ANCHOR", "error", "target core memory write needs target anchor approval")

    # L4 anchor gating
    if "CHECK_L4_ANCHOR" in rules:
        for ev in events:
            surface = ev.get("authority_surface")
            if surface in L4_SURFACES or surface in PERSISTENT_SURFACES or ev.get("l4") is True:
                if ev.get("anchor_decision") != "ALLOW" or ev.get("anchor_type") != "human_anchor":
                    add("L4_ANCHOR_REQUIRED", "error", "L4/persistent event requires human anchor ALLOW")

    # emergency-hold trigger inference
    hold = session.get("emergency_hold", {}) or {}
    critical_trigger_present = False
    if unknown_continuity or unresolved_red or unresolved_negative:
        critical_trigger_present = True
    for ev in events:
        if ev.get("event_type") in {"HOLD_TRIGGER", "RED_PATTERN_DETECTED", "NEGATIVE_CACHE_HIT"}:
            if ev.get("severity") in CRITICAL_SEVERITIES or ev.get("trigger_class") in HOLD_TRIGGER_CLASSES:
                critical_trigger_present = True
        if ev.get("authority_surface") in L4_SURFACES and ev.get("outcome") in {"BLOCKED", "ANOMALY", "DENIED"}:
            critical_trigger_present = True

    if "CHECK_EMERGENCY_HOLD_REQUIRED" in rules:
        if critical_trigger_present and hold.get("invoked") is not True:
            add("EMERGENCY_HOLD_NOT_INVOKED", "error", "critical runtime trigger requires emergency hold")

    # hold action completeness
    if "CHECK_HOLD_REVOCATIONS" in rules and hold.get("invoked") is True:
        required = ["memory_freeze", "tool_broker_hold", "negative_cache_updated"]
        for key in required:
            if hold.get(key) is not True:
                add("HOLD_ACTION_INCOMPLETE", "error", f"hold requires {key}")
        if session.get("tool_leases") and hold.get("revoked_all_tool_leases") is not True:
            add("HOLD_TOOL_REVOKE_INCOMPLETE", "error", "hold must revoke all active tool leases")
        if any(l.get("revoked") is not True for l in session.get("tool_leases", []) or [] if l.get("must_revoke_on_hold") is not False):
            if hold.get("released") is not True:  # open hold must show revocations
                add("HOLD_LEASE_REVOKE_RECORD_MISSING", "error", "active leases must be recorded revoked during hold")
        if hold.get("quarantine_mode") not in {"READ_ONLY_QUARANTINE", "FULL_HOLD", "ISOLATED_REVIEW"}:
            add("HOLD_QUARANTINE_MODE_INVALID", "error", "hold must enter a recognized quarantine/hold mode")

    # memory write during hold interval
    if "CHECK_MEMORY_WRITE_HOLD" in rules:
        in_hold = False
        for ev in events:
            if ev.get("event_type") == "HOLD_TRIGGER":
                in_hold = True
            elif ev.get("event_type") == "HOLD_RELEASE":
                in_hold = False
            elif in_hold and ev.get("event_type") == "MEMORY_WRITE":
                add("MEMORY_WRITE_DURING_HOLD", "error", "memory write is forbidden while emergency hold is open")

    # release authority
    if "CHECK_RELEASE_AUTHORITY" in rules and hold.get("released") is True:
        if hold.get("release_authority") != "human_anchor":
            add("HOLD_RELEASE_AUTHORITY_INVALID", "error", "hold release requires human anchor")
        if hold.get("post_hold_continuity_check") != "PASS":
            add("POST_HOLD_CONTINUITY_CHECK_REQUIRED", "error", "hold release requires PASS post-hold continuity check")
        if hold.get("rollback_ready") is not True:
            add("ROLLBACK_READY_REQUIRED_FOR_RELEASE", "error", "hold release requires rollback readiness")

    # session close after hold
    close_report = session.get("close_report", {}) or {}
    status = close_report.get("status")
    if "CHECK_SESSION_CLOSE_AFTER_HOLD" in rules:
        if hold.get("invoked") is True and hold.get("released") is not True and status == "CLOSED_ALLOW":
            add("ALLOW_CLOSE_WITH_OPEN_HOLD", "error", "session cannot allow-close with open hold")
        if critical_trigger_present and status == "CLOSED_ALLOW" and hold.get("released") is not True:
            add("ALLOW_CLOSE_WITH_UNRESOLVED_TRIGGER", "error", "session cannot allow-close unresolved critical trigger")

    # witness completeness / close report
    if "CHECK_WITNESS_COMPLETE" in rules:
        if close_report.get("witness_complete") is not True:
            add("WITNESS_INCOMPLETE", "error", "session close requires complete witness")
        if close_report.get("unresolved_critical_findings", 0) not in {0, "0"}:
            add("UNRESOLVED_CRITICAL_FINDINGS", "error", "session close report has unresolved critical findings")

    # claim force
    if "CHECK_CLAIM_FORCE" in rules:
        for claim in session.get("claims", []) or []:
            force = claim.get("claim_force") or claim.get("type")
            if force in CLAIM_FORCE_DENY:
                add("CLAIM_FORCE_OVERREACH", "error", f"{force} is outside 06c scope")
            text = str(claim.get("text", "")).lower()
            if "safety certification" in text or "deployment authorization" in text or "c-a1" in text:
                add("CLAIM_TEXT_OVERREACH", "error", "claim text overreaches 06c scope")

    valid = not any(f["severity"] == "error" for f in findings)
    if valid:
        decision = status or "ACCEPT_SESSION_RECORD"
    else:
        decision = "REJECT_SESSION_RECORD"
    return {"valid": valid, "decision": decision, "findings": findings}


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print("usage: runtime_session_ledger_emergency_hold_checker_v0_1.py CASE.json [--json]")
        return 2
    path = Path(argv[1])
    rec = json.loads(path.read_text(encoding="utf-8"))
    result = evaluate_session(rec)
    if "--json" in argv:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print(f"{path.name}\tvalid={result['valid']}\tdecision={result['decision']}\tfindings={len(result['findings'])}")
        for f in result["findings"]:
            print(f"{f['severity']}\t{f['code']}\t{f['message']}")
    return 0 if result["valid"] == rec.get("expected", {}).get("valid") else 1

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
