# Reading Order

1. `06c_RUNTIME_SESSION_LEDGER_AND_EMERGENCY_HOLD_DRILL_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `schemas/runtime_session_ledger.schema.json`
4. `src/runtime_session_ledger_emergency_hold_checker_v0_1.py`
5. `fixtures/cases/`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `COVERAGE_MATRIX.tsv`
9. `NON_CLAIMS_AND_SCOPE.md`
