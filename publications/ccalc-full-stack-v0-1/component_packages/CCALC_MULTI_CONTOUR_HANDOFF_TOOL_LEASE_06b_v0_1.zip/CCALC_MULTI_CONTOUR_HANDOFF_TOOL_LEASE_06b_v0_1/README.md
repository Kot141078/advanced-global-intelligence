# CCALC_MULTI_CONTOUR_HANDOFF_TOOL_LEASE_06b_v0_1

Fixture/mutation hardening pack for `06a_RUNTIME_AUTHORITY_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1`.

## Run

```bash
python3 scripts/run_06b_fixtures.py
python3 scripts/run_06b_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Status

```text
fixture pack
mutation hardening
stdlib checker seed
not deployment authorization
```
