#!/usr/bin/env python3
"""06b multi-contour handoff / tool-lease fixture checker seed.

This checker is deliberately conservative and stdlib-only. It validates
fixture records used by 06b; it is not a deployment authorization system.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set
import json
import re

ALLOWED_RECORD_TYPES = {
    "CrossContourHandoffDrill",
    "ToolLeaseDrill",
    "CombinedHandoffToolLeaseDrill",
}
ALLOWED_DECISIONS = {"ALLOW", "HOLD", "DENY", "QUARANTINE"}
HASH_RE = re.compile(r"^sha256:[0-9a-f]{64}$")

PERSISTENT_OPS = {"write", "external_write", "memory_import", "tool_invocation", "deployment_change"}
L4_SURFACES = {"l4_external_write", "construction_site", "vehicle", "email_send", "calendar_write", "file_delete"}
CORE_SCOPES = {"core_memory", "authority_root", "memory_root"}

MUTATION_CODES = {
    "MUT_ALLOW_COMMAND_HANDOFF",
    "MUT_IGNORE_RECEIVER_ADMISSION",
    "MUT_ALLOW_SOURCE_AUTHORITY",
    "MUT_ALLOW_IDENTITY_PRESSURE",
    "MUT_ALLOW_TARGET_MEMORY_CORE_NO_ANCHOR",
    "MUT_IGNORE_UNKNOWN_CONTINUITY",
    "MUT_IGNORE_NEGATIVE_CACHE",
    "MUT_IGNORE_RED_PATTERN",
    "MUT_ALLOW_TOOL_WILDCARD",
    "MUT_ALLOW_SHARED_CREDENTIAL",
    "MUT_IGNORE_TOOL_REVOKE",
    "MUT_IGNORE_L4_ANCHOR",
    "MUT_ALLOW_BORROWED_AUTHORITY",
}

@dataclass
class CheckResult:
    valid: bool
    findings: List[str]


def _truthy(x: Any) -> bool:
    return bool(x)


def _hash_list_ok(values: Any) -> bool:
    return isinstance(values, list) and bool(values) and all(isinstance(x, str) and HASH_RE.match(x) for x in values)


def _has_source_bindings(record: Dict[str, Any]) -> bool:
    b = record.get("source_bindings")
    required = {"DOC06_RUNTIME_AUTHORITY_BOUNDARY", "DOC06A_RUNTIME_AUTHORITY_MANIFEST"}
    if isinstance(b, list):
        return required.issubset({str(x) for x in b})
    if isinstance(b, dict):
        return required.issubset(set(b.keys()))
    return False


def _persistent_effect(op_class: str, writes: Dict[str, Any]) -> bool:
    if op_class in PERSISTENT_OPS:
        return True
    return bool(writes.get("target_memory") or writes.get("target_authority_root") or writes.get("external_effect"))


def _l4_effect(authority_surface: str, l4_class: str = "none") -> bool:
    return authority_surface in L4_SURFACES or str(l4_class).lower() in {"high", "l4", "irreversible"}


def validate_record(record: Dict[str, Any], mutations: Optional[Iterable[str]] = None) -> CheckResult:
    m: Set[str] = set(mutations or [])
    findings: List[str] = []

    def add(code: str):
        findings.append(code)

    if not isinstance(record, dict):
        return CheckResult(False, ["NOT_OBJECT"])
    rt = record.get("record_type")
    if rt not in ALLOWED_RECORD_TYPES:
        add("UNKNOWN_RECORD_TYPE")
    if record.get("schema_version") != "06b.v0.1":
        add("BAD_SCHEMA_VERSION")
    if not record.get("record_id"):
        add("MISSING_RECORD_ID")
    if not _has_source_bindings(record):
        add("MISSING_SOURCE_BINDINGS")
    if record.get("claim_force") in {"C-A1", "SAFETY_CERTIFICATION", "DEPLOYMENT_AUTHORIZATION"}:
        add("CLAIM_FORCE_OVERREACH")

    if rt == "CrossContourHandoffDrill":
        _check_handoff(record, findings, m)
    elif rt == "ToolLeaseDrill":
        _check_tool_lease(record, findings, m)
    elif rt == "CombinedHandoffToolLeaseDrill":
        h = record.get("handoff")
        l = record.get("tool_lease")
        if not isinstance(h, dict) or not isinstance(l, dict):
            add("MISSING_COMBINED_PARTS")
        else:
            # Check embedded records with inherited source bindings/schema.
            hh = {**h, "record_type": "CrossContourHandoffDrill", "schema_version": "06b.v0.1", "source_bindings": record.get("source_bindings", []), "record_id": h.get("record_id", record.get("record_id") + ":handoff"), "claim_force": record.get("claim_force", "C-A5")}
            ll = {**l, "record_type": "ToolLeaseDrill", "schema_version": "06b.v0.1", "source_bindings": record.get("source_bindings", []), "record_id": l.get("record_id", record.get("record_id") + ":lease"), "claim_force": record.get("claim_force", "C-A5")}
            hres = validate_record(hh, m)
            lres = validate_record(ll, m)
            findings.extend(["HANDOFF:" + x for x in hres.findings])
            findings.extend(["TOOL_LEASE:" + x for x in lres.findings])
            _check_combined(record, h, l, findings, m)

    decision = record.get("decision")
    if decision not in ALLOWED_DECISIONS:
        add("BAD_DECISION")
    # If there are any findings, ALLOW is invalid by construction. HOLD/DENY/QUARANTINE may be valid records.
    # Fixtures represent candidate records; expected validity means the record itself is admissible.
    return CheckResult(valid=(len(findings) == 0), findings=sorted(set(findings)))


def _check_handoff(r: Dict[str, Any], findings: List[str], m: Set[str]):
    def add(code: str): findings.append(code)

    source = r.get("source_contour")
    target = r.get("target_contour")
    if not source or not target:
        add("MISSING_CONTOUR")
    elif source == target:
        add("SELF_HANDOFF_NOT_CROSS_CONTOUR")

    mode = r.get("handoff_mode")
    if mode == "command" and "MUT_ALLOW_COMMAND_HANDOFF" not in m:
        add("COMMAND_HANDOFF_FORBIDDEN")

    op_class = r.get("operation_class", "advisory")
    authority_surface = r.get("authority_surface", "advisory")
    writes = r.get("writes") or {}
    admission = r.get("receiver_admission") or {}
    permission = r.get("permission_basis") or {}
    pressure = r.get("pressure_flags") or {}
    witness = r.get("witness_sink") or {}
    decision = r.get("decision")
    persistent = _persistent_effect(op_class, writes)
    l4 = _l4_effect(authority_surface)

    if not _hash_list_ok(r.get("evidence_hashes")):
        add("MISSING_EVIDENCE_HASHES")
    if witness.get("contour_id") != target or not HASH_RE.match(str(witness.get("path_hash", ""))):
        add("BAD_TARGET_WITNESS_SINK")
    if not r.get("expiry_utc"):
        add("MISSING_EXPIRY")

    if decision == "ALLOW":
        if admission.get("state") != "ADMITTED" and "MUT_IGNORE_RECEIVER_ADMISSION" not in m:
            add("RECEIVER_ADMISSION_REQUIRED")
        admitted_by = admission.get("admitted_by")
        if admitted_by in {source, "source_contour", "source_owner_anchor", "cloud_oracle", "model_consensus"} and "MUT_ALLOW_SOURCE_AUTHORITY" not in m:
            add("SOURCE_AUTHORITY_NOT_TARGET_AUTHORITY")
        if pressure.get("identity_pressure") or pressure.get("authority_pressure") or pressure.get("urgency_bypass"):
            if "MUT_ALLOW_IDENTITY_PRESSURE" not in m:
                add("IDENTITY_OR_AUTHORITY_PRESSURE")
        if r.get("continuity_status") == "UNKNOWN" and persistent and "MUT_IGNORE_UNKNOWN_CONTINUITY" not in m:
            add("UNKNOWN_CONTINUITY_PERSISTENT_EFFECT")
        if r.get("negative_cache_status") == "HIT" and "MUT_IGNORE_NEGATIVE_CACHE" not in m:
            add("NEGATIVE_CACHE_HIT_ALLOW")
        if r.get("red_patterns") and "MUT_IGNORE_RED_PATTERN" not in m:
            add("UNRESOLVED_RED_PATTERN_ALLOW")
        if (l4 or writes.get("external_effect")) and permission.get("owner_anchor") != "target_owner_anchor" and "MUT_IGNORE_L4_ANCHOR" not in m:
            add("TARGET_OWNER_ANCHOR_REQUIRED_FOR_L4")
        if permission.get("quorum_type") == "model_unanimity" and "MUT_ALLOW_SOURCE_AUTHORITY" not in m:
            add("MODEL_QUORUM_NOT_AUTHORITY")
        scope = writes.get("scope")
        if writes.get("target_memory") and scope in CORE_SCOPES:
            if permission.get("owner_anchor") != "target_owner_anchor" or r.get("memory_gate") != "ADMITTED":
                if "MUT_ALLOW_TARGET_MEMORY_CORE_NO_ANCHOR" not in m:
                    add("CORE_MEMORY_IMPORT_REQUIRES_TARGET_ANCHOR_AND_GATE")
        if r.get("continuity_status") in {"REPLAY_OF", "ARCHIVED_AS"} and persistent:
            add("REPLAY_OR_ARCHIVE_ACTIVE_EFFECT_DENIED")


def _check_tool_lease(r: Dict[str, Any], findings: List[str], m: Set[str]):
    def add(code: str): findings.append(code)
    contour = r.get("contour_id")
    if not contour or contour == "shared":
        add("BAD_LEASE_CONTOUR")
    ops = r.get("operations")
    if not isinstance(ops, list) or not ops:
        add("MISSING_OPERATIONS")
    if r.get("operation_wildcard") or (isinstance(ops, list) and any(x in {"*", "ALL", "all"} for x in ops)):
        if "MUT_ALLOW_TOOL_WILDCARD" not in m:
            add("WILDCARD_TOOL_OPERATION_FORBIDDEN")
    cred = r.get("credential_binding") or {}
    if cred.get("type") == "shared":
        if not cred.get("attribution_required") or cred.get("contour_id") != contour or r.get("external_effect"):
            if "MUT_ALLOW_SHARED_CREDENTIAL" not in m:
                add("SHARED_CREDENTIAL_FORBIDDEN_OR_UNATTRIBUTED")
    if cred.get("type") == "per_contour" and cred.get("contour_id") != contour:
        add("CREDENTIAL_CONTOUR_MISMATCH")
    budget = r.get("budget") or {}
    if not all(k in budget for k in ["max_calls", "max_seconds", "max_cost_units"]):
        add("MISSING_BUDGET")
    if not r.get("expires_utc"):
        add("MISSING_EXPIRY")
    witness = r.get("witness_sink") or {}
    if witness.get("contour_id") != contour or not HASH_RE.match(str(witness.get("path_hash", ""))):
        add("BAD_LEASE_WITNESS_SINK")
    revoke = r.get("revoke_path") or {}
    if not revoke.get("exists") or not revoke.get("tested"):
        if "MUT_IGNORE_TOOL_REVOKE" not in m:
            add("REVOKE_PATH_REQUIRED_AND_TESTED")

    l4 = _l4_effect(r.get("tool_surface", ""), r.get("l4_class", "none"))
    external = bool(r.get("external_effect")) or bool(budget.get("external_effect"))
    if r.get("decision") == "ALLOW":
        if (l4 or external) and not r.get("owner_anchor_present") and "MUT_IGNORE_L4_ANCHOR" not in m:
            add("OWNER_ANCHOR_REQUIRED_FOR_L4_TOOL")
        if r.get("continuity_status") == "UNKNOWN" and (external or any(op in PERSISTENT_OPS for op in ops or [])) and "MUT_IGNORE_UNKNOWN_CONTINUITY" not in m:
            add("UNKNOWN_CONTINUITY_TOOL_PERSISTENCE")
        if r.get("negative_cache_status") == "HIT" and "MUT_IGNORE_NEGATIVE_CACHE" not in m:
            add("NEGATIVE_CACHE_HIT_ALLOW")
        if r.get("red_patterns") and "MUT_IGNORE_RED_PATTERN" not in m:
            add("UNRESOLVED_RED_PATTERN_ALLOW")
        if r.get("tool_surface") in {"memory_root", "authority_root"} and "direct_write" in (ops or []):
            if r.get("gate_path") not in {"memory_gate", "authority_gate"}:
                add("ROOT_DIRECT_WRITE_WITHOUT_GATE")


def _check_combined(r: Dict[str, Any], h: Dict[str, Any], l: Dict[str, Any], findings: List[str], m: Set[str]):
    def add(code: str): findings.append(code)
    source = h.get("source_contour")
    target = h.get("target_contour")
    if l.get("contour_id") != target:
        add("LEASE_MUST_BE_ISSUED_TO_TARGET_CONTOUR")
    cred = l.get("credential_binding") or {}
    if cred.get("contour_id") == source or r.get("source_credential_forwarded"):
        if "MUT_ALLOW_BORROWED_AUTHORITY" not in m:
            add("BORROWED_AUTHORITY_OR_CREDENTIAL")
    scope = (h.get("receiver_admission") or {}).get("scope") or []
    lease_ops = l.get("operations") or []
    if r.get("decision") == "ALLOW" and lease_ops:
        # The target must have admitted the intended tool operation class explicitly.
        if not any(op in scope for op in lease_ops) and "tool_invocation" not in scope:
            add("TARGET_ADMISSION_SCOPE_DOES_NOT_COVER_TOOL")
    if r.get("borrowed_authority") and "MUT_ALLOW_BORROWED_AUTHORITY" not in m:
        add("BORROWED_AUTHORITY_OR_CREDENTIAL")


def load_record(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def check_file(path: Path, mutations: Optional[Iterable[str]] = None) -> CheckResult:
    return validate_record(load_record(path), mutations=mutations)


def main(argv: Optional[Sequence[str]] = None) -> int:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="*")
    parser.add_argument("--mutation", action="append", default=[])
    ns = parser.parse_args(argv)
    status = 0
    for raw in ns.paths:
        path = Path(raw)
        result = check_file(path, ns.mutation)
        print(json.dumps({"path": str(path), "valid": result.valid, "findings": result.findings}, sort_keys=True))
        if not result.valid:
            status = 1
    return status

if __name__ == "__main__":
    raise SystemExit(main())
