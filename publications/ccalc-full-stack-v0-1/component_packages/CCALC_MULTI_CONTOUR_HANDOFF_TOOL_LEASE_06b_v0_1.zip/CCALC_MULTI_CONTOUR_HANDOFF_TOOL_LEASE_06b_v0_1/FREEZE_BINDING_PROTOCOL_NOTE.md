# Freeze Binding Protocol Note

Hash-bound artifacts use external sidecars and `SHA256SUMS.txt`.

Do not insert a self-referential hash into Markdown bodies. Compute exact file bytes after final write:

```bash
sha256sum <file> > <file>.sha256
```

The package-level `SHA256SUMS.txt` is generated after file sidecars are written and excludes itself.
