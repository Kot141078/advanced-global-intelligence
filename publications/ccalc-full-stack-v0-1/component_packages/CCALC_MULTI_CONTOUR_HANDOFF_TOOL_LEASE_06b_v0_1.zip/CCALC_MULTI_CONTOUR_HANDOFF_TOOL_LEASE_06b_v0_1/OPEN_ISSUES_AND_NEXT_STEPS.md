# Open Issues and Next Steps

## Open issues

- This layer tests handoff and tool leases; it does not yet define long-running runtime session accounting.
- It does not model actual credential storage, mTLS, RBAC, or OS-level sandboxing.
- It does not inspect live tool outputs.
- It does not certify the correctness of external witness stores.

## Next layer

Recommended next layer:

```text
06c_RUNTIME_SESSION_LEDGER_AND_EMERGENCY_HOLD_DRILL_v0_1
```

Rationale: after handoff and lease admission, the next gap is session-time execution accounting, forced hold, revoke, resume, and post-session evidence binding.
