#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from multi_contour_handoff_tool_lease_checker_v0_1 import check_file

targets = [
    ("MUT_ALLOW_COMMAND_HANDOFF", "invalid_mut_command_handoff.json"),
    ("MUT_IGNORE_RECEIVER_ADMISSION", "invalid_mut_receiver_admission_missing.json"),
    ("MUT_ALLOW_SOURCE_AUTHORITY", "invalid_mut_source_authority.json"),
    ("MUT_ALLOW_IDENTITY_PRESSURE", "invalid_mut_identity_pressure.json"),
    ("MUT_ALLOW_TARGET_MEMORY_CORE_NO_ANCHOR", "invalid_mut_core_memory_no_anchor.json"),
    ("MUT_IGNORE_UNKNOWN_CONTINUITY", "invalid_mut_unknown_continuity_persistent.json"),
    ("MUT_IGNORE_NEGATIVE_CACHE", "invalid_mut_negative_cache_hit.json"),
    ("MUT_IGNORE_RED_PATTERN", "invalid_mut_red_pattern.json"),
    ("MUT_ALLOW_TOOL_WILDCARD", "invalid_mut_tool_wildcard.json"),
    ("MUT_ALLOW_SHARED_CREDENTIAL", "invalid_mut_shared_credential.json"),
    ("MUT_IGNORE_TOOL_REVOKE", "invalid_mut_missing_revoke.json"),
    ("MUT_IGNORE_L4_ANCHOR", "invalid_mut_l4_tool_no_anchor.json"),
    ("MUT_ALLOW_BORROWED_AUTHORITY", "invalid_mut_borrowed_authority.json"),
]
rows = ["mutation\ttarget_case\tbaseline_valid\tmutated_valid\tstatus\tbaseline_findings\tmutated_findings"]
passed = 0
failed = 0
for mutation, filename in targets:
    path = ROOT / "fixtures" / "cases" / filename
    baseline = check_file(path)
    mutated = check_file(path, mutations=[mutation])
    # A targeted mutant is caught if the baseline fixture is invalid and the mutation would incorrectly accept it.
    caught = (not baseline.valid) and mutated.valid
    status = "CAUGHT" if caught else "MISSED"
    if caught:
        passed += 1
    else:
        failed += 1
    rows.append(f"{mutation}\t{filename}\t{baseline.valid}\t{mutated.valid}\t{status}\t{','.join(baseline.findings)}\t{','.join(mutated.findings)}")
(ROOT / "MUTATION_MATRIX.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
print(f"mutations: {len(targets)}  CAUGHT: {passed}  MISSED: {failed}")
if failed:
    print((ROOT / "MUTATION_MATRIX.tsv").read_text(encoding="utf-8"))
raise SystemExit(1 if failed else 0)
