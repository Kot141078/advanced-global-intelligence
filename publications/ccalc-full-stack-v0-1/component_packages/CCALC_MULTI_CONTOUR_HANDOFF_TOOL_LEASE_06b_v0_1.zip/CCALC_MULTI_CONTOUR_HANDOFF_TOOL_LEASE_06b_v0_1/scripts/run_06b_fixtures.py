#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from multi_contour_handoff_tool_lease_checker_v0_1 import check_file

cases = sorted((ROOT / "fixtures" / "cases").glob("*.json"))
rows = ["case_id\trecord_type\texpected_valid\tactual_valid\tstatus\texpected_code\tfindings"]
passed = 0
failed = 0
for path in cases:
    data = json.loads(path.read_text(encoding="utf-8"))
    expected_valid = bool(data.get("expected_valid"))
    expected_code = data.get("expected_code", "")
    result = check_file(path)
    code_ok = True
    if not expected_valid and expected_code:
        code_ok = expected_code in result.findings or any(x.endswith(":" + expected_code) for x in result.findings)
    ok = result.valid == expected_valid and code_ok
    if ok:
        passed += 1
        status = "PASS"
    else:
        failed += 1
        status = "FAIL"
    rows.append(f"{data.get('record_id')}\t{data.get('record_type')}\t{expected_valid}\t{result.valid}\t{status}\t{expected_code}\t{','.join(result.findings)}")

(ROOT / "FIXTURE_RESULTS.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
print(f"fixtures: {len(cases)}  PASS: {passed}  FAIL: {failed}")
if failed:
    print((ROOT / "FIXTURE_RESULTS.tsv").read_text(encoding="utf-8"))
raise SystemExit(1 if failed else 0)
