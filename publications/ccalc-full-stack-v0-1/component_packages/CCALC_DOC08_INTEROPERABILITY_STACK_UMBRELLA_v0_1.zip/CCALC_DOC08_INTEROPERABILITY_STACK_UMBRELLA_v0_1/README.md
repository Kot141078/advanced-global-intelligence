# CCALC_DOC08_INTEROPERABILITY_STACK_UMBRELLA_v0_1

Umbrella package closing the current `08` interoperability stack.

Read first:

1. `CCALC_DOC08_INTEROPERABILITY_STACK_INDEX_AND_RELEASE_MANIFEST_v0_1.md`
2. `READING_ORDER.md`
3. `COMPONENT_REGISTRY.tsv`
4. `SOURCE_BINDINGS.tsv`
5. `EXECUTABLE_RERUN_SUMMARY.tsv`
6. `NON_CLAIMS_AND_SCOPE.md`
7. `UMBRELLA_VERIFICATION_LOG.md`

The package includes component ZIPs under `components/` and upstream source-binding packages under `source_bindings/`.
