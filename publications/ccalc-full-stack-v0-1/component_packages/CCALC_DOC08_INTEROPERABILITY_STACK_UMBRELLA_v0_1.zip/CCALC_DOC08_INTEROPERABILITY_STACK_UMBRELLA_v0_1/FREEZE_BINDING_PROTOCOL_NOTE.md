# Freeze Binding Protocol Note

Freeze binding is external to Markdown body text.

For each frozen file:

```bash
sha256sum exact_file_bytes > filename.sha256
```

Do not place a self-referential hash inside the file whose bytes are being hashed.
