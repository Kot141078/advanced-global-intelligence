# Umbrella Verification Log

**Artifact:** `CCALC_DOC08_INTEROPERABILITY_STACK_UMBRELLA_v0_1`  
**Generated UTC:** `2026-07-05T16:06:29Z`

## Component Presence

All component packages were present and copied into `components/`.

## Source Binding Presence

All upstream source-binding packages were present and copied into `source_bindings/`.

## Component SHA-256 Recompute

Component and upstream source-binding SHA-256 values were recomputed from copied bytes and written into:

- `COMPONENT_REGISTRY.tsv`
- `SOURCE_BINDINGS.tsv`
- sidecar `.sha256` files
- `SHA256SUMS.txt`

## Internal Component SHA256SUMS

The following component packages were extracted and their internal `SHA256SUMS.txt` checks were run successfully:

```text
08: PASS
08a: PASS
08b: PASS
08c: PASS
08d: PASS
```

## Executable Rerun Summary

```text
08a: fixtures 66/66 PASS, mutations 18/18 CAUGHT
08b: fixtures 91/91 PASS, mutations 22/22 CAUGHT
08c: fixtures 73/73 PASS, mutations 24/24 CAUGHT
08d: fixtures 55/55 PASS, mutations 27/27 CAUGHT
```

## Umbrella Checks

```text
component packages present: PASS
component SHA-256 recomputed: PASS
source-binding packages present: PASS
source-binding SHA-256 recomputed: PASS
internal component SHA256SUMS: PASS
executable reruns: PASS for 08a/08b/08c/08d
zip integrity: PASS
umbrella SHA256SUMS: PASS
```
