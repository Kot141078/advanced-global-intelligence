# Open Issues and Next Steps

## Closed in this umbrella

- External review intake boundary.
- Review role and claim-translation discipline.
- External conflict and patch-intake ledger.
- Implementation/reproduction mapping.
- External disclosure/test-vector registry.

## Next stack

The next natural layer is `09_C_DEPLOYMENT_PROFILE_AND_REGULATED_RELEASE_BOUNDARY_v0_1` only after the publication/interoperability surfaces are stable.

Recommended immediate next action: decide whether `08` requires a public-facing minimal example bundle or should remain a governed internal/public-intake interface only.
