# CCALC checker v2.3 — adversarial robustness sweep v1.0

**Artifact under test:** `c-calculus-checker v2.3`  
**Archive SHA256:** `02db71bcecb0c180fbfb37797bdfe3fff157799e07566199e70fb863beb1cf48`

## Result

**Status:** `PASS_TARGETED_ADVERSARIAL_ROBUSTNESS_WITH_SCOPE_LIMITS`

This package closes the gap identified by the conformance-sweep review: coverage is not the same as adversarial robustness. The final conformance sweep showed that the known class vocabulary is mapped across the implemented checker surface; this follow-up performs targeted adversarial probes against the mechanisms that had coverage evidence but had not received the same direct stress treatment as the earlier authority/delegation/lease seams.

## Executed evidence

- Official v2.3 fixture runner: **PASS**.
- Targeted adversarial cases: **24**.
- Targeted case failures: **0**.
- Mechanisms probed: **8**.

## Mechanisms probed

- `binding_certificate_emitter`
- `context_causal_state_binding`
- `genesis_authorization`
- `manifest_fact_registry`
- `operator_classification_registry`
- `rendered_layer_registry`
- `review_binding_map`
- `viewport_atomicity`

## What was tested

The sweep is not a proof and not a full formal verification. It is a targeted stress pass over the coverage-only surface using the accumulated class vocabulary:

- registry drift / unclassified elements;
- missing -> fail-safe;
- trust/source-gate;
- hash/binding mismatch;
- checker-owned error-code selection;
- viewport/review surface coverage;
- genesis review-object binding;
- emitter precondition gating;
- enumerated-list -> fail-safe for manifest projection.

## Outcome

All targeted adversarial probes produced the expected checker findings or expected valid result. No new finding was raised in this sweep.

## Important boundary

This confirms targeted robustness for the selected mechanisms and cases. It does **not** prove the checker correct or complete. It does **not** claim every matrix cell was adversarially exhausted. It narrows the gap between coverage and stress-testing for the previously under-attacked mechanisms.

## Files

- `ADVERSARIAL_ROBUSTNESS_MATRIX.json` — machine-readable cases and results.
- `ADVERSARIAL_ROBUSTNESS_CASES.tsv` — tabular case list.
- `cases/` — mutated JSON fixtures used for targeted probes.
- `scripts/run_adversarial_robustness_sweep.py` — reproducibility script.
- `EXECUTION_LOG.md` — run log.
- `NON_CLAIMS_AND_SCOPE.md` — explicit scope limits.
