#!/usr/bin/env python3
"""Re-run the v2.3 adversarial robustness sweep cases.

Usage:
  python scripts/run_adversarial_robustness_sweep.py --checker-dir /path/to/c-calculus-checker-v2.3
"""
from __future__ import annotations
import argparse, json, pathlib, sys

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--checker-dir', required=True)
    args=ap.parse_args()
    checker=pathlib.Path(args.checker_dir).resolve()
    sys.path.insert(0, str(checker/'src'))
    from c_calculus_checker.validators import run_all_checks
    from c_calculus_checker.genesis import emit_certificate
    base=pathlib.Path(__file__).resolve().parents[1]
    matrix=json.load(open(base/'ADVERSARIAL_ROBUSTNESS_MATRIX.json', encoding='utf-8'))
    failures=0
    for case in matrix['cases']:
        if case['fixture_file'] == '<valid_minimal_genesis>':
            fixture=json.load(open(checker/'06_FIXTURES'/'valid_minimal_genesis.json', encoding='utf-8'))
        else:
            fixture=json.load(open(base/case['fixture_file'], encoding='utf-8'))
        if case['case'].startswith('emitter_'):
            cert, findings=emit_certificate(fixture)
            codes=[f.code for f in findings]
            if case['expected']=='cert_issued':
                ok=bool(cert and not findings)
            else:
                ok=not cert and case['expected'] in codes
        else:
            findings=run_all_checks(fixture)
            codes=[f.code for f in findings]
            ok=case['expected'] in codes
        print(('PASS' if ok else 'FAIL'), case['case'], '->', ','.join(codes) or '[]')
        failures += 0 if ok else 1
    print(f"SUMMARY cases={len(matrix['cases'])} failures={failures}")
    return 1 if failures else 0
if __name__ == '__main__':
    raise SystemExit(main())
