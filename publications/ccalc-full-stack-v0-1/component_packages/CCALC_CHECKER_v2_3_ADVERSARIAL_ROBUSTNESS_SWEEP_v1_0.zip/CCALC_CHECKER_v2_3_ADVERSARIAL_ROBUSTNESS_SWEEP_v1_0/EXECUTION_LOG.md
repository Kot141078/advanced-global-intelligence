# Execution log — v2.3 adversarial robustness sweep v1.0
Artifact under test: `c-calculus-checker v2.3`
Archive SHA256: `02db71bcecb0c180fbfb37797bdfe3fff157799e07566199e70fb863beb1cf48`
## Targeted adversarial cases
Cases: 24; pass: 24; fail: 0
- PASS `op_registry_missing_effect_axis_classifier` -> expected `OPERATOR_CLASSIFICATION_DRIFT`, actual `OPERATOR_CLASSIFICATION_DRIFT`
- PASS `op_registry_invalid_fail_safe_class` -> expected `OPERATOR_CLASSIFICATION_FAIL_SAFE_INVALID`, actual `OPERATOR_CLASSIFICATION_FAIL_SAFE_INVALID`
- PASS `rendered_layer_unclassified_authority_layer` -> expected `RENDERED_LAYER_UNCLASSIFIED`, actual `RENDERED_LAYER_UNCLASSIFIED, REVIEW_BINDING_MAP_DRIFT, REVIEW_VIEWPORT_HIDDEN_AUTHORITY`
- PASS `rendered_layer_non_authority_induces_authority` -> expected `NON_AUTHORITY_LAYER_USED_TO_INDUCE_AUTHORITY`, actual `NON_AUTHORITY_LAYER_USED_TO_INDUCE_AUTHORITY`
- PASS `rendered_layer_authority_missing_review_binding_map` -> expected `REVIEW_BINDING_MAP_DRIFT`, actual `REVIEW_BINDING_MAP_DRIFT, REVIEW_VIEWPORT_HIDDEN_AUTHORITY`
- PASS `manifest_fact_unclassified` -> expected `MANIFEST_FACT_UNCLASSIFIED`, actual `MANIFEST_FACT_UNCLASSIFIED`
- PASS `manifest_unknown_key_fails_authority` -> expected `MANIFEST_AUTHORITY_PROJECTION_CHANGED`, actual `MANIFEST_AUTHORITY_PROJECTION_CHANGED`
- PASS `manifest_b_supplied_projection_ignored` -> expected `MANIFEST_AUTHORITY_PROJECTION_CHANGED`, actual `MANIFEST_AUTHORITY_PROJECTION_CHANGED`
- PASS `review_binding_source_missing` -> expected `REVIEW_BINDING_SOURCE_MISSING`, actual `REVIEW_BINDING_SOURCE_MISSING`
- PASS `review_binding_hash_missing` -> expected `REVIEW_BINDING_SOURCE_HASH_MISSING`, actual `REVIEW_BINDING_SOURCE_HASH_MISSING`
- PASS `review_binding_payload_hash_mismatch` -> expected `PAYLOAD_REVIEW_BINDING_MISMATCH`, actual `PAYLOAD_REVIEW_BINDING_MISMATCH`
- PASS `review_binding_checker_owned_mismatch_code` -> expected `CONTEXT_CAUSAL_STATE_MISMATCH`, actual `CONTEXT_CAUSAL_STATE_MISMATCH`
- PASS `context_causal_pre_state_projection_missing` -> expected `CAUSAL_PRE_STATE_MISSING`, actual `CAUSAL_PRE_STATE_MISSING`
- PASS `context_causal_pre_state_hash_mismatch` -> expected `CAUSAL_TOKEN_PRE_STATE_HASH_MISMATCH`, actual `CAUSAL_TOKEN_PRE_STATE_HASH_MISMATCH`
- PASS `context_rendered_state_hash_missing` -> expected `CONTEXT_STATE_PROJECTION_MISSING`, actual `CONTEXT_STATE_PROJECTION_MISSING`
- PASS `context_l4_hash_missing` -> expected `L4_STATE_PROJECTION_MISSING`, actual `L4_STATE_PROJECTION_MISSING`
- PASS `viewport_authority_layer_not_signature_covered` -> expected `REVIEW_VIEWPORT_HIDDEN_AUTHORITY`, actual `REVIEW_VIEWPORT_HIDDEN_AUTHORITY`
- PASS `viewport_authority_unit_without_signature_coverage` -> expected `REVIEW_VIEWPORT_INCOMPLETE`, actual `REVIEW_VIEWPORT_INCOMPLETE, REVIEW_VIEWPORT_HIDDEN_AUTHORITY`
- PASS `viewport_hidden_authority_backstop` -> expected `REVIEW_VIEWPORT_HIDDEN_AUTHORITY`, actual `REVIEW_VIEWPORT_HIDDEN_AUTHORITY, REVIEW_VIEWPORT_HIDDEN_AUTHORITY`
- PASS `genesis_binding_parameter_hash_mismatch` -> expected `GENESIS_AUTHORIZATION_MISMATCH`, actual `GENESIS_AUTHORIZATION_MISMATCH, GENESIS_AUTHORIZATION_MISMATCH, GENESIS_AUTHORIZATION_MISMATCH`
- PASS `genesis_anchor_envelope_review_hash_mismatch` -> expected `GENESIS_AUTHORIZATION_MISMATCH`, actual `GENESIS_AUTHORIZATION_MISMATCH, ANCHOR_NONCE_NOT_BOUND_TO_FINAL_REVIEW_OBJECT`
- PASS `genesis_bundle_review_hash_mismatch` -> expected `GENESIS_AUTHORIZATION_MISMATCH`, actual `GENESIS_AUTHORIZATION_MISMATCH`
- PASS `emitter_valid_certificate_emits` -> expected `cert_issued`, actual `[]`
- PASS `emitter_revoked_anchor_blocks_certificate` -> expected `ANCHOR_STATE_BIND_INCOMPATIBLE`, actual `ANCHOR_STATE_BIND_INCOMPATIBLE`

## Official fixture suite
Return code: 0
```text
PASS: all fixtures matched expected outcomes
```
