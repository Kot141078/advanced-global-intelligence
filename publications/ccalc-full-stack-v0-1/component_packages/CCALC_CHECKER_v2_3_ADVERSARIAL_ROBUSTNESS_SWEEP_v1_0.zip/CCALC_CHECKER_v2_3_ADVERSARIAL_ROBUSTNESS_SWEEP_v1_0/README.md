# CCALC checker v2.3 adversarial robustness sweep v1.0

A targeted adversarial follow-up to the final conformance sweep.

## Reproduce

```bash
python scripts/run_adversarial_robustness_sweep.py --checker-dir /path/to/c-calculus-checker-v2.3
```

## Verify package

```bash
sha256sum -c SHA256SUMS.txt
```
