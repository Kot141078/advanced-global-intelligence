# Non-claims and scope

This robustness sweep does **not** claim:

1. that `c-calculus-checker v2.3` is correct, complete, or proven;
2. that fixture-level adversarial probes imply enforcement against a real substrate;
3. that every possible input shape was exhausted;
4. that production viewport / display-oracle behavior is implemented;
5. that external c-criteria or fifth-ring observability are solved;
6. that coverage evidence equals full adversarial exhaustion.

This sweep only claims: the selected adversarial probes against the previously coverage-only implemented mechanisms produced the expected findings under the v2.3 checker.
