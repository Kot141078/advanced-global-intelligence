#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parents[1]
script = root / 'src' / 'deployment_fixture_mutation_checker_v0_1.py'
raise SystemExit(subprocess.call([sys.executable, str(script), str(root), 'fixtures']))
