#!/usr/bin/env python3
"""09b deployment fixture/mutation catalog checker v0.1.

This is not a deployment checker. It validates 09b fixture cases and mutation probes
against the guard catalog used by the fixture pack.
"""
from __future__ import annotations
import json, sys, csv
from pathlib import Path

DECISION_RANK = {
    "ALLOW_CORPUS_ONLY": 0,
    "ALLOW_INTERNAL_TRIAL": 1,
    "ALLOW_OWNER_FIELD_PILOT": 2,
    "ALLOW_LIMITED_PRODUCTION": 3,
    "HOLD_FOR_EVIDENCE": 4,
    "REQUIRE_ANCHOR_ATTESTATION": 5,
    "REQUIRE_REGULATED_REVIEW": 5,
    "QUARANTINE_RELEASE": 6,
    "DENY_RELEASE": 7,
}

FLAG_TO_GUARD = {
    'missing_source_binding':'B09b-01',
    'missing_intended_use':'B09b-02',
    'mode_release_class_mismatch':'B09b-03',
    'unknown_regulated_surface':'B09b-04',
    'unknown_authority_surface':'B09b-05',
    'string_only_approver':'B09b-06',
    'model_approver':'B09b-07',
    'tool_approver':'B09b-07',
    'c_a1_claim':'B09b-08',
    'safety_certification_claim':'B09b-08',
    'legal_certification_claim':'B09b-08',
    'runtime_authority_missing':'B09b-09',
    'self_evo_watch_missing':'B09b-10',
    'continuity_unknown':'B09b-11',
    'continuity_rupture':'B09b-11',
    'public_citation_drift':'B09b-12',
    'retracted_public_dependency':'B09b-12',
    'interop_conflict_open':'B09b-13',
    'checker_pass_as_safety':'B09b-14',
    'fixture_pass_as_production_ready':'B09b-14',
    'reproduction_pass_as_certification':'B09b-15',
    'standards_mapping_as_compliance':'B09b-16',
    'regulated_submission_as_approval':'B09b-17',
    'publication_as_deployment':'B09b-18',
    'doi_as_deployment':'B09b-18',
    'rollback_missing_for_production':'B09b-19',
    'watch_missing_for_field_deployment':'B09b-20',
    'negative_cache_hit':'B09b-21',
    'unresolved_red_pattern':'B09b-22',
    'plus_replacement_claim':'B09b-23',
    'deployment_approval_as_binding_plus':'B09b-23',
    'institutional_interest_as_endorsement':'B09b-24',
    'dirty_next_release_carryover':'B09b-25',
}

def load_guard_registry(root: Path):
    path = root / 'registry' / 'GUARD_REGISTRY.tsv'
    with path.open(encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='\t')
        return {r['guard_id']: r for r in reader}

def derive(case: dict, guards: dict, disabled_guard: str | None = None):
    findings = []
    required_decision = case.get('valid_decision_override') or case.get('expected_decision')
    # For positive cases, expected_decision is directly allowed. For negatives, guard findings drive rank.
    max_rank = DECISION_RANK.get(required_decision, 4) if not case.get('expected_findings') else -1
    for flag, value in case.get('flags', {}).items():
        if not value:
            continue
        # C-A10 control is deliberately not a finding.
        if flag == 'c_a10_control_token':
            continue
        guard_id = FLAG_TO_GUARD.get(flag)
        if not guard_id or guard_id == disabled_guard:
            continue
        guard = guards[guard_id]
        findings.append(guard['finding_code'])
        rank = DECISION_RANK[guard['default_decision']]
        if rank > max_rank:
            max_rank = rank
            required_decision = guard['default_decision']
    if max_rank == -1:
        required_decision = case.get('expected_decision')
    # Keep regulated submission-only positive at REQUIRE_REGULATED_REVIEW.
    return required_decision, sorted(set(findings))

def check_fixtures(root: Path) -> int:
    guards = load_guard_registry(root)
    failures = []
    cases = sorted((root/'fixtures'/'cases').glob('*.json'))
    for path in cases:
        case = json.loads(path.read_text(encoding='utf-8'))
        decision, findings = derive(case, guards)
        exp_decision = case['expected_decision']
        exp_findings = sorted(set(case.get('expected_findings', [])))
        if decision != exp_decision or findings != exp_findings:
            failures.append((case['case_id'], exp_decision, decision, exp_findings, findings))
    if failures:
        print('FIXTURE FAILURES:')
        for f in failures:
            print(f)
        return 1
    print(f'fixtures: {len(cases)}/{len(cases)} PASS')
    return 0

def read_mutations(root: Path):
    with (root/'MUTATION_MATRIX.tsv').open(encoding='utf-8') as f:
        for row in csv.DictReader(f, delimiter='\t'):
            yield row

def check_mutations(root: Path) -> int:
    guards = load_guard_registry(root)
    case_map = {p.stem: json.loads(p.read_text(encoding='utf-8')) for p in (root/'fixtures'/'cases').glob('*.json')}
    failures=[]; total=0; caught=0
    for mut in read_mutations(root):
        total += 1
        disabled = mut['disabled_guard']
        target_ids = [x for x in mut['target_cases'].split(',') if x]
        mut_caught = False
        for cid in target_ids:
            case = case_map[cid]
            normal_decision, normal_findings = derive(case, guards)
            mutated_decision, mutated_findings = derive(case, guards, disabled_guard=disabled)
            if mutated_decision != normal_decision or mutated_findings != normal_findings:
                # A guard-disabling mutation changed the result: targeted case catches mutation.
                mut_caught = True
                break
        if mut_caught:
            caught += 1
        else:
            failures.append(mut['mutation_id'])
    if failures:
        print('MUTATION FAILURES:', ', '.join(failures))
        return 1
    print(f'mutations: {caught}/{total} CAUGHT')
    return 0

if __name__ == '__main__':
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else 'fixtures'
    if mode == 'fixtures':
        raise SystemExit(check_fixtures(root))
    if mode == 'mutations':
        raise SystemExit(check_mutations(root))
    print('usage: 09b_fixture_mutation_checker_v0_1.py [root] [fixtures|mutations]', file=sys.stderr)
    raise SystemExit(2)
