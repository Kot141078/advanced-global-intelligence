# CCALC Self-Evolution Gate 05 v0.1

Package: `CCALC_SELF_EVOLUTION_GATE_05_v0_1`

Primary document:

```text
05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1.md
```

Purpose:

```text
Define self-evolution as a governed transition class and bounded-growth gate.
```

Core rule:

```text
A c may grow.
A c may not self-certify growth.
```

Integrity:

```text
sha256sum -c SHA256SUMS.txt
```

Boundary: normative draft only; not deployment authorization; not safety certification; not C-A1 ratification.
