# Reading Order — 05 Self-Evolution Gate v0.1

Recommended order:

1. `01_TYPED_GOVERNED_OPERATIONAL_ALGEBRA_FOR_C_v0_1_7.md`
2. `02_GOVERNED_BINDING_OPERATOR_PROFILE_v0_1_5.md`
3. `03_C_STATE_AND_TRANSITION_SEMANTICS_v0_1_2.md`
4. `CCALC_DOC04_CONTINUITY_STACK_UMBRELLA_v0_1.zip`
5. `05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1.md`
6. CGAM root / task / memory / rollback / review references as implementation-control background.
7. SRLM, TRIAD-SYNAPS, Memory Gate, Anti-Autarky, and Claim Strength references.

This package is a normative bridge profile. It is not yet the executable checker seed.
