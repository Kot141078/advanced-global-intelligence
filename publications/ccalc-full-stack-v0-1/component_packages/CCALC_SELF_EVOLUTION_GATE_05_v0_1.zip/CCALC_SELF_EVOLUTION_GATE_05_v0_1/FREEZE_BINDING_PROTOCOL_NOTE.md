# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each Markdown record:

```text
sha256sum exact_file_bytes > filename.md.sha256
```

Markdown files do not mutate to include their own hashes. This avoids self-referential instability.
