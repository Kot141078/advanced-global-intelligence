# Open Issues and Next Steps — 05 Self-Evolution Gate v0.1

## Immediate next packages

```text
05a_SELF_EVO_PROPOSAL_PACKET_SCHEMA_AND_CHECKER_SEED_v0_1
05b_SELF_EVO_FIXTURE_PACK_AND_MUTATION_MATRIX_v0_1
```

## Open issues

- `SE-OI-001`: Full JSON schema extraction.
- `SE-OI-002`: Deterministic checker seed.
- `SE-OI-003`: Fitness evidence ontology.
- `SE-OI-004`: TRIAD independence weighting.
- `SE-OI-005`: L4 resource envelope schema.
- `SE-OI-006`: Statistical sufficiency thresholds for repeated trials.
- `SE-OI-007`: Post-anchor reduced-authority self-evolution.

## Non-action

Do not treat this package as deployment permission. Do not wire it into live promotion without 05a/05b checker/fixture layer and human gate.
