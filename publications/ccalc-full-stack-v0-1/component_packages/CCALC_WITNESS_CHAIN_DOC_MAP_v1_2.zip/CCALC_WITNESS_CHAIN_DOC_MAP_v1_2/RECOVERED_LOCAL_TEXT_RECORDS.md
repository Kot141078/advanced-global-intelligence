# Recovered local text records — DOC_MAP v1.2

These records were moved from reference-only to recovered local full-text. They are sidecar-bound in this package.

| record_id | local_file | record_file_sha256 | source refs |
|---|---|---|---|
| `CCALC_CHECKER_v1_7_INTEGRATION__b` | `records/CCALC_CHECKER_v1_7_INTEGRATION_RECORD__b_layer_claude.md` | `89b7c1beab2620a48052f5f689c5364365eacba7e109c4ade4a4c78e1d3135d9` | turn73file2 / turn74file7 / turn68file10 / turn70file18 |
| `CCALC_CHECKER_v1_8_INTEGRATION__b` | `records/CCALC_CHECKER_v1_8_INTEGRATION_RECORD__b_layer_claude.md` | `7e881a517c2a7e8545c269e8154b21ab10d281b611e88a29e75202fb5fba8bd6` | turn73file1 / turn74file0 / turn68file14 / turn68file15 |
| `CCALC_CHECKER_v1_9_INTEGRATION__b` | `records/CCALC_CHECKER_v1_9_INTEGRATION_RECORD__b_layer_claude.md` | `f253cfce9161b352655f34ebc5afd55896772f7d6f0c620f225c97bbcd228aca` | turn73file3 / turn74file1 / turn70file9 / turn74file12 |

Caveat: recovered records are normalized local witness texts reconstructed from available review evidence. They do not claim byte-identity with an unavailable standalone pre-freeze original.
