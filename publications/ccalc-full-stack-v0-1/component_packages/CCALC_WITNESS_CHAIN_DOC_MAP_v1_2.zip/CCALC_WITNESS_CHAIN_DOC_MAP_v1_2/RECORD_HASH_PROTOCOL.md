# RECORD_HASH_PROTOCOL — sidecar registration v1.1

## Decision

DOC_MAP v1.1 uses **sidecar record hashing**. Historical review files are not mutated to replace their internal `record_sha256: PLACEHOLDER__compute_on_freeze` strings.

## Protocol

For each local Markdown record under `records/`:

1. Read the exact packaged file bytes.
2. Compute `SHA256(raw_file_bytes)`.
3. Store that value in two places:
   - adjacent sidecar file `records/<record_filename>.sha256`;
   - aggregate `RECORD_HASH_SIDECAR.tsv`.
4. Do not rewrite the historical record body.

Reference-only / missing-local-text nodes do not receive a sidecar hash because no local Markdown file is packaged for them.

## Verification

A verifier recomputes each local record hash from the packaged bytes and compares it with both the adjacent `.sha256` file and `RECORD_HASH_SIDECAR.tsv`.

## Non-claim

Sidecar registration is a package-level frozen binding. It does not retroactively make the review advisory record an authorization, certification, or proof of checker correctness.
