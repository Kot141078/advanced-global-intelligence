# CCALC Witness Chain DOC_MAP v1.2

This package is a navigable witness map for the c-calculus checker / operator review chain.

v1.2 changes from v1.1:

- recovers three integration records (`v1.7`, `v1.8`, `v1.9`) as local normalized full-text witness files;
- reduces reference-only nodes from six to three;
- keeps the policy honest: complete-by-policy with partial A1 recovery, not complete-by-history;
- sidecar-binds all 32 local/recovered records.

Primary files:

- `CCALC_WITNESS_CHAIN_DOC_MAP_v1_2.md`
- `CCALC_WITNESS_CHAIN_DOC_MAP_v1_2.json`
- `REVIEW_RECORD_MANIFEST.tsv`
- `RECORD_HASH_SIDECAR.tsv`
- `MISSING_OR_EXTERNAL_RECORDS.md`
- `RECOVERED_LOCAL_TEXT_RECORDS.md`
- `SHA256SUMS.txt`

Verify:

```bash
cd CCALC_WITNESS_CHAIN_DOC_MAP_v1_2
sha256sum -c SHA256SUMS.txt
```
