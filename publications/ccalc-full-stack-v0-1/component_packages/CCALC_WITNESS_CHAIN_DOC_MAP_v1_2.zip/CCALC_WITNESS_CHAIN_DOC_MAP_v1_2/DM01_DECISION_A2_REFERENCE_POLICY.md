# DM-01 decision — complete-by-policy with partial A1 recovery (DOC_MAP v1.2)

v1.1 chose A2: complete-by-policy, because six graph nodes existed without local full-text records.

v1.2 narrows that gap without fabricating missing canonical originals:

- Three integration records that existed as review text in the conversation/file-search evidence were recovered as local normalized full-text files and sidecar-bound:
  - `CCALC_CHECKER_v1_7_INTEGRATION__b`
  - `CCALC_CHECKER_v1_8_INTEGRATION__b`
  - `CCALC_CHECKER_v1_9_INTEGRATION__b`
- Three nodes remain reference-only / missing-local-text because no standalone canonical local text is available in this package.

Status:

```text
total graph nodes: 35
local full-text inherited: 29
recovered local full-text: 3
local/recovered full-text total: 32
reference-only remaining: 3
```

This is stronger than v1.1 but still not full A1 complete-by-history.
