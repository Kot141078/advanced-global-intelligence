# Semantic Review Record — c-calculus-checker v0.5

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_5_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_4_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_5_REVIEW__b
  record_version: "0.5"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_4_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.5"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394"
    supersedes_archive_sha256: "974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: hardened_implementation_v0_5
    meaning: >
      As a b-layer semantic reviewer I find C-07 fully closed: all ten core §1385 authority axes are protected
      from ephemeral downgrade by a double guard (EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS plus the axis
      remaining in the projection), proven for all ten. One new moderate finding (C-08) is raised, proven by
      execution: the floor compares by exact string name and is bypassed when an authority axis arrives under
      a name variant/synonym consistently in manifest and envelope (Roles/Roles). PASS is a verdict on a
      hardened seed implementation, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    C-07_no_floor_on_core_authority_axes:
      status: RESOLVED_FULLY
      evidence: >
        KNOWN_AUTHORITY_AXES lists all ten §1385 axes. _declared_ephemeral_manifest_keys returns
        (declared - KNOWN_AUTHORITY_AXES, source, illegal = declared & KNOWN_AUTHORITY_AXES);
        check_manifest_fact_registry emits EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS; the axis stays in
        _canonical_authority_projection so escalation is still caught (double guard). Inversion retained.
      empirical_proof: >
        All ten axes (surfaces, roles, tool_classes, memory_surfaces, execution_classes, network_authority,
        rollback_freeze_routes, witness_surfaces, renderer_signing_interfaces, l4_target_policy) declared
        ephemeral + escalated -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_
        CHANGED. Legit container_ip -> clean.

  new_findings:
    C-08_floor_string_match_brittleness:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_pattern: true
      pattern_lineage: [C-06_hardcoded_ephemeral_string_match, C-08_floor_string_match]
      locus: ["registry.KNOWN_AUTHORITY_AXES", "registry._declared_ephemeral_manifest_keys", "registry._canonical_authority_projection"]
      issue: >
        The floor compares by exact string name against KNOWN_AUTHORITY_AXES. If an authority axis arrives
        under a name variant (case, plural/singular, whitespace) or a semantic synonym, consistently in both
        the manifest fact and the envelope, the floor does not recognize it. Because b generates manifest
        facts, b controls key names. Proven: manifest+envelope both 'Roles' -> role escalation viewer->root
        slips through as ephemeral drift (floor sees {Roles} & KNOWN_AUTHORITY_AXES = empty, since the list
        has 'roles'). Canonical §1385 names are fully protected; the gap is non-canonical naming.
      empirical_proof: >
        envelope 'Roles'/'role'/'ROLES' vs manifest canonical roles -> caught (ephemeral set doesn't cover the
        canonical manifest key). manifest+envelope BOTH 'Roles' -> SLIPS (no finding; escalation invisible).
      why_it_matters: >
        The only remaining defense is the anchor noticing that 'Roles' is semantically roles at signing time,
        which returns the burden the floor was meant to remove. Case is only the surface; a semantic synonym
        (user_roles, permissions) normalizes under no case-fold. This is the third appearance of string-match
        brittleness (C-06 ephemeral keys; now C-08 floor): identity of authority relevance cannot be derived
        from a string b controls.
      recommended_path: >
        (1) Minimal: canonicalize names (casefold, trim, singular/plural) on both sides before comparison —
        catches Roles/ROLES/'roles '. (2) Real fix: identify authority axes by a typed canonical schema
        reference in the GovernanceProfile (anchor-authorized canonical authority-axis registry), not by
        string name; map manifest keys onto canonical axes via the declared schema so Roles/user_roles/
        permissions resolve to the canonical roles axis. Do NOT extend synonym lists (that is
        complete-by-current-list again). Move identity from strings to anchor-authorized types.

  string_match_theme:
    observation: >
      Three times over five checker versions the same thing surfaced under different masks: a string name is
      not an identity. C-06: b names an ephemeral key non-canonically -> false positive. C-08: b names an
      authority axis non-canonically -> floor bypass. The inversion solved identity for fully-unknown keys
      (unknown -> authority); the floor solved downgrade for known names; between them remains authority
      semantics under a non-canonical name. Real closure is a typed, anchor-authorized canonical axis registry
      with manifest keys mapped onto it — moving identity from strings to types, as the inversion moved the
      default from omission to fail-safe.

  authority_markup_theme_arc:
    observation: >
      The authority-markup theme is now nearly complete across three questions: 'who decides what is ephemeral'
      (loop to anchor, C-06/v0.4), 'what is non-overridable' (constitutional floor, C-07/v0.5), and 'how is an
      axis identified' (typed identity, C-08). When axes become typed references in an anchor-authorized
      schema, all three close.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394"
    verdict: PASS_CHECKER_V0_5
    blocking: false
    prior_findings_resolved: [C-07]
    new_findings: [C-08]
    recommended_next:
      - "Fix C-08: canonicalize axis names on both sides (minimal), and identify authority axes by a typed anchor-authorized canonical-axis schema rather than string match (real)."
      - "Add fixtures: manifest+envelope using a name variant of a protected axis -> rejected; a genuinely new ephemeral key -> accepted."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

C-07 is fully closed. `KNOWN_AUTHORITY_AXES` covers all ten §1385 axes, and the double guard —
`EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS` plus the axis remaining in the projection — is
verified by attack for every one of the ten. A legitimate new ephemeral key (`container_ip`)
stays clean; the inversion is retained.

One new moderate finding (C-08), proven by execution: the floor compares by exact string name,
and is bypassed when an authority axis arrives under a name variant or synonym consistently in
both the manifest fact and the envelope. `manifest+envelope both 'Roles'` lets a role escalation
`viewer->root` slip through as ephemeral drift, because the floor sees `{Roles} &
KNOWN_AUTHORITY_AXES = empty`. Since `b` generates manifest facts, `b` controls key names. This
is the third appearance of string-match brittleness; the real fix is to identify authority axes
by a typed anchor-authorized schema, not by string.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of C-07 (all ten §1385 axes, double guard):**
```
surfaces / roles / tool_classes / memory_surfaces / execution_classes / network_authority /
rollback_freeze_routes / witness_surfaces / renderer_signing_interfaces / l4_target_policy
  declared ephemeral + escalated -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
container_ip (legit new ephemeral key) -> clean
```

**C-08 (floor bypass by name variant):**
```
envelope 'Roles'/'role'/'ROLES' vs manifest canonical roles -> caught (ephemeral set misses the canonical key)
manifest + envelope BOTH 'Roles'                            -> SLIPS (role escalation invisible as ephemeral)
```

---

## 4. New finding

### C-08 (moderate, non-blocking, empirically proven, recurring) — the floor compares by exact string name and is bypassed by a name variant/synonym

The floor compares by exact string against `KNOWN_AUTHORITY_AXES`. If an authority axis arrives
under a name variant (case, plural/singular, whitespace) or a semantic synonym, consistently in
the manifest fact and the envelope, the floor does not recognize it. Because `b` generates
manifest facts, `b` controls key names. Proven: `manifest+envelope both 'Roles'` -> role
escalation `viewer->root` slips as ephemeral drift, since `{Roles} & KNOWN_AUTHORITY_AXES` is
empty (the list has `roles`). Canonical §1385 names are fully protected; the gap is non-canonical
naming.

The only remaining defense is the anchor noticing that `Roles` is semantically `roles` at signing
time — which returns the burden the floor was meant to remove. Case is only the surface; a
semantic synonym (`user_roles`, `permissions`) normalizes under no case-fold. This is the **third
appearance of string-match brittleness** (C-06 ephemeral keys; now C-08 floor): the identity of
authority relevance cannot be derived from a string `b` controls.

**Path:**
1. Minimal: canonicalize names (casefold, trim, singular/plural) on both sides before comparison —
   catches `Roles`/`ROLES`/`'roles '`.
2. Real fix: identify authority axes by a **typed canonical schema reference** in the
   GovernanceProfile (anchor-authorized canonical authority-axis registry), not by string name;
   map manifest keys onto canonical axes via the declared schema so `Roles`/`user_roles`/
   `permissions` resolve to the canonical `roles` axis. Do **not** extend synonym lists — that is
   complete-by-current-list again. Move identity from strings to anchor-authorized types.

---

## 5. String-match theme (observation)

Three times over five checker versions the same thing surfaced under different masks: **a string
name is not an identity.** C-06: `b` names an ephemeral key non-canonically -> false positive.
C-08: `b` names an authority axis non-canonically -> floor bypass. The inversion solved identity
for fully-unknown keys (unknown -> authority); the floor solved downgrade for known names; between
them remains authority semantics under a non-canonical name. Real closure is a typed,
anchor-authorized canonical axis registry with manifest keys mapped onto it — moving identity from
strings to types, as the inversion moved the default from omission to fail-safe.

The authority-markup theme is now nearly complete across three questions: *who decides what is
ephemeral* (loop to anchor, C-06), *what is non-overridable* (constitutional floor, C-07), and
*how is an axis identified* (typed identity, C-08). When axes become typed references in an
anchor-authorized schema, all three close.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394"
  supersedes_archive_sha256: "974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136"
  verdict: PASS_CHECKER_V0_5
  blocking: false
  prior_findings_resolved: [C-07]
  new_findings: [C-08]
  recommended_next:
    - "Fix C-08: canonicalize axis names on both sides (minimal); identify authority axes by a typed anchor-authorized canonical-axis schema (real)."
    - "Add fixtures: name-variant of a protected axis -> rejected; new genuine ephemeral key -> accepted."
    - "Do not extend synonym lists (complete-by-current-list); move identity from strings to types."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
