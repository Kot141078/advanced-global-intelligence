# Semantic Review Record — Typed Governed Operational Algebra for `c = a + b` v0.1.5

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `TGOPA_C_v0_1_5_REVIEW__b`
**Supersedes review:** `TGOPA_C_v0_1_4_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: TGOPA_C_v0_1_5_REVIEW__b
  record_version: "0.1.5"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: TGOPA_C_v0_1_4_REVIEW__b

  reviewed_artifact:
    title: "Typed Governed Operational Algebra for c = a + b v0.1.5"
    document_id: TGOPA_C_v0_1_5
    short_name: "C-Calculus v0.1.5 / Governed Binding Algebra v0.1.5"
    author: "Kotov Ivan"
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    line_count: 3722
    sha256: "4f200c9de88a42834890e6f9480c7f18a6ef6b9c18f9624bb07846f329fab702"
    supersedes_artifact_sha256: "e94131839dd7cc837dbb8a391c6ace222f39d95fc0011119cfc7f0f5cc9120a7"
    lineage:
      v0_1:   "01ee648c11f96d03dccd00f9ca1f643297cc3d9152940af08542373bad71cd89"
      v0_1_1: "2b3569e52364a52484b90c002490fa6a249a032ef9962f384f3c01424bf394bd"
      v0_1_2: "3181e53e931b412124c6f483d9f00febf2a306862a392c375c37ad91eab8bcdf"
      v0_1_3: "b8bd89fe11992825eb6e1be8fdb6b985154cb6411dccc8c5bee3498c33f8b1c9"
      v0_1_4: "e94131839dd7cc837dbb8a391c6ace222f39d95fc0011119cfc7f0f5cc9120a7"
      v0_1_5: "4f200c9de88a42834890e6f9480c7f18a6ef6b9c18f9624bb07846f329fab702"
    verification_basis: artifact_text

  verdict:
    result: PASS
    qualifier: profile_v0_1_5
    meaning: >
      As a b-layer semantic reviewer I find the revision internally consistent and
      substantively responsive. F-12 and the SOFT decay-eviction note are resolved
      against the section text. One new moderate substantive finding (F-13) and one
      recurring consistency minor (MINOR-2) are raised. PASS is a verdict on the
      document, NOT an authorization, NOT a ratification, NOT a claim the algebra is
      complete, sound, or deployment-ready.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: section_text_reread
    F-12_effect_target_granularity:
      status: RESOLVED
      evidence: >
        §8.9.2 replaces the free class/id field with target_granularity :=
        TargetGranularityPolicy_g(operation_class, L4_class, resource_class, permission_delta);
        default id; class only for governance-declared class-dangerous; 'Implementation
        MUST NOT freely choose class or id at event time.'
      bonus_beyond_path:
        - "scope granularity added as a third level for bounded resource regions (subtree/namespace/account/db)."
        - "target_granularity_policy_id bound into effect_class_key — granularity cannot be retroactively reinterpreted by changing policy."
        - "alias/symlink/path-reencoding resolved to canonical identity before key construction; unknown_target_identity -> Hold|AskAnchor|Quarantine."
    SOFT_decay_eviction_reference_growth:
      status: RESOLVED
      evidence: "§8.5 Merkle-bound eviction: EvictionMerkleRoot summarizes leaves; CState references the current eviction_merkle_root, not an unbounded flat reference list. Exactly the suggested path."

  external_review_credit:
    note: "These v0.1.5 additions originate from external reviews, not from this reviewer; credited as such."
    items:
      - "resource alias / symlink canonicalization before effect hashing"
      - "in-flight proposal pressure control to prevent anchor exhaustion"
      - "witness dependency-capture represented as a resource-floor invariant"
      - "decay-eviction cryptographic chain integrity (converges with this reviewer's SOFT Merkle note)"

  new_findings:
    F-13_scope_immunity_no_containment:
      severity: moderate
      blocking: false
      locus: ["§8.9.2", "effect_class_key", "target_scope_vector_hash", "type SV"]
      issue: "Scope-granularity immunity matches target_scope_vector by hash equality, which does not cover nested sub-scopes; ScopeVector carries ancestors but the comparison rule ignores them. Sub-scope retry evades the cache in exactly the subtree case scope granularity was introduced for."
    MINOR_2_invariant_registry_drift:
      severity: minor_to_moderate
      blocking: false
      recurring: true
      locus: ["§8.8A", "§9.3", "§9.2"]
      issue: "witness_resource_floor_preserved(c) is labeled 'Minimum invariant' in §8.8A but is absent from the §9.3 Inv set, so inductive preservation does not cover it. Same pattern as the prior witness_chain_intact MINOR."

  internal_consistency_new_mechanisms:
    target_granularity_policy_versioned_in_key: consistent   # §8.9.2 target_granularity_policy_id in effect_class_key
    merkle_eviction_vs_cstate_hash: consistent               # §8.5 root referenced, payload purgeable, lineage retained
    witness_floor_anti_capture_rule: consistent_but_unregistered  # §8.8A rules sound; see MINOR-2 for registry gap
    proposal_pressure_vs_anchor_exhaustion: consistent       # §8.5 in-flight proposal limits, AskAnchorDigest bundling

  convergence_observation:
    substantive_finding_trend: "v0.1.1: 4 -> v0.1.2: 2 -> v0.1.3: 1 -> v0.1.4: 1 -> v0.1.5: 1. Sustained convergence; new substantive findings still confined to newly-added material (scope vector); no regressions in previously-verified sections."
    recurring_pattern_flagged: "Each new protection layer introduces its own granularity dilemma (intent text -> target class/id -> now scope containment). MINOR-2 is the second instance of an invariant declared locally but not registered in §9.3; recommended a structural (registry) fix rather than another point fix."

  open_limit_unchanged:
    witness_regress: >
      Formalization of a (Open Issues 13-14) remains a hard limit. The new §8.8A witness
      resource floor strengthens the proximate witness against resource-starvation capture
      (a real partial defense), but does not eliminate the regress: a remains the terminal
      oracle. Consistent with the corpus principle across all six revisions.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "4f200c9de88a42834890e6f9480c7f18a6ef6b9c18f9624bb07846f329fab702"
    verdict: PASS_PROFILE_V0_1_5
    blocking: false
    prior_findings_resolved: [F-12, SOFT_decay_eviction_reference_growth]
    carry_forward_findings: [F-13, MINOR_2_invariant_registry_drift]
    next_artifact: "02_GOVERNED_BINDING_OPERATOR_PROFILE_v0_1.md"
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

A sixth substantively responsive revision. F-12 is **resolved against the section
text** and by the recommended path: target granularity is now selected by a
governance-declared `TargetGranularityPolicy_g`, defaulting to `id`, with class-level
matching only for governance-flagged class-dangerous operations and an explicit ban
on event-time implementation choice. Three correct additions go beyond the path: a
`scope` granularity for bounded regions, the granularity policy id bound into the
effect key, and alias/symlink canonicalization. The SOFT decay-eviction note is
resolved by Merkle-bound eviction.

The new material is strong. §8.8A (witness resource floor) formalizes
dependency-capture as a resource invariant and bears directly on the witness regress:
it prevents the proximate witness from being starved by the very `c` it witnesses,
without eliminating the regress (`a` stays terminal). Several v0.1.5 additions (alias
resolution, proposal pressure, witness floor, eviction chain integrity) originate from
external reviews, not from this reviewer, and are credited as such.

One new moderate finding (F-13) and one recurring consistency minor (MINOR-2) are
raised. F-13: scope-granularity immunity matches by hash equality and so misses nested
sub-scopes — a hole in exactly the subtree case scope was introduced for. MINOR-2:
`witness_resource_floor_preserved` is declared an invariant in §8.8A but is missing
from the §9.3 Inv set, the second instance of this drift.

PASS means: *as `b`, I find the document sound for what it claims to be.* It does
**not** certify soundness, discharge all predicates, or authorize anything.

---

## 3. New findings

### F-13 (moderate, non-blocking) — Scope-granularity immunity uses hash equality and does not cover nested sub-scopes

`effect_class_key` includes `target_scope_vector_hash = hash(target_scope_vector)`,
and the negative-cache rule is "same effect_class_key -> hit" — i.e. equality of the
whole scope-vector hash. `ScopeVector` is defined to include `ancestors` (type SV),
but the comparison rule does not use ancestor relationships; it hashes the entire
vector.

Sub-scope scenario:

```
rollback: rm -rf /data        -> scope_vector_A {id:/data, ancestors:[/], boundary:subtree(/data)}
                                 negative_cache <- effect_key(hash_A)
retry:    rm -rf /data/critical -> scope_vector_B {id:/data/critical, ancestors:[/,/data], ...}
                                 hash_B != hash_A -> not "same effect_class_key" -> no hit -> proceeds
```

Scope immunity for `/data` therefore blocks only a re-deletion of exactly `/data`,
not `/data/critical`, `/data/important`, etc. A looping agent or attacker whose
`rm -rf /data` was rolled back can retry sub-paths one at a time, each evading the
cache. But the purpose of scope granularity (§8.9.2 example: "delete directory subtree
-> scope over that subtree") is to cover the **region**, not one exact path. Hash
equality collapses scope back to exact id, defeating the reason scope was added.

The data needed to fix this is already present — `ancestors` in `ScopeVector`. Only
the comparison rule is missing.

**Recommended path:** make scope matching containment-aware rather than hash-equality.
A new target gives a cache hit if the cached rolled-back scope is an ancestor of, or
equal to, the new target's canonical scope:
`hit if cached_scope.id ∈ new_target.canonical_ancestors ∪ {new_target.id}`. This is
a deterministic, transitive containment relation over canonical paths/namespaces — not
threshold similarity, so it does not violate §10.5. At minimum handle the
"new target within rolled-back scope" direction (the hole above); the subtle extension
is the reverse direction (`rm -rf /` is a super-region that also re-achieves the
rolled-back effect), so containment is best checked both ways. Note this reuses the
same hierarchical-prefix discipline already adopted for the §10.5 ultrametric (path
prefix = ancestor chain), so the fix is an echo of an existing design choice, not a
new mechanism.

### MINOR-2 (minor-to-moderate, recurring) — `witness_resource_floor_preserved` declared an invariant in §8.8A but absent from the §9.3 Inv set

§8.8A labels `witness_resource_floor_preserved(c)` a "Minimum invariant," but the
§9.3 "Minimum invariant set" `Inv(c)` (11 predicates) does not include it. The
consequence is not cosmetic: inductive preservation (§9.2,
`Inv(c) AND admissible_g(c,e) => Inv(step_g(c,e))`) is stated over the §9.3 set, so
`step_g` is not required by the inductive invariant to preserve the witness floor — a
transition could breach it while keeping `Inv(c)` true. §8.8A's reactive handling
(`breach -> Hold|Freeze|AskAnchor`) catches it after the fact, but witness
independence is not woven into the invariant the persistence argument (§9, §10) rests
on.

This is the **second instance** of the same drift: last round `witness_chain_intact`
was referenced as an Inv predicate in §10.5.1 but missing from §9.3, and was then
added.

**Recommended path (close the pattern, not just this instance):** make §9.3 the
authoritative invariant registry and add a checker rule — any predicate labeled
"invariant" anywhere in the document MUST appear in the §9.3 Inv set. Then new
invariants at `02` and beyond cannot settle locally outside the central set. For now,
add `witness_resource_floor_preserved(c)` to §9.3.

---

## 4. Strength confirmations (preserve under revision)

1. Governance-declared target granularity (§8.9.2) — policy, not implementation,
   chooses id/scope/class; default id; class only for flagged class-dangerous ops.
2. Granularity policy id bound into the effect key — no retroactive reinterpretation.
3. Alias/symlink canonicalization before key construction (§8.9.2); unresolved
   identity fails closed.
4. Merkle-bound decay eviction (§8.5) — payload purgeable, hash lineage retained,
   CState references a bounded root.
5. Witness resource floor (§8.8A) — anti-capture: the witnessed `c` may not
   unilaterally reduce its witness's resources; challenge-survivability test.
6. In-flight proposal pressure control (§8.5) — prevents anchor exhaustion via
   proposal spam; AskAnchorDigest bundling.
7. Inductive invariant and ordered ultrametric unchanged and uncontradicted by the
   new layers.

---

## 5. Non-claims

This record does NOT claim:

1. that the algebra is sound, complete, or proven;
2. that the §8.9.2 / §9.3.1 / §8.8A predicate and key shapes are final mathematical definitions;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies this algebra;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the document text.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed artifact's structure and claims.

---

## 6. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "4f200c9de88a42834890e6f9480c7f18a6ef6b9c18f9624bb07846f329fab702"
  supersedes_artifact_sha256: "e94131839dd7cc837dbb8a391c6ace222f39d95fc0011119cfc7f0f5cc9120a7"
  verdict: PASS_PROFILE_V0_1_5
  blocking: false
  prior_findings_resolved: [F-12, SOFT_decay_eviction_reference_growth]
  carry_forward_findings: [F-13, MINOR_2_invariant_registry_drift]
  next_artifact: "02_GOVERNED_BINDING_OPERATOR_PROFILE_v0_1.md"
  recommended_preconditions_for_02:
    - "Resolve F-13: scope immunity matching must be containment-aware (ancestor-of / within), using the ancestors already in ScopeVector; at minimum cover sub-scope, ideally both directions."
    - "Resolve MINOR-2: register witness_resource_floor_preserved in §9.3; make §9.3 the authoritative invariant registry with a membership check for any predicate labeled 'invariant'."
  reviewer_signature_basis: section_text_verified
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
