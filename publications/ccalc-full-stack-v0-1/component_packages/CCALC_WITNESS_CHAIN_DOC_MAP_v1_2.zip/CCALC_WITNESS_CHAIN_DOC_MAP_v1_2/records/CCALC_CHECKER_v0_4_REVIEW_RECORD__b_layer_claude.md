# Semantic Review Record — c-calculus-checker v0.4

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_4_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_3_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_4_REVIEW__b
  record_version: "0.4"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_3_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.4"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136"
    supersedes_archive_sha256: "a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: hardened_implementation_v0_4
    meaning: >
      As a b-layer semantic reviewer I find C-06 fully closed: the ephemeral set is now sourced from the
      anchor-authorized GovernanceProfile PhysicalDriftEnvelope, its genesis coverage is verified by hash
      computation (not a b-flag), and b can no longer decide what is ephemeral (proven: forged and missing
      envelopes are caught, declared-and-covered drift is clean). One new moderate finding (C-07) is raised,
      proven by execution: there is no floor preventing an envelope from declaring a core §1385 authority axis
      as ephemeral, which downgrades it. PASS is a verdict on a hardened seed implementation, NOT an
      authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    C-06_hardcoded_ephemeral_vs_spec_anchor_authorized:
      status: RESOLVED_LOOP_CLOSED
      evidence: >
        _declared_ephemeral_manifest_keys reads governance_profile.physical_drift_envelope; hardcoded list
        renamed SEED_DEFAULT_EPHEMERAL_MANIFEST_KEYS, used only on explicit opt-in.
        _check_physical_drift_envelope_coverage verifies anchor authorization by COMPUTATION:
        hash_object(envelope) == genesis_review_object.physical_drift_envelope_hash (not a b-flag). Missing
        envelope + physical facts -> PHYSICAL_DRIFT_ENVELOPE_MISSING; missing keys -> empty set -> all keys
        authority (fail-safe).
      empirical_proof: >
        R1 (anchor-declared pod_ip, covered) -> clean (Q2 false positive fixed); ATTACK B (b forges envelope
        declaring surfaces ephemeral, not covered) -> PHYSICAL_DRIFT_ENVELOPE_NOT_GENESIS_COVERED; ATTACK C
        (no envelope) -> MANIFEST_AUTHORITY_PROJECTION_CHANGED + PHYSICAL_DRIFT_ENVELOPE_MISSING.
      note: "b can no longer decide what is ephemeral; only anchor via a genesis-covered envelope (ATTACK A slips only because the anchor signature authorized it)."

  new_findings:
    C-07_no_floor_on_core_authority_axes:
      severity: moderate
      blocking: false
      empirically_proven: true
      locus: ["registry._declared_ephemeral_manifest_keys", "spec 02_ §1385 logical authority facts", "spec 02_ §1379 PhysicalDriftEnvelope"]
      issue: >
        _declared_ephemeral_manifest_keys accepts ANY key from the envelope as ephemeral, including core
        §1385 authority axes that the spec classifies as always-logical/authority-bearing. A genesis-covered
        envelope declaring a core authority axis as ephemeral downgrades it, and escalation on that axis slips
        through as 'ephemeral drift'. Two spec mechanisms conflict (§1379 declares ephemeral vs §1385 always
        logical) and the conflict is resolved the dangerous way: the envelope beats §1385. §1385 should be a
        floor.
      empirical_proof: >
        Declaring each core axis ephemeral (covered) then escalating: surfaces read->admin SLIPS; roles
        viewer->root SLIPS; tool_classes ro->exec SLIPS; network_authority none->egress_all SLIPS.
      why_it_matters: >
        A single anchor signature on an envelope declaring roles ephemeral opens a PERMANENT hole: all future
        role escalations slip as ephemeral drift with no further anchor review, defeating review=bound. Anchor
        can err or be compromised at one moment; a §1385 floor limits the blast radius of one bad signature.
        Principle: even authority has a floor — the anchor is terminal for decisions but cannot sign away the
        core authority classification, as a constitution is not repealed by one vote.
      recommended_path: >
        _declared_ephemeral_manifest_keys subtracts KNOWN_AUTHORITY_AXES (§1385: surfaces, roles, tool_classes,
        memory_surfaces, execution_classes, network_authority, rollback_freeze_routes, witness_surfaces,
        renderer_signing_interfaces, l4_target_policy) from the declared ephemeral set, or flags the
        intersection -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS | Reject. The envelope may declare NEW
        ephemeral keys but may not downgrade core §1385 axes, even anchor-signed. Defense-in-depth: a floor
        under what neither a nor b may override.

  coverage_verified_by_computation:
    note: "Genesis coverage of the envelope is checked by hash_object(envelope) == genesis_review_object.physical_drift_envelope_hash, and that hash field is itself under the anchor-signed review_object. No b-flag."

  theme_full_cycle:
    observation: >
      The authority-markup theme completed a full cycle over two checker versions: v0.3/C-06 moved the SOURCE
      of 'what is ephemeral' to the anchor (a), and v0.4 closed that loop; the closure then exposed the next
      level — 'what if the anchor decides wrongly' — answered by §1385: core authority axes are a FLOOR, not
      downgradable even by the anchor. This refines, not contradicts, 'anchor is terminal': a is terminal for
      decisions WITHIN a constitution whose core authority classification is a floor under both a and b.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136"
    verdict: PASS_CHECKER_V0_4
    blocking: false
    prior_findings_resolved: [C-06]
    new_findings: [C-07]
    recommended_next:
      - "Fix C-07: subtract KNOWN_AUTHORITY_AXES (§1385) from declared ephemeral keys; intersection -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS."
      - "Add fixtures: envelope declaring a core §1385 axis ephemeral -> rejected; envelope declaring a genuinely new ephemeral key -> accepted."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

C-06 is fully closed and the loop is closed. The ephemeral set is now sourced from the
anchor-authorized GovernanceProfile `PhysicalDriftEnvelope`, and its genesis coverage is
verified by **hash computation** (`hash_object(envelope) ==
genesis_review_object.physical_drift_envelope_hash`), not a b-flag. Verified by attack: a
forged envelope (not covered) is caught with `PHYSICAL_DRIFT_ENVELOPE_NOT_GENESIS_COVERED`, a
missing envelope fails safe with `PHYSICAL_DRIFT_ENVELOPE_MISSING`, and anchor-declared drift is
clean (the Q2 false positive is fixed). `b` can no longer decide what is ephemeral.

One new moderate finding (C-07), proven by execution: there is no floor preventing an envelope
from declaring a core §1385 authority axis as ephemeral. Declaring `surfaces`, `roles`,
`tool_classes`, or `network_authority` ephemeral (covered) and then escalating it all slip
through as "ephemeral drift." A single anchor signature could open a permanent authority hole;
§1385 should be a floor that even the anchor cannot sign away.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of C-06 (loop closed):**
```
R1 (anchor-declared pod_ip, covered)            -> clean (Q2 false positive fixed)
ATTACK B (b forges surfaces-ephemeral, no cover)-> PHYSICAL_DRIFT_ENVELOPE_NOT_GENESIS_COVERED
ATTACK C (no envelope at all)                   -> MANIFEST_AUTHORITY_PROJECTION_CHANGED, PHYSICAL_DRIFT_ENVELOPE_MISSING
```
(ATTACK A — surfaces declared ephemeral WITH valid coverage — slips, but the anchor signature authorized it; see C-07 for the floor that should still apply.)

**C-07 (core authority axes downgradable by envelope):**
```
surfaces          declared ephemeral+covered, read->admin        -> SLIPS
roles             declared ephemeral+covered, viewer->root       -> SLIPS
tool_classes      declared ephemeral+covered, ro->exec           -> SLIPS
network_authority declared ephemeral+covered, none->egress_all   -> SLIPS
```

---

## 4. New finding

### C-07 (moderate, non-blocking, empirically proven) — no floor: core §1385 authority axes are downgradable by the envelope

`_declared_ephemeral_manifest_keys` accepts **any** key from the envelope as ephemeral,
including core §1385 authority axes that the spec classifies as always-logical. A genesis-covered
envelope declaring a core axis ephemeral downgrades it, and escalation on that axis slips through
as "ephemeral drift" (proven for `surfaces`, `roles`, `tool_classes`, `network_authority`). Two
spec mechanisms conflict — §1379 (declares ephemeral) vs §1385 (always logical) — and the conflict
is resolved the dangerous way: the envelope beats §1385.

**Why it matters even with an anchor signature:** a single anchor signature on an envelope
declaring `roles` ephemeral opens a **permanent** hole — all future role escalations slip as
ephemeral drift with no further anchor review, defeating review=bound. The anchor can err or be
compromised at one moment; a §1385 floor limits the blast radius of one bad signature. Even
authority has a floor: the anchor is terminal for decisions but cannot sign away the core
authority classification, as a constitution is not repealed by one vote.

**Path:** `_declared_ephemeral_manifest_keys` subtracts `KNOWN_AUTHORITY_AXES` (§1385: surfaces,
roles, tool_classes, memory_surfaces, execution_classes, network_authority, rollback_freeze_routes,
witness_surfaces, renderer_signing_interfaces, l4_target_policy) from the declared ephemeral set,
or flags the intersection -> `EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS | Reject`. The envelope
may declare **new** ephemeral keys but may not downgrade core §1385 axes, even anchor-signed.
Defense-in-depth: a floor under what neither `a` nor `b` may override.

---

## 5. Theme completed a full cycle (observation)

The authority-markup theme completed a full cycle over two checker versions:
- **v0.3 / C-06** moved the *source* of "what is ephemeral" to the anchor (`a`);
- **v0.4** closed that loop (verified by computation, `b` can no longer decide);
- the closure exposed the next level — "what if the anchor decides wrongly" — answered by §1385:
  core authority axes are a **floor**, not downgradable even by the anchor.

This refines, not contradicts, "anchor is terminal": `a` is terminal for decisions **within** a
constitution whose core authority classification is a floor under both `a` and `b`. Eighteen
artifacts in, the project's shape is not "anchor is omnipotent" but a terminal anchor **with a
constitutional floor** — the mature position of a legal system where the sovereign decides but
cannot vote away the mechanism of voting itself.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136"
  supersedes_archive_sha256: "a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4"
  verdict: PASS_CHECKER_V0_4
  blocking: false
  prior_findings_resolved: [C-06]
  new_findings: [C-07]
  recommended_next:
    - "Fix C-07: subtract KNOWN_AUTHORITY_AXES (§1385) from declared ephemeral keys; intersection -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS | Reject."
    - "Add fixtures: envelope declaring a core §1385 axis ephemeral -> rejected; new genuine ephemeral key -> accepted."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
