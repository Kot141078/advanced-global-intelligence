# Semantic Review Record — c-calculus-checker v0.2

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_2_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_1_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_2_REVIEW__b
  record_version: "0.2"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_1_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.2"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0"
    supersedes_archive_sha256: "3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516"
    core_loc: 559
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: hardened_implementation_v0_2
    meaning: >
      As a b-layer semantic reviewer I find v0.2 a strong, substantive hardening. C-01 is closed as a
      principle (fail-safe on missing authority-bearing fields applied uniformly across the checker, proven
      by 12 executed attacks including new variations and previously-untouched functions), and C-02/C-03/C-04
      are closed correctly. One new moderate finding (C-05) is raised on the authority projection, proven by
      execution. PASS is a verdict on a hardened seed implementation, NOT an authorization, NOT a
      certification of production readiness.
    blocking_findings: 0
    safety_escalations: 0
    fixture_tests: "all fixtures pass incl. new omission fixtures"

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_replay
    C-01_missing_field_skip:
      status: RESOLVED_AS_PRINCIPLE
      evidence: >
        'if field and ...' replaced by 'if field is None: finding' across affected functions; signature check
        changed from blacklist (== model_output) to whitelist membership (ANCHOR_SIGNATURE_UNVERIFIED).
      empirical_proof: >
        12 executed attacks all caught: prior Attack2 -> CONTEXT_STATE_PROJECTION_MISSING+L4;
        Attack3 -> CAUSAL_PRE_STATE_MISSING; Attack4 -> ANCHOR_SIGNATURE_UNVERIFIED; N1 junk source ->
        ANCHOR_SIGNATURE_UNVERIFIED (whitelist, not blacklist); N2 dropped nonce -> NONCE_NOT_FUSED; N6
        delegation root without sig_source -> DELEGATION_ROOT_MISSING_OR_EMULATED; and untouched functions:
        M2 dropped authority block -> SURFACE_PROJECTION_UNDECLARED; M4 dropped genesis_review_object ->
        GENESIS_AUTHORIZATION_MISMATCH; M3 lease expired no cascade -> ACTIVE_EXECUTION_AFTER_LEASE_EXPIRY.
      note: "Principle, not point-patch: new variations and previously-unattacked functions also fail-safe."
    C-02_manifest_projection_trusts_b:
      status: RESOLVED
      evidence: >
        _canonical_authority_projection computes projection from raw manifest_before/manifest_after; docstring
        'does not read b-supplied authority_projection_before/after'. Missing raw -> MANIFEST_AUTHORITY_
        PROJECTION_SOURCE_MISSING. N4 (real change, b unflagged) -> MANIFEST_AUTHORITY_PROJECTION_CHANGED.
    C-03_self_accusing_flags:
      status: RESOLVED
      evidence: >
        check_viewport_atomicity diffs authority-bearing rendered layer ids against signature-covered unit
        ids (REVIEW_VIEWPORT_HIDDEN_AUTHORITY); legacy self-accusing flag retained but explicitly marked a
        fixture-level backstop, not the primary check.
    C-04_emitter_skips_preconditions:
      status: RESOLVED
      evidence: "emit_certificate runs run_all_checks before building the certificate; any finding -> return {}, findings. invalid_emitter_revoked_anchor fixture added."
    minor_mismatch_code_from_b:
      status: RESOLVED
      evidence: "_layer_mismatch_code is checker-owned (LAYER_MISMATCH_CODES by layer_type/layer_id); docstring 'Do not trust b-supplied mismatch_error'."

  author_epistemics:
    assessment: honest
    note: >
      ADVERSARIAL_PROOF_v0_2.md states 'the point is not that these are exhaustive ... changes the default from
      missing->skip to missing->fail-safe for the first authority-bearing surfaces'; CHANGELOG states 'still a
      seed ... does not claim production readiness'. No overclaim. C-05 continues the author's own 'not exhaustive'.

  new_findings:
    C-05_projection_complete_by_current_list:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_pattern: true
      locus: ["registry._canonical_authority_projection"]
      issue: >
        _canonical_authority_projection iterates a fixed list of 10 authority axes; an authority change on an
        axis outside the list is not detected. Proven: P1 (manifest_after adds gpu_compute_authority /
        signing_key_access, both unlisted) -> NO finding (authority drift slips through); P2 control (change on
        listed network_authority) -> MANIFEST_AUTHORITY_PROJECTION_CHANGED. This is the same
        complete-by-current-list pattern the series closed at spec level (F2-05, F2-06, meta-invariant §4.4).
        The checker fail-safes on missing FIELDS (C-01) but not on unknown AXES in the projection: an unknown
        axis is ignored (non-authority) rather than treated as authority-bearing, the opposite of §4.4.
      recommended_path: >
        Invert the projection to realize the meta-invariant at this sub-level: whitelist known-EPHEMERAL keys
        (IP, pod_id, process_id, RAM/VRAM, rotating handles, transient route, telemetry per §1391) and treat
        ANY key outside the ephemeral whitelist as authority-bearing (fail-safe toward authority,
        complete-by-construction) — matching RenderedLayerRegistry (unknown->authority_bearing) and
        ManifestFactRegistry (unknown->logical). Alternatively, a key in neither list ->
        MANIFEST_FACT_UNCLASSIFIED | treat as authority.

  progress_observation:
    pattern: >
      Findings deepened: v0.1 was 'functions skip on missing fields' (trust boundary); v0.2 closed that as a
      principle, and the residual is now 'the authority projection enumerates known axes' — one level below,
      inside a helper. This is the last known residual of the complete-by-current-list pattern the series has
      tracked since F2-05.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0"
    verdict: PASS_CHECKER_V0_2
    blocking: false
    prior_findings_resolved: [C-01, C-02, C-03, C-04]
    new_findings: [C-05]
    recommended_next:
      - "Fix C-05: invert _canonical_authority_projection to an ephemeral whitelist so unknown axes fail safe toward authority."
      - "Add a fixture: physical drift changing authority on an unlisted axis -> MANIFEST_AUTHORITY_PROJECTION_CHANGED."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

A strong, substantive hardening. C-01 is closed **as a principle, not a point-patch**: the
`if field and ...` idiom is replaced by `if field is None: finding` across the checker, and
the signature check moved from a blacklist (`== "model_output"`) to whitelist membership. I
verified this by execution, not reading — 12 attacks all caught, including new variations
absent from the fixtures (junk `signature_source`, dropped `nonce`, delegation root without
`signature_source`) and functions I never attacked before (dropped authority block, dropped
`genesis_review_object`, lease expiry without cascade). C-02 (compute projection from raw
manifest), C-03 (viewport diffs authority layers against signature-covered units), and C-04
(emitter runs full preconditions) are closed correctly. `ADVERSARIAL_PROOF_v0_2.md` is
epistemically honest and does not overclaim.

One new moderate finding (C-05), proven by execution: `_canonical_authority_projection`
enumerates 10 authority axes, so an authority change on an axis outside the list slips through
(P1 vs P2 control). This is the same complete-by-current-list pattern the series closed at spec
level — the checker fail-safes on missing fields but not on unknown axes in the projection. The
fix is to invert the projection to an ephemeral whitelist, matching the meta-invariant.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification
of production readiness.

---

## 3. Empirical proof (executed)

**Closure of C-01 (12 attacks, all caught):**
```
prior Attack2 (omit projection hashes)  -> CONTEXT_STATE_PROJECTION_MISSING, L4_STATE_PROJECTION_MISSING
prior Attack3 (omit pre_state)          -> CAUSAL_PRE_STATE_MISSING
prior Attack4 (omit signature_source)   -> ANCHOR_SIGNATURE_UNVERIFIED
N1 (junk signature_source)              -> ANCHOR_SIGNATURE_UNVERIFIED   (whitelist, not blacklist)
N2 (drop nonce entirely)                -> NONCE_NOT_FUSED
N6 (delegation root without sig_source) -> DELEGATION_ROOT_ENVELOPE_MISSING_OR_EMULATED
M2 (drop authority block)               -> SURFACE_PROJECTION_UNDECLARED
M4 (drop genesis_review_object)         -> GENESIS_AUTHORIZATION_MISMATCH
M3 (lease expired, no cascade)          -> ACTIVE_EXECUTION_AFTER_LEASE_EXPIRY, SAFE_ABORT_ROUTE_MISSING
N4 (manifest real change, b unflagged)  -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
N5 (manifest physical, no raw source)   -> MANIFEST_AUTHORITY_PROJECTION_SOURCE_MISSING
M6 (drop effect_axis classifier)        -> OPERATOR_CLASSIFICATION_DRIFT
```

**C-05 (authority drift on unlisted axis):**
```
P1 (change on gpu_compute_authority / signing_key_access, both unlisted) -> NO finding  (slips through)
P2 (control: change on network_authority, listed)                        -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
```

---

## 4. New finding

### C-05 (moderate, non-blocking, empirically proven, recurring) — the authority projection is complete-by-current-list

`_canonical_authority_projection` iterates a fixed list of 10 authority axes (§1385 logical
facts). A key outside the list is ignored, so it never enters the projection, so `before ==
after`, so an authority change on that key is not detected (P1). A listed key is caught (P2).

This is the **same complete-by-current-list pattern** the series closed at spec level (F2-05,
F2-06, meta-invariant §4.4, which requires "unknown -> fail-safe toward authority"). The checker
fail-safes on missing **fields** (C-01 closed as a principle) but not on unknown **axes** in the
projection: an unknown axis is treated as non-authority (ignored), the opposite of §4.4.

**Path:** invert the projection to realize the meta-invariant at this sub-level. Whitelist
known-**ephemeral** keys (IP, pod_id, process_id, RAM/VRAM, rotating handles, transient route,
telemetry per §1391) and treat **any** key outside the ephemeral whitelist as authority-bearing
(fail-safe toward authority, complete-by-construction) — matching `RenderedLayerRegistry`
(unknown -> authority_bearing) and `ManifestFactRegistry` (unknown -> logical). Alternatively, a
key in neither list -> `MANIFEST_FACT_UNCLASSIFIED | treat as authority`.

---

## 5. Progress observation

Findings deepened. v0.1 was "functions skip on missing fields" — a trust-boundary failure at
the function level. v0.2 closed that as a principle, and the residual is now "the authority
projection enumerates known axes" — one level below, inside a helper function. This is the last
known residual of the complete-by-current-list pattern the series has tracked since F2-05.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0"
  supersedes_archive_sha256: "3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516"
  verdict: PASS_CHECKER_V0_2
  blocking: false
  prior_findings_resolved: [C-01, C-02, C-03, C-04]
  new_findings: [C-05]
  recommended_next:
    - "Fix C-05: invert _canonical_authority_projection to an ephemeral whitelist; unknown axis -> authority-bearing."
    - "Add fixture: physical drift changing authority on an unlisted axis -> MANIFEST_AUTHORITY_PROJECTION_CHANGED."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
