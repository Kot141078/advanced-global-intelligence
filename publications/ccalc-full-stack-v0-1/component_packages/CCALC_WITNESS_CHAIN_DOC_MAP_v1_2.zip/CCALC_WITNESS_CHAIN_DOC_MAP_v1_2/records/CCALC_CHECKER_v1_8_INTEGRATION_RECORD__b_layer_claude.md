# Semantic Review Record — c-calculus-checker v1.8 (cross-subsystem layer, fifth fix pass + seam matrix)

**Record class:** b-layer semantic review record (advisory) — integration follow-up  
**Review protocol:** CGAM b-layer checker, advisory only  
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`  
**Review date:** 2026-06-30  
**Record short name:** `CCALC_CHECKER_v1_8_INTEGRATION__b`  
**Supersedes review:** `CCALC_CHECKER_v1_7_INTEGRATION__b`

> **Recovery note (DOC_MAP v1.2):** this local file is a recovered normalized full-text witness record reconstructed from conversation-uploaded review text and DOC_MAP lineage evidence. It is now sidecar-bound as a local witness file. It does not claim byte-identity with an unavailable pre-freeze standalone original.

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_8_INTEGRATION__b
  record_version: "1.8-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_7_INTEGRATION__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.8 (active surface declaration divergence)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "9f6e57034986be3d3109f4beb9931ae0689292c6eed56af06ba2723b00b14144"
    supersedes_archive_sha256: "2accc1a6653fdda721345de69d7802ad9e64cf3e14d121b458834c4974224e2d"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: cross_subsystem_layer_fifth_pass_with_seam_matrix
    meaning: >
      As a b-layer semantic reviewer I find INT-06 closed (divergence flag, canonicalized). A systematic matrix
      pass of the active x authority seam against the whole class vocabulary revealed INT-07: a CLASS of masking
      channels (worker_id, arbitrary field names, string form), five vectors with one root — active-surface
      extraction is enumerated over fields {surface_id, authority_surfaces, surfaces} and dict form only. This
      is empirical proof of the matrix-over-queue thesis: one pass found the whole class at once, where
      one-by-one would take several turns. PASS is a verdict on a seed integration layer, NOT an authorization,
      NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    INT-06_surface_id_dual_role:
      status: RESOLVED
      evidence: >
        _active_surface_declaration_divergence_findings flags surface_id present + explicit authority_surfaces +
        surface_id not in set -> ACTIVE_SURFACE_DECLARATION_DIVERGENCE. Roles split structurally: surface_id is
        always authority-bearing, worker_id a label. Divergence check canonicalizes.
      empirical_proof: "surface_id=write_memory + auth=[read_logs] -> DECLARATION_DIVERGENCE; surface_id=Read_Logs vs auth=[read_logs] -> clean."

  new_findings:
    INT-07_enumerated_active_surface_extraction:
      severity: significant
      blocking: false
      empirically_proven: true
      class: enumerated_vs_fail_safe
      issue: >
        Active-surface extraction enumerates fields {surface_id, authority_surfaces, surfaces} and dict form only.
        Any channel outside that enumeration is ignored and can hide the real surface. Five vectors have one
        root: worker_id, worker_id alone, execution_surface, target_surface, and string form.
      empirical_proof: >
        worker_id=write_memory + auth=[read_logs] -> CLEAN; worker_id=write_memory alone -> CLEAN;
        execution_surface=write_memory -> CLEAN; target_surface=write_memory -> CLEAN; active=['write_memory']
        (string form, not dict) -> CLEAN.
      recommended_path: >
        Invert to fail-safe. Extract the surface from all fields/forms except an explicit label whitelist.
        String element -> surface_id; known labels such as worker_id/execution_id/pid are ignored; any other
        field is authority-bearing by default.

  seam_map_active_x_authority:
    containment_INT05: "surface_id=write_memory (no explicit) -> EXCEEDS [closed]"
    canonicalization: "surface_id=Write_Memory vs write_memory -> EXCEEDS canonical [closed]"
    trust_surface_id_INT06: "surface_id=write_memory + auth=[read_logs] -> DIVERGENCE [closed]"
    trust_worker_id_INT07: "worker_id=write_memory + benign -> CLEAN [OPEN]"
    worker_id_alone_INT07: "worker_id=write_memory -> CLEAN [OPEN]"
    arbitrary_field_INT07: "execution_surface / target_surface=write_memory -> CLEAN [OPEN]"
    string_form_INT07: "active=['write_memory'] not dict -> CLEAN [OPEN]"

  matrix_over_queue_thesis_proven:
    observation: >
      A matrix pass of one seam against the class vocabulary found the whole remaining class at once. Closing by
      queue would return a sub-seam each turn; closing by matrix takes the class as a batch.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "9f6e57034986be3d3109f4beb9931ae0689292c6eed56af06ba2723b00b14144"
    supersedes_archive_sha256: "2accc1a6653fdda721345de69d7802ad9e64cf3e14d121b458834c4974224e2d"
    verdict: PASS_CHECKER_V1_8_CROSS_SUBSYSTEM_FIFTH_PASS
    blocking: false
    prior_findings_resolved: [INT-06]
    new_findings: [INT-07]
    probe_areas: [INT-C_delegation_vs_anchor_revocation, active_x_lease, authority_x_lease_downgrade]
    recommended_next:
      - "Fix INT-07 as a class: invert active-surface extraction to fail-safe."
      - "Build the full cross-subsystem seam matrix; close each seam as a batch."
      - "Probe active x lease and authority x lease downgrade."
      - "Write a Claude Code contract per seam once the matrix is built."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement

INT-06 is closed. A systematic matrix pass of active x authority revealed INT-07: not one hole, but a class of masking channels caused by enumerated extraction. This record is the point where the matrix-over-queue recommendation was proven by execution.

---

## 3. Empirical proof

```text
surface_id=write_memory + auth=[read_logs] -> ACTIVE_SURFACE_DECLARATION_DIVERGENCE
surface_id=Read_Logs vs auth=[read_logs]   -> clean
worker_id=write_memory + auth=[read_logs]  -> CLEAN
worker_id=write_memory alone               -> CLEAN
execution_surface=write_memory             -> CLEAN
target_surface=write_memory                -> CLEAN
active=['write_memory'] (string, not dict) -> CLEAN
```

---

## 4. Non-claims

This record does NOT claim that the checker is correct, complete, proven, deployable, a safety guarantee, a conformance certificate, or an authorization. It makes no statement about the memory or dialogue content of any live entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

*End of recovered review record.*
