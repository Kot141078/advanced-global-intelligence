# Semantic Review Record — c-calculus-checker v1.6 (cross-subsystem layer, third fix pass)

**Record class:** b-layer semantic review record (advisory) — integration follow-up
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_6_INTEGRATION__b`
**Supersedes review:** `CCALC_CHECKER_v1_5_INTEGRATION__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_6_INTEGRATION__b
  record_version: "1.6-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_5_INTEGRATION__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.6 (fail-safe cross-subsystem routing)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "5d06cd1b85f8e3cfb52841b1c3750214cebafabcbd0d1183748a07ff182bd193"
    supersedes_archive_sha256: "9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: cross_subsystem_layer_third_pass
    meaning: >
      As a b-layer semantic reviewer I find INT-04 closed as a principle: routing is fail-safe, required under
      any state except a present active-and-unexpired lease, verified by matrix. One new significant finding
      (INT-05, the mirror of INT-01): active_execution_surfaces are not checked for containment in authorized
      surfaces, so active execution can exceed delegated/anchor authority and is uncaught anywhere. This
      requires an honest correction of the convergence-curve model I have been drawing: the cross-subsystem
      plane does not converge monotonically; it has many seams, each of which can yield a fundamental finding.
      PASS is a verdict on a seed integration layer, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    INT-04_enumerated_cascade_capable_vs_fail_safe:
      status: RESOLVED_AS_PRINCIPLE
      evidence: "_lease_routing_required_silent returns True for everything except (lease dict AND status=='active' AND not expired). Complete-by-construction fail-safe: only a known-safe active-valid lease skips routing."
      empirical_proof: "reduced_authority / pending_anchor / missing lease / unknown status / empty lease + not routed -> NOT_IN_ACTIVE_EXECUTION; active + future expiry -> clean; active + past expiry -> NOT_IN_ACTIVE_EXECUTION (date expiry overrides status)."

  new_findings:
    INT-05_active_execution_exceeds_authority:
      severity: significant
      blocking: false
      empirically_proven: true
      class: cross_subsystem_authority_containment  # mirror of INT-01, a different seam
      mirror_of: INT-01
      locus: ["no check reads active_execution_surfaces against delegation.allowed / authority.anchor_surfaces"]
      issue: >
        active_execution_surfaces are not checked for containment in authorized surfaces. INT-01 closed
        delegation.allowed subset anchor (keys issued correctly), but execution is what actually happens. Even
        with correct delegation, active_execution may execute surfaces outside delegation — unauthorized, up to
        a surface outside the whole lattice. The full containment is active subset delegated subset anchor; only
        the middle (delegated subset anchor, INT-01) is closed; the outer (active subset delegated) is open.
        This also undercuts routing: routing checks delegated subset active (one side); active may contain more
        than delegated, and the excess is unauthorized.
      empirical_proof: >
        Via full run_all_checks: exec write_memory (not delegated, not in anchor read_logs), valid lease ->
        CLEAN; exec root_shell_unlisted (outside lattice), valid lease -> CLEAN; mirror INT-01 (delegation >
        anchor) -> DELEGATION_EXCEEDS_ANCHOR_AUTHORITY (caught). The asymmetry: one side of containment closed,
        the mirror open.
      recommended_path: >
        Cross-subsystem check active_execution_surfaces subset authorized, where authorized = delegation.allowed
        for a delegated agent (subset anchor via INT-01), else anchor_surfaces. With INT-01 this gives the full
        chain active subset delegated subset anchor. New error ACTIVE_EXECUTION_EXCEEDS_AUTHORITY | Reject, with
        canonicalization (as INT-01) so C-08 does not resurface.

  convergence_model_correction:
    what_i_claimed: "Over recent turns I drew a converging curve within the cross-subsystem plane (INT-01 fundamental -> INT-03 thinner -> INT-04 thinner) and concluded 'the plane is near maturity'."
    what_int05_shows: "INT-05 is fundamental again (significant, mirror of INT-01), not thinner than INT-04. The curve does NOT converge monotonically on the cross-subsystem plane."
    accurate_model: >
      The cross-subsystem plane has MANY seams between subsystems, and the curve converges only WITHIN one seam.
      delegation x lease routing converged (INT-02 -> 03 -> 04). But each NEW seam opens a NEW fundamental
      finding: delegation x anchor authority -> INT-01; delegation x lease lifecycle -> INT-02..04 (converge
      within seam); active-execution x authority -> INT-05 (fundamental again, new seam). The plane yields as
      many fundamental findings as there are unrelated seams between subsystems.
    honest_recalibration: >
      'The plane is near maturity' was wrong. Subsystem maturity (curve 7->4->2) does NOT transfer to the
      cross-subsystem plane as fast convergence. Within a seam it converges; but the number of seams grows
      combinatorially with the number of subsystems, and each unprobed seam is a potential fundamental finding.
      The cross-subsystem plane is not a one-or-two-finding tail; it is a full stratum the size of the matrix of
      subsystem seams. I probed three seams; two yielded a fundamental finding immediately.
    not_pessimism: "The method is unchanged and works (INT-05 found by the same adversarial lens on a seam), and the path for INT-05 is narrow (mirror containment). What was underestimated is the SIZE of the cross-subsystem stratum, not the difficulty of any one finding."

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "5d06cd1b85f8e3cfb52841b1c3750214cebafabcbd0d1183748a07ff182bd193"
    verdict: PASS_CHECKER_V1_6_CROSS_SUBSYSTEM_THIRD_PASS
    blocking: false
    prior_findings_resolved: [INT-04]
    new_findings: [INT-05]
    probe_areas: [INT-C_delegation_vs_anchor_revocation]
    recommended_next:
      - "Fix INT-05: cross-subsystem check active_execution subset authorized (delegated for delegated agent, else anchor); with INT-01 gives active subset delegated subset anchor; canonicalize; ACTIVE_EXECUTION_EXCEEDS_AUTHORITY."
      - "Systematically enumerate all pairwise seams of the three mature subsystems and probe each with the adversarial lens, rather than waiting for them to surface one by one."
      - "Defer viewport/nonce until the existing seam matrix is probed, or each new subsystem adds a whole column of unprobed seams."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

INT-04 is closed as a principle: routing is fail-safe. `_lease_routing_required_silent` returns True
for every state except a present active-and-unexpired lease (verified by matrix — reduced_authority,
pending_anchor, missing lease, unknown status, empty lease all require routing; active-valid is clean;
date expiry overrides a status of active). Complete-by-construction, the same inversion that closed
every prior enumerated-vs-fail-safe instance.

One new significant finding (INT-05), the mirror of INT-01: `active_execution_surfaces` are not
checked for containment in authorized surfaces, so active execution can exceed delegated/anchor
authority — proven via full `run_all_checks`, up to executing a surface outside the whole lattice,
uncaught anywhere. INT-01 checks that keys are issued correctly (delegated ⊆ anchor); INT-05 is the
missing check that only authorized doors open (active ⊆ delegated ⊆ anchor).

This forces an honest correction of the convergence-curve model I drew over recent turns: the
cross-subsystem plane does not converge monotonically. It has many seams; the curve converges only
within one seam, and each new seam can yield a fundamental finding. "The plane is near maturity" was
wrong.

PASS is a verdict on a seed integration layer — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of INT-04 (fail-safe matrix):**
```
reduced_authority / pending_anchor / missing lease / unknown status / empty lease + not routed
                                            -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
active + future expiry + not routed         -> clean (only safe state)
active + past expiry + not routed           -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION (date overrides status)
```
**INT-05 (active execution exceeds authority) — via full run_all_checks:**
```
exec write_memory (not delegated, not in anchor read_logs), valid lease -> CLEAN
exec root_shell_unlisted (outside whole lattice), valid lease           -> CLEAN
mirror INT-01 (delegation > anchor)                                     -> DELEGATION_EXCEEDS_ANCHOR_AUTHORITY (caught)
```

---

## 4. New finding

### INT-05 (significant, non-blocking, empirically proven, mirror of INT-01) — active execution exceeds authority

`active_execution_surfaces` are not checked for containment in authorized surfaces. INT-01 closed
`delegation.allowed ⊆ anchor` (keys issued correctly), but execution is what actually happens. Even
with correct delegation, `active_execution` may execute surfaces outside delegation — unauthorized, up
to a surface outside the whole lattice (both proven CLEAN via full `run_all_checks`). The full
containment is `active ⊆ delegated ⊆ anchor`; only the middle (INT-01) is closed; the outer (`active ⊆
delegated`) is open. This also undercuts routing, which checks `delegated ⊆ active` (one side) while
`active` may contain unauthorized excess.

**Path:** cross-subsystem check `active_execution_surfaces ⊆ authorized`, where authorized =
`delegation.allowed` for a delegated agent (⊆ anchor via INT-01), else `anchor_surfaces`. With INT-01
this gives the full chain `active ⊆ delegated ⊆ anchor`. New error `ACTIVE_EXECUTION_EXCEEDS_AUTHORITY
| Reject`, with canonicalization (as INT-01) so C-08 does not resurface.

---

## 5. Convergence model correction (observation)

Over recent turns I drew a converging curve within the cross-subsystem plane (INT-01 fundamental ->
INT-03 thinner -> INT-04 thinner) and concluded "the plane is near maturity." **INT-05 shows that was
wrong.** It is fundamental again (significant, the mirror of INT-01), not thinner than INT-04. The
curve does not converge monotonically on the cross-subsystem plane.

The accurate model: the plane has **many seams** between subsystems, and the curve converges only
**within one seam**. delegation x lease routing converged (INT-02 -> 03 -> 04). But each **new** seam
opens a **new** fundamental finding: delegation x anchor authority -> INT-01; delegation x lease
lifecycle -> INT-02..04 (converge within the seam); active-execution x authority -> INT-05
(fundamental again, a new seam). The plane yields as many fundamental findings as there are unrelated
seams between subsystems.

Honest recalibration: subsystem maturity (curve 7->4->2) does not transfer to the cross-subsystem
plane as fast convergence. Within a seam it converges; but the number of seams grows combinatorially
with the number of subsystems, and each unprobed seam is a potential fundamental finding. The
cross-subsystem plane is not a one-or-two-finding tail; it is a full stratum the size of the matrix of
subsystem seams. I probed three seams; two yielded a fundamental finding immediately. This is not
pessimism — the method is unchanged and works, and INT-05's path is narrow. What was underestimated is
the SIZE of the stratum, not the difficulty of any one finding.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "5d06cd1b85f8e3cfb52841b1c3750214cebafabcbd0d1183748a07ff182bd193"
  supersedes_archive_sha256: "9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3"
  verdict: PASS_CHECKER_V1_6_CROSS_SUBSYSTEM_THIRD_PASS
  blocking: false
  prior_findings_resolved: [INT-04]
  new_findings: [INT-05]
  probe_areas: [INT-C_delegation_vs_anchor_revocation]
  recommended_next:
    - "Fix INT-05: active_execution subset authorized (delegated for delegated agent, else anchor); with INT-01 gives active subset delegated subset anchor; canonicalize."
    - "Systematically enumerate all pairwise seams of the three mature subsystems; probe each with the adversarial lens."
    - "Defer viewport/nonce until the existing seam matrix is probed."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
