# Semantic Review Record — c-calculus-checker v1.5 (cross-subsystem layer, second fix pass)

**Record class:** b-layer semantic review record (advisory) — integration follow-up
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_5_INTEGRATION__b`
**Supersedes review:** `CCALC_CHECKER_v1_4_INTEGRATION__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_5_INTEGRATION__b
  record_version: "1.5-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_4_INTEGRATION__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.5 (cross-subsystem routing for held leases)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3"
    supersedes_archive_sha256: "db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: cross_subsystem_layer_second_pass
    meaning: >
      As a b-layer semantic reviewer I find INT-03 closed as a principle: routing is now a lifecycle/cascade
      visibility invariant applied under any cascade-capable lease state (expired OR held), verified by matrix.
      One new moderate finding (INT-04): the routing check uses enumerated cascade-capable states {expired,
      held} instead of fail-safe (any non-active lease state, including missing) — the enumerated-vs-fail-safe
      class that recurred throughout the track, now on the cross-subsystem layer. One probe area (S3, reverse
      containment). PASS is a verdict on a seed integration layer, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    INT-03_routing_only_in_expired_branch:
      status: RESOLVED_AS_PRINCIPLE
      evidence: "Routing lifted out of the expired branch into 'if lease_expired or lease_held' (line 62); routing is now a lifecycle/cascade visibility invariant, not an expired-only branch."
      empirical_proof: "expired + not routed -> NOT_IN_ACTIVE_EXECUTION; held valid + not routed -> NOT_IN_ACTIVE_EXECUTION; held valid + routed -> clean; held invalid + not routed -> NOT_IN_ACTIVE_EXECUTION."

  new_findings:
    INT-04_enumerated_cascade_capable_vs_fail_safe:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_class: enumerated_list_vs_fail_safe  # MINOR-2 / C-05 / D-06 lineage, now on cross-subsystem layer
      locus: ["validators.check_cross_subsystem_enforcement (routing gated on lease_expired or lease_held only)", "lease status whitelist {active, expired, reduced_authority, pending_anchor, held}"]
      issue: >
        The routing check uses an enumerated set of cascade-capable states {expired, held} instead of fail-safe
        (any non-active lease state with a valid lease, including missing). This is the enumerated-list-vs-fail-
        safe class that recurred throughout the track (MINOR-2 registry-drift, C-05 projection complete-by-
        current-list, D-06 empty-vs-missing). Two manifestations, both proven.
      empirical_proof: >
        S1: status=reduced_authority + not routed -> clean; status=pending_anchor + not routed -> clean;
        status=suspended + not routed -> clean. These are legitimate non-active states (authority degraded;
        awaiting anchor) that can transition to expiry; if a delegated surface under them is not routed and the
        state transitions to expiry, the cascade will not see it. S2: no lease + delegated (not in active) ->
        clean; delegated authority exists with no lease lifecycle at all, routing not checked (missing lease ->
        skip, the C-01 class on the cross-subsystem layer).
      recommended_path: >
        cascade-capable = fail-safe, not enumerated. Apply routing under ANY lease state except active-with-a-
        valid-unexpired-lease. Concretely: if not (lease present AND status==active AND not expired) -> require
        routing. Then reduced_authority, pending_anchor, unknown status, and missing lease all trigger routing
        (fail toward visibility). active with a valid lease is the only state where routing is not required.
        Complete-by-construction: not a list of cascade-capable states, but everything except the known-safe
        active.

  probe_area_not_a_finding:
    S3_reverse_containment:
      status: unconfirmed
      note: "Executing a surface not in delegation (executed write_memory, only read_logs delegated) is caught, but by expired-lease + read_logs-not-routed, not because write_memory is unauthorized. Routing checks delegated subset active (delegated visible to cascade), not active subset authorized (executed is authorized). The reverse invariant (executing surface must be authorized) is separate and may be covered by another subsystem check. Held as a probe: verify whether active execution of a surface outside delegation/authority is caught anywhere. Requires knowing where active-surface authorization lives; not confirmed here."

  lesson_transfer_meta:
    curve_still_converging: >
      The cross-subsystem curve keeps converging: INT-01 (fundamental, a c=a+b violation) -> INT-03 (branch
      asymmetry) -> INT-04 (enumerated vs fail-safe on lease states). Each is thinner than the last.
    old_class_on_new_layer: >
      INT-04 is not a new class but an old one on a new layer: enumerated-list vs fail-safe/complete-by-
      construction, the same one run through the whole text (MINOR-2 registry-drift, C-05 projection) and each
      time closed by inversion to fail-safe.
    recent_vs_old_transfer: >
      Cumulative transfer is real but not automatically complete: canonicalization transferred (C-08 -> v1.4
      at once), but enumerated-vs-fail-safe did not (INT-04 resurfaced). The difference is recency:
      canonicalization was fresh (closed just before delegation, v0.6-v0.7), while enumerated-vs-fail-safe is
      an old lesson (MINOR-2/C-05, many turns back) and did not transfer to the new layer on its own. The
      cumulative vocabulary transfers RECENT lessons more reliably than OLD ones — normal for any learning, the
      fresh is nearer to hand.
    practical_implication: >
      When opening a new stratum, deliberately run it against the WHOLE accumulated class vocabulary, including
      old classes (enumerated-vs-fail-safe, missing->skip, string-match), not only recent ones — otherwise old
      classes resurface, as INT-04 did.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3"
    verdict: PASS_CHECKER_V1_5_CROSS_SUBSYSTEM_SECOND_PASS
    blocking: false
    prior_findings_resolved: [INT-03]
    new_findings: [INT-04]
    probe_areas: [S3_reverse_containment, INT-C_delegation_vs_anchor_revocation]
    recommended_next:
      - "Fix INT-04: cascade-capable = fail-safe, not enumerated; routing under any non-(active-with-valid-lease) state, including missing lease."
      - "Add fixtures: reduced_authority / pending_anchor / missing lease + delegated surface not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION."
      - "Probe S3: where does active-surface authorization live (active subset authorized)?"
      - "When adding viewport/nonce subsystems, run the new cross-subsystem seams against the WHOLE class vocabulary, old classes included."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

INT-03 is closed as a principle: routing is lifted out of the expired branch into `if lease_expired
or lease_held` and is now a lifecycle/cascade visibility invariant applied under any cascade-capable
lease state (verified by matrix — expired and held, valid and invalid, routed and not routed, all
correct).

One new moderate finding (INT-04): the routing check uses an enumerated set of cascade-capable states
`{expired, held}` instead of fail-safe (any non-active lease state, including missing). This is the
enumerated-list-vs-fail-safe class that recurred throughout the track. Proven in two forms: legitimate
non-active states `reduced_authority` / `pending_anchor` do not trigger routing (S1), and a missing
lease under delegated surfaces skips routing entirely (S2). The fix is the same inversion that closed
every prior instance: cascade-capable = fail-safe, not enumerated.

One probe area (S3, reverse containment) is noted, unconfirmed.

PASS is a verdict on a seed integration layer — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of INT-03 (matrix):**
```
expired + not routed        -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
held valid + not routed      -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
held valid + routed          -> clean
held invalid + not routed    -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
```
**INT-04 (enumerated vs fail-safe):**
```
S1 status=reduced_authority + not routed -> clean (not treated cascade-capable)
S1 status=pending_anchor    + not routed -> clean
S1 status=suspended         + not routed -> clean
S2 no lease + delegated (not in active)  -> clean (no lease = no lifecycle check)
```
**S3 (probe):**
```
active write_memory, only read_logs delegated, expired -> DELEGATION_ACTIVE_UNDER_EXPIRED_LEASE + NOT_IN_ACTIVE_EXECUTION
  (caught via expired + read_logs-not-routed, not because write_memory is unauthorized)
```

---

## 4. New finding

### INT-04 (moderate, non-blocking, empirically proven) — enumerated cascade-capable states vs fail-safe

The routing check uses an enumerated set of cascade-capable states `{expired, held}` instead of
fail-safe (any non-active lease state with a valid lease, including missing). This is the
enumerated-list-vs-fail-safe class that recurred throughout the track (MINOR-2 registry-drift, C-05
projection complete-by-current-list, D-06 empty-vs-missing).

Two manifestations, both proven: **S1** — legitimate non-active states `reduced_authority` /
`pending_anchor` (in the lease status whitelist) do not trigger routing; both can transition to
expiry, and a delegated surface under them, if not routed, is invisible to the cascade when the state
transitions. **S2** — a missing lease under delegated surfaces skips routing entirely (the C-01
missing->skip class on the cross-subsystem layer); delegated authority exists with no lease lifecycle
at all.

**Path:** cascade-capable = fail-safe, not enumerated. Apply routing under any lease state except
`active`-with-a-valid-unexpired-lease: `if not (lease present AND status==active AND not expired) ->
require routing`. Then `reduced_authority`, `pending_anchor`, unknown status, and missing lease all
trigger routing (fail toward visibility); `active` with a valid lease is the only state where routing
is not required. Complete-by-construction: not a list of cascade-capable states, but everything except
the known-safe active.

---

## 5. Probe area

**S3 — reverse containment (unconfirmed).** Executing a surface not in delegation is caught, but by
expired-lease + the delegated surface not being routed, not because the executed surface is
unauthorized. Routing checks `delegated ⊆ active` (delegated visible to cascade), not `active ⊆
authorized` (executed is authorized). The reverse invariant is separate and may be covered by another
subsystem check. Held as a probe: verify whether active execution of a surface outside
delegation/authority is caught anywhere. Not confirmed here.

---

## 6. Lesson transfer (observation)

The cross-subsystem curve keeps converging: INT-01 (fundamental, a c=a+b violation) -> INT-03 (branch
asymmetry) -> INT-04 (enumerated vs fail-safe). Each is thinner than the last. And INT-04 is not a new
class but an old one on a new layer: enumerated-list vs fail-safe/complete-by-construction, the same
one run through the whole text and each time closed by inversion to fail-safe.

Cumulative transfer is real but not automatically complete: canonicalization transferred (C-08 -> v1.4
at once), but enumerated-vs-fail-safe did not (INT-04 resurfaced). The difference is recency —
canonicalization was fresh (v0.6-v0.7, just before delegation), while enumerated-vs-fail-safe is old
(MINOR-2/C-05, many turns back) and did not transfer to the new layer on its own. The cumulative
vocabulary transfers RECENT lessons more reliably than OLD ones — normal for any learning, the fresh
is nearer to hand.

Practical implication: when opening a new stratum, deliberately run it against the WHOLE accumulated
class vocabulary, including old classes (enumerated-vs-fail-safe, missing->skip, string-match), not
only recent ones — otherwise old classes resurface, as INT-04 did.

---

## 7. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3"
  supersedes_archive_sha256: "db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63"
  verdict: PASS_CHECKER_V1_5_CROSS_SUBSYSTEM_SECOND_PASS
  blocking: false
  prior_findings_resolved: [INT-03]
  new_findings: [INT-04]
  probe_areas: [S3_reverse_containment, INT-C_delegation_vs_anchor_revocation]
  recommended_next:
    - "Fix INT-04: cascade-capable = fail-safe, not enumerated; routing under any non-(active-with-valid-lease) state, including missing lease."
    - "Add fixtures: reduced_authority / pending_anchor / missing lease + delegated not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION."
    - "Probe S3: where does active-surface authorization live?"
    - "When adding viewport/nonce, run new cross-subsystem seams against the WHOLE class vocabulary, old classes included."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
