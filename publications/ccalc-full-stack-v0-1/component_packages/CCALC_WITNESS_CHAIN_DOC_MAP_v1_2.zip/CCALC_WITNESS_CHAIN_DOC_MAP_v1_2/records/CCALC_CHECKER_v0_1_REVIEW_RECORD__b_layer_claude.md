# Semantic Review Record — c-calculus-checker v0.1 (seed implementation)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_1_REVIEW__b`
**Relation:** first implementation artifact from `02_` §16.1; follows the `TGOPA 01_` (v0.1–v0.1.7) and `GBOP 02_` (v0.1–v0.1.5) text review chain

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_1_REVIEW__b
  record_version: "0.1"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]

  reviewed_artifact:
    title: "c-calculus-checker v0.1 (seed implementation)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516"
    core_loc: 557
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
      doc_01_v0_1_7_sha256: "d060ef513bf4bedcb7e88f43f8456452bc87f0c0409d5b4caeffc590ae22c29e"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: seed_implementation_v0_1
    meaning: >
      As a b-layer semantic reviewer I find the checker structurally sound and spec-conformant
      for honest input: all 18 invalid fixtures are rejected with correct error codes, the valid
      fixture passes. However, the checker does NOT hold adversarial input — it systematically
      skips checks on missing/renamed fields and trusts b-supplied projections and self-classification
      flags. This is the predicted text->code floor. PASS is a verdict on a seed implementation for
      fixture scope, NOT an authorization, NOT a certification, NOT a claim the checker enforces the
      spec against an adversarial substrate.
    blocking_findings: 0
    safety_escalations: 0
    fixture_tests: "18/18 invalid rejected with correct codes; valid passes"
    adversarial_input: fails_open

  empirical_proof:
    method: "Constructed adversarial inputs from invalid_context_causal_state_mismatch.json and ran run_all_checks."
    results:
      attack_1_declared_mismatch: "['CONTEXT_CAUSAL_STATE_MISMATCH'] (caught, baseline)"
      attack_2_omit_projection_hashes: "[] -> context binding BYPASSED (rendered_hash short-circuits 'and')"
      attack_3_omit_pre_state_projection: "[] -> whole causal check SKIPPED (early 'return findings')"
      attack_4_mislabel_signature_source: "[] -> emulation check keys on exact string 'model_output'"
    conclusion: "The checker fails open on missing/renamed fields — a b-layer tool trusting b's input."

  what_is_implemented_correctly:
    computed_not_trusted:
      - "validate_genesis_authorization: computes hash_object(review_object) and hash_object(binding_params), compares (F2-03 real)"
      - "check_review_binding_map: computes hash_object(source) and compares to declared (review=bound real)"
      - "check_context_causal_state_binding: computes hash_object(pre_state_projection) (F2-04 in substance)"
      - "check_authority_intersection: real set intersection a & b & g"
      - "compute_certificate_hash: without_keys avoids self-referential cycle"
    fail_safe_done_right:
      - "check_rendered_layer_registry: unclassified -> authority_bearing"
      - "check_anchor_state_compatibility: allowed.get(status, {'reject'}) -> unknown status rejects"
    note: "The author knows the fail-safe pattern (applied in two places); C-01 is inconsistency, not ignorance."

  findings:
    C-01_missing_field_skip_not_failsafe:
      severity: moderate_to_significant
      blocking: false
      empirically_proven: true
      locus: ["review_binding.check_context_causal_state_binding", "validators.check_anchor_signature_envelope", "validators.check_delegation_root"]
      issue: >
        The checker systematically skips checks when authority-bearing fields are absent, violating the
        operator meta-invariant (02_ §4.4: 'unknown or ambiguous is never silently treated as harmless').
        Proven by execution (attacks 2-4): omitting current_state_projection_hash / pre_state_projection, or
        renaming signature_source, bypasses the relevant check and yields no findings. A b-layer tool whose
        purpose is 'do not trust b' fails open on b-supplied absence. check_anchor_state_compatibility does
        fail-safe correctly, so this is an inconsistency against the document's own principle.
      recommended_path: >
        Every absent authority-bearing field for a privileged decision -> fail-safe finding, not skip.
        Privileged envelope without current_state_projection_hash -> CONTEXT_STATE_PROJECTION_MISSING | Hold;
        causal_token without pre_state_projection -> CAUSAL_PRE_STATE_MISSING | Hold; envelope signature_source
        not in an anchor-source whitelist -> ANCHOR_SIGNATURE_UNVERIFIED | Reject (membership, not equality to
        'model_output'); nonce without final_review_object_hash -> NONCE_NOT_FUSED | Reject. Replace
        'if field and ...' with 'if field_required and field_absent: fail-safe'.
    C-02_manifest_projection_trusts_b:
      severity: moderate
      blocking: false
      locus: ["registry.check_manifest_fact_registry"]
      issue: >
        Manifest authority-change detection compares b-supplied fact['authority_projection_before'] vs
        ['authority_projection_after'], directly violating 02_ v0.1.5 §1397 ('determined by deterministic
        authority-axis projection, not by b assertion'). A b that supplies before == after for an
        authority-changing drift passes. The checker trusts exactly what the spec forbade trusting.
      recommended_path: >
        Compute the authority projection from the manifest fact deterministically (same projection used at
        genesis) and compare computed before/after, rather than reading fixture-supplied values.
    C-03_self_accusing_flags:
      severity: minor_to_moderate
      blocking: false
      locus: ["registry.check_rendered_layer_registry (used_to_induce_authority)", "review_binding.check_viewport_atomicity (hidden_authority_material)"]
      issue: >
        used_to_induce_authority, hidden_authority_material, and contains_authority_bearing_material are
        b-supplied flags. A real adversarial b will not self-report. These checks catch only honest
        self-reporting input (the fixtures); they provide a false sense of coverage.
      recommended_path: >
        For v0.1 seed acceptable as placeholder, but mark explicitly (# FIXTURE-ONLY: requires semantic
        analysis, not b-flag). Real viewport check: diff the set of authority-bearing rendered layers against
        the set inside signature-covered units; divergence -> hidden.
    C-04_emitter_skips_preconditions:
      severity: minor
      blocking: false
      locus: ["genesis.emit_certificate"]
      issue: >
        emit_certificate takes status from fixture and calls only validate_genesis_authorization, not
        check_anchor_state_compatibility / check_delegation_root / check_lease_and_abort. As a standalone
        path (05_) it could issue an active certificate for a revoked anchor. Certificate emission is where
        preconditions must be enforced.
      recommended_path: "emit_certificate runs the full precondition set before building the certificate; any finding -> return {}, findings."

  minor_notes:
    - "check_review_binding_map: mismatch error code taken from b-supplied entry['mismatch_error']; checker should determine the code by layer type."
    - "canonical.py ensure_ascii=False: interop risk; another implementation with ensure_ascii=True yields different hashes for non-ASCII. Fix the canonical form normatively in the spec."
    - "check_operator_classification_registry hard-codes 8 required classifiers (complete-by-current-list); ironic for the meta-invariant checker, though new-classifier detection is static analysis of operator code, partly out of fixture-checker scope."

  text_to_code_assessment:
    predicted: "Across 14 text artifacts the reviewer stated the remaining floor is implementation, where 'fail safe toward authority' and 'review = bound' meet real ambiguous inputs the text cannot enumerate."
    confirmed: >
      The seed implementation passes fixtures (honest input) but leaks exactly where input is adversarial:
      missing-field skip (C-01, proven), trusting b projections (C-02), self-accusing flags (C-03). The text
      was right; the first code draft does not yet hold the principle against an adversarial substrate. This
      is not a failure of the text — text describes intent; the adversarial bypass lives in implementation,
      which is precisely why the move to code was necessary.
    self_application: "The checker enforces 'do not trust b / review = bound / fail safe toward authority' but does not apply those principles to its OWN input."

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516"
    verdict: PASS_CHECKER_V0_1_SEED
    blocking: false
    findings: [C-01, C-02, C-03, C-04]
    must_fix_before_real_input: [C-01, C-02]
    recommended_next:
      - "Add negative/omission fixtures (fields deleted, keys renamed) so 'missing -> Hold' is tested, not only 'present-and-wrong'."
      - "Fix C-01 and C-02 before the checker runs on any non-fixture (adversarial) input."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

The first implementation artifact, and it confirms the whole series' trajectory. The checker
is **structurally sound and spec-conformant for honest input**: 18/18 invalid fixtures rejected
with correct codes, valid passes. Several checks are done exactly right — by computation, not
trust: genesis-authorization hashing (F2-03), ReviewBindingMap source hashing (review=bound),
causal pre_state hashing (F2-04), real authority-set intersection, self-reference-free
certificate hashing. Two checks fail-safe correctly (`unclassified -> authority_bearing`;
`unknown anchor status -> reject`), which shows the author knows the pattern.

But the checker **does not hold adversarial input**, proven by execution: omitting
`current_state_projection_hash` or `pre_state_projection`, or renaming `signature_source`,
bypasses the relevant check and yields no findings (attacks 2–4). The tool whose purpose is
"do not trust b" fails open on b-supplied absence. This is the predicted text->code floor: the
text was right; the first code draft leaks exactly where input is adversarial.

PASS is a verdict on a **seed implementation for fixture scope** — not an authorization, not a
certification, and not a claim the checker enforces the spec against an adversarial substrate.
C-01 and C-02 are must-fix before the checker runs on any real (non-fixture) input, because
real input from `b` is adversarial.

---

## 3. Empirical proof of C-01 (executed, not asserted)

Adversarial inputs derived from `invalid_context_causal_state_mismatch.json`, run through
`run_all_checks`:

```
Attack 1 (declared mismatch)         -> ['CONTEXT_CAUSAL_STATE_MISMATCH']   (caught, baseline)
Attack 2 (omit projection hashes)    -> []   context binding BYPASSED
Attack 3 (omit pre_state_projection) -> []   whole causal check SKIPPED
Attack 4 (mislabel signature_source) -> []   emulation check keys on exact string
```

- Attack 2: `if rendered_hash and rendered_hash != computed` — absent `rendered_hash`
  short-circuits the `and`; the check is skipped.
- Attack 3: `if pre_state_projection is None: return findings` — empty list = PASS.
- Attack 4: `if envelope.get("signature_source") == "model_output"` — keyed on an exact
  string; absence or a renamed key passes.

The same pattern appears in `check_anchor_signature_envelope` (nonce fusion skipped when
`final_review_object_hash` absent) and `check_delegation_root` (root without `signature_source`
not flagged emulated).

---

## 4. Findings (detail)

### C-01 (moderate-to-significant, non-blocking, empirically proven) — missing field -> skip instead of fail-safe Hold

The operator meta-invariant (02_ §4.4) states "unknown or ambiguous is never silently treated
as harmless." The checker systematically violates this for **absent** fields (see §3). A
b-layer tool whose whole purpose is "do not trust b" fails open on b-supplied absence — the
checker does not apply its own enforced principle to its own input. `check_anchor_state_
compatibility` fails-safe correctly, so this is an inconsistency, not ignorance.

**Path:** every absent authority-bearing field for a privileged decision -> fail-safe finding,
not skip. Privileged envelope without `current_state_projection_hash` ->
`CONTEXT_STATE_PROJECTION_MISSING | Hold`; `causal_token` without `pre_state_projection` ->
`CAUSAL_PRE_STATE_MISSING | Hold`; `signature_source` not in an anchor-source whitelist ->
`ANCHOR_SIGNATURE_UNVERIFIED | Reject` (membership, not equality to `"model_output"`); nonce
without `final_review_object_hash` -> `NONCE_NOT_FUSED | Reject`. Replace `if field and ...`
with `if field_required and field_absent: fail-safe`.

### C-02 (moderate, non-blocking) — manifest authority projection trusts b-supplied values

`check_manifest_fact_registry` compares b-supplied `authority_projection_before` vs
`authority_projection_after`, violating 02_ v0.1.5 §1397 ("deterministic authority-axis
projection, not by b assertion"). A b supplying `before == after` for an authority-changing
drift passes.

**Path:** compute the authority projection from the manifest fact deterministically (same
projection used at genesis), compare computed values, rather than reading fixture-supplied ones.

### C-03 (minor-to-moderate, non-blocking) — self-accusing flags

`used_to_induce_authority`, `hidden_authority_material`, `contains_authority_bearing_material`
are b-supplied flags; a real adversarial b will not self-report. These catch only honest
self-reporting input.

**Path:** acceptable as a v0.1 placeholder, but mark explicitly (`# FIXTURE-ONLY: requires
semantic analysis`). Real viewport check: diff authority-bearing rendered layers against the set
inside signature-covered units.

### C-04 (minor, non-blocking) — emitter skips preconditions

`emit_certificate` calls only `validate_genesis_authorization`, not anchor-state / delegation /
lease checks, and could issue an active certificate for a revoked anchor as a standalone path.

**Path:** run the full precondition set before building the certificate; any finding ->
`return {}, findings`.

### Minor notes
- `check_review_binding_map` mismatch code taken from b-supplied `entry['mismatch_error']`.
- `canonical.py` `ensure_ascii=False` interop risk; fix the canonical form normatively.
- `check_operator_classification_registry` hard-codes 8 required classifiers (complete-by-current-list).

---

## 5. Text -> code (the culmination, an observation)

Across fourteen text artifacts I stated the remaining floor is implementation, where "fail safe
toward authority" and "review = bound" meet real ambiguous inputs the text cannot enumerate.
The seed implementation confirms it: it passes fixtures (honest input) but leaks exactly where
input is adversarial — missing-field skip (C-01, proven), trusting b projections (C-02),
self-accusing flags (C-03). The text was right; the first code draft does not yet hold the
principle against an adversarial substrate. This is not a failure of the text — text describes
intent; the adversarial bypass lives in implementation, which is precisely why the move to code
was necessary. The checker enforces "do not trust b" but does not apply that to its own input.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures implies enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516"
  implements_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
  verdict: PASS_CHECKER_V0_1_SEED
  blocking: false
  findings: [C-01, C-02, C-03, C-04]
  must_fix_before_real_input: [C-01, C-02]
  recommended_next:
    - "Add negative/omission fixtures (deleted fields, renamed keys) so 'missing -> Hold' is tested."
    - "Fix C-01 and C-02 before the checker runs on any non-fixture (adversarial) input."
    - "emit_certificate runs full preconditions (C-04); mark or replace self-accusing flag checks (C-03)."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
