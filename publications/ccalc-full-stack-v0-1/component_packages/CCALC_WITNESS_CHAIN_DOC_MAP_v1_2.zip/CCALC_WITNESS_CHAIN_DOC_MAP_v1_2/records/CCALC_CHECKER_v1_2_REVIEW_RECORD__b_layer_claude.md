# Semantic Review Record — c-calculus-checker v1.2 (lease subsystem, first adversarial pass)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_2_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v1_1_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_2_REVIEW__b
  record_version: "1.2"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_1_REVIEW__b
  subsystem_under_review: lease_expiry_cascade

  reviewed_artifact:
    title: "c-calculus-checker v1.2 (lease subsystem)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "1a8c27f4b7637e2cff9959c987d8842c4f9fc69c238744d2682a53b1b6dc0e0f"
    supersedes_archive_sha256: "4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: lease_first_adversarial_pass_clean
    meaning: >
      As a b-layer semantic reviewer I find v1.2 a sound and notably clean first adversarial pass on the lease
      subsystem: all prior single-field classes are transferred ahead (whitelists, computed hashes, fail-safe
      status, date expiry, no-b-renewal), and emergency hold does not mask cascade. One new moderate finding
      (L-01, composition/C-09 class): status='held' is decoupled from emergency-hold TTL discipline. Two policy
      angles (L5 unbounded lease, L3 missing active-surfaces) are noted, not findings. PASS is a verdict on a
      first-pass seed, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  lessons_transferred_ahead:
    note: "The lease first pass starts near-mature on single-field classes; the entire vocabulary from two prior subsystems is already applied."
    items:
      - "Whitelists for cascade trigger / safe-abort route / hold timer sources (C-01 membership)."
      - "hash_object(lease) binding for the cascade (C-02)."
      - "Missing lease status -> fail-safe expired (C-01)."
      - "Date expiry from expires_at_logical, unparseable -> fail-closed (D-04)."
      - "Emergency hold no-b-renewal and elapsed<=ttl (D-03 class)."
      - "Emergency hold does not mask cascade (verified L4: date-expired + valid hold still ACTIVE_EXECUTION_AFTER_LEASE_EXPIRY)."

  findings:
    L-01_held_status_decoupled_from_ttl:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_class: C-09_composition
      locus: ["validators._lease_status_and_expiry (status whitelist includes 'held')", "validators.check_lease_and_abort (emergency hold block only checked if present+active)"]
      issue: >
        Two mechanisms are unlinked: lease.status (whitelist includes 'held') and lease_expired_emergency_hold
        (TTL discipline, checked only if the block is present and active). status='held' semantically means the
        lease is held — a form of emergency hold — but TTL discipline applies only through the separate block,
        which 'held' status does not require. And status='held' yields expired=False, so the cascade is not
        required either. Result: lease.status='held' + active surfaces WITHOUT an emergency-hold block holds
        active execution indefinitely with no cascade, no absolute TTL, no witnessed timer — bypassing the
        emergency-hold mechanism via a status loophole.
      empirical_proof: >
        held WITHOUT hold block -> CLEAN; held WITH valid hold block -> TTL discipline applies
        (TIMER_UNVERIFIED); held WITH expired hold -> LEASE_EXPIRED_EMERGENCY_HOLD_EXPIRED. Date expiry still
        catches 'held' with a past expires_at (L2 -> LEASE_EXPIRED_BY_LOGICAL_TIME), so the hole is for 'held'
        without expires_at.
      recommended_path: >
        status='held' under active execution MUST require a valid lease_expired_emergency_hold block with full
        TTL discipline (positive TTL, witnessed timer, no b-renewal, elapsed<=ttl). Link the two mechanisms:
        status='held' -> hold discipline mandatory; otherwise fail-safe (LEASE_HELD_WITHOUT_TTL | Hold). 'held'
        must not be a way to hold a lease free of the constraints emergency hold imposes.

  advisory_notes_not_findings:
    L5_unbounded_lease:
      type: policy
      observation: "status='active' without expires_at_logical -> never expired (line 372 'if expires_at is not None')."
      not_a_spec_violation: "Like delegation P1; the spec requires TTL discipline at expiry, not a mandatory expiry."
      suggestion: "Consider a mandatory lease TTL."
    L3_missing_active_surfaces:
      type: acceptable
      observation: "expired lease + absent active_execution_surfaces -> cascade not required."
      why_acceptable: "No active surfaces = no execution = nothing to cascade. Here empty=no-execution is semantically correct, unlike delegation scope where empty=zero-permissions. Not a finding."

  cumulative_acceleration_meta:
    first_pass_comparison:
      authority_markup_v0_1: "C-01..C-04, four findings, foundational (missing->skip of whole classes, trust b-supplied)."
      delegation_v0_8: "D-01..D-05, five findings (multi-hop + C-01 on delegation fields + string-match)."
      lease_v1_2: "L-01, one composition finding + two policy angles."
    observation: >
      The curve accelerates BETWEEN subsystems, not only within. The third subsystem's first pass is cleaner
      than the second's because ever more lessons are carried ahead: by lease, whitelists, hash binding,
      fail-safe status, date expiry, and no-b-renewal are all pre-applied — a vocabulary accumulated over two
      subsystems. The one thing the vocabulary had not yet covered is composition between a status and a
      discipline (status='held' <-> hold TTL) — exactly the C-09 class, the thinnest, appearing when mechanisms
      interact rather than when a single field is handled.
    implication: >
      The method does not merely transfer — it accelerates cumulatively. Each subsystem adds lessons to a
      shared vocabulary and the next starts with more capital. Lease started near-mature on single-field
      classes and its first finding is at the thinnest level (composition). If this continues, the next
      subsystem (viewport, nonce, review-binding) may present only composition findings or policy angles on
      its first pass — starting where prior subsystems only arrived near the end.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "1a8c27f4b7637e2cff9959c987d8842c4f9fc69c238744d2682a53b1b6dc0e0f"
    verdict: PASS_CHECKER_V1_2_LEASE_FIRST_PASS
    blocking: false
    findings: [L-01]
    advisory_notes: [L5_unbounded_lease, L3_missing_active_surfaces]
    recommended_next:
      - "Fix L-01: link status='held' to mandatory emergency-hold TTL discipline; held without a valid hold block -> fail-safe."
      - "Add fixtures: status='held' active surface without hold block -> LEASE_HELD_WITHOUT_TTL; held with valid hold -> clean."
      - "Optional: L5 mandatory lease TTL policy-hardening."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

A sound and notably clean first adversarial pass on the lease subsystem. Every single-field class
from two prior subsystems is transferred ahead: whitelists for cascade trigger / safe-abort route /
hold timer sources, `hash_object(lease)` binding, missing status -> fail-safe expired, date expiry
from `expires_at_logical` (unparseable -> fail-closed), emergency-hold no-b-renewal and elapsed<=ttl.
Emergency hold does not mask the cascade (verified).

One new moderate finding (L-01, composition/C-09 class): `status='held'` is decoupled from the
emergency-hold TTL discipline. A held lease with active surfaces but no emergency-hold block holds
active execution indefinitely with no cascade, no absolute TTL, and no witnessed timer — proven by
contrast (held without a hold block is CLEAN; held with a hold block enforces TTL). The fix is to
require the emergency-hold discipline whenever `status='held'`.

Two policy angles are noted, not findings: an unbounded lease when expiry is absent (L5, like
delegation P1), and a missing active-surfaces set at expiry (L3, acceptable — no execution to
cascade).

PASS is a verdict on a first-pass seed — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**L-01 (status='held' decoupled from TTL) — by contrast:**
```
held WITHOUT hold block            -> CLEAN  (no TTL, no cascade, no witnessed timer)
held WITH valid hold block         -> TTL discipline applies (TIMER_UNVERIFIED)
held WITH expired hold             -> LEASE_EXPIRED_EMERGENCY_HOLD_EXPIRED
held + expires_at past (L2)        -> LEASE_EXPIRED_BY_LOGICAL_TIME  (date expiry still catches)
```
**Transferred lessons verified:**
```
L4 date-expired + valid hold       -> ACTIVE_EXECUTION_AFTER_LEASE_EXPIRY  (hold does not mask cascade)
L6 control valid cascade           -> clean (no AFTER_LEASE_EXPIRY)
full-suite regression              -> clean (delegation + authority-markup intact)
```
**Policy angles:**
```
L5 active, no expires_at           -> clean (unbounded lease, policy)
L3 expired, active_surfaces absent -> clean (no execution to cascade, acceptable)
```

---

## 4. Finding

### L-01 (moderate, non-blocking, empirically proven, composition/C-09 class) — status='held' decoupled from emergency-hold TTL discipline

Two mechanisms are unlinked: `lease.status` (whitelist includes `'held'`) and
`lease_expired_emergency_hold` (TTL discipline, checked only if the block is present and active).
`status='held'` semantically means the lease is held — a form of emergency hold — but TTL discipline
applies only through the separate block, which `'held'` status does not require; and `status='held'`
yields `expired=False`, so the cascade is not required either. Result: `lease.status='held'` + active
surfaces without an emergency-hold block holds active execution indefinitely with no cascade, no
absolute TTL, no witnessed timer — bypassing the emergency-hold mechanism via a status loophole
(proven by contrast; date expiry still catches a `'held'` lease with a past `expires_at`).

**Path:** `status='held'` under active execution MUST require a valid `lease_expired_emergency_hold`
block with full TTL discipline (positive TTL, witnessed timer, no b-renewal, elapsed<=ttl). Link the
two mechanisms: `status='held'` -> hold discipline mandatory; otherwise fail-safe
(`LEASE_HELD_WITHOUT_TTL | Hold`). `'held'` must not be a way to hold a lease free of the constraints
emergency hold imposes.

---

## 5. Advisory notes (policy/acceptable, NOT findings)

- **L5 — unbounded lease (policy):** `status='active'` without `expires_at_logical` is never expired.
  Like delegation P1; not a spec violation (the spec requires TTL discipline at expiry, not a
  mandatory expiry). Suggestion: consider a mandatory lease TTL.
- **L3 — missing active-surfaces (acceptable):** expired lease + absent `active_execution_surfaces` ->
  cascade not required. No active surfaces = no execution = nothing to cascade. Here empty=no-execution
  is semantically correct (unlike delegation scope where empty=zero-permissions). Not a finding.

---

## 6. Cumulative acceleration (observation)

First-pass comparison:
- **authority-markup** (v0.1): C-01..C-04, four findings, foundational;
- **delegation** (v0.8): D-01..D-05, five findings;
- **lease** (v1.2): L-01, one composition finding + two policy angles.

The curve accelerates **between** subsystems, not only within. The third subsystem's first pass is
cleaner because ever more lessons are carried ahead: by lease, whitelists, hash binding, fail-safe
status, date expiry, and no-b-renewal are all pre-applied — a vocabulary accumulated over two
subsystems. The one thing not yet covered is composition between a status and a discipline
(`status='held'` <-> hold TTL) — exactly the C-09 class, the thinnest, appearing when mechanisms
interact rather than when a single field is handled.

The method does not merely transfer — it accelerates cumulatively. Each subsystem adds lessons to a
shared vocabulary and the next starts with more capital. If this continues, the next subsystem may
present only composition findings or policy angles on its first pass — starting where prior
subsystems only arrived near the end. One fix (link status='held' to hold discipline) and lease is
close to maturity in one or two turns, faster than delegation (four) and far faster than
authority-markup (seven).

---

## 7. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "1a8c27f4b7637e2cff9959c987d8842c4f9fc69c238744d2682a53b1b6dc0e0f"
  supersedes_archive_sha256: "4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9"
  verdict: PASS_CHECKER_V1_2_LEASE_FIRST_PASS
  blocking: false
  findings: [L-01]
  advisory_notes: [L5_unbounded_lease, L3_missing_active_surfaces]
  recommended_next:
    - "Fix L-01: link status='held' to mandatory emergency-hold TTL discipline; held without a valid hold block -> fail-safe."
    - "Add fixtures: status='held' active surface without hold block -> LEASE_HELD_WITHOUT_TTL; held with valid hold -> clean."
    - "Optional: L5 mandatory lease TTL policy-hardening."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
