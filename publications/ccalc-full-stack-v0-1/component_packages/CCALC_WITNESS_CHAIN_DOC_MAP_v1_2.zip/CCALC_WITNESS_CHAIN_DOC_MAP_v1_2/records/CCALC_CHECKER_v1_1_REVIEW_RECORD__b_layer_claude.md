# Semantic Review Record — c-calculus-checker v1.1 (delegation subsystem, maturity pass)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_1_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v1_0_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_1_REVIEW__b
  record_version: "1.1"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_0_REVIEW__b
  subsystem_under_review: delegation_chains

  reviewed_artifact:
    title: "c-calculus-checker v1.1 (delegation subsystem, maturity pass)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9"
    supersedes_archive_sha256: "46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: delegation_adversarial_maturity_reached
    meaning: >
      As a b-layer semantic reviewer I find D-07 closed: a missing scope is carried downstream as conservative
      zero, making missing/empty/non-empty consistent downstream, proven by execution, with no authority-markup
      regression. No new security finding this round. The delegation subsystem has reached adversarial maturity,
      parallel to authority-markup at v0.7. Two advisory policy/hygiene angles (P1 unbounded delegation, P2
      cycle) are noted but violate no invariant and are NOT findings. PASS is a verdict on a hardened seed,
      NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0
    new_security_findings: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    D-07_missing_scope_downstream:
      status: RESOLVED
      evidence: "previous_allowed = link_allowed if link_allowed is not None else set() (line 287); root analogously (line 227). Missing scope emits SCOPE_MISSING and carries conservative zero downstream."
      empirical_proof: "missing mid-hop + hop3 restores wide -> CHAIN_SCOPE_WIDENED; missing root + hop grants -> WIDENED from zero; empty mid (E1) -> WIDENED; E3 non-empty control -> WIDENED. Missing and empty now consistent downstream."
    no_authority_markup_regression:
      status: VERIFIED
      evidence: "floor (roles declared ephemeral) -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED; full suite PASS."

  new_security_findings: []

  advisory_notes_not_findings:
    reasoning: "Built thin angles along the converging trajectory; both violate no delegation invariant (scope monotonicity, identity binding, root non-emulability, fail-closed lifecycle). Named honestly as policy/hygiene, not inflated into findings."
    P1_unbounded_delegation:
      type: policy
      observation: "if expires_at is not None (line 132): a delegation with no expires_at_logical is not expiry-checked, so an unbounded delegation is allowed."
      not_a_spec_violation: "The spec says 'expired delegation fails closed' but does not require expiry to be mandatory; absence of expiry is a valid unbounded delegation by design."
      suggestion: "Consider whether delegations should require a mandatory expiry (least-privilege includes a time bound); this is an anchor/policy decision, not a checker defect."
    P2_cycle_in_chain:
      type: hygiene
      observation: "cycle A->B->A is not detected; delegator_id_hash binds each hop to the previous but does not track identity reuse."
      harm_contained_by_monotonicity: "Each hop narrows scope, so a cycle grants no escalation (the final delegate has a narrowed scope, not a widened one). Within what the checker verifies, this is not an exploit."
      suggestion: "Consider forbidding cycles / identity reuse for clarity (may cause identity confusion in downstream logic outside the checker); not a security hole."

  delegation_theme_complete:
    turns: "v0.8 -> v1.1, four turns, findings D-01..D-07."
    arc:
      D-01: "multi-hop unsupported -> chain iteration with monotone narrowing"
      D-02_D-03_D-04: "C-01 request/identity/expiry missing->skip -> fail-safe"
      D-05: "C-06 scope string-match -> canonicalization"
      D-06: "empty scope as no-constraint -> three-state distinction"
      D-07: "missing scope downstream None -> conservative zero downstream"
    vs_authority_markup: "authority-markup took seven turns (v0.1->v0.7, C-01..C-09); delegation took four, because the classes were known and foundational lessons (whitelist, computed hashes) were transferred ahead of time."

  convergence_and_scalability_meta:
    convergence_confirmed: >
      The finding thickness converged: D-01 a whole unsupported structure (multi-hop); D-06 widening for an
      empty scope; D-07 downstream widening for a missing intermediate hop; P1/P2 no longer security holes but
      policy/hygiene angles violating no invariant. Each turn thinner, more specific, and the last turn passed
      out of security findings into policy. This is the signature of reached maturity: not 'no bugs' in the
      absolute, but 'the adversarial pass stopped finding invariant violations; only policy choices remain'.
    scalability_demonstrated: >
      The method proved scalable across two subsystems. Authority-markup learned the classes from scratch
      (seven turns). Delegation applied them ahead (four turns, the last already policy). The class vocabulary
      (missing->skip -> fail-safe, empty != missing, string -> typed, single -> multi-hop, composition-recheck)
      transfers, and each subsequent subsystem is shorter.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9"
    verdict: PASS_CHECKER_V1_1_DELEGATION_MATURE
    blocking: false
    prior_findings_resolved: [D-07]
    new_security_findings: []
    advisory_notes: [P1_unbounded_delegation, P2_cycle]
    reviewer_recommendation: >
      (2) next subsystem (lease cascade, viewport, review-binding, nonce), each faster than the last; keep (1)
      P1/P2 policy-hardening as an optional tail if delegation must be production-grade; do (3) integration once
      >=3 subsystems are mature (only one seam exists now, authority x delegation, and it is already clean).
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

D-07 is closed: a missing scope is carried downstream as conservative zero, so missing, empty, and
non-empty scopes are now consistent downstream — verified by execution (missing mid-hop and missing
root both trigger `DELEGATION_CHAIN_SCOPE_WIDENED` from zero, alongside the empty and non-empty
controls). There is no authority-markup regression.

No new security finding this round. The delegation subsystem has reached adversarial maturity,
parallel to authority-markup at v0.7. I built thin angles along the converging trajectory; the two
that surfaced — an unbounded delegation when expiry is absent (P1), and an undetected cycle (P2) —
violate no delegation invariant and are noted honestly as policy/hygiene, not inflated into findings.
P1 is not a spec violation (the spec does not require mandatory expiry); P2's harm is contained by
scope monotonicity (a cycle grants no escalation).

PASS is a verdict on a hardened seed — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of D-07 (missing/empty consistent downstream):**
```
missing mid-hop, hop3 restores wide      -> DELEGATION_CHAIN_SCOPE_WIDENED
missing root scope, hop grants           -> DELEGATION_CHAIN_SCOPE_WIDENED (from zero)
empty mid-hop (E1)                        -> DELEGATION_CHAIN_SCOPE_WIDENED
E3 control non-empty narrowing           -> DELEGATION_CHAIN_SCOPE_WIDENED
```
**No authority-markup regression:**
```
floor (roles declared ephemeral)         -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
full suite                               -> PASS
```
**Thin-angle probes (advisory, not findings):**
```
P1 no expiry field                       -> no expiry check (unbounded delegation allowed; not a spec violation)
P2 cycle A->B->A                         -> no cycle detection (harm contained by scope monotonicity)
```

---

## 4. Advisory notes (policy/hygiene, NOT security findings)

Both angles violate no delegation invariant (scope monotonicity, identity binding, root
non-emulability, fail-closed lifecycle). They are named as policy/hygiene, not inflated into
findings.

### P1 — unbounded delegation when expiry is absent (policy)

`if expires_at is not None` (line 132): a delegation with no `expires_at_logical` is not
expiry-checked, so an unbounded delegation is allowed. This is **not** a spec violation — the spec
says "expired delegation fails closed" but does not require expiry to be mandatory; absence of
expiry is a valid unbounded delegation by design. **Suggestion:** consider whether delegations
should require a mandatory expiry (least-privilege includes a time bound); an anchor/policy decision,
not a checker defect.

### P2 — cycle in chain not detected (hygiene)

A cycle `A->B->A` is not detected; `delegator_id_hash` binds each hop to the previous but does not
track identity reuse. **Harm is contained by monotonicity:** each hop narrows scope, so a cycle
grants no escalation (the final delegate has a narrowed scope, not a widened one). Within what the
checker verifies, this is not an exploit. **Suggestion:** consider forbidding cycles / identity reuse
for clarity (possible identity confusion in downstream logic outside the checker); not a security
hole.

---

## 5. Delegation theme complete, and convergence confirmed

Delegation ran four turns (v0.8 -> v1.1, findings D-01..D-07):
- **D-01** multi-hop unsupported -> chain iteration with monotone narrowing;
- **D-02/D-03/D-04** C-01 request/identity/expiry missing->skip -> fail-safe;
- **D-05** C-06 scope string-match -> canonicalization;
- **D-06** empty scope as no-constraint -> three-state distinction;
- **D-07** missing scope downstream None -> conservative zero downstream.

Authority-markup took seven turns (v0.1 -> v0.7, C-01..C-09); delegation took four, because the
classes were known and foundational lessons (whitelist, computed hashes) were transferred ahead.

The finding thickness **converged**: D-01 a whole unsupported structure; D-06 widening for an empty
scope; D-07 downstream widening for a missing intermediate hop; P1/P2 no longer security holes but
policy/hygiene angles violating no invariant. Each turn thinner, more specific, and the last turn
passed out of security findings into policy. This is the signature of reached maturity: not "no bugs"
in the absolute, but "the adversarial pass stopped finding invariant violations; only policy choices
remain".

The method proved **scalable** across two subsystems. Authority-markup learned the classes from
scratch; delegation applied them ahead and finished in fewer turns, the last already policy. The
class vocabulary transfers, and each subsequent subsystem is shorter.

**Recommendation:** (2) next subsystem (lease cascade, viewport, review-binding, nonce), each faster
than the last; keep (1) P1/P2 policy-hardening as an optional tail if delegation must be
production-grade; do (3) integration once >=3 subsystems are mature (only one seam exists now,
authority x delegation, already clean).

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9"
  supersedes_archive_sha256: "46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae"
  verdict: PASS_CHECKER_V1_1_DELEGATION_MATURE
  blocking: false
  prior_findings_resolved: [D-07]
  new_security_findings: []
  advisory_notes: [P1_unbounded_delegation, P2_cycle]
  reviewer_recommendation:
    - "Next subsystem (lease cascade, viewport, review-binding, nonce); each faster than the last."
    - "Optional tail: P1/P2 policy-hardening if delegation must be production-grade."
    - "Integration once >=3 subsystems mature; the one existing seam (authority x delegation) is already clean."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
