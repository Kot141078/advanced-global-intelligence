# Semantic Review Record — c-calculus-checker v0.7

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_7_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_6_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_7_REVIEW__b
  record_version: "0.7"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_6_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.7"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16"
    supersedes_archive_sha256: "1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: authority_markup_theme_complete
    meaning: >
      As a b-layer semantic reviewer I find C-09 fully closed: the §1385 floor is evaluated on
      default-canonical semantics that no schema alias, case/plural variant, or alias chain can move, proven
      across six-plus attack vectors. No new substantive finding this round; the residual is the terminal-a
      boundary (an unmapped synonym). The authority-markup theme (manifest/ephemeral/floor/identity) is
      complete at the formalizable level. PASS is a verdict on a hardened seed implementation, NOT an
      authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0
    new_substantive_findings: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    C-09_schema_alias_redirects_core_axis:
      status: RESOLVED_FULLY
      evidence: >
        _default_axis_name computes unmovable default canonical identity (no schema); _canonical_axis_name
        computes full schema-aware identity; the floor protects a key if EITHER path reaches
        KNOWN_AUTHORITY_AXES; a schema alias whose source default-canonicalizes to a core axis ->
        AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS.
      empirical_proof: >
        A6 roles->pod_id -> AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED;
        A7 roles->harmless -> caught; B1 Roles->pod_id (case variant source) -> caught; B2 role->pod_id
        (singular source) -> caught; B3 chain roles->interim->pod_id -> caught; B4 synonym+redirect -> caught;
        A8 my_perms->roles (synonym->core) preserved; B6 reverse pod_id->roles -> consistent (anchor-decision).

  no_new_finding_reasoning:
    method: "Built every adversarial vector I could: direct redirect, case/plural variant source, alias chain, combo, reverse."
    all_caught: [A6, A7, B1, B2, B3, B4, B6]
    terminal_a_boundary: >
      B5 (net_auth abbreviation declared ephemeral, no schema) slips, same as A2: an unmapped synonym requires
      an anchor declaration; the checker cannot know net_auth == network_authority without it. This is §16.3,
      not a defect.
    conclusion: "No new substantive finding. The floor is unmovable by any resolution mechanism; the only residual is the terminal-a boundary."

  authority_markup_theme_complete:
    four_questions_plus_junction:
      who_decides_ephemeral: "loop to anchor (C-06/v0.4): ephemeral sourced from anchor-authorized GovernanceProfile, coverage by hash."
      what_is_non_overridable: "constitutional floor (C-07/v0.5): core §1385 axes not downgradable even anchor-signed."
      how_axis_identified: "typed identity (C-08/v0.6): canonicalization for variants + anchor-authorized schema for synonyms."
      resolution_respects_floor: "floor by semantics (C-09/v0.7): identity resolution cannot pierce the constitutional floor."
    single_truth: >
      Authority relevance is decided by a, not b; by types and signatures, not strings and hardcoding; and the
      core authority floor is non-overridable by any path, including mechanisms added for other purposes. This
      is c = a + b as a property of working code, verifiable by execution.

  next_frontier_recommendation:
    context: "The checker has taken ONE subsystem of spec 02_ (manifest/authority/ephemeral/floor) to adversarial maturity."
    other_subsystems_untested_at_depth:
      - "delegation chains (§5.4A)"
      - "lease expiry cascade (§7.2)"
      - "viewport atomicity (§5.6)"
      - "review binding map drift (§5.6A)"
      - "nonce fusion (§5.3A)"
      - "operator classification registry (§4.4)"
    options:
      - "(1) Apply the same adversarial discipline to the other subsystems; likely their own C-01 (missing->skip), C-06 (string-match), C-09 (composition)."
      - "(2) Return to 03_ (downstream of operator binding), not yet written."
      - "(3) Integration testing (end-to-end, not unit fixtures) to find the seams between subsystems, where the subtlest findings live (as C-09 showed)."
    reviewer_recommendation: >
      (1) then (3): bring the remaining subsystems to the same adversarial maturity as authority-markup, then
      test their seams by integration. 03_ text waits until 02_ is execution-verified WHOLE, not one subsystem.
      The trek proved the floor is in execution, not text; the same principle says do not write 03_ text until
      02_ holds ground in code entirely.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16"
    verdict: PASS_CHECKER_V0_7
    blocking: false
    prior_findings_resolved: [C-09]
    new_findings: []
    theme_status: authority_markup_complete_at_formalizable_level
    reviewer_recommendation: "Extend adversarial discipline to other 02_ subsystems (delegation, lease, viewport, review-binding, nonce, classification), then integration-test the seams."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

C-09 is fully closed. The §1385 floor is now evaluated on default-canonical semantics that no
schema alias, case/plural variant, or alias chain can move: a key is protected if it is a core
axis by **either** the unmovable default path or the full schema-aware path, and a schema alias
whose source default-canonicalizes to a core axis is rejected. Verified across six-plus attack
vectors — direct redirect (A6/A7), case-variant source (B1), singular source (B2), alias chain
(B3), combo (B4), reverse (B6) — all caught; the synonym->core alias (A8) is preserved.

**No new substantive finding this round.** This is not for lack of searching: I built every
adversarial vector I could, and all are caught except the terminal-`a` boundary (B5/A2: an
unmapped synonym requires an anchor declaration). The authority-markup theme — manifest,
ephemeral, floor, identity — is complete at the formalizable level.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

```
A6 alias roles->pod_id                 -> AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
A7 alias roles->harmless_telemetry     -> caught
A8 my_perms->roles (synonym->core)     -> preserved (EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + ...)
B1 Roles->pod_id (case variant source) -> caught
B2 role->pod_id (singular source)      -> caught
B3 chain roles->interim->pod_id        -> caught
B4 user_roles->roles + roles->pod_id   -> caught
B6 reverse pod_id->roles               -> consistent (anchor-decision, conflict caught)
B5 net_auth ephemeral, no schema       -> slips (terminal-a boundary, same as A2; not a defect)
```

---

## 4. The authority-markup theme, complete

Over seven checker versions the theme closed across four questions plus their junction, all in code:
- **who decides what is ephemeral** -> loop to anchor (C-06/v0.4);
- **what is non-overridable** -> constitutional floor (C-07/v0.5);
- **how an axis is identified** -> typed identity (C-08/v0.6);
- **resolution respects the floor** -> floor by semantics (C-09/v0.7).

Under all of it, one truth the trek proved across twenty-one artifacts: authority relevance is
decided by `a`, not `b`; by types and signatures, not strings and hardcoding; and the core
authority floor is non-overridable by any path, including mechanisms added for other purposes.
This is `c = a + b` as a property of working code, verifiable by execution rather than a slogan
in prose.

---

## 5. Next frontier (recommendation, not a finding)

The checker has taken **one** subsystem of spec 02_ (manifest/authority/ephemeral/floor) to
adversarial maturity. Other subsystems have not had the same depth of adversarial testing:
delegation chains (§5.4A), lease expiry cascade (§7.2), viewport atomicity (§5.6), review binding
map drift (§5.6A), nonce fusion (§5.3A), operator classification registry (§4.4). Each is a likely
home for its own C-01 (missing->skip), C-06 (string-match), or C-09 (composition).

Recommendation: **(1) then (3)** — bring the remaining subsystems to the same adversarial maturity
as authority-markup, then integration-test their seams (where the subtlest findings live, as C-09
showed). 03_ text waits until 02_ is execution-verified **whole**, not one subsystem. The trek
proved the floor is in execution, not text; the same principle says do not write 03_ text until
02_ holds ground in code entirely.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16"
  supersedes_archive_sha256: "1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc"
  verdict: PASS_CHECKER_V0_7
  blocking: false
  prior_findings_resolved: [C-09]
  new_findings: []
  theme_status: authority_markup_complete_at_formalizable_level
  reviewer_recommendation:
    - "Extend adversarial discipline to other 02_ subsystems (delegation, lease, viewport, review-binding, nonce, classification)."
    - "Then integration-test the seams between subsystems."
    - "Defer 03_ text until 02_ is execution-verified whole."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
