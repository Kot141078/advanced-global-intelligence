# Semantic Review Record — c-calculus-checker v1.4 (cross-subsystem layer, first fix pass)

**Record class:** b-layer semantic review record (advisory) — integration follow-up
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_4_INTEGRATION__b`
**Supersedes review:** `CCALC_CHECKER_v1_3_INTEGRATION__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_4_INTEGRATION__b
  record_version: "1.4-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_3_INTEGRATION__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.4 (cross-subsystem enforcement layer)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63"
    supersedes_archive_sha256: "474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: cross_subsystem_layer_first_pass
    meaning: >
      As a b-layer semantic reviewer I find v1.4 a sound first cross-subsystem enforcement layer. INT-01 is
      closed as a principle (delegation containment on every scope root+hop) with C-08 canonicalization
      transferred ahead to the new layer, and INT-02 is closed for the expired-lease branch. One new moderate
      finding (INT-03): the routing check lives only in the expired branch, so delegated surfaces under a held
      lease (valid or invalid) are not routing-checked. INT-C remains a probe, correctly deferred until anchor
      revocation is canonicalized. PASS is a verdict on a seed integration layer, NOT an authorization, NOT a
      certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    INT-01_delegation_exceeds_anchor:
      status: RESOLVED_AS_PRINCIPLE
      evidence: "check_cross_subsystem_enforcement reads delegation_chain + authority.anchor_surfaces together; iterates all scopes (root + hop links) via _delegation_scopes_with_paths; emits DELEGATION_EXCEEDS_ANCHOR_AUTHORITY on allowed - anchor_surfaces. _surface_set canonicalizes (C-08 lesson transferred to the new layer)."
      empirical_proof: "exceeds (write_memory) -> EXCEEDS; outside lattice -> EXCEEDS; multi-hop link exceeds (root ok, hop grants write_memory) -> EXCEEDS; anchor write_memory + deleg Write_Memory -> clean (canonicalized, no false EXCEEDS); anchor read_logs + deleg Read_Logs -> clean."
    INT-02_delegation_lifecycle:
      status: RESOLVED_FOR_EXPIRED_BRANCH
      evidence: "expired lease + delegated surfaces -> DELEGATION_ACTIVE_UNDER_EXPIRED_LEASE; not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION."
      residual: "The held branch is incomplete on routing; see INT-03."

  new_findings:
    INT-03_routing_only_in_expired_branch:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_pattern: "new mechanism carries its own edge; branch asymmetry"
      locus: ["validators.check_cross_subsystem_enforcement (routing check nested inside the expired branch, lines 637-654; held branch 655-662 checks TTL only)"]
      issue: >
        The routing check (delegated surfaces subset active_execution_surfaces) lives only in the expired-lease
        branch. Under a held lease it is not applied: held-without-valid-hold checks only TTL, and under a VALID
        held lease the held branch does not fire at all (elif _lease_held_without_valid_hold is False), so a
        delegated surface under a valid-held lease is entirely invisible and outlives the hold's expiry with no
        flag. A held lease is a lifecycle state with a TTL; when it expires the cascade fires, so delegated
        surfaces must be routed under held as under expired.
      empirical_proof: >
        expired + not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION; held w/o valid hold + not routed ->
        only HELD_WITHOUT_TTL (no routing); held WITH valid hold + not routed -> CLEAN (held branch never fires,
        routing never checked).
      recommended_path: >
        Apply the routing check under ANY lease lifecycle state from which a cascade can fire (expired OR held),
        not only expired. Lift routing out of the expired branch into a check parallel to the lifecycle check:
        if there are delegated surfaces and the lease is in a cascade-capable state, verify routing.

  probe_area_still_open:
    INT-C_delegation_vs_anchor_revocation:
      status: correctly_deferred
      note: "Changelog states anchor revocation encoding is not yet canonicalized for integration. This is the right call: do not build a cross-check on an unfixed model. INT-C waits until anchor revocation has a canonical fixture form, then it can be probed empirically (does a revoked anchor annul active delegation). Do not fabricate a field."

  cumulative_curve_on_new_stratum_meta:
    stratum: "The cross-subsystem enforcement layer is a new dimension of work opened by integration."
    inherits_vocabulary: >
      The layer behaves like a subsystem on the cumulative curve: it inherits the accumulated vocabulary.
      INT-01 was closed not only correctly but WITH canonicalization applied ahead of time (the C-08 lesson,
      transferred to the cross-subsystem level without prompting). The layer's first shortfall (INT-03) is not
      crude (not string-match, not missing->skip of whole fields) but thin (branch asymmetry) — just as lease
      started near-mature on single-field classes and its first finding was composition.
    converging_within_stratum: >
      The same converging dynamic holds within the new stratum: the first finding was fundamental (INT-01, a
      c=a+b violation), the second is thinner (INT-03, branch asymmetry). Encouraging for the route: the
      cross-subsystem stratum, though it opened a fundamental class, is not unbounded and obeys the same curve.
    two_dimensional_picture: >
      The picture is now two-dimensional: subsystem hardening (curve 7->4->2, mature) and cross-subsystem
      enforcement (new stratum, INT-01 fundamental -> INT-03 thinner, inherits the vocabulary). Both obey one
      method (adversarial vectors against invariants, empirical checking) and one dynamic (converging curve,
      cumulative transfer of lessons).

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63"
    verdict: PASS_CHECKER_V1_4_CROSS_SUBSYSTEM_FIRST_PASS
    blocking: false
    prior_findings_resolved: [INT-01, INT-02_expired_branch]
    new_findings: [INT-03]
    probe_areas: [INT-C_delegation_vs_anchor_revocation]
    recommended_next:
      - "Fix INT-03: lift the routing check out of the expired branch; apply it under any cascade-capable lease state (expired OR held)."
      - "Add fixtures: held lease + delegated surface not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION; valid-held + routed -> clean."
      - "Canonicalize anchor revocation, then probe INT-C empirically."
      - "As viewport/nonce/review-binding subsystems are added, each gets two fronts: subsystem hardening and cross-subsystem seams with the mature subsystems."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

A sound first cross-subsystem enforcement layer. INT-01 is closed as a principle:
`check_cross_subsystem_enforcement` reads the delegation chain and `authority.anchor_surfaces`
together, iterates every scope (root and hop links), and emits `DELEGATION_EXCEEDS_ANCHOR_AUTHORITY`
on any surface outside anchor authority — and `_surface_set` canonicalizes, so the C-08 string-match
lesson is transferred ahead to the new layer (no false EXCEEDS on a case variant). INT-02 is closed
for the expired-lease branch (lifecycle + routing).

One new moderate finding (INT-03): the routing check lives only in the expired branch, so a delegated
surface under a held lease is not routing-checked — and under a *valid* held lease the held branch
does not fire at all, leaving the surface entirely invisible and able to outlive the hold's expiry
with no flag. The fix is to apply routing under any cascade-capable lease state, not only expired.

INT-C remains a probe, correctly deferred: the changelog states anchor revocation is not yet
canonicalized for integration, which is the right call — do not build a cross-check on an unfixed
model.

PASS is a verdict on a seed integration layer — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of INT-01 (principle + C-08 canonicalization transferred):**
```
exceeds (write_memory, anchor=read_logs)                 -> DELEGATION_EXCEEDS_ANCHOR_AUTHORITY
outside lattice (root_shell_unlisted)                    -> DELEGATION_EXCEEDS_ANCHOR_AUTHORITY
multi-hop link exceeds (root ok, hop grants write_memory) -> DELEGATION_EXCEEDS_ANCHOR_AUTHORITY
anchor write_memory + deleg Write_Memory                 -> clean (canonicalized)
anchor read_logs + deleg Read_Logs                       -> clean
```
**Closure of INT-02 (expired branch):**
```
expired + delegated surface              -> DELEGATION_ACTIVE_UNDER_EXPIRED_LEASE
expired + not routed                     -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
```
**INT-03 (routing only in expired branch):**
```
held w/o valid hold + not routed         -> only HELD_WITHOUT_TTL (no routing)
held WITH valid hold + not routed        -> CLEAN (held branch never fires; surface invisible to cascade)
expired + not routed (contrast)          -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION
```

---

## 4. New finding

### INT-03 (moderate, non-blocking, empirically proven) — routing check lives only in the expired branch

The routing check (delegated surfaces subset `active_execution_surfaces`) lives only in the
expired-lease branch. Under a held lease it is not applied: held-without-valid-hold checks only TTL,
and under a valid held lease the held branch does not fire at all, so a delegated surface under a
valid-held lease is entirely invisible and outlives the hold's expiry with no flag. A held lease is a
lifecycle state with a TTL; when it expires the cascade fires, so delegated surfaces must be routed
under held as under expired.

**Path:** apply the routing check under any lease lifecycle state from which a cascade can fire
(expired OR held), not only expired. Lift routing out of the expired branch into a check parallel to
the lifecycle check: if there are delegated surfaces and the lease is in a cascade-capable state,
verify routing.

This is the same pattern as the whole series — a new mechanism (the cross-subsystem layer) carries
its own edge (branch asymmetry) — and it is thinner than INT-01: INT-01 was a c=a+b violation, INT-03
is a branch asymmetry. The converging curve holds within the new stratum.

---

## 5. Probe area still open

**INT-C — delegation vs anchor revocation (correctly deferred).** The changelog states anchor
revocation encoding is not yet canonicalized for integration. This is the right call: do not build a
cross-check on an unfixed model. INT-C waits until anchor revocation has a canonical fixture form,
then it can be probed empirically (does a revoked anchor annul active delegation). Do not fabricate a
field.

---

## 6. Cumulative curve on a new stratum (observation)

The cross-subsystem enforcement layer is a new dimension opened by integration, and it behaves like a
subsystem on the cumulative curve: it **inherits the accumulated vocabulary**. INT-01 was closed not
only correctly but with canonicalization applied ahead of time (the C-08 lesson, transferred to the
cross-subsystem level without prompting). The layer's first shortfall (INT-03) is not crude
(string-match or missing->skip of whole fields) but thin (branch asymmetry) — just as lease started
near-mature on single-field classes and its first finding was composition.

The same converging dynamic holds within the new stratum: the first finding was fundamental (INT-01, a
c=a+b violation), the second is thinner (INT-03, branch asymmetry). The cross-subsystem stratum,
though it opened a fundamental class, is not unbounded and obeys the same curve.

The picture is now two-dimensional: subsystem hardening (curve 7->4->2, mature) and cross-subsystem
enforcement (new stratum, INT-01 fundamental -> INT-03 thinner, inherits the vocabulary). Both obey
one method (adversarial vectors against invariants, empirical checking) and one dynamic (converging
curve, cumulative transfer of lessons).

---

## 7. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63"
  supersedes_archive_sha256: "474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114"
  verdict: PASS_CHECKER_V1_4_CROSS_SUBSYSTEM_FIRST_PASS
  blocking: false
  prior_findings_resolved: [INT-01, INT-02_expired_branch]
  new_findings: [INT-03]
  probe_areas: [INT-C_delegation_vs_anchor_revocation]
  recommended_next:
    - "Fix INT-03: lift routing out of the expired branch; apply under any cascade-capable lease state (expired OR held)."
    - "Add fixtures: held + delegated surface not routed -> DELEGATION_SURFACE_NOT_IN_ACTIVE_EXECUTION; valid-held + routed -> clean."
    - "Canonicalize anchor revocation, then probe INT-C."
    - "As viewport/nonce/review-binding are added, each gets two fronts: subsystem hardening and cross-subsystem seams."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
