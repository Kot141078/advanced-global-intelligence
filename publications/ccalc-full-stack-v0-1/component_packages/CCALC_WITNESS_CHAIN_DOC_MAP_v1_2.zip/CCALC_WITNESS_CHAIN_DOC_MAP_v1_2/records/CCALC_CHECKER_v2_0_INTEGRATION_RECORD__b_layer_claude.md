# Integration Review Record — c-calculus-checker v2.0 (INT-08 closure + milestone consolidation)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-07-02
**Record short name:** `CCALC_CHECKER_v2_0_INTEGRATION__b`
**Supersedes review:** `CCALC_CHECKER_v1_9_INTEGRATION__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v2_0_INTEGRATION__b
  record_version: "2.0"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_9_INTEGRATION__b
  milestone: true

  reviewed_artifact:
    title: "c-calculus-checker v2.0 (authority x lease closure + milestone)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-07-02"
    archive_sha256: "5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79"
    supersedes_archive_sha256: "6fe08355c09f63e6f6bab54c0e87fca62a1c7a0482f41458a17249a490d3b346"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: int08_closed_as_class_milestone_consolidation
    meaning: >
      As a b-layer semantic reviewer I find INT-08 closed as a CLASS, fully, including the review-exception and
      the held-non-interruptible sub-seam I had raised only as a candidate. This closes the last open seam that
      actually exists in the checker. Probing the remaining matrix seams established an honest scope boundary:
      viewport and review-binding subsystems are NOT in this checker (they are in spec 02 but unimplemented
      here), and nonce is locally mature inside the signature envelope. The cross-subsystem plane is probed
      across all seams present in the checker. PASS is a verdict on a hardened core, NOT an authorization, NOT a
      certification, and NOT a claim over the full 02 spec.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    INT-08_authority_lease_downgrade_semantically_empty:
      status: RESOLVED_AS_CLASS
      fix: >
        reduced_authority requires a declared reduced authority surface set and active execution must be
        contained by it (LEASE_REDUCED_AUTHORITY_SET_MISSING, LEASE_REDUCED_AUTHORITY_EXCEEDED). pending_anchor
        blocks active execution except explicitly declared review/re-anchor surfaces
        (LEASE_PENDING_ANCHOR_ACTIVE_EXECUTION, pending_anchor_allowed_surfaces; mirrors A7). Held active
        surfaces must be interruptible with a verified abort route (LEASE_HELD_NON_INTERRUPTIBLE_SURFACE).
      empirical_proof_all_vectors: >
        reduced_authority no set -> SET_MISSING; exec exceeds set -> EXCEEDED; exec within set -> clean;
        pending_anchor + execution -> PENDING_ANCHOR_ACTIVE_EXECUTION; pending_anchor + review-only
        (pending_anchor_allowed_surfaces) -> clean; held + non-interruptible -> NON_INTERRUPTIBLE.
      note: "The post-anchor state machine bridge from v1.9 (A7_REANCHORING_PENDING) is now realized in code as the pending_anchor review-exception."

  checker_scope_boundary:
    finding_method: "probed the remaining matrix seams; enumerated the implemented checks."
    implemented_checks: [anchor_signature_envelope_with_nonce, delegation_root, authority_intersection, lease_and_abort, cross_subsystem_enforcement, anchor_state_compatibility]
    seams_not_in_checker:
      viewport_x_review_binding: "viewport and ReviewBindingMap subsystems are NOT implemented in this checker; they are in spec 02 (§5.6, §5.6A) and marked 'local mature' in the matrix, but their seam cannot be probed here — out of scope, not closed."
    seams_locally_mature:
      nonce_x_signature: "nonce is locally mature inside check_anchor_signature_envelope: fusion to review_object_hash (ANCHOR_NONCE_NOT_BOUND_TO_FINAL_REVIEW_OBJECT), source whitelist, b-controlled ban. One subsystem, not a two-subsystem seam. nonce's link to delegation/active is transitive via review_object_hash (nonce bound to the frozen review object including them)."
    honest_statement: >
      'The cross-subsystem plane is probed' is true RELATIVE TO the subsystems implemented in the checker, not
      relative to the whole 02 spec. The checker hardens the core (authority/delegation/lease/active/signature);
      viewport/review-binding are a separate stratum not present here. Completeness is relative to the
      implemented subset.

  consolidated_state_at_milestone:
    subsystems_mature: {authority_markup: "7 turns", delegation: "4 turns", lease: "2 turns"}
    seam_plane_probed_in_checker:
      delegation_x_anchor_authority: "INT-01 containment closed"
      delegation_x_lease_lifecycle: "INT-02/03/04 routing closed"
      active_x_authority: "INT-05/06/07 containment/trust/extraction closed"
      authority_x_lease_downgrade: "INT-08 reduced/pending/held closed"
      nonce_signature: "locally mature"
    open_or_out_of_scope:
      INT-C_delegation_x_anchor_revocation: "waiting on a canonical anchor-revocation fixture model"
      viewport_x_review_binding: "no subsystems in this checker (out of scope)"

  milestone_retrospective:
    method_not_fixes: >
      What was built is a method, not a set of fixes. Finding classes are universal (the a/b boundary), remedies
      transferable, vocabulary cumulative. Subsystems converged 7->4->2, each faster by inheriting the
      vocabulary. Reproducible, not a one-off.
    whole_is_not_the_sum: >
      The key turn of the path: integration showed the whole is not the sum of its parts. Three mature
      subsystems had holes at their seams — INT-01 (delegation exceeds anchor) and INT-05 (execution exceeds
      authority) were violations of c=a+b itself at the place where '+' is implemented. I corrected my own model
      three times openly (the plane larger than each estimate), converging on the seam matrix as the tool, which
      the anchor adopted and extended. The substantive architectural point: a is formalizable, b is hardenable,
      and '+' (the join) is a separate entity with its own complexity where most fundamental invariants live.
    honest_boundary: >
      The checker is a subset of the spec. It does not 'prove' safety (non-claims hold in every record); it
      hardens the implemented core against specific adversarial vectors. viewport/review-binding, the ARQ
      quantum layer, provenance economics are outside it. And the terminal boundary remains: the checker checks
      the declared fixture, not the real substrate — the truthfulness of the declaration against execution is a
      witness/attestation matter, outside the code. Not a weakness, but precise knowledge of what the checker
      does and does not do.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79"
    verdict: PASS_CHECKER_V2_0_MILESTONE_INT08_CLOSED
    blocking: false
    prior_findings_resolved: [INT-08]
    open_items: [INT-C_delegation_x_anchor_revocation]
    out_of_scope: [viewport_x_review_binding]
    recommended_next:
      - "Option 1 (recommended): canonicalize anchor revocation in the fixture model (a Codex contract for model + fixtures), then probe delegation x anchor revocation and close INT-C — the last open seam in checker scope."
      - "Option 2: implement viewport / review-binding subsystems in the checker if their seams should be covered — a new subsystem front, fast on the curve, plus their seams with the core."
      - "Option 3: consolidate the witness chain — a summary index/registry (DOC_MAP of all review records with lineage) so the SHA-256-bound chain is navigable as one corpus."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

INT-08 is closed as a **class**, fully: `reduced_authority` requires a declared reduced authority set
with execution contained by it; `pending_anchor` blocks execution except explicitly declared
review/re-anchor surfaces (mirroring `A7_REANCHORING_PENDING`); held active surfaces must be
interruptible with a verified abort route. Verified across all vectors, including the review-exception
(via `pending_anchor_allowed_surfaces`) and the held-non-interruptible sub-seam I had raised only as a
candidate. This closes the last open seam that actually exists in the checker.

Probing the remaining matrix seams established an **honest scope boundary**: the viewport and
review-binding subsystems are NOT implemented in this checker (they are in spec 02 but unimplemented
here), so their seam cannot be probed — out of scope, not closed. nonce is locally mature inside the
signature envelope (fusion to `review_object_hash`), a single subsystem rather than a two-subsystem
seam. So "the cross-subsystem plane is probed" is true relative to the subsystems the checker
implements, not the whole 02 spec.

PASS is a verdict on a hardened core — not an authorization, not a certification, and not a claim over
the full 02 spec.

---

## 3. Empirical proof (executed)

**INT-08 class closure (all vectors):**
```
reduced_authority, NO declared set   -> LEASE_REDUCED_AUTHORITY_SET_MISSING
reduced_authority, exec exceeds set  -> LEASE_REDUCED_AUTHORITY_EXCEEDED
reduced_authority, exec within set   -> clean
pending_anchor + execution            -> LEASE_PENDING_ANCHOR_ACTIVE_EXECUTION
pending_anchor + review-only surface  -> clean  (pending_anchor_allowed_surfaces)
held + non-interruptible surface      -> LEASE_HELD_NON_INTERRUPTIBLE_SURFACE
```
**Scope boundary (enumerated checks):**
```
implemented: anchor_signature_envelope(+nonce), delegation_root, authority_intersection,
             lease_and_abort, cross_subsystem_enforcement, anchor_state_compatibility
not present: viewport, review-binding
```

---

## 4. Prior finding closure

### INT-08 (resolved as a class) — authority x lease downgrade

`reduced_authority` requires a declared reduced authority surface set with active execution contained
by it (`LEASE_REDUCED_AUTHORITY_SET_MISSING`, `LEASE_REDUCED_AUTHORITY_EXCEEDED`). `pending_anchor`
blocks active execution except explicitly declared review/re-anchor surfaces
(`LEASE_PENDING_ANCHOR_ACTIVE_EXECUTION`, `pending_anchor_allowed_surfaces`; mirrors `A7`). Held active
surfaces must be interruptible with a verified abort route (`LEASE_HELD_NON_INTERRUPTIBLE_SURFACE`).
All vectors verified, including the review-exception and the held-non-interruptible sub-seam. The
post-anchor state machine bridge from v1.9 is now realized in code.

---

## 5. Checker scope boundary (established this milestone)

The checker implements a subset of spec 02. Implemented checks:
`anchor_signature_envelope`(+nonce), `delegation_root`, `authority_intersection`, `lease_and_abort`,
`cross_subsystem_enforcement`, `anchor_state_compatibility`.

- **viewport x review-binding:** the viewport and ReviewBindingMap subsystems are NOT in this checker;
  they are in spec 02 (§5.6, §5.6A) and marked "local mature" in the matrix, but their seam cannot be
  probed here — out of scope, not closed.
- **nonce x signature:** nonce is locally mature inside `check_anchor_signature_envelope` (fusion to
  `review_object_hash`, source whitelist, b-controlled ban) — one subsystem, not a two-subsystem seam.
  nonce's link to delegation/active is transitive via `review_object_hash`.

So "the cross-subsystem plane is probed" is true relative to the implemented subsystems, not the whole
02 spec. Completeness is relative to the implemented subset.

---

## 6. Milestone retrospective (honest)

**Method, not fixes.** Finding classes are universal (the a/b boundary), remedies transferable,
vocabulary cumulative. Subsystems converged 7->4->2, each faster by inheriting the vocabulary.
Reproducible.

**The whole is not the sum.** Integration showed three mature subsystems had holes at their seams —
INT-01 (delegation exceeds anchor) and INT-05 (execution exceeds authority) were violations of `c=a+b`
itself at the place where `+` is implemented. I corrected my own model three times openly (the plane
larger than each estimate), converging on the seam matrix, which the anchor adopted and extended. The
architectural point: `a` is formalizable, `b` is hardenable, and `+` (the join) is a separate entity
with its own complexity where most fundamental invariants live.

**Honest boundary.** The checker is a subset of the spec. It does not prove safety (non-claims hold in
every record); it hardens the implemented core against specific adversarial vectors.
viewport/review-binding, the ARQ quantum layer, provenance economics are outside it. And the terminal
boundary remains: the checker checks the declared fixture, not the real substrate — the truthfulness
of the declaration against execution is a witness/attestation matter, outside the code.

---

## 7. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed;
7. that the cross-subsystem plane is probed relative to the whole 02 spec — only relative to the subsystems the checker implements.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79"
  supersedes_archive_sha256: "6fe08355c09f63e6f6bab54c0e87fca62a1c7a0482f41458a17249a490d3b346"
  verdict: PASS_CHECKER_V2_0_MILESTONE_INT08_CLOSED
  blocking: false
  prior_findings_resolved: [INT-08]
  open_items: [INT-C_delegation_x_anchor_revocation]
  out_of_scope: [viewport_x_review_binding]
  recommended_next:
    - "Option 1 (recommended): canonicalize anchor revocation (Codex contract for model + fixtures), then close INT-C — the last open seam in checker scope."
    - "Option 2: implement viewport / review-binding subsystems if their seams should be covered."
    - "Option 3: consolidate the witness chain — a DOC_MAP of all review records with lineage."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*