# Semantic Review Record — c-calculus-checker v1.3 CROSS-SUBSYSTEM INTEGRATION PASS

**Record class:** b-layer semantic review record (advisory) — integration pass
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_3_INTEGRATION__b`
**Complements review:** `CCALC_CHECKER_v1_3_REVIEW__b` (subsystem maturity pass)

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_3_INTEGRATION__b
  record_version: "1.3-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  complements_review: CCALC_CHECKER_v1_3_REVIEW__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.3 (cross-subsystem integration)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114"
    mature_subsystems_covered: [authority_markup, delegation, lease_expiry_cascade]
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: INTEGRATION_FINDINGS_RAISED
    qualifier: subsystems_correct_in_isolation_composition_has_gaps
    meaning: >
      This is an integration pass, not a subsystem PASS/FAIL. Each subsystem is correct in isolation; the gap
      is the absence of a cross-subsystem enforcement layer. run_all_checks concatenates isolated checks, each
      reading only its own section, so cross-subsystem invariants cannot be checked. One significant finding
      (INT-01: delegation scope is not bounded by anchor authority — a c=a+b violation) and one moderate
      (INT-02: delegation validity is unlinked from lease/anchor lifecycle) are raised, plus one probe area
      (INT-C: delegation vs anchor revocation, unconfirmed).
    blocking_findings: 0
    safety_escalations: 0

  architecture_observation:
    run_all_checks: "for check in CHECKS: findings.extend(check(fixture)) — pure concatenation of isolated checks."
    isolation: "check_delegation_root reads anchor_contract; check_lease_and_abort reads lease/active_execution_surfaces; check_authority_intersection reads authority. None reads the intersection of sections. Cross-subsystem invariants are structurally uncheckable — there is no layer that sees them."

  findings:
    INT-01_delegation_exceeds_anchor_authority:
      severity: significant
      blocking: false
      empirically_proven: true
      class: cross_subsystem_authority_containment  # new class, only visible at integration
      locus: ["validators.check_delegation_root (checks requested subset delegation.allowed only)", "validators.check_authority_intersection (does not read delegation)"]
      issue: >
        Delegation scope is not bounded by anchor authority. A delegate can be granted surfaces the anchor does
        not have, and even surfaces outside the entire declared lattice. This is the core c=a+b violation: the
        b branch (delegation) may not exceed a (anchor). check_delegation_root checks requested subset
        delegation.allowed (inside delegation); check_authority_intersection computes anchor_surfaces &
        substrate & governance but does not read delegation scope; nobody checks delegation.allowed subset
        anchor_surfaces. It is invisible per-subsystem because each is internally correct; the hole is exactly
        at the seam neither check reads.
      empirical_proof: >
        anchor_surfaces=[read_logs], delegation grants [write_memory, network_access] -> CLEAN; delegation
        grants [root_shell_unlisted] outside the whole declared_surface_lattice -> CLEAN.
      recommended_path: >
        Cross-subsystem check: delegation.allowed_surfaces subset authority.anchor_surfaces (root delegation may
        not grant more than the anchor holds); for multi-hop, scope_root subset anchor_surfaces as the upper
        bound (intra-chain monotone narrowing already exists). New error DELEGATION_EXCEEDS_ANCHOR_AUTHORITY |
        Reject.
    INT-02_delegation_unlinked_from_lifecycle:
      severity: moderate
      blocking: false
      empirically_proven: true
      class: cross_subsystem_lifecycle
      locus: ["check_delegation_root vs check_lease_and_abort / check_anchor_state_compatibility"]
      issue: >
        Delegation validity is not linked to lease/anchor lifecycle. Delegation stays valid under an expired
        lease and a held lease. Partially mitigated: lease flags active execution (ACTIVE_EXECUTION_AFTER_LEASE_
        EXPIRY) only if delegation-granted surfaces appear in active_execution_surfaces; if not, the link is
        lost entirely and delegation authority outlives lease expiry with no flag. Delegation validity itself
        is not annulled — only active execution is flagged, by a separate mechanism.
      empirical_proof: >
        delegation valid + lease expired -> lease flags expiry, delegation stays valid (no link); delegation
        valid + lease held -> lease flags HELD_WITHOUT_TTL, deleg-lease interaction not checked.
      recommended_path: >
        Delegation-granted surfaces must land in active_execution_surfaces (so lease cascade catches them), and
        delegation validity must account for lease/anchor lifecycle — an expired lease or revoked anchor annuls
        delegated authority, not merely flags active execution.

  probe_area_not_a_finding:
    INT-C_delegation_vs_anchor_revocation:
      status: unconfirmed
      note: "Probed with anchor_health=revoked, a fabricated field; the model may encode anchor revocation differently. Honestly held as a hypothesis: check whether a revoked/doubtful anchor annuls active delegation (delegation root traces to the anchor; a revoked anchor should annul authority it delegated). Requires knowing how the model encodes anchor revocation alongside delegation; not empirically confirmed."

  cross_subsystem_layer_meta:
    new_class: >
      INT-01 is not another instance of an existing class. It is a new class visible only at integration:
      cross-subsystem authority containment. Three subsystems were matured in isolation (curve 7->4->2, each
      internally correct), but their COMPOSITION has a hole no isolated review can see: delegation checks that
      the delegate does not exceed what is DELEGATED; authority checks that anchor surfaces intersect; but
      'delegated' is never reconciled with 'the anchor holds'. Each subsystem guards its own boundary; none
      guards the boundary BETWEEN them.
    extends_C09: >
      This confirms the C-09 principle one level up. C-09 (in authority-markup) showed a new mechanism must be
      re-checked against standing invariants, or fixing one opens another's seam. Integration is the same
      principle a level higher: each SUBSYSTEM must be re-checked against the others' invariants, or one
      subsystem's maturity does not guarantee the composition's safety. The thinnest findings are at seams;
      C-09 found them at mechanism seams within a subsystem, integration at subsystem seams. Notably, at the
      subsystem seam the finding is not thinner but MORE fundamental — not an empty-set edge case, but a
      violation of c=a+b itself.
    implication: >
      Subsystem maturity is necessary but not sufficient. Above mature subsystems a cross-subsystem enforcement
      layer is needed — checks that read the INTERSECTION of sections: delegation subset authority (INT-01),
      delegation validity x lease/anchor lifecycle (INT-02), and likely other seams (viewport x review-binding,
      nonce x anchor signature, lease x authority downgrade). This is a new stratum of work, orthogonal to
      subsystem hardening, and integration just showed it is not empty: its first vector (delegation x
      authority) exposed a significant hole.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114"
    verdict: INTEGRATION_FINDINGS_RAISED
    blocking: false
    findings: [INT-01, INT-02]
    probe_areas: [INT-C_delegation_vs_anchor_revocation]
    recommended_next:
      - "Fix INT-01: add a cross-subsystem check delegation.allowed_surfaces subset authority.anchor_surfaces (root and chain upper bound); DELEGATION_EXCEEDS_ANCHOR_AUTHORITY."
      - "Fix INT-02: route delegation-granted surfaces into active_execution_surfaces; link delegation validity to lease/anchor lifecycle."
      - "Add a cross-subsystem enforcement layer (checks that read section intersections), the new stratum above mature subsystems."
      - "Probe remaining seams: delegation x anchor revocation (INT-C), and future viewport/nonce/review-binding seams."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

This is an integration pass, not a subsystem PASS/FAIL. Each subsystem is correct in isolation; the
gap is the absence of a cross-subsystem enforcement layer. `run_all_checks` concatenates isolated
checks, each reading only its own section (delegation -> `anchor_contract`, lease -> `lease`,
authority -> `authority`), so cross-subsystem invariants cannot be checked.

One significant finding: **INT-01** — delegation scope is not bounded by anchor authority. A delegate
can be granted surfaces the anchor does not have, and even surfaces outside the entire declared
lattice (both proven CLEAN). This is the core `c = a + b` violation — the `b` branch (delegation) may
not exceed `a` (anchor) — and it is invisible per-subsystem because each is internally correct; the
hole is at the seam neither check reads.

One moderate finding: **INT-02** — delegation validity is unlinked from lease/anchor lifecycle
(delegation stays valid under an expired or held lease; partially mitigated only if delegation
surfaces appear in `active_execution_surfaces`). One probe area: **INT-C** — delegation vs anchor
revocation, unconfirmed (probed with a fabricated field).

---

## 3. Empirical proof (executed)

```
valid baseline                                              -> clean
INT-01 anchor=[read_logs], delegation grants [write_memory, network_access] -> CLEAN
INT-01 delegation grants [root_shell_unlisted] (outside lattice)            -> CLEAN
INT-02 delegation valid + lease expired  -> lease flags ACTIVE_EXECUTION_AFTER_LEASE_EXPIRY + LEASE_EXPIRED_BY_LOGICAL_TIME; delegation stays valid (no link)
INT-02 delegation valid + lease held     -> lease flags LEASE_HELD_WITHOUT_TTL; deleg-lease interaction not checked
INT-C  delegation + anchor_health=revoked (fabricated field) -> CLEAN (unconfirmed; model may encode revocation differently)
check_authority_intersection on the INT-01 fixture          -> none (does not read delegation)
```

---

## 4. Findings

### INT-01 (significant, non-blocking, empirically proven) — delegation scope not bounded by anchor authority

Delegation scope is not bounded by anchor authority. A delegate can be granted surfaces the anchor
does not have, and even surfaces outside the entire declared lattice (proven). `check_delegation_root`
checks `requested ⊆ delegation.allowed` (inside delegation); `check_authority_intersection` computes
`anchor_surfaces & substrate & governance` but does not read delegation scope; nobody checks
`delegation.allowed ⊆ anchor_surfaces`. This is the core `c = a + b` violation: the delegate (b
branch) may not exceed what the anchor (a) holds. It is invisible per-subsystem because each is
internally correct; the hole is exactly at the seam.

**Path:** cross-subsystem check `delegation.allowed_surfaces ⊆ authority.anchor_surfaces` (root may not
grant more than the anchor holds); for multi-hop, `scope_root ⊆ anchor_surfaces` as the upper bound
(intra-chain monotone narrowing already exists). New error `DELEGATION_EXCEEDS_ANCHOR_AUTHORITY |
Reject`.

### INT-02 (moderate, non-blocking, empirically proven) — delegation validity unlinked from lifecycle

Delegation validity is not linked to lease/anchor lifecycle; delegation stays valid under an expired
or held lease. Partially mitigated: lease flags active execution only if delegation-granted surfaces
appear in `active_execution_surfaces`; otherwise the link is lost and delegation authority outlives
lease expiry with no flag. Delegation validity itself is not annulled — only active execution is
flagged, by a separate mechanism.

**Path:** route delegation-granted surfaces into `active_execution_surfaces` (so lease cascade catches
them), and link delegation validity to lease/anchor lifecycle — an expired lease or revoked anchor
annuls delegated authority, not merely flags active execution.

### INT-C (probe area, not a finding) — delegation vs anchor revocation

Probed with `anchor_health=revoked`, a fabricated field; the model may encode anchor revocation
differently. Held as a hypothesis: check whether a revoked/doubtful anchor annuls active delegation
(delegation root traces to the anchor). Requires knowing how the model encodes anchor revocation
alongside delegation; not empirically confirmed.

---

## 5. The cross-subsystem layer (observation)

INT-01 is not another instance of an existing class. It is a new class visible only at integration:
**cross-subsystem authority containment**. Three subsystems were matured in isolation (curve 7->4->2,
each internally correct), but their **composition** has a hole no isolated review can see: delegation
checks that the delegate does not exceed what is *delegated*; authority checks that anchor surfaces
intersect; but *delegated* is never reconciled with *the anchor holds*. Each subsystem guards its own
boundary; none guards the boundary **between** them.

This confirms the C-09 principle one level up. C-09 showed a new mechanism must be re-checked against
standing invariants, or fixing one opens another's seam. Integration is the same principle a level
higher: each **subsystem** must be re-checked against the others' invariants, or one subsystem's
maturity does not guarantee the composition's safety. The thinnest findings are at seams — C-09 found
them at mechanism seams within a subsystem, integration at subsystem seams. Notably, at the subsystem
seam the finding is not thinner but **more fundamental** — not an empty-set edge case, but a violation
of `c = a + b` itself.

Subsystem maturity is necessary but not sufficient. Above mature subsystems a **cross-subsystem
enforcement layer** is needed — checks that read the **intersection** of sections: delegation ⊆
authority (INT-01), delegation validity x lease/anchor lifecycle (INT-02), and likely other seams
(viewport x review-binding, nonce x anchor signature, lease x authority downgrade). This is a new
stratum of work, orthogonal to subsystem hardening, and integration just showed it is not empty: its
first vector exposed a significant hole.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that raising integration findings confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114"
  verdict: INTEGRATION_FINDINGS_RAISED
  blocking: false
  findings: [INT-01, INT-02]
  probe_areas: [INT-C_delegation_vs_anchor_revocation]
  recommended_next:
    - "Fix INT-01: cross-subsystem check delegation.allowed_surfaces subset authority.anchor_surfaces; DELEGATION_EXCEEDS_ANCHOR_AUTHORITY."
    - "Fix INT-02: route delegation surfaces into active_execution_surfaces; link delegation validity to lease/anchor lifecycle."
    - "Add a cross-subsystem enforcement layer (checks reading section intersections)."
    - "Probe remaining seams: delegation x anchor revocation (INT-C); future viewport/nonce/review-binding seams."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
