# Semantic Review Record — c-calculus-checker v0.6

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_6_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_5_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_6_REVIEW__b
  record_version: "0.6"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_5_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.6"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc"
    supersedes_archive_sha256: "8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: hardened_implementation_v0_6
    meaning: >
      As a b-layer semantic reviewer I find C-08 closed on both levels: canonicalization catches name variants
      (Roles/ROLES/whitespace), and a typed anchor-authorized authority_axis_schema resolves semantic synonyms
      with genesis coverage enforced. One new moderate finding (C-09) is raised, proven by execution: the
      schema-alias mechanism added for C-08 opens a new bypass of the C-07 constitutional floor — a
      genesis-covered alias can redirect a core §1385 axis to a non-authority name and out of the floor. PASS
      is a verdict on a hardened seed implementation, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    C-08_floor_string_match_brittleness:
      status: RESOLVED_BOTH_LEVELS
      evidence: >
        Level 1: _normalise_axis_token (casefold/trim/hyphen-space->underscore) + _DEFAULT_AXIS_ALIASES
        (singular/plural) resolve Roles/ROLES/role to canonical roles before floor/projection. Level 2:
        GovernanceProfile.authority_axis_schema.aliases maps deployment synonyms (user_roles->roles) only when
        the schema is genesis-covered; _check_authority_axis_schema_coverage verifies by hash
        (AUTHORITY_AXIS_SCHEMA_NOT_GENESIS_COVERED). Inversion and floor retained.
      empirical_proof: >
        A1 Roles/Roles -> caught; A1b ROLES / 'roles ' -> caught; A3 user_roles + covered schema -> caught;
        A4 schema not covered -> AUTHORITY_AXIS_SCHEMA_NOT_GENESIS_COVERED; A5 legit container_ip -> clean.
      boundary_not_a_hole:
        A2_user_roles_no_schema: >
          user_roles declared ephemeral without a schema slips, because the checker fundamentally cannot know
          user_roles == roles without an anchor declaration. This is the terminal-a boundary (§16.3), not a
          checker defect: the identity of an arbitrary semantic synonym requires an anchor-authorized mapping.

  new_findings:
    C-09_schema_alias_redirects_core_axis:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_class: constitutional_floor_bypass  # same class as C-07, new mechanism
      locus: ["registry._canonical_axis_name", "registry._schema_aliases", "registry._declared_ephemeral_manifest_keys"]
      issue: >
        Canonicalization runs before the floor. A genesis-covered authority_axis_schema alias can map a core
        §1385 axis (roles) to a non-authority canonical name (pod_id / harmless_telemetry); after resolution
        the floor sees the non-core name and does not protect it, so declaring that name ephemeral downgrades
        the core axis. The alias direction is asymmetric: synonym->core (my_perms->roles) is protected
        correctly, but core->non-core (roles->pod_id) bypasses. This is the C-07 constitutional-floor bypass
        via a new mechanism (the alias resolution added for C-08).
      empirical_proof: >
        A6 (alias roles->pod_id, covered, pod_id ephemeral) -> SLIPS; A7 (alias roles->harmless_telemetry) ->
        SLIPS; A8 control (alias my_perms->roles) -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS +
        MANIFEST_AUTHORITY_PROJECTION_CHANGED.
      recommended_path: >
        §1385 detection must protect a key that is a core axis by ANY canonical path, so schema cannot smuggle
        core out: (1) compute default_canonical(raw) = normalize + _DEFAULT_AXIS_ALIASES only, no schema; (2) if
        default_canonical(raw) in KNOWN_AUTHORITY_AXES -> protected regardless of schema mapping (closes A6/A7);
        (3) or full_canonical(raw) in KNOWN_AUTHORITY_AXES -> protected (keeps A8); (4) defensive: a schema alias
        whose source default-canonicalizes to a §1385 core axis -> AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS |
        Reject. The floor is then checked by semantics (is this a core axis by any path), not by the final
        post-alias name schema can move.

  composition_of_invariants_meta:
    observation: >
      C-07 built the constitutional floor (anchor cannot downgrade a core axis). The C-08 fix (canonicalization
      + schema for synonym identity) was correct and necessary, but it introduced a new mechanism (alias
      resolution) that did not respect the existing floor: an alias can redirect a core axis out of the floor,
      because the floor reads the alias output, not its input. Fixing one problem opened a bypass of another's
      invariant. Lesson: a constitutional invariant must be checked by a representation invariant to any
      resolution mechanism — every new mechanism must be re-checked against every standing invariant, and the
      floor must be evaluated on semantics that no later mechanism can move.

  authority_markup_theme_arc:
    observation: >
      The theme: who decides what is ephemeral (loop, C-06) -> what is non-overridable (floor, C-07) -> how an
      axis is identified (typed identity, C-08) -> and C-09 is the junction of the last two: identity
      resolution (C-08) must respect non-overridability (C-07). When the floor is evaluated on default-canonical
      semantics (unmovable by schema), the three close consistently: identity resolves via anchor-authorized
      schema, yet the core floor stays non-overridable by any resolution path.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc"
    verdict: PASS_CHECKER_V0_6
    blocking: false
    prior_findings_resolved: [C-08]
    new_findings: [C-09]
    recommended_next:
      - "Fix C-09: evaluate the §1385 floor on default-canonical semantics (no schema), protect a core axis by any canonical path, and reject a schema alias whose source is a core axis."
      - "Add fixtures: schema alias redirecting a core axis to a non-authority name -> rejected; synonym->core alias -> still protected."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

C-08 is closed on both levels. Canonicalization resolves name variants (`Roles`/`ROLES`/
whitespace) to the canonical axis before the floor, and a typed anchor-authorized
`authority_axis_schema` resolves semantic synonyms (`user_roles`->`roles`) only when the schema
is genesis-covered (verified by hash, `AUTHORITY_AXIS_SCHEMA_NOT_GENESIS_COVERED`). Verified by
attack: A1/A1b variants caught, A3 covered-schema synonym caught, A4 forged schema rejected, A5
legit clean. The A2 residual (`user_roles` with no schema slips) is the terminal-`a` boundary,
not a defect — the identity of an arbitrary synonym requires an anchor declaration.

One new moderate finding (C-09), proven by execution: the schema-alias mechanism added for C-08
opens a new bypass of the C-07 constitutional floor. A genesis-covered alias mapping a core
§1385 axis (`roles`) to a non-authority name (`pod_id`) lets the floor see the non-core name and
declare it ephemeral, downgrading the core axis (A6/A7 slip; A8 synonym->core control is
protected). The fix is to evaluate the floor on default-canonical semantics that no schema alias
can move.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of C-08 (both levels):**
```
A1 Roles/Roles                         -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
A1b ROLES / 'roles ' (whitespace)      -> caught (both)
A3 user_roles + covered schema         -> caught (both)
A4 schema NOT genesis-covered          -> AUTHORITY_AXIS_SCHEMA_NOT_GENESIS_COVERED (+ floor)
A5 legit container_ip                  -> clean
A2 user_roles, NO schema               -> slips (terminal-a boundary, not a defect)
```

**C-09 (schema alias redirects a core axis out of the floor):**
```
A6 alias roles->pod_id (covered), pod_id ephemeral -> SLIPS
A7 alias roles->harmless_telemetry (covered)       -> SLIPS
A8 control alias my_perms->roles (synonym->core)   -> EPHEMERAL_ENVELOPE_DECLARES_AUTHORITY_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
```

---

## 4. New finding

### C-09 (moderate, non-blocking, empirically proven) — a genesis-covered schema alias can redirect a core §1385 axis out of the constitutional floor

Canonicalization runs before the floor. A genesis-covered `authority_axis_schema` alias can map a
core §1385 axis (`roles`) to a non-authority canonical name (`pod_id`, `harmless_telemetry`);
after resolution the floor sees the non-core name and does not protect it, so declaring that name
ephemeral downgrades the core axis. The alias direction is asymmetric: `synonym->core`
(`my_perms->roles`) is protected correctly (A8), but `core->non-core` (`roles->pod_id`) bypasses
(A6/A7). This is the **C-07 constitutional-floor bypass via a new mechanism** — the alias
resolution added for C-08.

**Path:** §1385 detection must protect a key that is a core axis by **any** canonical path, so
schema cannot smuggle core out:
1. compute `default_canonical(raw)` = normalize + `_DEFAULT_AXIS_ALIASES` only, no schema;
2. if `default_canonical(raw)` in `KNOWN_AUTHORITY_AXES` -> protected regardless of schema mapping
   (closes A6/A7);
3. or `full_canonical(raw)` in `KNOWN_AUTHORITY_AXES` -> protected (keeps A8);
4. defensive: a schema alias whose source default-canonicalizes to a §1385 core axis ->
   `AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS | Reject`.

The floor is then evaluated by **semantics** (is this a core axis by any path), not by the final
post-alias name a schema can move. Schema aliases may only **add** `synonym->core` protection, not
**remove** core.

---

## 5. Composition of invariants (observation)

C-07 built the constitutional floor (anchor cannot downgrade a core axis). The C-08 fix
(canonicalization + schema for synonym identity) was correct and necessary, but it introduced a
new mechanism (alias resolution) that did not respect the existing floor: an alias can redirect a
core axis out of the floor, because the floor reads the alias output, not its input. Fixing one
problem opened a bypass of another's invariant.

Lesson: a constitutional invariant must be checked by a representation invariant to any resolution
mechanism — every new mechanism must be re-checked against every standing invariant, and the floor
must be evaluated on semantics no later mechanism can move. This is the code-level echo of the
text-level composition findings (F2-05 review=bound meets registry-drift; F2-06 uniformity).

The authority-markup theme: *who decides what is ephemeral* (loop, C-06) -> *what is
non-overridable* (floor, C-07) -> *how an axis is identified* (typed identity, C-08) -> and C-09 is
the junction of the last two: identity resolution must respect non-overridability. When the floor
is evaluated on default-canonical semantics, the three close consistently.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc"
  supersedes_archive_sha256: "8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394"
  verdict: PASS_CHECKER_V0_6
  blocking: false
  prior_findings_resolved: [C-08]
  new_findings: [C-09]
  recommended_next:
    - "Fix C-09: evaluate the §1385 floor on default-canonical semantics (no schema); protect a core axis by any canonical path; reject a schema alias whose source is a core axis."
    - "Add fixtures: alias redirecting a core axis to a non-authority name -> rejected; synonym->core alias -> still protected."
    - "Re-check every existing invariant against each newly added resolution mechanism."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
