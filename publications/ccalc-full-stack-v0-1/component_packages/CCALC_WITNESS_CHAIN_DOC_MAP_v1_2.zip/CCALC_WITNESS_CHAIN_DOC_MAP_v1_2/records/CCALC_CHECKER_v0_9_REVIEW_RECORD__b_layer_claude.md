# Semantic Review Record — c-calculus-checker v0.9 (delegation subsystem, second pass)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_9_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_8_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_9_REVIEW__b
  record_version: "0.9"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_8_REVIEW__b
  subsystem_under_review: delegation_chains

  reviewed_artifact:
    title: "c-calculus-checker v0.9 (delegation subsystem, second pass)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f"
    supersedes_archive_sha256: "3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: delegation_second_pass
    meaning: >
      As a b-layer semantic reviewer I find all five prior delegation findings closed, with D-01 (multi-hop)
      closed as a principle: the chain is iterated and per-hop validation (emulation, scope widening, delegator
      identity, sub-delegation) fires on any hop, not just the first. One new moderate finding (D-06) is raised,
      proven by execution: an empty allowed_surfaces set is treated as no-constraint (skip) instead of
      zero-scope (maximal restriction), disabling the widening check at the root (whole chain) and via
      carry-forward at a hop. PASS is a verdict on a hardened seed, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    D-01_multi_hop:
      status: RESOLVED_AS_PRINCIPLE
      evidence: "check_delegation_root iterates chain_links; each hop validated for envelope, signature_source (hop/anchor whitelist), delegator_id_hash (computed) binding previous delegate, scope subset previous (monotone narrowing), sub-delegation authorization."
      empirical_proof: "middle hop emulated -> HOP_SIGNATURE_UNVERIFIED; widen at hop 3 -> CHAIN_SCOPE_WIDENED; broken identity hop 2 -> HOP_DELEGATOR_MISMATCH; subdeleg not authorized -> SUBDELEGATION_NOT_AUTHORIZED."
    D-02_scope_inert_without_request: {status: RESOLVED, empirical_proof: "no request anywhere -> DELEGATION_REQUEST_UNSPECIFIED; broad anchor_surfaces fallback removed."}
    D-03_delegate_id_absent: {status: RESOLVED, empirical_proof: "no delegate_id -> DELEGATION_DELEGATE_ID_MISSING."}
    D-04_expiry_by_flag: {status: RESOLVED, empirical_proof: "expires_at_logical='t-1' -> DELEGATION_EXPIRED; parser handles t-1/t0/t+100/int."}
    D-05_scope_string_match: {status: RESOLVED, empirical_proof: "Read_Logs vs read_logs -> clean (canonical match, no false EXCEEDED)."}

  new_findings:
    D-06_empty_scope_treated_as_no_constraint:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_class: C-01_missing_skip  # empty-vs-missing variant, inside the new multi-hop mechanism
      locus: ["validators.check_delegation_root (line ~250 widening guard; line ~259 carry-forward)"]
      issue: >
        An empty allowed_surfaces set is treated as no-constraint (skip) instead of zero-scope (maximal
        restriction). Python falsiness conflates 'absent' and 'empty'. Line 250 'if previous_allowed and
        link_allowed and not subset' short-circuits when previous_allowed is empty (empty root scope or empty
        carried scope), so widening is not checked. Line 259 'previous_allowed = link_allowed or previous_
        allowed' makes an empty hop scope INHERIT the prior scope instead of zeroing it, so an intermediate hop
        with an empty scope erases narrowing and a later hop is compared against an earlier (wider) scope.
      empirical_proof: >
        E2 empty root scope, hops [admin] -> SLIPS (widening disabled for whole chain); E1 empty mid-hop C=[]
        then D restores [read,write,admin] -> SLIPS (C had [] but D gets all, uncaught); E3 control mid-hop
        C=[read] then D restores wide -> DELEGATION_CHAIN_SCOPE_WIDENED (caught). The E1/E3 difference proves
        the root: a non-empty intermediate catches restoration; an empty one does not.
      semantics: >
        A delegation with allowed_surfaces=[] means the delegate gets NO surfaces — the maximally narrow scope
        — so any later hop with a non-empty scope widens it. The error direction is fail-open (widening skipped
        -> scope escalation). Three states must be distinguished: scope absent (missing field) -> fail-safe
        Hold; scope empty ([]) -> zero permissions (all later is widening); scope non-empty -> normal
        narrowing. The code collapses absent and empty into 'falsy -> skip'.
      recommended_path: >
        (1) Widening: link_allowed - previous_allowed non-empty -> widened, regardless of whether previous is
        empty; drop the 'if previous_allowed' guard (use 'is not None'). If previous is zero scope (empty), any
        non-empty link -> widened. (2) Carry-forward: previous_allowed = link_allowed always (even empty), not
        'link_allowed or previous_allowed'. (3) Distinguish missing scope (Hold) from empty scope (zero
        permissions).

  progress_and_pattern_meta:
    velocity: "Delegation went v0.8->v0.9 in one turn: five findings closed, including multi-hop as a principle. Path to maturity is shorter than authority-markup (v0.1->v0.7) because the classes and remedies are known."
    same_pattern_as_authority_markup: >
      D-06 shows the same pattern authority-markup showed: a new mechanism (multi-hop iteration, the D-01 fix)
      introduces new logic (scope narrowing), which carries its own adversarial edge (empty scope as a C-01
      variant). As the authority-markup fixes opened a composition seam (C-09), the multi-hop mechanism opened
      an empty-scope seam. Each new mechanism meets adversarial input for the first time and carries its own
      edge — not a regression, a natural consequence.
    empty_vs_missing_note: >
      In delegation, an empty scope is the semantic opposite of an absent one: absent means 'unknown what is
      allowed' (fail-safe Hold), empty means 'zero allowed' (fail-closed, all later is escalation). Collapsing
      them into 'falsy -> skip' inverts maximal restriction (zero permissions) into absence of restriction (do
      not check) — exactly where delegation must be strictest, on monotone narrowing.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f"
    verdict: PASS_CHECKER_V0_9_DELEGATION_SECOND_PASS
    blocking: false
    prior_findings_resolved: [D-01, D-02, D-03, D-04, D-05]
    new_findings: [D-06]
    recommended_next:
      - "Fix D-06: distinguish missing/empty/non-empty scope; empty -> zero permissions; widening checked even when previous is empty; carry-forward does not inherit past an empty hop."
      - "Add fixtures: empty root scope + non-empty hop -> widened; empty intermediate hop + later restoration -> widened; missing scope -> Hold."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

All five prior delegation findings are closed, with D-01 (multi-hop) closed as a principle: the
chain is iterated, and per-hop validation fires on any hop — a middle hop emulated triggers
`DELEGATION_HOP_SIGNATURE_UNVERIFIED`, a widen at hop 3 triggers `DELEGATION_CHAIN_SCOPE_WIDENED`,
a broken identity at hop 2 triggers `DELEGATION_HOP_DELEGATOR_MISMATCH`, and sub-delegation when
unauthorized triggers `DELEGATION_SUBDELEGATION_NOT_AUTHORIZED`. D-02..D-05 are confirmed closed
by execution.

One new moderate finding (D-06), proven by execution: an empty `allowed_surfaces` set is treated
as no-constraint (skip) rather than zero-scope (maximal restriction). An empty root scope disables
the widening check for the whole chain (E2), and an empty intermediate hop scope erases narrowing
via carry-forward so a later hop restores a wider scope uncaught (E1); a non-empty intermediate
(E3 control) is caught. The fix is to distinguish missing/empty/non-empty scope and treat empty as
zero permissions.

PASS is a verdict on a hardened seed — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of D-01 (multi-hop as principle):**
```
middle hop emulated (b-sig)      -> DELEGATION_HOP_SIGNATURE_UNVERIFIED
widen at hop 3 (deep)            -> DELEGATION_CHAIN_SCOPE_WIDENED
broken identity chain hop 2      -> DELEGATION_HOP_DELEGATOR_MISMATCH
subdeleg when not authorized     -> DELEGATION_SUBDELEGATION_NOT_AUTHORIZED
```
**Closure of D-02..D-05:**
```
no request anywhere              -> DELEGATION_REQUEST_UNSPECIFIED
no delegate_id                   -> DELEGATION_DELEGATE_ID_MISSING
expires_at_logical='t-1'         -> DELEGATION_EXPIRED
Read_Logs vs read_logs           -> clean (canonical match)
```
**D-06 (empty scope as no-constraint):**
```
E2 empty root scope, hops [admin]                  -> SLIPS  (widening disabled whole chain)
E1 empty mid-hop C=[], D restores [read,write,admin] -> SLIPS  (uncaught)
E3 control mid-hop C=[read], D restores wide         -> DELEGATION_CHAIN_SCOPE_WIDENED  (caught)
```

---

## 4. New finding

### D-06 (moderate, non-blocking, empirically proven) — empty scope treated as no-constraint instead of zero-scope

An empty `allowed_surfaces` set is treated as no-constraint (skip) rather than zero-scope (maximal
restriction). Python falsiness conflates *absent* and *empty*. The widening guard short-circuits
when the previous scope is empty (empty root scope, or empty carried scope), so widening is not
checked (E2); and the carry-forward `previous_allowed = link_allowed or previous_allowed` makes an
empty hop scope inherit the prior scope instead of zeroing it, so an intermediate empty hop erases
narrowing and a later hop is compared against an earlier wider scope (E1). The E1/E3 difference
proves the root.

A delegation with `allowed_surfaces=[]` means the delegate gets **no** surfaces — the maximally
narrow scope — so any later hop with a non-empty scope widens it. The error direction is fail-open
(widening skipped -> scope escalation). Three states must be distinguished: scope **absent**
(missing field) -> fail-safe `Hold`; scope **empty** (`[]`) -> zero permissions (all later is
widening); scope **non-empty** -> normal narrowing. The code collapses absent and empty into
"falsy -> skip".

**Path:** (1) widening: `link_allowed - previous_allowed` non-empty -> widened, regardless of
whether previous is empty (drop the `if previous_allowed` guard, use `is not None`); if previous is
zero scope, any non-empty link -> widened. (2) carry-forward: `previous_allowed = link_allowed`
always (even empty). (3) distinguish missing scope (Hold) from empty scope (zero permissions).

---

## 5. Progress and pattern (observation)

Delegation went v0.8->v0.9 in one turn: five findings closed, including multi-hop as a principle.
The path to maturity is shorter than authority-markup (v0.1->v0.7) because the classes and remedies
are known.

D-06 shows the **same pattern** authority-markup showed: a new mechanism (multi-hop iteration, the
D-01 fix) introduces new logic (scope narrowing), which carries its own adversarial edge (empty
scope as a C-01 variant). As the authority-markup fixes opened a composition seam (C-09), the
multi-hop mechanism opened an empty-scope seam. Each new mechanism meets adversarial input for the
first time and carries its own edge — not a regression, a natural consequence.

In delegation, an empty scope is the semantic **opposite** of an absent one: absent means "unknown
what is allowed" (fail-safe Hold), empty means "zero allowed" (fail-closed, all later is
escalation). Collapsing them into "falsy -> skip" inverts maximal restriction into absence of
restriction — exactly where delegation must be strictest, on monotone narrowing.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f"
  supersedes_archive_sha256: "3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91"
  verdict: PASS_CHECKER_V0_9_DELEGATION_SECOND_PASS
  blocking: false
  prior_findings_resolved: [D-01, D-02, D-03, D-04, D-05]
  new_findings: [D-06]
  recommended_next:
    - "Fix D-06: distinguish missing/empty/non-empty scope; empty -> zero permissions; widening checked even when previous empty; carry-forward does not inherit past an empty hop."
    - "Add fixtures: empty root scope + non-empty hop -> widened; empty intermediate hop + restoration -> widened; missing scope -> Hold."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
