# Integration Review Record — c-calculus-checker v2.1 (INT-C closure: delegation × anchor revocation)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-07-02
**Record short name:** `CCALC_CHECKER_v2_1_INTEGRATION__b`
**Supersedes review:** `CCALC_CHECKER_v2_0_INTEGRATION__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v2_1_INTEGRATION__b
  record_version: "2.1"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v2_0_INTEGRATION__b

  reviewed_artifact:
    title: "c-calculus-checker v2.1 (anchor revocation integration closure)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-07-02"
    archive_sha256: "58d7ad1c770853e0416b8e9801c80828e68f8aeec2f51f8c97691eb60c5ea08f"
    supersedes_archive_sha256: "5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: int_c_closed_as_class_last_in_scope_seam
    meaning: >
      As a b-layer semantic reviewer I find INT-C closed as a CLASS: the checker now has a canonical root
      anchor lifecycle model, and revoked/non-active/missing/tampered/unverified/unknown root anchor states all
      annul or fail-close delegated authority (verified across all vectors). This closes the last open seam that
      exists in the checker's scope. Three mechanism edges are clean (independence from containment, clean stop
      of active execution, correct isolation to delegated status). One thin sub-seam candidate: root_anchor_state
      freshness (a stale observed_at is not checked). PASS is a verdict on a hardened core, NOT an authorization,
      NOT a certification, NOT a claim over the full 02 spec.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    INT-C_delegation_x_anchor_revocation:
      status: RESOLVED_AS_CLASS
      model_added: "anchor_contract.root_anchor_state {anchor_id, status, state_source, observed_at_logical} + root_anchor_state_hash; checked before delegated authority is valid."
      empirical_proof_all_vectors: >
        revoked / withdrawn -> DELEGATION_ROOT_ANCHOR_REVOKED; doubtful / unavailable / declared_fatigue ->
        DELEGATION_ROOT_ANCHOR_NOT_ACTIVE; state missing -> ROOT_ANCHOR_STATE_MISSING; hash mismatch (b tamper)
        -> ROOT_ANCHOR_STATE_HASH_MISMATCH; source=b -> ROOT_ANCHOR_STATE_SOURCE_UNVERIFIED; status missing ->
        ROOT_ANCHOR_STATE_STATUS_MISSING; status unknown -> ROOT_ANCHOR_STATE_UNKNOWN (fail-safe).
      lessons_transferred_ahead: >
        The new mechanism started with the accumulated vocabulary: hash-binding (C-02), source whitelist (C-01),
        unknown -> fail-safe. The root_anchor_state model mirrors the post-anchor state machine
        (revoked/doubtful/unavailable/declared_fatigue), the same bridge used in INT-08.

  mechanism_edges_clean:
    revoked_root_x_delegation_exceeds:
      result: "Both fire (ROOT_ANCHOR_REVOKED + DELEGATION_EXCEEDS + ACTIVE_EXECUTION_EXCEEDS). Independent checks; neither masks the other."
    revoked_root_x_active_execution:
      result: "DELEGATION_ROOT_ANCHOR_REVOKED. Root revocation stops the delegated branch cleanly."
    status_not_delegated_x_revoked_root:
      result: "CLEAN, and correct: root_anchor_state pertains to delegation lifecycle; if the contract is not delegated, root-anchor-under-delegation does not apply (handled by anchor_state_compatibility). Correct isolation, not a hole."

  new_sub_seam_candidate:
    root_anchor_state_freshness:
      severity: minor_to_moderate_by_semantics
      blocking: false
      empirically_proven: true
      recurring_class: temporal_validity  # D-04 date-expiry lineage, on root_anchor_state
      locus: ["validators root anchor lifecycle check (status checked, observed_at_logical freshness not checked)"]
      issue: >
        root_anchor_state.observed_at_logical is not checked for freshness. Delegated authority can rest on a
        STALE observation of the root anchor: observed 'active' long ago, the anchor may have been revoked since,
        but the stale state still shows active -> delegation holds on a stale observation. Same class as lease
        date-expiry (D-04), on root_anchor_state.
      empirical_proof: "stale observed_at (t-99999, very old) -> CLEAN (no freshness check)."
      honest_caveat: >
        Severity depends on whether the model has a TTL/freshness contract for anchor observations. The changelog
        calls it 'current root_anchor_state' ('current' implies freshness), and by analogy to lease (expires_at
        enforced) freshness should be checked; but this is the reviewer's inference from analogy, not a direct
        spec contract. minor if anchor observations are assumed instantaneous/always-fresh, moderate if a
        snapshot can go stale (which in a distributed system it can).
      recommended_path: >
        Add a freshness bound to root_anchor_state: observed_at_logical must be within a TTL of
        current_logical_time (like lease expires_at), else ROOT_ANCHOR_STATE_STALE | fail-closed. This closes the
        temporal side of the root anchor lifecycle — the status side (revoked/non-active) is closed, the temporal
        side (a stale active observation) is not.

  seam_plane_complete_in_scope:
    seams_closed:
      delegation_x_anchor_authority: "INT-01"
      delegation_x_lease_lifecycle: "INT-02/03/04"
      active_x_authority: "INT-05/06/07"
      authority_x_lease_downgrade: "INT-08"
      delegation_x_anchor_revocation: "INT-C (v2.1)"
      nonce_signature: "locally mature"
    remaining:
      root_anchor_state_freshness: "thin sub-seam candidate (this record)"
      viewport_x_review_binding: "out of scope — no subsystems in the checker"

  cumulative_curve_completed:
    observation: >
      The seams closed ever faster: delegation x anchor (INT-01, several turns as the first) -> active x
      authority (INT-05/06/07, a class but with the matrix pass) -> authority x lease (INT-08, one probe) ->
      delegation x anchor revocation (INT-C, one turn, with the whole vocabulary transferred ahead: hash-binding,
      source whitelist, unknown-fail-safe, the post-anchor mirror — all up front). The last seam was the cheapest
      because it inherited all accumulated capital. The cumulative curve observed on subsystems (7->4->2) and
      then honestly re-discovered on the seam plane has completed: both subsystems and their seams obey one law
      — each next element is cheaper because the vocabulary is cumulative.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "58d7ad1c770853e0416b8e9801c80828e68f8aeec2f51f8c97691eb60c5ea08f"
    verdict: PASS_CHECKER_V2_1_INT_C_CLOSED_LAST_IN_SCOPE_SEAM
    blocking: false
    prior_findings_resolved: [INT-C]
    sub_seam_candidates: [root_anchor_state_freshness]
    out_of_scope: [viewport_x_review_binding]
    recommended_next:
      - "Option 1: close the freshness sub-seam — add a TTL bound to root_anchor_state (narrow, closes the temporal side of the last seam)."
      - "Option 2: implement viewport / review-binding subsystems — the one uncovered stratum of spec 02 (a new subsystem front, fast on the curve)."
      - "Option 3 (recommended now): consolidate the witness chain into a DOC_MAP of all review records with lineage and hashes — 35 records as a navigable corpus, the form of the 'fifth ring'."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

INT-C is closed as a **class**. The checker now has a canonical root anchor lifecycle model
(`anchor_contract.root_anchor_state` + hash), checked before delegated authority is valid. Verified
across all vectors: revoked/withdrawn annul delegation (`DELEGATION_ROOT_ANCHOR_REVOKED`),
doubtful/unavailable/declared_fatigue are non-active (`DELEGATION_ROOT_ANCHOR_NOT_ACTIVE`), and
missing/tampered/unverified/missing-status/unknown-status all fail closed. The new mechanism started
with the accumulated vocabulary (hash-binding, source whitelist, unknown -> fail-safe), and the model
mirrors the post-anchor state machine — the same bridge used in INT-08.

This closes the last open seam that exists in the checker's scope. Three mechanism edges are clean:
revoked root and delegation-exceeds fire independently (neither masks the other); revoked root stops
active execution cleanly; and a non-delegated contract correctly does not trigger the root-anchor
check (correct isolation, not a hole).

One thin sub-seam candidate: `root_anchor_state` freshness — a stale `observed_at_logical` is not
checked, so delegated authority can rest on a stale "active" observation of the root anchor. Same
class as lease date-expiry, on root_anchor_state; the fix is a TTL bound.

PASS is a verdict on a hardened core — not an authorization, not a certification, not a claim over the
full 02 spec.

---

## 3. Empirical proof (executed)

**INT-C class closure (all vectors):**
```
revoked / withdrawn            -> DELEGATION_ROOT_ANCHOR_REVOKED
doubtful/unavailable/fatigue   -> DELEGATION_ROOT_ANCHOR_NOT_ACTIVE
state missing                  -> ROOT_ANCHOR_STATE_MISSING
hash mismatch (b tamper)       -> ROOT_ANCHOR_STATE_HASH_MISMATCH
source=b                       -> ROOT_ANCHOR_STATE_SOURCE_UNVERIFIED
status missing / unknown       -> STATUS_MISSING / UNKNOWN (fail-safe)
```
**Mechanism edges:**
```
revoked root + delegation exceeds -> ROOT_ANCHOR_REVOKED + DELEGATION_EXCEEDS + ACTIVE_EXECUTION_EXCEEDS (independent)
revoked root + active execution   -> DELEGATION_ROOT_ANCHOR_REVOKED (clean stop)
status != delegated + revoked root -> CLEAN (correct isolation)
```
**Sub-seam candidate:**
```
stale observed_at (t-99999)       -> CLEAN (no freshness check on root_anchor_state)
```

---

## 4. Prior finding closure

### INT-C (resolved as a class) — delegation x anchor revocation

The checker has a canonical root anchor lifecycle model, checked before delegated authority is valid.
Revoked/non-active/missing/tampered/unverified/unknown root anchor states all annul or fail-close
delegated authority (all vectors verified). Lessons transferred ahead (hash-binding, source whitelist,
unknown -> fail-safe); the model mirrors the post-anchor state machine.

---

## 5. New sub-seam candidate

### root_anchor_state freshness (minor->moderate by semantics, non-blocking, empirically proven)

`root_anchor_state.observed_at_logical` is not checked for freshness. Delegated authority can rest on
a stale observation of the root anchor: observed "active" long ago, the anchor may have been revoked
since, but the stale state still shows active. Same class as lease date-expiry (D-04), on
root_anchor_state. **Honest caveat:** severity depends on whether the model has a TTL/freshness
contract for anchor observations; the changelog calls it "current root_anchor_state" and by analogy to
lease freshness should be checked, but this is inference from analogy, not a direct spec contract.
**Path:** add a freshness bound — `observed_at_logical` within a TTL of `current_logical_time`, else
`ROOT_ANCHOR_STATE_STALE | fail-closed`. This closes the temporal side of the root anchor lifecycle;
the status side is closed, the temporal side is not.

---

## 6. Seam plane complete in scope, cumulative curve completed

All seams that exist in the checker are closed: delegation x anchor authority (INT-01), delegation x
lease lifecycle (INT-02/03/04), active x authority (INT-05/06/07), authority x lease downgrade
(INT-08), delegation x anchor revocation (INT-C, v2.1); nonce/signature locally mature. Remaining: the
thin freshness sub-seam candidate (this record) and viewport x review-binding (out of scope — no
subsystems in the checker).

The seams closed ever faster: INT-01 (several turns as the first) -> INT-05/06/07 (a class but with
the matrix pass) -> INT-08 (one probe) -> INT-C (one turn, the whole vocabulary transferred ahead).
The last seam was the cheapest because it inherited all accumulated capital. The cumulative curve
observed on subsystems (7->4->2) and then honestly re-discovered on the seam plane has completed: both
subsystems and their seams obey one law — each next element is cheaper because the vocabulary is
cumulative.

---

## 7. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed;
7. that the root_anchor_state freshness inference is a spec contract; it is the reviewer's analogy to lease freshness pending anchor/spec confirmation.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "58d7ad1c770853e0416b8e9801c80828e68f8aeec2f51f8c97691eb60c5ea08f"
  supersedes_archive_sha256: "5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79"
  verdict: PASS_CHECKER_V2_1_INT_C_CLOSED_LAST_IN_SCOPE_SEAM
  blocking: false
  prior_findings_resolved: [INT-C]
  sub_seam_candidates: [root_anchor_state_freshness]
  out_of_scope: [viewport_x_review_binding]
  recommended_next:
    - "Option 1: close the freshness sub-seam — add a TTL bound to root_anchor_state."
    - "Option 2: implement viewport / review-binding subsystems — the one uncovered stratum of spec 02."
    - "Option 3 (recommended now): consolidate the witness chain into a DOC_MAP of all review records with lineage and hashes."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*