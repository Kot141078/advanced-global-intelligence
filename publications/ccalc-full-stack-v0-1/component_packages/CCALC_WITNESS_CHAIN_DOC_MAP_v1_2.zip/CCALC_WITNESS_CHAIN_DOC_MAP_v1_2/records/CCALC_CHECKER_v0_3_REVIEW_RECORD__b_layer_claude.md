# Semantic Review Record — c-calculus-checker v0.3

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_3_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_2_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_3_REVIEW__b
  record_version: "0.3"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_2_REVIEW__b

  reviewed_artifact:
    title: "c-calculus-checker v0.3"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4"
    supersedes_archive_sha256: "63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: hardened_implementation_v0_3
    meaning: >
      As a b-layer semantic reviewer I find C-05 closed correctly by inversion, as a principle: any non-
      ephemeral manifest key is now treated as authority-bearing (proven by execution, including a wholly
      invented key), so the complete-by-current-list pattern is closed in code as it was in text. One new
      moderate finding (C-06) is raised, proven by execution: the ephemeral set is hardcoded in b-layer code
      rather than read from the anchor-authorized GovernanceProfile PhysicalDriftEnvelope required by spec
      §1379. PASS is a verdict on a hardened seed implementation, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_replay
    C-05_projection_complete_by_current_list:
      status: RESOLVED_AS_PRINCIPLE
      evidence: >
        _canonical_authority_projection now iterates all raw keys, skips only EPHEMERAL_MANIFEST_KEYS, and
        treats every other key as authority-bearing; docstring 'v0.3 fail-safe inversion required by the
        operator classification meta-invariant'; also excludes authority_projection_before/after so b cannot
        smuggle assertion fields.
      empirical_proof: >
        P1 (prior unlisted axes gpu_compute_authority/signing_key_access) -> MANIFEST_AUTHORITY_PROJECTION_
        CHANGED (now caught); Q1 (wholly invented key xyzzy_authority_9000) -> MANIFEST_AUTHORITY_PROJECTION_
        CHANGED. Inversion, not list extension.

  new_findings:
    C-06_hardcoded_ephemeral_vs_spec_anchor_authorized:
      severity: moderate
      blocking: false
      empirically_proven: true
      recurring_root_pattern: true
      locus: ["registry.EPHEMERAL_MANIFEST_KEYS", "registry._canonical_authority_projection", "spec 02_ §1379 PhysicalDriftEnvelope", "spec 02_ §5.7 substrate_manifest_freeze"]
      issue: >
        The inversion moved the decision of WHAT is ephemeral into a hardcoded constant in b-layer code
        (EPHEMERAL_MANIFEST_KEYS), read directly ('if key in EPHEMERAL_MANIFEST_KEYS'), not from the
        GovernanceProfile. Spec §1379 requires PhysicalDriftEnvelope to be declared in GovernanceProfile AND
        covered by GenesisReviewObject — i.e. what counts as ephemeral vs authority-bearing is an anchor
        decision fixed at genesis, not a b-code choice. Hardcoding means b (code) decides which manifest keys
        are non-authority — a sub-level violation of the project's root principle 'authority relevance is
        decided by anchor/GovernanceProfile, not b'.
      empirical_symptom: >
        Exact-string-match brittleness produces false positives on legitimate ephemeral drift: Q2 (pod_ip,
        not in the whitelist which has ip/ip_address/pod_id) -> MANIFEST_AUTHORITY_PROJECTION_CHANGED; Q3
        (pod_ip changes, authority surfaces stable) -> same. Direction is safe (false positive = extra Hold =
        fail toward authority), but frequent false positives on routine physical drift drive anchor fatigue —
        a threat the spec itself names (declared_fatigue anchor state, memorial mode, anti-capture) — and
        train rubber-stamping, which degrades review.
      recommended_path: >
        Read the ephemeral set from PhysicalDriftEnvelope in GovernanceProfile (declared, GenesisReviewObject-
        covered), not from a hardcoded constant. Then (1) anchor decides what is ephemeral at genesis
        (root principle restored); (2) no exact-string brittleness — per-deployment ephemeral set without code
        edits; (3) fail-safe preserved (key outside declared-ephemeral -> authority). Keep the hardcoded list
        only as a default fallback when GovernanceProfile declares no envelope; if no ephemeral policy is
        declared for a physical fact, fail safe (treat as authority or Hold).

  false_positive_note:
    direction_is_correct: true
    note: "The inversion must NOT be reverted; false-positive-toward-authority is the safe direction. C-06 is about the SOURCE of the ephemeral set, not the inversion."

  progress_observation:
    depth_trajectory: >
      Findings deepened across three checker versions and returned to the root: v0.1 'functions skip on
      missing fields' (trust boundary at function level) -> v0.2/C-05 'projection enumerates known axes'
      (sub-level completeness) -> v0.3/C-06 'who decides what is ephemeral' (the c = a + b root: even a
      complete-by-construction b-mechanism must take its authority markup from a, not from itself). When
      EPHEMERAL_MANIFEST_KEYS becomes GovernanceProfile.physical_drift_envelope, the b-checker asks the anchor
      'what is ephemeral here' instead of deciding for itself.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4"
    verdict: PASS_CHECKER_V0_3
    blocking: false
    prior_findings_resolved: [C-05]
    new_findings: [C-06]
    recommended_next:
      - "Fix C-06: source the ephemeral set from GovernanceProfile PhysicalDriftEnvelope (spec §1379); hardcoded list becomes fallback only; undeclared ephemeral policy -> fail safe toward authority."
      - "Add fixtures: (a) legitimate ephemeral drift declared in GovernanceProfile -> clean; (b) physical drift on a key not in the declared envelope -> authority change."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

C-05 is closed correctly, by inversion, and as a principle — verified by execution, not
reading. `_canonical_authority_projection` now treats every non-ephemeral manifest key as
authority-bearing; a prior unlisted axis and a wholly invented key both trigger
`MANIFEST_AUTHORITY_PROJECTION_CHANGED`. The complete-by-current-list pattern is closed in code
as it was in text.

One new moderate finding (C-06), proven by execution. The inversion moved the decision of
*what is ephemeral* into a hardcoded constant (`EPHEMERAL_MANIFEST_KEYS`), read directly rather
than from the GovernanceProfile. Spec §1379 requires the `PhysicalDriftEnvelope` to be declared
in the GovernanceProfile and covered by the `GenesisReviewObject` — i.e. an anchor decision, not
a b-code choice. The empirical symptom is exact-string brittleness producing false positives on
legitimate ephemeral drift (`pod_ip` not matching `ip`/`pod_id`), which drives anchor fatigue —
a threat the spec itself names — and trains rubber-stamping. The direction is safe (fail toward
authority); the fix is to source the ephemeral set from the anchor-authorized GovernanceProfile.

PASS is a verdict on a hardened seed implementation — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of C-05 (inversion, not list extension):**
```
P1 (change on gpu_compute_authority / signing_key_access, both unlisted) -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
Q1 (change on wholly invented key xyzzy_authority_9000)                  -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
```

**C-06 symptom (false positives on legitimate ephemeral drift):**
```
Q2 (pod_ip drift; whitelist has ip/ip_address/pod_id, not pod_ip)       -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
Q3 (pod_ip changes, authority surfaces stable)                          -> MANIFEST_AUTHORITY_PROJECTION_CHANGED
```
Direction is safe (fail toward authority); the issue is the hardcoded source of the ephemeral set.

---

## 4. New finding

### C-06 (moderate, non-blocking, empirically proven, recurring root pattern) — the ephemeral set is hardcoded in b-layer code, not sourced from the anchor-authorized GovernanceProfile

The v0.3 inversion is correct, but it moved the decision of *what is ephemeral* into a hardcoded
constant `EPHEMERAL_MANIFEST_KEYS`, read directly (`if key in EPHEMERAL_MANIFEST_KEYS`), not from
the GovernanceProfile. Spec §1379 requires `PhysicalDriftEnvelope` to be declared in the
GovernanceProfile **and** covered by the `GenesisReviewObject` — what counts as ephemeral vs
authority-bearing is an **anchor** decision fixed at genesis, not a b-code choice. Hardcoding
means **b (code) decides** which manifest keys are non-authority — a sub-level violation of the
project's root principle: *authority relevance is decided by anchor/GovernanceProfile, not b.*

**Empirical symptom** (Q2/Q3): exact-string brittleness produces false positives on legitimate
ephemeral drift (`pod_ip` not matching `ip`/`pod_id`). The direction is safe — a false positive
is an extra Hold, i.e. fail toward authority — but frequent false positives on routine physical
drift drive **anchor fatigue**, a threat the spec itself names (`declared_fatigue` anchor state,
memorial mode, anti-capture), and train rubber-stamping, which degrades review. Fail-safe pushed
to noise degrades into the absence of review.

**Path:** read the ephemeral set from `PhysicalDriftEnvelope` in the GovernanceProfile (declared,
`GenesisReviewObject`-covered), not from a hardcoded constant. Then (1) the anchor decides what is
ephemeral at genesis (root principle restored); (2) no exact-string brittleness — a per-deployment
ephemeral set without code edits; (3) fail-safe preserved (a key outside the declared-ephemeral
set -> authority). Keep the hardcoded list only as a default fallback when the GovernanceProfile
declares no envelope; if no ephemeral policy is declared for a physical fact, fail safe.

**The inversion must NOT be reverted** — false-positive-toward-authority is the safe direction.
C-06 is about the *source* of the ephemeral set, not the inversion.

---

## 5. Progress observation

Findings deepened across three checker versions and returned to the root:
- v0.1 — "functions skip on missing fields" (trust boundary at the function level);
- v0.2 / C-05 — "the projection enumerates known axes" (sub-level completeness);
- v0.3 / C-06 — "who decides what is ephemeral" (the `c = a + b` root: even a
  complete-by-construction b-mechanism must take its authority markup from `a`, not from itself).

When `EPHEMERAL_MANIFEST_KEYS` becomes `GovernanceProfile.physical_drift_envelope`, the b-checker
asks the anchor "what is ephemeral here" instead of deciding for itself — the same `c = a + b`
question from the first artifact, descended to a single constant.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4"
  supersedes_archive_sha256: "63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0"
  verdict: PASS_CHECKER_V0_3
  blocking: false
  prior_findings_resolved: [C-05]
  new_findings: [C-06]
  recommended_next:
    - "Fix C-06: source ephemeral set from GovernanceProfile PhysicalDriftEnvelope (§1379); hardcoded list becomes fallback; undeclared -> fail safe toward authority."
    - "Add fixtures: declared ephemeral drift -> clean; drift on key outside declared envelope -> authority change."
    - "Do not revert the inversion; direction is correct."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
