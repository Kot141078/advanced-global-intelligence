# Semantic Review Record — c-calculus-checker v1.0 (delegation subsystem, third pass)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v1_0_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_9_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_0_REVIEW__b
  record_version: "1.0"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_9_REVIEW__b
  subsystem_under_review: delegation_chains

  reviewed_artifact:
    title: "c-calculus-checker v1.0 (delegation subsystem, third pass)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae"
    supersedes_archive_sha256: "4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: delegation_third_pass_near_maturity
    meaning: >
      As a b-layer semantic reviewer I find D-06 closed by a three-state scope distinction
      (missing/empty/non-empty), proven by execution, with no authority-markup regression. One new
      minor-moderate finding (D-07) is raised, proven by contrast: a missing scope on an intermediate hop
      sets previous_allowed=None, which disables downstream widening — an asymmetry with the just-introduced
      empty branch, which catches downstream. PASS is a verdict on a hardened seed, NOT an authorization,
      NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    verification_method: source_reread_plus_empirical_attack
    D-06_empty_scope:
      status: RESOLVED_AS_PRINCIPLE
      evidence: "_check_scope_bound distinguishes missing/empty/non-empty; widening uses is-not-None (line 264); carry-forward preserves an explicit empty set (lines 275-278: if link_allowed is not None -> previous = link_allowed else None); requested surfaces distinguish missing (UNSPECIFIED) from explicit empty (valid)."
      empirical_proof: "E2 empty root + hop admin -> CHAIN_SCOPE_WIDENED; E1 empty mid-hop + restoration -> CHAIN_SCOPE_WIDENED; E3 control non-empty narrowing -> CHAIN_SCOPE_WIDENED; missing allowed_surfaces -> SCOPE_MISSING; explicit empty request -> valid."
    no_authority_markup_regression:
      status: VERIFIED
      evidence: "A6 alias roles->pod_id -> AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED; full suite (incl valid_minimal_genesis) PASS. The two subsystems coexist without mutual damage."

  new_findings:
    D-07_missing_scope_disables_downstream_widening:
      severity: minor_moderate
      blocking: false
      empirically_proven: true
      recurring_class: C-01_missing_skip  # downstream effect of the new three-state logic's missing branch
      locus: ["validators.check_delegation_root (line ~264 widening guard; line ~278 carry-forward None)"]
      issue: >
        A missing scope on an intermediate hop makes _check_scope_bound return None, so carry-forward sets
        previous_allowed=None, and the widening guard 'if previous_allowed is not None' short-circuits — so a
        later hop's widening is not checked. Although SCOPE_MISSING is flagged on the missing hop, downstream
        widening is invisible. This is an asymmetry inside the new three-state logic: an empty scope
        (previous=set()) catches downstream widening (E1), but a missing scope (previous=None) disables it.
        Missing is semantically MORE dangerous than empty (empty = 'zero, known'; missing = 'unknown what is
        allowed'), yet is handled less strictly downstream.
      empirical_proof: >
        Contrast with E1: empty mid-hop C=[] then hop3 restores wide -> CHAIN_SCOPE_WIDENED (caught); missing
        mid-hop C then hop3 restores wide -> no WIDEN (only SCOPE_MISSING). Same restoration, opposite result.
      mitigating: "SCOPE_MISSING is flagged, so the chain has a finding; on a re-pass after fixing the missing scope, downstream widening is finally caught. But in a single pass a missing scope masks downstream widening, and the missing/empty asymmetry is backwards from fail-safe."
      recommended_path: >
        On a missing scope at a hop, set previous_allowed = set() (zero, conservative) instead of None, so
        downstream widening catches all later grants — consistent with empty=zero. OR: a missing scope ->
        immediate fail-closed of the whole chain (chain-broken flag), downstream not processed as valid. The
        first makes the three states consistent downstream: both empty and missing are treated downstream as
        zero (catch escalation), differing only in their own finding (empty valid, missing -> SCOPE_MISSING).

  converging_angle_meta:
    observation: >
      The D-06 fix introduced three-state logic (missing/empty/non-empty), resolving the empty=missing
      conflation from v0.9. But the new distinction itself opened D-07: the code now correctly separates empty
      (->zero->catches downstream) from missing (->None->does not catch downstream), and the missing branch has
      its own unfinished corner. Same pattern as the whole series: each fix, resolving one conflation,
      introduces new logic, and the new logic carries its own edge (authority-markup fix -> composition seam
      C-09; multi-hop fix -> empty-scope seam D-06; three-state fix -> missing-downstream seam D-07).
    convergence: >
      But the angle narrows each turn. C-01 (v0.1) disabled checks for whole field classes. D-06 (v0.9)
      disabled widening for an empty scope. D-07 (v1.0) disables downstream widening only when an intermediate
      hop has a missing scope, and SCOPE_MISSING is already flagged. A converging sequence: each turn the
      finding is thinner, needs more specific conditions, and is more covered by prior checks. This is what a
      system approaching maturity looks like — not 'no bugs', but 'the remaining bugs are ever thinner,
      narrower, and more shielded'.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae"
    verdict: PASS_CHECKER_V1_0_DELEGATION_THIRD_PASS
    blocking: false
    prior_findings_resolved: [D-06]
    new_findings: [D-07]
    recommended_next:
      - "Fix D-07: missing scope at a hop -> previous_allowed = set() (conservative zero) or fail-closed chain; make missing/empty consistent downstream."
      - "Add fixtures: missing intermediate hop scope + later widening -> both SCOPE_MISSING and CHAIN_SCOPE_WIDENED."
      - "Then delegation reaches the adversarial maturity authority-markup had at v0.7; consider next subsystem (lease cascade, viewport, review-binding)."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

D-06 is closed by a three-state scope distinction — missing, empty, and non-empty are now separate
states, verified by execution: an empty root scope with a granting hop is caught
(`DELEGATION_CHAIN_SCOPE_WIDENED`, E2), an empty intermediate hop no longer erases narrowing (E1), a
non-empty narrowing still works (E3), a missing `allowed_surfaces` is flagged (`DELEGATION_SCOPE_
MISSING`), and an explicit empty request is valid. There is no authority-markup regression (A6 alias
redirect still caught; full suite PASS).

One new minor-moderate finding (D-07), proven by contrast: a missing scope on an intermediate hop
sets `previous_allowed=None`, so the widening guard short-circuits and a later hop's widening is not
checked — the same restoration that is caught for an empty hop (E1) is missed for a missing hop.
Missing is more dangerous than empty yet handled less strictly downstream. The fix is to treat a
missing scope as conservative zero downstream (or fail-closed), making the three states consistent.

PASS is a verdict on a hardened seed — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

**Closure of D-06 (three-state scope):**
```
E2 empty root scope, hop admin           -> DELEGATION_CHAIN_SCOPE_WIDENED
E1 empty mid-hop, D restores wide        -> DELEGATION_CHAIN_SCOPE_WIDENED
E3 control non-empty narrowing           -> DELEGATION_CHAIN_SCOPE_WIDENED
missing allowed_surfaces                 -> DELEGATION_SCOPE_MISSING
explicit empty request                   -> valid (no UNSPECIFIED)
```
**No authority-markup regression:**
```
A6 alias roles->pod_id                   -> AUTHORITY_AXIS_SCHEMA_REDIRECTS_CORE_AXIS + MANIFEST_AUTHORITY_PROJECTION_CHANGED
full suite                               -> PASS
```
**D-07 (missing scope disables downstream widening) — contrast with E1:**
```
empty mid-hop C=[],  hop3 restores wide  -> DELEGATION_CHAIN_SCOPE_WIDENED  (caught)
missing mid-hop C,   hop3 restores wide  -> no WIDEN (only SCOPE_MISSING)   (not caught)
```

---

## 4. New finding

### D-07 (minor-moderate, non-blocking, empirically proven) — missing scope disables downstream widening

A missing scope on an intermediate hop makes `_check_scope_bound` return None, so carry-forward sets
`previous_allowed=None`, and the widening guard `if previous_allowed is not None` short-circuits — a
later hop's widening is not checked (proven by contrast with E1: same restoration, empty hop caught,
missing hop missed). Although `SCOPE_MISSING` is flagged, downstream widening is invisible. This is
an asymmetry inside the new three-state logic: empty (`previous=set()`) catches downstream widening,
but missing (`previous=None`) disables it. Missing is semantically more dangerous than empty yet is
handled less strictly.

Mitigating: `SCOPE_MISSING` is flagged, so the chain has a finding; on a re-pass after fixing the
missing scope, downstream widening is finally caught. But in a single pass a missing scope masks
downstream widening, and the missing/empty asymmetry is backwards from fail-safe.

**Path:** on a missing scope at a hop, set `previous_allowed = set()` (conservative zero) instead of
None, so downstream widening catches all later grants — consistent with empty=zero. Or a missing
scope -> immediate fail-closed of the whole chain. The first makes the three states consistent
downstream: both empty and missing are treated downstream as zero, differing only in their own
finding.

---

## 5. Converging angle (observation)

The D-06 fix introduced three-state logic (missing/empty/non-empty), resolving the empty=missing
conflation from v0.9. But the new distinction itself opened D-07: the code now correctly separates
empty (->zero->catches downstream) from missing (->None->does not catch downstream), and the missing
branch has its own unfinished corner. Same pattern as the whole series: each fix, resolving one
conflation, introduces new logic, and the new logic carries its own edge — authority-markup fix ->
composition seam (C-09); multi-hop fix -> empty-scope seam (D-06); three-state fix ->
missing-downstream seam (D-07).

But the angle narrows each turn. C-01 (v0.1) disabled checks for whole field classes; D-06 (v0.9)
disabled widening for an empty scope; D-07 (v1.0) disables downstream widening only when an
intermediate hop has a missing scope, and `SCOPE_MISSING` is already flagged. A converging sequence:
each turn the finding is thinner, needs more specific conditions, and is more shielded by prior
checks. This is what a system approaching maturity looks like — not "no bugs", but "the remaining
bugs are ever thinner, narrower, and more shielded". One small fix (missing -> conservative zero
downstream) and delegation reaches the adversarial maturity authority-markup had at v0.7.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae"
  supersedes_archive_sha256: "4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f"
  verdict: PASS_CHECKER_V1_0_DELEGATION_THIRD_PASS
  blocking: false
  prior_findings_resolved: [D-06]
  new_findings: [D-07]
  recommended_next:
    - "Fix D-07: missing scope at a hop -> conservative zero downstream or fail-closed chain; make missing/empty consistent."
    - "Add fixtures: missing intermediate hop scope + later widening -> SCOPE_MISSING and CHAIN_SCOPE_WIDENED."
    - "Then consider next subsystem (lease cascade, viewport, review-binding)."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
