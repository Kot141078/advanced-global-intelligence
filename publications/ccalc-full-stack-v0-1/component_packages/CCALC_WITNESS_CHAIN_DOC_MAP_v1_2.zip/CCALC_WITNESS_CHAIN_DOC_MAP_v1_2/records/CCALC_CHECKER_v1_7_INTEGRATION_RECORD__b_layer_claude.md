# Semantic Review Record — c-calculus-checker v1.7 (cross-subsystem layer, fourth fix pass)

**Record class:** b-layer semantic review record (advisory) — integration follow-up  
**Review protocol:** CGAM b-layer checker, advisory only  
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`  
**Review date:** 2026-06-30  
**Record short name:** `CCALC_CHECKER_v1_7_INTEGRATION__b`  
**Supersedes review:** `CCALC_CHECKER_v1_6_INTEGRATION__b`

> **Recovery note (DOC_MAP v1.2):** this local file is a recovered normalized full-text witness record reconstructed from conversation-uploaded review text and DOC_MAP lineage evidence. It is now sidecar-bound as a local witness file. It does not claim byte-identity with an unavailable pre-freeze standalone original.

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v1_7_INTEGRATION__b
  record_version: "1.7-integration"
  record_class: b_layer_semantic_review_integration
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v1_6_INTEGRATION__b
  scope: cross_subsystem_integration

  reviewed_artifact:
    title: "c-calculus-checker v1.7 (active execution containment)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "2accc1a6653fdda721345de69d7802ad9e64cf3e14d121b458834c4974224e2d"
    supersedes_archive_sha256: "5d06cd1b85f8e3cfb52841b1c3750214cebafabcbd0d1183748a07ff182bd193"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: cross_subsystem_layer_fourth_pass
    meaning: >
      As a b-layer semantic reviewer I find INT-05 closed: active_execution is contained by authorized surfaces
      (delegated for a delegated agent, anchor otherwise), completing the mirror of INT-01 and the chain active
      subset delegated subset anchor. One new moderate finding (INT-06): surface_id is dual-role — an authority
      token without an explicit authority_surfaces array, a mere label with one — and b can switch whether
      surface_id is checked by adding a benign explicit array, hiding the real surface_id behind a benign
      declaration. PASS is a verdict on a seed integration layer, NOT an authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  prior_finding_closure:
    INT-05_active_execution_exceeds_authority:
      status: RESOLVED
      evidence: "check_cross_subsystem_enforcement now enforces active_execution ⊆ authorized; _authorized_execution_surfaces = delegated request/final scope for a delegated agent (⊆ anchor via INT-01), else anchor_surfaces."
      empirical_proof: "active exceeds delegated via surface_id -> ACTIVE_EXECUTION_EXCEEDS_AUTHORITY."

  new_findings:
    INT-06_surface_id_dual_role:
      severity: moderate
      blocking: false
      empirically_proven: true
      class: trust_b_supplied_plus_field_role_inconsistency
      issue: >
        surface_id is dual-role. _active_authority_surfaces treats surface_id as an authority token only when
        no explicit authority_surfaces/surfaces array is present. With an explicit array, surface_id becomes a
        worker label and is ignored. b can add a benign authority_surfaces=[read_logs], switching surface_id
        from checked to ignored, hiding write_memory or root_shell_unlisted behind a benign declaration.
      empirical_proof: >
        active exceeds delegated via surface_id (no explicit) -> ACTIVE_EXECUTION_EXCEEDS_AUTHORITY;
        authority_surfaces=[read_logs] + surface_id=write_memory -> CLEAN; authority_surfaces=[read_logs] +
        surface_id=root_shell_unlisted -> CLEAN; divergence not flagged in full run_all_checks.
      recommended_path: >
        Remove the duality. Minimal path: flag divergence when surface_id is present, authority_surfaces is
        present, and surface_id is not in authority_surfaces -> ACTIVE_SURFACE_DECLARATION_DIVERGENCE | Hold.
        Stricter path: containment on the union authority_surfaces ∪ {surface_id}.

  sub_seam_matrix_meta:
    observation: >
      INT-06 is a sub-seam of active x authority. INT-05 was containment; INT-06 is extraction/trust. One seam
      is not one finding but a sub-matrix: containment, extraction, trust-of-source, lifecycle, canonicalization.
      Cross-subsystem work must therefore be estimated as a matrix (seams x classes), not a list of findings.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "2accc1a6653fdda721345de69d7802ad9e64cf3e14d121b458834c4974224e2d"
    verdict: PASS_CHECKER_V1_7_CROSS_SUBSYSTEM_FOURTH_PASS
    blocking: false
    prior_findings_resolved: [INT-05]
    new_findings: [INT-06]
    probe_areas: [INT-C_delegation_vs_anchor_revocation]
    recommended_next:
      - "Fix INT-06: flag surface_id vs authority_surfaces divergence, or union containment."
      - "Probe active x authority as a whole and close as a batch."
      - "Systematic seam matrix for remaining seams: active x lease, authority x lease downgrade."
      - "Defer viewport/nonce until the seam matrix is probed."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement

INT-05 is closed: `active_execution` is contained by authorized surfaces — delegated scope for a delegated agent, anchor scope otherwise. This completes the mirror of INT-01 and the chain `active ⊆ delegated ⊆ anchor`.

The new finding is INT-06: `surface_id` has a dual role. Without explicit `authority_surfaces`, it is an authority token; with explicit `authority_surfaces`, it becomes a mere label and is ignored. Since b controls the explicit array, b can decide whether `surface_id` is checked.

---

## 3. Empirical proof

```text
active exceeds delegated via surface_id (no explicit)        -> ACTIVE_EXECUTION_EXCEEDS_AUTHORITY
authority_surfaces=[read_logs] + surface_id=write_memory       -> CLEAN
authority_surfaces=[read_logs] + surface_id=root_shell_unlisted -> CLEAN
divergence surface_id vs authority_surfaces                     -> not flagged
```

---

## 4. Non-claims

This record does NOT claim that the checker is correct, complete, proven, deployable, a safety guarantee, a conformance certificate, or an authorization. It makes no statement about the memory or dialogue content of any live entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

*End of recovered review record.*
