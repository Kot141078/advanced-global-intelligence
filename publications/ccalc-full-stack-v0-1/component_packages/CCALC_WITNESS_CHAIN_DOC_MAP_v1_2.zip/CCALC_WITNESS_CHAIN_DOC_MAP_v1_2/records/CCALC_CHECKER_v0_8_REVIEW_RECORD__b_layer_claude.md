# Semantic Review Record — c-calculus-checker v0.8 (delegation subsystem, first adversarial pass)

**Record class:** b-layer semantic review record (advisory)
**Review protocol:** CGAM b-layer checker, advisory only
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`
**Review date:** 2026-06-30
**Record short name:** `CCALC_CHECKER_v0_8_REVIEW__b`
**Supersedes review:** `CCALC_CHECKER_v0_7_REVIEW__b`

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_CHECKER_v0_8_REVIEW__b
  record_version: "0.8"
  record_class: b_layer_semantic_review
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]
  supersedes_review: CCALC_CHECKER_v0_7_REVIEW__b
  subsystem_under_review: delegation_chains

  reviewed_artifact:
    title: "c-calculus-checker v0.8 (delegation subsystem)"
    artifact_type: python_implementation
    project: "Self-Evo / Ester / c = a + b"
    artifact_date: "2026-06-30"
    archive_sha256: "3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91"
    supersedes_archive_sha256: "6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16"
    implements_spec:
      doc_02_v0_1_5_sha256: "1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d"
    verification_basis: source_code_and_empirical_execution

  verdict:
    result: PASS
    qualifier: delegation_first_adversarial_pass
    meaning: >
      As a b-layer semantic reviewer I find v0.8 a sound first adversarial pass on the delegation subsystem:
      the single-hop root/scope/identity/lifecycle checks are correct and key authority-markup lessons are
      transferred ahead of time (whitelist root source, computed scope/delegate hashes). But multi-hop
      delegation is unsupported (D-01, which the author's own note predicted), and three C-01-class
      missing->skip gaps (D-02/D-03/D-04) plus one C-06-class string-match (D-05) are present. The subsystem
      is roughly where authority-markup was at v0.1. PASS is a verdict on a first-pass seed, NOT an
      authorization, NOT a certification.
    blocking_findings: 0
    safety_escalations: 0

  lessons_transferred_ahead:
    note: "Authority-markup lessons already applied to delegation before this review, a good sign the method transfers."
    items:
      - "_root_source_valid uses a whitelist (in ROOT_ANCHOR_SIGNATURE_SOURCES), not a blacklist — the C-01 membership lesson; missing/variant signature_source is caught."
      - "delegation_scope_hash and delegate_id_hash are COMPUTED by the checker (hash_object), not taken b-supplied — the C-02 lesson."

  findings:
    D-01_multi_hop_unsupported:
      severity: significant
      blocking: false
      empirically_proven: true
      predicted_by_author: true
      locus: ["validators.check_delegation_root"]
      issue: >
        check_delegation_root reads only root_envelope + a single scope + a single delegate_id; there is no
        iteration over a chain of hops (grep for multi-hop iteration returns nothing). A delegation chain is
        multi-hop by definition; the invariant is that every hop is valid, non-emulable, and scope-narrowing
        (S_C subset S_B subset S_A). The checker validates only the first hop.
      empirical_proof: >
        D-01a intermediate hop emulated (b-signed) + scope widened to admin_root -> CLEAN; D-01b chain_links
        escalating scope -> CLEAN. Intermediate links are invisible.
      recommended_path: >
        Iterate the whole chain. For each hop_i (delegate_{i-1} -> delegate_i): (a) the signer's
        signature_source in ROOT_ANCHOR_SIGNATURE_SOURCES or a valid prior delegate authorized to sub-delegate;
        (b) scope_i subset scope_{i-1} (monotone narrowing; a hop may not widen); (c) delegate_id_i bound by
        hash; (d) every hop covered by a signature tracing back to the root anchor. Only the root comes from the
        original anchor; every later hop narrows. Chain valid iff all hops valid AND scope narrows monotonically.
    D-02_scope_enforcement_inert_without_request:
      severity: moderate
      blocking: false
      recurring_class: C-01_missing_skip
      empirically_proven: true
      locus: ["validators.check_delegation_root (requested_surfaces)"]
      issue: "if requested_surfaces is absent everywhere (chain, delegated_authority_request, anchor_surfaces fallback), the SCOPE_EXCEEDED check is skipped. Proven: no request anywhere -> CLEAN. Scope enforcement relies on request presence; absence = no check."
      recommended_path: "requested_surfaces absent for an active delegation -> DELEGATION_REQUEST_UNSPECIFIED | Hold, not a silent scope skip."
    D-03_delegate_id_absent_identity_skipped:
      severity: moderate
      blocking: false
      recurring_class: C-01_missing_skip
      empirically_proven: true
      locus: ["validators.check_delegation_root (delegate_id is not None)"]
      issue: "if delegate_id is omitted entirely, the whole identity-binding check is skipped. Proven: no delegate_id -> CLEAN. The root passes bound to no delegate. Spec: 'root must bind delegate identity', so absence must fail, not skip."
      recommended_path: "delegate_id absent -> DELEGATION_DELEGATE_ID_MISSING | Reject."
    D-04_expiry_by_flag_not_date:
      severity: moderate
      blocking: false
      recurring_class: C-01_missing_skip
      empirically_proven: true
      locus: ["validators.check_delegation_root (expired flag)"]
      issue: "expiry is checked only via the expired / expiry_status flag, not expires_at_logical vs current time. Proven: expires_at_logical='t-1' (past) with no flag -> CLEAN; expired=true -> DELEGATION_EXPIRED (control). Spec: 'expired delegation fails closed', but date-based expiry is not computed."
      recommended_path: "compute expiry from expires_at_logical against current logical time, not only the flag."
    D-05_scope_surface_string_match:
      severity: minor
      blocking: false
      recurring_class: C-06_string_match
      empirically_proven: true
      locus: ["validators.check_delegation_root (set.issubset on surfaces)"]
      issue: "scope surfaces compared by exact string (set.issubset). Proven: requested Read_Logs vs allowed read_logs -> DELEGATION_SCOPE_EXCEEDED (case variant). False-positive direction is safe (fail toward restriction), but scope-surface equivalence is brittle to name variants."
      recommended_path: "canonicalize surface names before scope comparison (the same _normalise_axis_token already used for authority axes)."

  class_transfer_meta:
    observation: >
      Delegation's first adversarial pass leaks along the SAME classes as authority-markup: C-01 missing->skip
      (D-02/D-03/D-04), C-06 string-match (D-05), plus a new structural gap specific to delegation (multi-hop,
      D-01). The finding classes transfer between subsystems because they are not about a specific mechanism but
      about how an implementation meets adversarial input: trusting a field's presence, identity by string, and
      incomplete handling of a structure.
    asymmetry: >
      Foundational lessons (whitelist root source, computed hashes) were transferred ahead of time — they are
      now part of the engineering vocabulary after authority-markup. But the delegation-specific expressions of
      the same classes (multi-hop, delegation-field missing->skip) are fresh, because they live in a new
      structure. General principle transfers; concrete expression needs a new adversarial pass — which is why
      each subsystem should be passed separately rather than assumed covered by prior hardening.

  handoff:
    from: b_layer_reviewer
    to: c_gate_review_queue
    artifact_sha256: "3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91"
    verdict: PASS_CHECKER_V0_8_DELEGATION_FIRST_PASS
    blocking: false
    findings: [D-01, D-02, D-03, D-04, D-05]
    must_fix: [D-01, D-02, D-03, D-04]
    recommended_next:
      - "Fix D-01: iterate the whole chain with per-hop validation and monotone scope narrowing."
      - "Fix D-02/D-03/D-04: missing delegation fields fail safe (request unspecified -> Hold; delegate_id missing -> Reject; expiry computed from date)."
      - "Fix D-05: canonicalize surface names before scope comparison."
      - "Add multi-hop fixtures: valid narrowing chain; emulated intermediate hop; scope-widening hop; broken identity chain."
    record_sha256: "PLACEHOLDER__compute_on_freeze"
```

---

## 2. Verdict statement (human-readable)

A sound first adversarial pass on the delegation subsystem. The single-hop checks are correct,
and — notably — key authority-markup lessons are transferred ahead of time: `_root_source_valid`
uses a whitelist (the C-01 membership lesson, so missing/variant `signature_source` is caught),
and `delegation_scope_hash` / `delegate_id_hash` are computed by the checker (the C-02 lesson).

But multi-hop delegation is unsupported (D-01, which the author's own note predicted): the checker
validates only the first hop, so an emulated, scope-widening intermediate hop is invisible (proven).
Three C-01-class missing->skip gaps are present — scope enforcement inert without a request (D-02),
delegate identity skipped when `delegate_id` is absent (D-03), expiry checked by flag not date
(D-04) — plus one C-06-class string-match on scope surfaces (D-05). The subsystem is roughly where
authority-markup was at v0.1.

PASS is a verdict on a first-pass seed — not an authorization, not a certification.

---

## 3. Empirical proof (executed)

```
valid baseline                                  -> clean
D-01a hop emulated + scope widened to admin_root -> CLEAN  (intermediate hop unchecked)
D-01b chain_links escalate scope                 -> CLEAN  (chain_links ignored)
D-02 no request anywhere                         -> CLEAN  (scope enforcement inert)
D-03 no delegate_id                              -> CLEAN  (identity binding skipped)
D-04 expires_at_logical='t-1' (past), no flag    -> CLEAN  (date-based expiry not caught)
D-04 control expired flag=true                   -> DELEGATION_EXPIRED
D-05 requested Read_Logs vs allowed read_logs    -> DELEGATION_SCOPE_EXCEEDED  (case variant)
```

---

## 4. Findings (detail)

### D-01 (significant, non-blocking, empirically proven, author-predicted) — multi-hop delegation is unsupported

`check_delegation_root` reads only `root_envelope` + a single `scope` + a single `delegate_id`;
there is no iteration over a chain of hops. A delegation chain is multi-hop by definition, and the
invariant is that every hop is valid, non-emulable, and scope-narrowing (`S_C ⊆ S_B ⊆ S_A`). The
checker validates only the first hop, so an emulated intermediate hop that widens scope to
`admin_root` is invisible (D-01a).

**Path:** iterate the whole chain. For each hop_i (delegate_{i-1} -> delegate_i): (a) the signer's
`signature_source` in `ROOT_ANCHOR_SIGNATURE_SOURCES` or a valid prior delegate authorized to
sub-delegate; (b) `scope_i ⊆ scope_{i-1}` (monotone narrowing; a hop may not widen); (c)
`delegate_id_i` bound by hash; (d) every hop covered by a signature tracing to the root anchor.
Only the root comes from the original anchor; every later hop narrows. Chain valid iff all hops
valid AND scope narrows monotonically.

### D-02 / D-03 / D-04 (moderate, non-blocking, C-01 missing->skip class)

- **D-02** — scope enforcement is inert when `requested_surfaces` is absent everywhere; the
  `SCOPE_EXCEEDED` check is skipped (proven CLEAN). Path: absent request -> `DELEGATION_REQUEST_
  UNSPECIFIED | Hold`.
- **D-03** — when `delegate_id` is omitted, identity binding is skipped and the root passes bound
  to no delegate (proven CLEAN). Spec requires the root to bind delegate identity. Path: absent
  `delegate_id` -> `DELEGATION_DELEGATE_ID_MISSING | Reject`.
- **D-04** — expiry is checked only via the flag, not `expires_at_logical` vs current time; an
  expired-by-date delegation with no flag passes (proven CLEAN; flag control -> `DELEGATION_
  EXPIRED`). Path: compute expiry from the date.

### D-05 (minor, non-blocking, C-06 string-match class)

Scope surfaces are compared by exact string (`set.issubset`); a case variant (`Read_Logs` vs
`read_logs`) yields `DELEGATION_SCOPE_EXCEEDED`. The false-positive direction is safe, but
scope-surface equivalence is brittle to name variants. Path: canonicalize surface names before
comparison (the `_normalise_axis_token` already used for authority axes).

---

## 5. Class transfer (observation)

Delegation's first adversarial pass leaks along the **same classes** as authority-markup: C-01
missing->skip (D-02/D-03/D-04), C-06 string-match (D-05), plus a new structural gap specific to
delegation (multi-hop, D-01). The finding classes transfer between subsystems because they are not
about a specific mechanism but about how an implementation meets adversarial input: trusting a
field's presence, identity by string, and incomplete handling of a structure.

The asymmetry is instructive: foundational lessons (whitelist root source, computed hashes) were
transferred **ahead of time** — they are now part of the engineering vocabulary after
authority-markup. But the delegation-specific expressions of the same classes (multi-hop,
delegation-field missing->skip) are fresh, because they live in a new structure. The general
principle transfers; the concrete expression needs a new adversarial pass — which is exactly why
each subsystem should be passed separately rather than assumed covered by prior hardening. The path
to delegation maturity is the same arc authority-markup walked over v0.1->v0.7, but shorter, because
the classes and their remedies are now known.

---

## 6. Non-claims

This record does NOT claim:

1. that the checker is correct, complete, or proven;
2. that passing fixtures or the executed attacks implies full enforcement against an adversarial substrate;
3. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
4. that the artifact is a safety guarantee, conformance certificate, or deployment authorization;
5. personhood, consciousness, or legal status for any `c`;
6. that PASS confers any authority beyond an advisory b-layer opinion on the code as read and executed.

This record makes no statement about the memory or dialogue content of any live
entity; it concerns only the reviewed implementation's structure, behavior, and spec-conformance.

---

## 7. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91"
  supersedes_archive_sha256: "6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16"
  verdict: PASS_CHECKER_V0_8_DELEGATION_FIRST_PASS
  blocking: false
  findings: [D-01, D-02, D-03, D-04, D-05]
  must_fix: [D-01, D-02, D-03, D-04]
  recommended_next:
    - "Fix D-01: iterate the whole chain, per-hop validation, monotone scope narrowing."
    - "Fix D-02/D-03/D-04: missing delegation fields fail safe."
    - "Fix D-05: canonicalize surface names before scope comparison."
    - "Add multi-hop fixtures: valid narrowing chain; emulated intermediate hop; scope-widening hop; broken identity chain."
  reviewer_signature_basis: source_code_and_empirical_execution
  record_sha256: "PLACEHOLDER__compute_on_freeze"
```

> `record_sha256` is a placeholder to be computed against the frozen text of this
> review record and bound at registration, per corpus convention.

---

*End of review record.*
