# Non-claims and scope — DOC_MAP v1.2

This package does not claim:

1. that the checker is correct, complete, or proven;
2. that any implementation (Ester, Lia, Rita, or otherwise) satisfies the spec;
3. that the artifacts are a safety guarantee, conformance certificate, deployment authorization, personhood claim, consciousness claim, or legal-status claim;
4. that the DOC_MAP is complete-by-history;
5. that recovered local records are byte-identical to unavailable standalone originals;
6. that `record_file_sha256` equals `artifact_sha256`.

This package claims only:

- a navigable witness map of 35 record nodes;
- 32 local/recovered full-text review records bound by sidecar hashes;
- 3 explicitly marked reference-only nodes;
- a reproducible sidecar hash protocol over raw UTF-8 file bytes.
