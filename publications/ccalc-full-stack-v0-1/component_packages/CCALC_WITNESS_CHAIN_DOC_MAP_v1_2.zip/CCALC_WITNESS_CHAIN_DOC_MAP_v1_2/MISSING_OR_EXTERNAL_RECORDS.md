# Missing or external records — DOC_MAP v1.2

v1.2 reduced the reference-only set from six nodes to three by recovering the `v1.7`, `v1.8`, and `v1.9` integration records as local sidecar-bound witness files.

Remaining reference-only / missing-local-text nodes:

| # | record_id | artifact_sha256 | supersedes | source_note |
|---:|---|---|---|---|
| 1 | `GBOP_02_v0_1_1_REVIEW__b` | `859fec89c61919539a8a2af1a8703003b258149454abbab74f09c2ddd0f03929` | `GBOP_02_v0_1_REVIEW__b` | citation-only / no canonical local standalone text in this package |
| 2 | `GBOP_02_v0_1_2_REVIEW__b` | `1a405693261627bcda8460be1b9b3ca5aa917d4d12e8dd5609709a3779cb179e` | `GBOP_02_v0_1_1_REVIEW__b` | citation-only / no canonical local standalone text in this package |
| 3 | `CCALC_CHECKER_v1_3_REVIEW__b` | `474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114` | `CCALC_CHECKER_v1_2_REVIEW__b` | referenced by `CCALC_CHECKER_v1_3_INTEGRATION__b`; local canonical subsystem-review file absent |

Non-claim: these three are not hidden. They are retained in the graph and explicitly marked reference-only.
