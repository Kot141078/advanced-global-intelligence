# DOC_MAP v1.2 build/recovery note — b-layer

**Record class:** package build/recovery note  
**Review date:** 2026-07-02  
**Authority:** advisory only

v1.2 applies partial A1 recovery over v1.1:

- `CCALC_CHECKER_v1_7_INTEGRATION__b` recovered as local normalized full-text.
- `CCALC_CHECKER_v1_8_INTEGRATION__b` recovered as local normalized full-text.
- `CCALC_CHECKER_v1_9_INTEGRATION__b` recovered as local normalized full-text.

Counts after recovery:

```text
total mapped records: 35
local inherited full-text: 29
recovered local full-text: 3
local/recovered total: 32
remaining reference-only: 3
```

Non-claim: recovered records are not asserted byte-identical to unavailable standalone originals. They are local witness reconstructions from available review evidence, now sidecar-bound and explicitly labeled.

*End of build/recovery note.*
