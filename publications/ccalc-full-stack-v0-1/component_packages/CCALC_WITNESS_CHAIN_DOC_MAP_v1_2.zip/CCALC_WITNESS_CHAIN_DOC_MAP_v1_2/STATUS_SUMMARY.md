# Status summary — DOC_MAP v1.2

```text
DM-01: narrowed, not fully A1-closed
  v1.1: 29 local full-text / 6 reference-only
  v1.2: 32 local-or-recovered full-text / 3 reference-only

DM-02: closed for local/recovered corpus
  sidecar-bound records: 32
  sidecar mismatches: 0

Package status:
  complete-by-policy with partial A1 recovery
```

Important: `artifact_sha256` binds reviewed artifacts. `.md.sha256` sidecars bind review record files. They are not the same object.
