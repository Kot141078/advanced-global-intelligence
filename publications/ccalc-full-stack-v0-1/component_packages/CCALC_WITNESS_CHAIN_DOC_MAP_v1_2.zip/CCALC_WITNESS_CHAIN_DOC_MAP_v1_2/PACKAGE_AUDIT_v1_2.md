# Package audit — DOC_MAP v1.2

Checks performed during build:

- Added 3 recovered local full-text records.
- Generated `.md.sha256` sidecars for all local/recovered records.
- Rebuilt `RECORD_HASH_SIDECAR.tsv`.
- Updated `REVIEW_RECORD_MANIFEST.tsv`.
- Updated JSON and Markdown DOC_MAP.
- Updated missing/reference-only policy files.
- Rebuilt `SHA256SUMS.txt`.

Expected counts:

```text
total graph nodes: 35
local/recovered record files: 32
remaining reference-only nodes: 3
```
