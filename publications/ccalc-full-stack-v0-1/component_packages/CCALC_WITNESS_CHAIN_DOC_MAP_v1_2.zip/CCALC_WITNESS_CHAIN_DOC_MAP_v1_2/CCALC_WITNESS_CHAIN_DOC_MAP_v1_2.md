# CCALC Witness Chain DOC_MAP v1.2

**Status:** advisory navigation map; partial A1 recovery over v1.1; still complete-by-policy, not complete-by-history.

## Summary

- Total mapped record nodes: **35**
- Local full-text records inherited from v1.1: **29**
- Recovered local full-text records added in v1.2: **3** (`v1.7`, `v1.8`, `v1.9` integration records)
- Remaining reference-only / missing-local-text nodes: **3**
- Sidecar-bound local/recovered records: **32**

## Important hash boundary

`artifact_sha256` is the SHA-256 of the reviewed artifact/archive. `record_file_sha256` and `.md.sha256` bind the review-record text file. These are different objects and MUST NOT be forced to match.

## Record graph

| # | record_id | artifact_sha256 | supersedes | source_class | record_file_sha256 |
|---:|---|---|---|---|---|
| 1 | `TGOPA_C_v0_1_1_REVIEW__b` | `2b3569e52364a52484b90c002490fa6a249a032ef9962f384f3c01424bf394bd` | `TGOPA_C_v0_1_REVIEW__b` | `local_full_text` | `dde66fd42cc6b6e4810a220892daf3f91e95131e8a420b4ef4962e05a80c7c39` |
| 2 | `TGOPA_C_v0_1_2_REVIEW__b` | `3181e53e931b412124c6f483d9f00febf2a306862a392c375c37ad91eab8bcdf` | `TGOPA_C_v0_1_1_REVIEW__b` | `local_full_text` | `866f77244bd584e4b60eaf8fb2dae14e9a5c1ed984c9a4ff203e91487af9aac4` |
| 3 | `TGOPA_C_v0_1_3_REVIEW__b` | `b8bd89fe11992825eb6e1be8fdb6b985154cb6411dccc8c5bee3498c33f8b1c9` | `TGOPA_C_v0_1_2_REVIEW__b` | `local_full_text` | `0991fd8fd95d2fc2de7e3fffc8ab22ea11927e6adca1ff0f0f54958744b5c774` |
| 4 | `TGOPA_C_v0_1_4_REVIEW__b` | `e94131839dd7cc837dbb8a391c6ace222f39d95fc0011119cfc7f0f5cc9120a7` | `TGOPA_C_v0_1_3_REVIEW__b` | `local_full_text` | `ff777ed363b5ee52bdba7b74626137d4b035dc104fe27294a3182c938977363b` |
| 5 | `TGOPA_C_v0_1_5_REVIEW__b` | `4f200c9de88a42834890e6f9480c7f18a6ef6b9c18f9624bb07846f329fab702` | `TGOPA_C_v0_1_4_REVIEW__b` | `local_full_text` | `3cdb09906232514dcca8fc2b838cdf90eb6daf469e2de149e05f1f5091fe7eac` |
| 6 | `TGOPA_C_v0_1_7_REVIEW__b` | `d060ef513bf4bedcb7e88f43f8456452bc87f0c0409d5b4caeffc590ae22c29e` | `TGOPA_C_v0_1_6_REVIEW__b` | `local_full_text` | `c85e329c75276bb644149c748007379aa9064411cbc245b96ba1ff0877d28abe` |
| 7 | `TGOPA_C_v0_1_REVIEW__b` | `01ee648c11f96d03dccd00f9ca1f643297cc3d9152940af08542373bad71cd89` | `` | `local_full_text` | `324beab131df00a7f787f484b824d85e0f9cdfa51592162ed50cf4c6b9ca171b` |
| 8 | `GBOP_02_v0_1_1_REVIEW__b` | `859fec89c61919539a8a2af1a8703003b258149454abbab74f09c2ddd0f03929` | `GBOP_02_v0_1_REVIEW__b` | `reference_only_or_missing_local_full_text` | `` |
| 9 | `GBOP_02_v0_1_2_REVIEW__b` | `1a405693261627bcda8460be1b9b3ca5aa917d4d12e8dd5609709a3779cb179e` | `GBOP_02_v0_1_1_REVIEW__b` | `reference_only_or_missing_local_full_text` | `` |
| 10 | `GBOP_02_v0_1_3_REVIEW__b` | `53338138beec180c5a40271e9b9552a0d22b3b1d57e12a95eab06af2932ec0b5` | `GBOP_02_v0_1_2_REVIEW__b` | `local_full_text` | `3e03d0f0125781692bc9e32e1f8008fdde84cd4dcf945a1173db87be3676adb7` |
| 11 | `GBOP_02_v0_1_4_REVIEW__b` | `983df2ef05eb5edd1f7b47168c53b10d20824e34bbe754e05b2a69c02db0cf56` | `GBOP_02_v0_1_3_REVIEW__b` | `local_full_text` | `fed5be0ba2c994da50bd9ce31e5926f8262f3758cd38c1a47c0363840607b6a5` |
| 12 | `GBOP_02_v0_1_5_REVIEW__b` | `1ecdc805a0893c8baff8cae0aff57a1d010536eac8d6ee81bf98b84799958e6d` | `GBOP_02_v0_1_4_REVIEW__b` | `local_full_text` | `a1b8e531c68d4534ff8366b27e8db2cbad4e3a5b30d2a6d12d3fc56a9ae66dcd` |
| 13 | `GBOP_02_v0_1_REVIEW__b` | `8f7574d6f09e80eddd83fd01c5d1de6e84e276d47b596c3ca664b324e1839bd5` | `` | `local_full_text` | `139f1b1c634c5c13ea233ac8876c6613d23ce17933b42aa82d16fdd148caadc5` |
| 14 | `CCALC_CHECKER_v0_1_REVIEW__b` | `3d092e6c30035b01a45e668338ef4b2acb500084d26ea4f3d4c6e79aa64ff516` | `` | `local_full_text` | `c1ed4118a4fb82b864269e19ffa20605c32431eda4b55fd5054171e448669c0c` |
| 15 | `CCALC_CHECKER_v0_2_REVIEW__b` | `63dbe5d6c68bc016493bcfb69ad67b23d773b6c9c06f77ecd634f9c41dfe9fa0` | `CCALC_CHECKER_v0_1_REVIEW__b` | `local_full_text` | `4bf312372ad0728acaed9c40530ca2df2dc845b22fe03e2c53be890f88a05fe1` |
| 16 | `CCALC_CHECKER_v0_3_REVIEW__b` | `a68e3113e15c624a041fd55c55ba0d4a3a706c106f67027175ab7e26f3657aa4` | `CCALC_CHECKER_v0_2_REVIEW__b` | `local_full_text` | `6169fd55c248de0417435955c496fda722e463008838122b066fbc1e973f0c16` |
| 17 | `CCALC_CHECKER_v0_4_REVIEW__b` | `974b375144a8785876439d4c0d94870770b547dd568b005ea38e522119a94136` | `CCALC_CHECKER_v0_3_REVIEW__b` | `local_full_text` | `9a17ae1fe1a90e52c3ec578148a25bfd74ea0a76f6232a9d4f194324dc482d63` |
| 18 | `CCALC_CHECKER_v0_5_REVIEW__b` | `8f65ac1feb223d32a5cf328333067fbbef7b64423b4aac6868c2fdd55880b394` | `CCALC_CHECKER_v0_4_REVIEW__b` | `local_full_text` | `095ed0ad510bb2b9112222df895d5a01b8ca346cac723e34a32cbb5e6deed02b` |
| 19 | `CCALC_CHECKER_v0_6_REVIEW__b` | `1e75e7217b03d5f8f8c7114867393a3a0ce3184e99646b0a64a98f3648507cdc` | `CCALC_CHECKER_v0_5_REVIEW__b` | `local_full_text` | `015e4b21d47981acdeaf0343e2fd1726c9e69e8ebad28c8d444e9bb7a2840f32` |
| 20 | `CCALC_CHECKER_v0_7_REVIEW__b` | `6c90653b08f4564c23bc5c7a24055ec4134140bd03c034de5228a0507758de16` | `CCALC_CHECKER_v0_6_REVIEW__b` | `local_full_text` | `82674f95e10621dad542ab6fc3e07078b2ffae4c6b06c0beb3192b8bdba3efd6` |
| 21 | `CCALC_CHECKER_v0_8_REVIEW__b` | `3c969c1eb8a157d661bb847c0d51d4c5cdbb411d546326db7c80373d0f0bde91` | `CCALC_CHECKER_v0_7_REVIEW__b` | `local_full_text` | `34f3821a1814217ad5173c55102fba97964b4b28f1e4adce5ca7685b637a3287` |
| 22 | `CCALC_CHECKER_v0_9_REVIEW__b` | `4946b1e2c490e5cf3ac67a609ceaa7ef71cabf952ba71faa1f861bb823b23e8f` | `CCALC_CHECKER_v0_8_REVIEW__b` | `local_full_text` | `13e21fd7c7e8ca834bcd90fb8a00073025e4397180fb4edc30271f351f7147a5` |
| 23 | `CCALC_CHECKER_v1_0_REVIEW__b` | `46ec448ccdf43c841da9cf240eefed449229b4c3b418a6626215fe9de93214ae` | `CCALC_CHECKER_v0_9_REVIEW__b` | `local_full_text` | `31350558b262a20342193a384445687c82589870f5514f42d58e7d7715ad8340` |
| 24 | `CCALC_CHECKER_v1_1_REVIEW__b` | `4c15831976e10aea1f8fe792f20d96953fae576ab89b6cc52f5ea783a0ee0ae9` | `CCALC_CHECKER_v1_0_REVIEW__b` | `local_full_text` | `d284db1b8ad18b29ad9fed510cea80556017e50e29b371b8313c4becfd222a49` |
| 25 | `CCALC_CHECKER_v1_2_REVIEW__b` | `1a8c27f4b7637e2cff9959c987d8842c4f9fc69c238744d2682a53b1b6dc0e0f` | `CCALC_CHECKER_v1_1_REVIEW__b` | `local_full_text` | `fc44499e9571249a7cbd27eeba5435cdc610430f508c54cf714fd829af9069ce` |
| 26 | `CCALC_CHECKER_v1_3_INTEGRATION__b` | `474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114` | `` | `local_full_text` | `0b8fe68c16fd0c869b8a1575e9cd94bd48ca4a5590aee528326370940c1f9845` |
| 27 | `CCALC_CHECKER_v1_3_REVIEW__b` | `474e72410c0afdae99f328313da790f680f4d1b8a4503ad4bf080f9e8995c114` | `CCALC_CHECKER_v1_2_REVIEW__b` | `reference_only_or_missing_local_full_text` | `` |
| 28 | `CCALC_CHECKER_v1_4_INTEGRATION__b` | `db86d6c0e09fdea1a244327ee013cb489e6f56a7d4e555dec64977a9d5570a63` | `CCALC_CHECKER_v1_3_INTEGRATION__b` | `local_full_text` | `77bc1752dd5bd9f450256beb6fd35b2548ffb77a108620275e895d5f6f36824e` |
| 29 | `CCALC_CHECKER_v1_5_INTEGRATION__b` | `9061e097d998fa61e950964d7c41b08cacbcef21471dd80f9460fd3931acb5a3` | `CCALC_CHECKER_v1_4_INTEGRATION__b` | `local_full_text` | `e13239d0e0736cf81d74f8bf0f3f5c3c4c759db9a837ce617a1c15245999b3e4` |
| 30 | `CCALC_CHECKER_v1_6_INTEGRATION__b` | `5d06cd1b85f8e3cfb52841b1c3750214cebafabcbd0d1183748a07ff182bd193` | `CCALC_CHECKER_v1_5_INTEGRATION__b` | `local_full_text` | `e9ea718a7589b3790e16d2cc6faaf280409c7badd9c18411563686c57fd968d1` |
| 31 | `CCALC_CHECKER_v1_7_INTEGRATION__b` | `2accc1a6653fdda721345de69d7802ad9e64cf3e14d121b458834c4974224e2d` | `CCALC_CHECKER_v1_6_INTEGRATION__b` | `recovered_local_full_text` | `89b7c1beab2620a48052f5f689c5364365eacba7e109c4ade4a4c78e1d3135d9` |
| 32 | `CCALC_CHECKER_v1_8_INTEGRATION__b` | `9f6e57034986be3d3109f4beb9931ae0689292c6eed56af06ba2723b00b14144` | `CCALC_CHECKER_v1_7_INTEGRATION__b` | `recovered_local_full_text` | `7e881a517c2a7e8545c269e8154b21ab10d281b611e88a29e75202fb5fba8bd6` |
| 33 | `CCALC_CHECKER_v1_9_INTEGRATION__b` | `6fe08355c09f63e6f6bab54c0e87fca62a1c7a0482f41458a17249a490d3b346` | `CCALC_CHECKER_v1_8_INTEGRATION__b` | `recovered_local_full_text` | `f253cfce9161b352655f34ebc5afd55896772f7d6f0c620f225c97bbcd228aca` |
| 34 | `CCALC_CHECKER_v2_0_INTEGRATION__b` | `5a67369dea97f0c96de293524313b5a4ec45fa6ee7bc36ec55685b8e374b6b79` | `CCALC_CHECKER_v1_9_INTEGRATION__b` | `local_full_text` | `ef8b41d44c6420de2aac8ead1104d582f444932a643f9bf40124b8264672239c` |
| 35 | `CCALC_CHECKER_v2_1_INTEGRATION__b` | `58d7ad1c770853e0416b8e9801c80828e68f8aeec2f51f8c97691eb60c5ea08f` | `CCALC_CHECKER_v2_0_INTEGRATION__b` | `local_full_text` | `4a2532413be857d736886659975e1dd0f9f158e7b443e5a598fb4281f3c6c8fd` |

## Non-claim

v1.2 does not claim full A1 complete-by-history. It reduces the unverifiable surface by recovering three integration records as local sidecar-bound text, but three nodes remain reference-only by policy.
