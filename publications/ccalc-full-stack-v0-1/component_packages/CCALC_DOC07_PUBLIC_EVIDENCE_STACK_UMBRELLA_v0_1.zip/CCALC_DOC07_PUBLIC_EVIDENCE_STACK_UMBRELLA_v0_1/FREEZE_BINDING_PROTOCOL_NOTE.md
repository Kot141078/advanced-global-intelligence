# Freeze Binding Protocol Note

Use external sidecar binding:

```bash
sha256sum exact_file_bytes > filename.sha256
```

No self-referential hash is embedded inside a file whose bytes are being hashed.

This umbrella uses recomputed SHA-256 values for all included component and source-binding ZIP files.
