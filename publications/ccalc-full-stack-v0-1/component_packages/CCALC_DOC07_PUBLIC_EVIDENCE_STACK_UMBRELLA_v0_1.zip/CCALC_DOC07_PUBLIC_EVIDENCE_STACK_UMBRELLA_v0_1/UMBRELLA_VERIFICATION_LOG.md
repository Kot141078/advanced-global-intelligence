# Umbrella Verification Log — Doc07 Public Evidence Stack

Generated UTC: `2026-07-05T12:16:34Z`

## Component package verification

| Package | SHA256 | Internal SHA256SUMS | Executable rerun |
|---|---:|---|---|
| `CCALC_PUBLIC_EVIDENCE_REDACTION_BOUNDARY_07_v0_1.zip` | `afced9a2c6830faebcb98d37195d56d6216fe8211d30bcb5bdf2d2ce6e4a4538` | PASS | NO_EXECUTABLE_SCRIPTS_EXPECTED |
| `CCALC_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST_07a_v0_1.zip` | `21cfd692d3520a57b46780d093430b123bcf3439ed73781f3074a47f6af15893` | PASS | fixtures 85/85 PASS; mutations 15/15 CAUGHT |
| `CCALC_PUBLIC_RELEASE_HASH_CUSTODY_07b_v0_1.zip` | `b84ccc97d9564b6f95e92b0acd68481aa2d316d7e6ceb6c561bcddf8433be246` | PASS | fixtures 82/82 PASS; mutations 21/21 CAUGHT |
| `CCALC_PUBLIC_RETRACTION_SUPERSESSION_ERRATA_07c_v0_1.zip` | `d191c3202c1463cf741f82c978d8414041432174cdff891947e515e32358eec3` | PASS | fixtures 78/78 PASS; mutations 18/18 CAUGHT |
| `CCALC_PUBLIC_CORPUS_CITATION_SYNC_07d_v0_1.zip` | `3c22108b7305ff755d236de08e73bbacf4f34c8a8f6bcbef11ed8d41272db512` | PASS | fixtures 90/90 PASS; mutations 21/21 CAUGHT |

## Source binding verification

| Package | SHA256 | Status |
|---|---:|---|
| `CCALC_DOC04_CONTINUITY_STACK_UMBRELLA_v0_1.zip` | `6caeab8d489aaa6b26902db3bd3ece4c5169e5c8d5617b93aed6586ea900322d` | PRESENT_AND_RECOMPUTED |
| `CCALC_DOC05_SELF_EVO_STACK_UMBRELLA_v0_1.zip` | `9a0717809029f49df9001dc8ffa1803d9e9bfa1a824d317eebb146cbc7df43b4` | PRESENT_AND_RECOMPUTED |
| `CCALC_DOC06_RUNTIME_AUTHORITY_STACK_UMBRELLA_v0_1.zip` | `ab95633f1b90f9d032fd231d6cbef3e71b7fe106e0a7fb61d198c2254fc7d307` | PRESENT_AND_RECOMPUTED |

## Umbrella checks

```text
component packages present: PASS
component SHA-256 recomputed: PASS
internal component SHA256SUMS: PASS
executable reruns: PASS for 07a/07b/07c/07d
source-binding packages present: PASS
source-binding SHA-256 recomputed: PASS
umbrella SHA256SUMS: generated after sidecars
```
