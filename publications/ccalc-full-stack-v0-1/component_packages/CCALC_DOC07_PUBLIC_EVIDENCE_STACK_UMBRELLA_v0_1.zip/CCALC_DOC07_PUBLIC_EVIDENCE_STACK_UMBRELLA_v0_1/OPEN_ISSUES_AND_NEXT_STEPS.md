# Open Issues and Next Steps

## Closed in this umbrella

- `07`: public evidence disclosure/redaction boundary.
- `07a`: disclosure manifest schema and checker seed.
- `07b`: public release bundle and hash custody audit.
- `07c`: retraction, supersession, and errata ledger.
- `07d`: public corpus index and citation-surface synchronization.

## Still outside scope

- Jurisdiction-specific legal/privacy compliance certification.
- Live repository/site modification.
- Zenodo/GitHub/website publication action.
- C-A1 ontology/personhood ratification.
- Safety certification or deployment authorization.

## Next natural layer

`08_C_INTEROPERABILITY_PROFILE_AND_EXTERNAL_REVIEW_INTAKE_BOUNDARY_v0_1`.
