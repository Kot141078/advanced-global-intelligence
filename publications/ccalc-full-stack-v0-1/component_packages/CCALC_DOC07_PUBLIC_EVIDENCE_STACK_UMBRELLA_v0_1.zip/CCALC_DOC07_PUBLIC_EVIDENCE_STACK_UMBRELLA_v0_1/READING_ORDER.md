# Reading Order — Doc07 Public Evidence Stack

1. `CCALC_DOC07_PUBLIC_EVIDENCE_STACK_INDEX_AND_RELEASE_MANIFEST_v0_1.md`
2. `components/CCALC_PUBLIC_EVIDENCE_REDACTION_BOUNDARY_07_v0_1.zip`
3. `components/CCALC_PUBLIC_EVIDENCE_DISCLOSURE_MANIFEST_07a_v0_1.zip`
4. `components/CCALC_PUBLIC_RELEASE_HASH_CUSTODY_07b_v0_1.zip`
5. `components/CCALC_PUBLIC_RETRACTION_SUPERSESSION_ERRATA_07c_v0_1.zip`
6. `components/CCALC_PUBLIC_CORPUS_CITATION_SYNC_07d_v0_1.zip`
7. `COMPONENT_REGISTRY.tsv`
8. `SOURCE_BINDINGS.tsv`
9. `EXECUTABLE_RERUN_SUMMARY.tsv`
10. `UMBRELLA_VERIFICATION_LOG.md`

Operational formula:

```text
evidence -> classify -> redact/hash/withhold -> claim-force ceiling -> release -> correction ledger -> citation-surface sync
```
