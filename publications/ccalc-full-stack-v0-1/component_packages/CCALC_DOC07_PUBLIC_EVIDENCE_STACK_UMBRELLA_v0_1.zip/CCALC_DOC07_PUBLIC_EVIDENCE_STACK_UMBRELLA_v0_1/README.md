# CCALC_DOC07_PUBLIC_EVIDENCE_STACK_UMBRELLA_v0_1

Current umbrella package for the `07` public evidence stack.

Closed stack:

```text
07   public evidence disclosure / redaction boundary
07a  disclosure manifest schema + checker seed
07b  public release bundle + hash custody audit
07c  public retraction / supersession / errata ledger
07d  public corpus index + citation surface sync
```

Formula:

```text
evidence -> classify -> redact/hash/withhold -> claim-force ceiling -> release -> correction ledger -> citation-surface sync
```

See `CCALC_DOC07_PUBLIC_EVIDENCE_STACK_INDEX_AND_RELEASE_MANIFEST_v0_1.md`.
