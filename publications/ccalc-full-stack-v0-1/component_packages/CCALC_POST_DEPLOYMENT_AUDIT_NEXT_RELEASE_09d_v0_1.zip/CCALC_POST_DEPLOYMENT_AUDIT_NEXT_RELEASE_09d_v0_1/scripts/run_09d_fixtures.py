#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / 'src' / 'post_deployment_audit_next_release_checker_v0_1.py'
CASES = sorted((ROOT / 'fixtures' / 'cases').glob('*.json'))

spec = importlib.util.spec_from_file_location('checker09d', CHECKER)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)

def main():
    passed = 0
    failed = []
    for case in CASES:
        pkt = json.loads(case.read_text(encoding='utf-8'))
        res = checker.check_packet(pkt)
        exp = pkt.get('expected', {})
        ok = (res['admissible'] == exp.get('admissible')) and (res['required_decision'] == exp.get('required_decision'))
        if ok:
            passed += 1
        else:
            failed.append((case.name, res, exp))
    print(f'09d fixtures: {passed}/{len(CASES)} PASS')
    if failed:
        for name, res, exp in failed:
            print(f'FAIL {name}\nRESULT={json.dumps(res, ensure_ascii=False, sort_keys=True)}\nEXPECTED={json.dumps(exp, ensure_ascii=False, sort_keys=True)}')
        return 1
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
