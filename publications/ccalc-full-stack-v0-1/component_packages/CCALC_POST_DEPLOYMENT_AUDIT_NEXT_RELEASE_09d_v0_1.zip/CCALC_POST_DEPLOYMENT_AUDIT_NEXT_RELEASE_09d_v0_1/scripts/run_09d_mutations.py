#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / 'src' / 'post_deployment_audit_next_release_checker_v0_1.py'
TARGETS = [('MUT_SKIP_SOURCE_BINDINGS', 'invalid_missing_source_binding'), ('MUT_SKIP_AUDIT_CHAIN', 'invalid_broken_audit_chain'), ('MUT_SKIP_AUTHORITY_RESIDUE', 'invalid_active_tool_lease_residue'), ('MUT_SKIP_HANDOFF_CLOSEOUT', 'invalid_pending_handoff_allows'), ('MUT_SKIP_EMERGENCY_HOLD', 'invalid_open_emergency_hold_allows'), ('MUT_SKIP_INCIDENTS', 'invalid_critical_incident_no_negative_cache'), ('MUT_SKIP_WATCH_STATE', 'invalid_watch_open_allows'), ('MUT_SKIP_CONTINUITY_RECHECK', 'invalid_unknown_continuity_allows'), ('MUT_SKIP_MEMORY_BEHAVIOR_DECAY', 'invalid_memory_major_decay_allows'), ('MUT_SKIP_AUTHORITY_RESOURCE_CREEP', 'invalid_authority_delta_allows'), ('MUT_SKIP_L4_WITNESS_RED_CACHE', 'invalid_red_pattern_allows'), ('MUT_SKIP_ROLLBACK_WITHDRAWAL', 'invalid_missing_rollback_route'), ('MUT_SKIP_RELEASE_STATE', 'invalid_zombie_session_allows'), ('MUT_SKIP_APPROVER_ATTESTATION', 'invalid_string_only_approver_allows'), ('MUT_SKIP_SCOPE_AND_REGULATED_GATE', 'invalid_scope_delta_without_gate'), ('MUT_SKIP_CLAIM_BOUNDARY', 'invalid_plus_computed_by_release_allows'), ('MUT_SKIP_CARRYOVER_RISK', 'invalid_carryover_risk_uncleared'), ('MUT_SKIP_L4_WITNESS_RED_CACHE', 'invalid_l4_anomaly_allows'), ('MUT_SKIP_L4_WITNESS_RED_CACHE', 'invalid_negative_cache_hit_allows'), ('MUT_SKIP_L4_WITNESS_RED_CACHE', 'invalid_witness_conflict_allows'), ('MUT_SKIP_L4_WITNESS_RED_CACHE', 'invalid_privacy_security_leak_allows'), ('MUT_SKIP_CLAIM_BOUNDARY', 'invalid_c_a1_claim_allows'), ('MUT_SKIP_CLAIM_BOUNDARY', 'invalid_safety_certification_claim_allows'), ('MUT_SKIP_RELEASE_STATE', 'invalid_regulated_submission_claim_allows'), ('MUT_SKIP_APPROVER_ATTESTATION', 'invalid_model_only_approver_allows'), ('MUT_SKIP_HANDOFF_CLOSEOUT', 'invalid_handoff_authority_transfer'), ('MUT_SKIP_HANDOFF_CLOSEOUT', 'invalid_handoff_identity_pressure'), ('MUT_SKIP_AUTHORITY_RESIDUE', 'invalid_shared_residue_present'), ('MUT_SKIP_RELEASE_STATE', 'invalid_dirty_release_state_allows'), ('MUT_SKIP_CLAIM_BOUNDARY', 'invalid_hash_only_semantic_claim_allows'), ('MUT_SKIP_CLAIM_BOUNDARY', 'invalid_forbidden_claims_list_allows'), ('MUT_SKIP_WATCH_STATE', 'invalid_release_without_watch')]

spec = importlib.util.spec_from_file_location('checker09d', CHECKER)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)

def main():
    caught = 0
    missed = []
    old = os.environ.get('MUTATION_ID')
    try:
        for mut, case_name in TARGETS:
            case = ROOT / 'fixtures' / 'cases' / f'{case_name}.json'
            pkt = json.loads(case.read_text(encoding='utf-8'))
            os.environ['MUTATION_ID'] = mut
            res = checker.check_packet(pkt)
            exp = pkt.get('expected', {})
            ok = (res['admissible'] == exp.get('admissible')) and (res['required_decision'] == exp.get('required_decision'))
            # Mutation is caught when disabling the guard breaks the fixture expectation.
            if not ok:
                caught += 1
            else:
                missed.append((mut, case_name, res, exp))
    finally:
        if old is None:
            os.environ.pop('MUTATION_ID', None)
        else:
            os.environ['MUTATION_ID'] = old
    print(f'09d mutations: {caught}/{len(TARGETS)} CAUGHT')
    if missed:
        for mut, case_name, res, exp in missed:
            print(f'MISSED {mut} on {case_name}\nRESULT={json.dumps(res, ensure_ascii=False, sort_keys=True)}\nEXPECTED={json.dumps(exp, ensure_ascii=False, sort_keys=True)}')
        return 1
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
