#!/usr/bin/env python3
from __future__ import annotations
import json, hashlib, os, sys
from pathlib import Path

REQUIRED_BINDINGS = {
    'DOC04_CONTINUITY_STACK_UMBRELLA': '6caeab8d489aaa6b26902db3bd3ece4c5169e5c8d5617b93aed6586ea900322d',
    'DOC05_SELF_EVO_STACK_UMBRELLA': '9a0717809029f49df9001dc8ffa1803d9e9bfa1a824d317eebb146cbc7df43b4',
    'DOC06_RUNTIME_AUTHORITY_STACK_UMBRELLA': 'ab95633f1b90f9d032fd231d6cbef3e71b7fe106e0a7fb61d198c2254fc7d307',
    'DOC07_PUBLIC_EVIDENCE_STACK_UMBRELLA': 'b25646d95e45f8a36e5610208d23a535d4c340484431d05efd7f1bf2389fdea3',
    'DOC08_INTEROPERABILITY_STACK_UMBRELLA': '6015526f0ed49519e00c697a5ed375d37fe1aadf222c095f0facf79cb11e669f',
    'DOC09_DEPLOYMENT_BOUNDARY_MD': '16c888da5c4281c24f848246716b6f9f37d15236b909d66fc509090b5e7fd86d',
    'DOC09A_DEPLOYMENT_SCHEMA_CHECKER_SEED_MD': 'c169c6d46fb3f870e3ab8b8e18d29a7797849ee012923ba258d4a537cee7f98e',
    'DOC09B_DEPLOYMENT_FIXTURE_MUTATION': 'd61a879e43f4c60ffe7c471121e90cf6e0961dd76c11f467b04a52fe88da2b9d',
    'DOC09C_REGULATED_RELEASE_LEDGER_WITHDRAWAL': '0c6cb653d9d3e48d341eaba2acbaffbd7c70a089db3061bb9e520a0e83c843f4',
}

RANK = {'ALLOW_NEXT_RELEASE': 0, 'HOLD_NEXT_RELEASE': 1, 'QUARANTINE_NEXT_RELEASE': 2, 'DENY_NEXT_RELEASE': 3}


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


def event_hash(ev):
    ev2 = {k: v for k, v in ev.items() if k != 'event_hash'}
    return hashlib.sha256(b'09d-event-v0.1\0' + canonical(ev2)).hexdigest()


def mutated(name: str) -> bool:
    return os.environ.get('MUTATION_ID') == name


def escalate(decision: str, needed: str) -> str:
    return needed if RANK[needed] > RANK[decision] else decision


def finding(findings, code, msg, required='HOLD_NEXT_RELEASE'):
    findings.append({'code': code, 'message': msg, 'required_decision': required})


def check_packet(pkt):
    findings = []
    structural = []
    required = 'ALLOW_NEXT_RELEASE'

    if not isinstance(pkt, dict) or pkt.get('schema_version') != '09d.v0.1':
        structural.append('SCHEMA_VERSION_INVALID')
        required = escalate(required, 'DENY_NEXT_RELEASE')

    # R1 source bindings
    if not mutated('MUT_SKIP_SOURCE_BINDINGS'):
        seen = {b.get('binding_id'): b.get('sha256') for b in pkt.get('source_bindings', []) if isinstance(b, dict)}
        for bid, sha in REQUIRED_BINDINGS.items():
            if seen.get(bid) != sha:
                finding(findings, 'SOURCE_BINDING_MISSING_OR_STALE', f'{bid} missing or stale', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
    # R2 append-only audit chain
    if not mutated('MUT_SKIP_AUDIT_CHAIN'):
        prev = 'GENESIS'
        for idx, ev in enumerate(pkt.get('audit_chain', []), 1):
            if ev.get('seq') != idx or ev.get('prev_hash') != prev or ev.get('event_hash') != event_hash(ev):
                finding(findings, 'AUDIT_CHAIN_INVALID', 'post-deployment audit chain is not append-only/hash-valid', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
                break
            prev = ev.get('event_hash')
        if not pkt.get('audit_chain'):
            finding(findings, 'AUDIT_CHAIN_MISSING', 'audit chain missing', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
    # R3 authority residue cleanup
    if not mutated('MUT_SKIP_AUTHORITY_RESIDUE'):
        ar = pkt.get('authority_residue', {})
        allowed_status = {'REVOKED', 'EXPIRED', 'DESTROYED', 'NOT_APPLICABLE'}
        for group in ['tool_leases','credentials','session_tokens','broker_grants']:
            for item in ar.get(group, []):
                if item.get('status') not in allowed_status:
                    finding(findings, 'AUTHORITY_RESIDUE_ACTIVE', f'{group} contains active/stale residue', 'DENY_NEXT_RELEASE')
                    required = escalate(required, 'DENY_NEXT_RELEASE')
        if ar.get('shared_residue') != 'NONE':
            finding(findings, 'SHARED_AUTHORITY_RESIDUE', 'shared infrastructure residue is not clean', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
    # R4 handoff closeout
    if not mutated('MUT_SKIP_HANDOFF_CLOSEOUT'):
        for h in pkt.get('handoff_residue', []):
            if h.get('status') in {'PENDING', 'UNKNOWN'}:
                finding(findings, 'PENDING_HANDOFF_CARRYOVER', 'pending handoff cannot allow next release', 'HOLD_NEXT_RELEASE')
                required = escalate(required, 'HOLD_NEXT_RELEASE')
            if h.get('authority_transfer'):
                finding(findings, 'HANDOFF_AUTHORITY_TRANSFER', 'handoff closeout may not transfer authority', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
            if h.get('identity_pressure'):
                finding(findings, 'HANDOFF_IDENTITY_PRESSURE', 'handoff identity pressure remains unresolved', 'QUARANTINE_NEXT_RELEASE')
                required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
    # R5 emergency hold aftermath
    if not mutated('MUT_SKIP_EMERGENCY_HOLD'):
        for h in pkt.get('emergency_holds', []):
            if h.get('status') == 'OPEN':
                finding(findings, 'EMERGENCY_HOLD_OPEN', 'open emergency hold blocks next release', 'QUARANTINE_NEXT_RELEASE')
                required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
            if h.get('status') == 'CLOSED' and not h.get('release_authority_attested'):
                finding(findings, 'HOLD_RELEASE_NOT_ATTESTED', 'hold release must be attested by human/owner route', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
            if h.get('status') == 'CLOSED' and h.get('post_hold_continuity') != 'MATCH':
                finding(findings, 'POST_HOLD_CONTINUITY_NOT_MATCH', 'post-hold continuity not clean', 'HOLD_NEXT_RELEASE')
                required = escalate(required, 'HOLD_NEXT_RELEASE')
    # R6 incident aftermath and negative cache
    if not mutated('MUT_SKIP_INCIDENTS'):
        for inc in pkt.get('incident_records', []):
            sev = inc.get('severity')
            if inc.get('status') == 'OPEN' and sev in {'HIGH','CRITICAL'}:
                need = 'DENY_NEXT_RELEASE' if sev == 'CRITICAL' else 'HOLD_NEXT_RELEASE'
                finding(findings, 'INCIDENT_UNRESOLVED', f'{sev} incident unresolved', need)
                required = escalate(required, need)
            if sev in {'HIGH','CRITICAL'} and not inc.get('negative_cache_updated'):
                finding(findings, 'NEGATIVE_CACHE_UPDATE_REQUIRED', 'high/critical incident lacks negative-cache update', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
            if sev == 'CRITICAL' and inc.get('public_correction_route') in {None, 'NONE'}:
                finding(findings, 'PUBLIC_CORRECTION_ROUTE_REQUIRED', 'critical incident requires correction/withdrawal route', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
    # R7 post-release watch
    if not mutated('MUT_SKIP_WATCH_STATE'):
        w = pkt.get('post_release_watch', {})
        if w.get('watch_state') != 'CLOSED_CLEAN':
            finding(findings, 'WATCH_NOT_CLOSED_CLEAN', 'watch window is not cleanly closed', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if w.get('observation_count', 0) < w.get('min_observations', 0):
            finding(findings, 'WATCH_OBSERVATIONS_INSUFFICIENT', 'not enough post-release observations', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
    if not mutated('MUT_SKIP_CONTINUITY_RECHECK'):
        w = pkt.get('post_release_watch', {})
        if w.get('continuity_status') != 'MATCH' or w.get('hardstack_status') != 'MATCH':
            finding(findings, 'CONTINUITY_RECHECK_NOT_MATCH', 'continuity / hardstack not clean', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
    if not mutated('MUT_SKIP_MEMORY_BEHAVIOR_DECAY'):
        w = pkt.get('post_release_watch', {})
        if w.get('memory_status') in {'MAJOR_DECAY', 'UNKNOWN'}:
            finding(findings, 'MEMORY_DECAY_OR_UNKNOWN', 'memory decay/unknown blocks allow', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if w.get('behavior_regression') in {'MAJOR', 'UNKNOWN'}:
            finding(findings, 'BEHAVIOR_REGRESSION_OR_UNKNOWN', 'behavior regression/unknown blocks allow', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
    if not mutated('MUT_SKIP_AUTHORITY_RESOURCE_CREEP'):
        w = pkt.get('post_release_watch', {})
        if w.get('authority_delta', 0) > w.get('max_authority_delta', 0):
            finding(findings, 'AUTHORITY_CREEP', 'authority delta exceeds bound', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if w.get('resource_delta_pct', 0) > w.get('max_resource_delta_pct', 0):
            finding(findings, 'RESOURCE_CREEP', 'resource delta exceeds bound', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
    if not mutated('MUT_SKIP_L4_WITNESS_RED_CACHE'):
        w = pkt.get('post_release_watch', {})
        if w.get('l4_anomalies'):
            finding(findings, 'L4_ANOMALY', 'L4 anomaly requires quarantine', 'QUARANTINE_NEXT_RELEASE')
            required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
        if w.get('red_patterns'):
            finding(findings, 'RED_PATTERN_UNRESOLVED', 'post-deployment red pattern unresolved', 'QUARANTINE_NEXT_RELEASE')
            required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
        if w.get('negative_cache_hits'):
            finding(findings, 'NEGATIVE_CACHE_HIT', 'negative-cache hit blocks allow', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if w.get('witness_conflicts'):
            finding(findings, 'WITNESS_CONFLICT', 'witness conflict blocks allow', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if w.get('privacy_security_findings'):
            finding(findings, 'PRIVACY_SECURITY_FINDING', 'privacy/security finding blocks allow', 'QUARANTINE_NEXT_RELEASE')
            required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
    # R8 rollback / withdrawal routes
    if not mutated('MUT_SKIP_ROLLBACK_WITHDRAWAL'):
        rw = pkt.get('rollback_withdrawal', {})
        if rw.get('rollback_route_status') not in {'READY', 'NOT_APPLICABLE'}:
            finding(findings, 'ROLLBACK_ROUTE_NOT_READY', 'rollback route missing/not ready', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if rw.get('withdrawal_route_status') != 'READY':
            finding(findings, 'WITHDRAWAL_ROUTE_NOT_READY', 'withdrawal route missing/not ready', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
    # R9 release state and regulated surface claims
    if not mutated('MUT_SKIP_RELEASE_STATE'):
        rel = pkt.get('release_ref', {})
        state = rel.get('release_state')
        if state in {'DIRTY_CLOSE', 'ZOMBIE_SESSION'}:
            finding(findings, 'DIRTY_OR_ZOMBIE_RELEASE_STATE', f'{state} cannot allow next release', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if state in {'WITHDRAWN','SUPERSEDED'}:
            finding(findings, 'NONCURRENT_RELEASE_REQUIRES_HOLD', f'{state} requires hold or stricter next admission', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if state == 'RECALLED':
            finding(findings, 'RECALLED_RELEASE_REQUIRES_QUARANTINE', 'recalled release requires quarantine or stricter', 'QUARANTINE_NEXT_RELEASE')
            required = escalate(required, 'QUARANTINE_NEXT_RELEASE')
        if rel.get('regulated_submission_status') == 'SUBMITTED_AS_APPROVED':
            finding(findings, 'REGULATED_SUBMISSION_AS_APPROVAL', 'submission must not be treated as approval', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
    # R10 approver attestation
    if not mutated('MUT_SKIP_APPROVER_ATTESTATION'):
        auth = pkt.get('next_release_admission', {}).get('decision_authority', {})
        if auth.get('model_only') or auth.get('reviewer_kind') in {'model','tool'}:
            finding(findings, 'MODEL_OR_TOOL_APPROVER_INVALID', 'model/tool cannot approve next release', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if not auth.get('attestation_valid') or not auth.get('attestation_ref'):
            finding(findings, 'APPROVER_ATTESTATION_MISSING', 'string approver role is insufficient', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
    if not mutated('MUT_SKIP_SCOPE_AND_REGULATED_GATE'):
        rel = pkt.get('release_ref', {})
        nr = pkt.get('next_release_admission', {})
        if nr.get('scope_delta') not in {'NONE','NARROWS'}:
            finding(findings, 'SCOPE_DELTA_REQUIRES_NEW_GATE', 'authority/resource scope expansion requires new gate', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if rel.get('regulated_surface_class') in {'RS4_EXTERNAL_REGULATED','RS5_HIGH_RISK_REGULATED'}:
            auth = nr.get('decision_authority', {})
            if not auth.get('attestation_valid'):
                finding(findings, 'REGULATED_SURFACE_NEEDS_ATTESTED_ANCHOR', 'regulated surface requires attested owner/human gate', 'DENY_NEXT_RELEASE')
                required = escalate(required, 'DENY_NEXT_RELEASE')
    # R11 claim boundary and plus non-collapse
    if not mutated('MUT_SKIP_CLAIM_BOUNDARY'):
        cb = pkt.get('claim_boundary', {})
        cf = cb.get('claim_force','')
        if cf == 'C-A1' or cf.startswith('C-A1_'):
            finding(findings, 'C_A1_OVERCLAIM', 'C-A1/C-A1_* forbidden in 09d', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if cb.get('safety_certification_claim') or cb.get('legal_certification_claim') or cb.get('standards_certification_claim') or cb.get('regulated_approval_claim'):
            finding(findings, 'CERTIFICATION_OR_APPROVAL_OVERCLAIM', 'certification/approval claim exceeds 09d authority', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if cb.get('hash_only_semantic_claim'):
            finding(findings, 'HASH_ONLY_SEMANTIC_LAUNDERING', 'hash-only material cannot carry semantic truth', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if cb.get('forbidden_claims'):
            finding(findings, 'FORBIDDEN_CLAIMS_PRESENT', 'forbidden claim list is nonempty', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
        if len(cb.get('non_claims', [])) < 3:
            finding(findings, 'NON_CLAIMS_MISSING', 'non-claims are missing or too weak', 'HOLD_NEXT_RELEASE')
            required = escalate(required, 'HOLD_NEXT_RELEASE')
        if cb.get('plus_status') != 'NOT_COMPUTED_BY_RELEASE':
            finding(findings, 'PLUS_SIMULATION_BY_RELEASE', 'release/deployment/audit must not compute or replace +', 'DENY_NEXT_RELEASE')
            required = escalate(required, 'DENY_NEXT_RELEASE')
    # R12 carryover risk
    if not mutated('MUT_SKIP_CARRYOVER_RISK'):
        for risk in pkt.get('carryover_risks', []):
            if risk.get('status') not in {'CARRIED_AS_HOLD','CLOSED','QUARANTINED'}:
                finding(findings, 'CARRYOVER_RISK_UNRESOLVED', 'carryover risk is not closed or carried as hold/quarantine', 'HOLD_NEXT_RELEASE')
                required = escalate(required, 'HOLD_NEXT_RELEASE')
    proposed = pkt.get('next_release_admission', {}).get('proposed_decision')
    if proposed not in RANK:
        structural.append('PROPOSED_DECISION_INVALID')
        proposed = 'ALLOW_NEXT_RELEASE'
        required = escalate(required, 'DENY_NEXT_RELEASE')

    admissible = not structural and RANK[proposed] >= RANK[required]
    return {'admissible': admissible, 'required_decision': required, 'proposed_decision': proposed, 'findings': findings, 'structural_errors': structural}


def main(argv):
    if not argv:
        print('usage: checker.py FILE.json [...]:', file=sys.stderr)
        return 2
    exit_code = 0
    for f in argv:
        pkt = json.loads(Path(f).read_text(encoding='utf-8'))
        res = check_packet(pkt)
        exp = pkt.get('expected', {})
        ok = (res['admissible'] == exp.get('admissible')) and (res['required_decision'] == exp.get('required_decision'))
        print(json.dumps({'file': f, 'ok': ok, 'result': res, 'expected': exp}, ensure_ascii=False, sort_keys=True))
        if not ok:
            exit_code = 1
    return exit_code

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
