# Semantic Review Record — CCALC Witness Chain DOC_MAP v1.0

**Record class:** b-layer semantic review record (advisory) — DOC_MAP / witness-chain integrity pass  
**Review protocol:** CGAM b-layer checker, advisory only  
**Reviewer role:** `b` (semantic reviewer); NOT ratifying, NOT authorizing; decision reserved for `c`-gate and accountable anchor `a`  
**Review date:** 2026-07-02  
**Record short name:** `CCALC_DOC_MAP_v1_0_REVIEW__b`  
**Reviewed artifact:** `CCALC_WITNESS_CHAIN_DOC_MAP_v1_0.zip`  
**Reviewed artifact SHA256:** `c29cf72a09a2d0318be582a8a42ed1e28a8b130b70573f0e34b3cb4e2a9bd6dc`  
**Review basis:** archive contents, `SHA256SUMS.txt`, record manifests, lineage table, and reviewer-held hash-lineage memory.

The key words MUST, MUST NOT, SHOULD, SHOULD NOT, MAY are to be interpreted as in RFC 2119.

---

## 1. Machine-readable review object

```yaml
review_record:
  record_id: CCALC_DOC_MAP_v1_0_REVIEW__b
  record_version: "1.0"
  record_class: b_layer_semantic_review_doc_map_integrity
  authority: advisory_only
  ratifies: false
  authorizes: false
  decision_reserved_for: [c_gate, anchor_a]

  reviewed_artifact:
    title: "CCALC Witness Chain DOC_MAP v1.0"
    artifact_type: doc_map_package
    project: "Self-Evo / Ester / c = a + b"
    archive_sha256: "c29cf72a09a2d0318be582a8a42ed1e28a8b130b70573f0e34b3cb4e2a9bd6dc"
    verification_basis: archive_structure_plus_manifest_plus_lineage

  verdict:
    result: PASS_WITH_SCOPE_LIMITS
    qualifier: doc_map_structure_valid_but_freeze_not_complete
    meaning: >
      The DOC_MAP is structurally sound as a navigation corpus: package SHA256SUMS verify,
      available artifact hashes match the recorded review lineage, and the lineage is connected
      relative to the included corpus. However, it must not be claimed as a complete frozen witness
      chain: there are local-full-text coverage gaps / representation inconsistencies, and the
      review records still contain record_sha256 placeholders rather than self- or sidecar-bound
      frozen hashes.
    blocking_findings: 0
    integrity_findings: [DM-01, DM-02]
    non_claims_added: true

  verified_clean:
    sha256sums_internal_integrity: PASS
    archive_hash_verified: true
    sample_artifact_hashes_match_reviewer_lineage: true
    lineage_connected_relative_to_included_corpus: true

  findings:
    DM-01_doc_map_not_full_chain:
      severity: moderate
      blocking: false
      issue: >
        DOC_MAP v1.0 is a valid navigation corpus but is not a complete local-full-text witness chain.
        The package contains 29 normalized local records, while the JSON index describes 35 record nodes
        and the TSV manifest has 34 data rows. Several historical records are citation/reference-only or
        absent as local full text, including integration/subsystem records around v1.3-v1.9 and earlier
        TGOPA/GBOP gaps depending on local availability.
      consequence: >
        A public verifier can follow much of the lineage, but not every historical record is present as a
        local Markdown witness. Therefore the map MUST be described as current-corpus navigation / partial
        local normalization, not as a complete frozen public witness chain.
      recommended_path: >
        Either include all missing local full-text records in records/ and regenerate manifests, or explicitly
        document a policy of inclusion that marks which records are citation-backed/reference-only and why.

    DM-02_record_sha256_placeholders_not_frozen:
      severity: moderate
      blocking: false
      issue: >
        The individual review records still contain record_sha256: PLACEHOLDER__compute_on_freeze. The
        DOC_MAP manifest computes file hashes externally, but the records themselves are not self-bound.
      consequence: >
        The hash binding lives in the external manifest only. That is useful but insufficient for a frozen
        witness-chain convention, because a standalone record does not carry or point to its own registration
        hash.
      recommended_path: >
        Use a reproducible two-part freeze protocol. Recommended: sidecar hashing. Keep the record body
        immutable, compute SHA256 over the exact record file, and store it in a sidecar .sha256 file and in
        the manifest. If inline record_sha256 is required, define a canonical placeholder-normalized hashing
        rule before replacing it.

  non_claims:
    - "This DOC_MAP v1.0 review does not claim that the v1.0 package is a complete local-full-text chain."
    - "It does not claim that placeholder record_sha256 fields are frozen bindings."
    - "It does not claim safety, deployment authorization, or correctness of any checker or entity."
    - "It does not claim that citation/reference-only records are equivalent to packaged local Markdown witnesses."

  recommended_next:
    - "Decide whether gaps are intentional policy or packaging undersupply."
    - "If undersupply: package missing local records and issue DOC_MAP v1.1/v1.2 with corrected manifests."
    - "If intentional: document inclusion policy and mark the map complete-by-policy, not complete-by-history."
    - "Adopt sidecar hash binding for record freeze to avoid self-referential hash instability."
```

---

## 2. Verdict statement

**PASS_WITH_SCOPE_LIMITS.** The DOC_MAP is the right kind of artifact: it turns the review chain into a navigable corpus with Markdown/JSON maps, manifests, local records, and SHA256SUMS. The internal package integrity is clean: `SHA256SUMS.txt` verifies, and the checked archive/artifact hashes match the reviewer-held lineage.

But DOC_MAP v1.0 is **not yet a complete frozen witness chain**. Two limits must be explicit:

1. **Completeness limit:** the package has local-full-text gaps / representation inconsistencies. It is a strong navigation map for the current active corpus, not yet a complete local record corpus.
2. **Freeze-binding limit:** record files still contain `record_sha256: PLACEHOLDER__compute_on_freeze`; the manifest knows their hashes, but the records are not self- or sidecar-bound.

These are not fatal flaws in the structure. They are exactly the kind of non-claims that must be visible before the DOC_MAP is used as the fifth-ring/public witness artifact.

---

## 3. Verified clean points

- `SHA256SUMS.txt` validates against the files inside the DOC_MAP package.
- The top-level reviewed archive hash is:

```text
c29cf72a09a2d0318be582a8a42ed1e28a8b130b70573f0e34b3cb4e2a9bd6dc
```

- Available checker archive hashes in the DOC_MAP agree with the recorded review lineage where checked.
- The lineage is connected relative to the included corpus; the only external supersedes-style links are earlier records not normalized as local full text.
- Status summaries reflect the latest checker state: `INT-C` closed in v2.1, in-scope seams closed through v2.1, `root_anchor_state_freshness` remains a candidate, and viewport/review-binding remain out of current checker scope.

---

## 4. Finding DM-01 — completeness / representation gap

DOC_MAP v1.0 packages the available local record corpus, but it should not claim full historical completeness.

Observed structure:

```text
local normalized records in records/: 29
JSON record nodes: 35
TSV manifest data rows: 34
```

This mismatch is not evidence of corruption; it is a representation boundary. Some records are local Markdown witnesses, while others are citation-backed, conversation-derived, reference-only, or absent as full local text.

**Required non-claim:** DOC_MAP v1.0 is a navigation artifact for the current active corpus, not a complete frozen local witness chain.

**Path:** either package all missing local records and regenerate the maps, or document an inclusion policy that explicitly marks records as `local_full_text`, `citation_backed`, `reference_only`, or `external_missing`.

---

## 5. Finding DM-02 — record hashes are external, not self/sidecar-bound

The review records still contain:

```yaml
record_sha256: "PLACEHOLDER__compute_on_freeze"
```

The DOC_MAP manifest computes file hashes externally, but the records themselves do not contain a reproducible self-binding. This is acceptable for a draft navigation pack, but not for a frozen witness convention.

**Required non-claim:** DOC_MAP v1.0 does not provide frozen self-bound review records.

**Recommended protocol:** sidecar binding.

- Keep each record body immutable.
- Compute SHA256 over the exact Markdown record file.
- Store the hash in `record_name.md.sha256` and in `REVIEW_RECORD_MANIFEST.tsv`.
- Do not mutate the record body to insert its own hash unless a placeholder-normalized canonical hashing rule is specified.

Sidecar binding is cleaner here because it avoids self-referential hash instability.

---

## 6. Non-claims for DOC_MAP v1.0

This review record explicitly adds the following non-claims to the DOC_MAP witness chain:

1. DOC_MAP v1.0 is **not** a complete local-full-text reconstruction of every historical review record.
2. DOC_MAP v1.0 is **not** a frozen self-bound record chain while `record_sha256` placeholders remain inside records.
3. Citation-backed/reference-only records are **not** equivalent to packaged local Markdown witness files.
4. The DOC_MAP is **not** a proof of checker correctness, safety, deployment readiness, personhood, consciousness, or legal status.
5. The DOC_MAP is an advisory navigation and lineage artifact; authority remains with `c`-gate and accountable anchor `a`.

---

## 7. Recommended next action

Two decisions are needed before a true freeze:

### A. Completeness policy

Either:

```text
Option A1: complete-by-history
  package every historical review record as local full text;
  regenerate manifests;
  no silent gaps.
```

or:

```text
Option A2: complete-by-policy
  explicitly mark records by source class;
  document why some are citation/reference-only;
  no silent gaps.
```

For public fifth-ring use, **A1 is better**. If the record text is unavailable, A2 is acceptable only with explicit source classification.

### B. Freeze hash protocol

Recommended:

```text
sidecar hash binding
```

not inline self-hash. Sidecar keeps record bodies stable and makes independent verification simple.

---

## 8. Register handoff

```yaml
handoff:
  from: b_layer_reviewer
  to: c_gate_review_queue
  artifact_sha256: "c29cf72a09a2d0318be582a8a42ed1e28a8b130b70573f0e34b3cb4e2a9bd6dc"
  verdict: PASS_DOC_MAP_V1_0_WITH_SCOPE_LIMITS
  blocking: false
  findings: [DM-01_doc_map_not_full_chain, DM-02_record_hash_placeholders_not_frozen]
  recommended_next:
    - "Choose completeness policy: complete-by-history or complete-by-policy."
    - "Adopt sidecar hash binding for frozen review records."
    - "Issue DOC_MAP v1.1/v1.2 with explicit source classes and freeze protocol."
  reviewer_signature_basis: archive_structure_manifest_lineage_verification
```

---

*End of DOC_MAP review record.*
