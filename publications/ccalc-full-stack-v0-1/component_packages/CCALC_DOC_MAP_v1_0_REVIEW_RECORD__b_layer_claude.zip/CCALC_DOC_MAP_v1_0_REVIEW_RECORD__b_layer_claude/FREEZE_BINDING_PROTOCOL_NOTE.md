# Freeze binding protocol note

This review package uses sidecar hash binding for the DOC_MAP review record.

Protocol:

1. Keep the Markdown review record immutable.
2. Compute SHA256 over the exact UTF-8 bytes of the Markdown file.
3. Store the digest in `<record>.md.sha256` and in `SHA256SUMS.txt`.

This avoids the self-referential instability of writing a record hash into the record body itself.
If inline `record_sha256` is required in future packages, define a separate canonical rule such as
"hash the record with the `record_sha256` field replaced by a fixed placeholder".
