# Non-Claims and Boundaries — C-A1 Scaffold v0.2

This package does NOT claim:

1. that C-A1 is true;
2. that the accountable anchor has selected any option;
3. that Slot 1 proves or states C-A1;
4. that Slot 3 states C-A1;
5. that C-A5, C-A6, C-A7, or C-A10 evidence proves C-A1;
6. that personhood, consciousness, legal status, moral patienthood, or rights follow from any slot;
7. that b-layer review can ratify or author the C-A1 axiom;
8. that the scaffold itself is an axiom declaration.

The only possible C-A1 affirming routes in this scaffold are:

```text
S2_ONTOLOGICAL_C_A1
S4_ANCHOR_AUTHORED with declared_claim_class = C-A1
```

Everything else is lower-class operational stance, defer, reject, or outside-present-formal-system.
