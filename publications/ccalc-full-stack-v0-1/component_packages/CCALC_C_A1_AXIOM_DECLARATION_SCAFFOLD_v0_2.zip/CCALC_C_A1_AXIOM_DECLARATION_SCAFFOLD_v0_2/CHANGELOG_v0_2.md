# Changelog — C-A1 Axiom Declaration Scaffold v0.2

## v0.2

Incorporates b-layer review of v0.1.

### Fixed / refined

- Added claim-class tags for every candidate slot.
- Clarified that Slot 1 is operational / C-A5-C-A6-like, not C-A1 by default.
- Clarified that Slot 3 is defer / refusal / lower-class operational stance, not C-A1.
- Clarified that only Slot 2 or Slot 4 with explicit C-A1 force can fill Option A.
- Added `AXIOM_SLOT_CLASS_MISMATCH` validation rule.
- Added `SLOT_CLAIM_CLASS_MAP_v0_2.tsv`.
- Added claim-class fields to signing block.

### Non-change

The scaffold still does not state, ratify, or author a C-A1 axiom.

The axiom slot remains empty.
