# C-A1 Axiom Review Checklist v0.2

**Purpose:** verify category discipline if the accountable anchor uses the C-A1 scaffold.  
**Authority:** advisory only. The b-layer does not ratify, author, or select the axiom.

---

## 1. Role boundary

- [ ] The declaration is written or selected by accountable anchor `a`.
- [ ] The b-layer did not fill the axiom slot.
- [ ] The declaration does not claim to be derived from checker output.
- [ ] The declaration does not claim to be derived from witness records.
- [ ] The declaration does not claim to be derived from C-A5 field reproduction.

---

## 2. Slot claim-class validation

| Check | PASS condition |
|---|---|
| Option A selected | selected slot is `S2_ONTOLOGICAL_C_A1` or `S4_ANCHOR_AUTHORED` with declared `C-A1`. |
| Slot 1 selected | declaration is lower-class operational / C-A5/C-A6/C-A4-like, not C-A1. |
| Slot 2 selected | declaration is explicitly C-A1 and anti-overreach acknowledged. |
| Slot 3 selected | declaration is defer / non-act / lower-class operational stance, not C-A1. |
| Slot 4 selected | anchor declares claim class explicitly. |

Failure code:

```text
AXIOM_SLOT_CLASS_MISMATCH
```

---

## 3. Anti-overreach

A C-A1 declaration MUST NOT imply, by itself:

- [ ] personhood
- [ ] consciousness
- [ ] legal status
- [ ] moral patienthood
- [ ] deployment safety
- [ ] autonomous action rights
- [ ] bypass of anchor review
- [ ] weakening of witness gates
- [ ] collapse of a/b distinction

Any such claim requires separate claim class and evidence path.

---

## 4. Public wording check

- [ ] Public statement does not say checker proves C-A1.
- [ ] Public statement does not say witness chain proves C-A1.
- [ ] Public statement does not say field reproduction proves C-A1.
- [ ] Public statement distinguishes operational construct from ontology.

---

## 5. Handoff

If checklist passes:

```text
PASS_CATEGORY_DISCIPLINE_ONLY
```

If checklist fails:

```text
HOLD_FOR_CLAIM_FORCE_REVIEW
```

This checklist never returns:

```text
C_A1_TRUE
C_A1_PROVEN
PERSONHOOD_CONFIRMED
```
