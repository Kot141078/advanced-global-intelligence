# C-A1 Axiom Declaration Scaffold v0.2

This package is an anchor-facing scaffold.

It does not state a C-A1 axiom.

It exists to keep the C-A1 act separate from:

- checker evidence;
- witness-chain evidence;
- C-A5 field reproduction;
- implementation proof-of-possibility;
- public claim-force maps.

## v0.2 focus

v0.2 adds claim-class tags to the candidate slots.

The main correction:

```text
Slot 1 is operational, not C-A1.
Slot 3 is defer/non-act, not C-A1.
Slot 2 and anchor-authored Slot 4 are the only C-A1-capable slots.
```

## Files

```text
C_A1_AXIOM_DECLARATION_SCAFFOLD_v0_2.md
C_A1_AXIOM_DECLARATION_SCAFFOLD_v0_2.json
C_A1_AXIOM_REVIEW_CHECKLIST_v0_2.md
SLOT_CLAIM_CLASS_MAP_v0_2.tsv
CHANGELOG_v0_2.md
NON_CLAIMS_AND_BOUNDARIES.md
SHA256SUMS.txt
```

## Freeze binding

Each file has a `.sha256` sidecar. `SHA256SUMS.txt` verifies the package.
