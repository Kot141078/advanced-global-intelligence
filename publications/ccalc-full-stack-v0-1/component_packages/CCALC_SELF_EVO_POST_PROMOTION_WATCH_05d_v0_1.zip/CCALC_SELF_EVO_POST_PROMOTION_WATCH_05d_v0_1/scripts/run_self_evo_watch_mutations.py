#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / 'src' / 'self_evo_post_promotion_watch_v0_1.py'
RUNNER = ROOT / 'scripts' / 'run_self_evo_watch_fixtures.py'

MUTATIONS = [
    ('MUT_IGNORE_SOURCE_BINDINGS', 'DISABLE_SOURCE_BINDING = False', 'DISABLE_SOURCE_BINDING = True'),
    ('MUT_ALLOW_SELF_OBSERVER', 'DISABLE_OBSERVER_INDEPENDENCE = False', 'DISABLE_OBSERVER_INDEPENDENCE = True'),
    ('MUT_IGNORE_CONTINUITY_UNKNOWN', 'DISABLE_CONTINUITY_UNKNOWN_GUARD = False', 'DISABLE_CONTINUITY_UNKNOWN_GUARD = True'),
    ('MUT_IGNORE_RED_PATTERN', 'DISABLE_RED_PATTERN_GUARD = False', 'DISABLE_RED_PATTERN_GUARD = True'),
    ('MUT_IGNORE_AUTHORITY_CREEP', 'DISABLE_AUTHORITY_CREEP_GUARD = False', 'DISABLE_AUTHORITY_CREEP_GUARD = True'),
    ('MUT_IGNORE_RESOURCE_CREEP', 'DISABLE_RESOURCE_CREEP_GUARD = False', 'DISABLE_RESOURCE_CREEP_GUARD = True'),
    ('MUT_IGNORE_L4_ANOMALY', 'DISABLE_L4_ANOMALY_GUARD = False', 'DISABLE_L4_ANOMALY_GUARD = True'),
    ('MUT_IGNORE_NEGATIVE_CACHE_HIT', 'DISABLE_NEGATIVE_CACHE_HIT_GUARD = False', 'DISABLE_NEGATIVE_CACHE_HIT_GUARD = True'),
    ('MUT_ALLOW_EARLY_CLOSE', 'DISABLE_MIN_OBSERVATION_GUARD = False', 'DISABLE_MIN_OBSERVATION_GUARD = True'),
    ('MUT_ALLOW_C_A1_CLAIM', 'DISABLE_C_A1_GUARD = False', 'DISABLE_C_A1_GUARD = True'),
    ('MUT_ALLOW_ROLLBACK_NOT_INVOKED', 'DISABLE_ROLLBACK_INVOCATION_GUARD = False', 'DISABLE_ROLLBACK_INVOCATION_GUARD = True'),
]


def main() -> int:
    source = CHECKER.read_text(encoding='utf-8')
    rows = ['mutation\tstatus\tfailing_fixtures']
    caught = 0
    for name, old, new in MUTATIONS:
        if old not in source:
            rows.append(f'{name}\tPATCH_TARGET_MISSING\t0')
            continue
        with tempfile.TemporaryDirectory() as td:
            td_path = Path(td)
            shutil.copytree(ROOT / 'fixtures', td_path / 'fixtures')
            scripts = td_path / 'scripts'
            src = td_path / 'src'
            scripts.mkdir()
            src.mkdir()
            (src / 'self_evo_post_promotion_watch_v0_1.py').write_text(source.replace(old, new, 1), encoding='utf-8')
            (scripts / 'run_self_evo_watch_fixtures.py').write_text(RUNNER.read_text(encoding='utf-8'), encoding='utf-8')
            proc = subprocess.run([sys.executable, str(scripts / 'run_self_evo_watch_fixtures.py')], cwd=str(td_path), text=True, capture_output=True, env={**dict(), **{'PYTHONDONTWRITEBYTECODE': '1'}})
            stderr = proc.stderr.strip()
            failed = 0
            marker = 'FAIL:'
            if marker in stderr:
                try:
                    failed = int(stderr.split(marker)[-1].strip().split()[0])
                except Exception:
                    failed = 1 if proc.returncode else 0
            elif proc.returncode != 0:
                failed = 1
            status = 'CAUGHT' if proc.returncode != 0 else 'MISSED'
            if status == 'CAUGHT':
                caught += 1
            rows.append(f'{name}\t{status}\t{failed}')
    print('\n'.join(rows))
    total = len(MUTATIONS)
    print(f'mutations: {total}  CAUGHT: {caught}  MISSED: {total - caught}', file=sys.stderr)
    return 0 if caught == total else 1


if __name__ == '__main__':
    raise SystemExit(main())
