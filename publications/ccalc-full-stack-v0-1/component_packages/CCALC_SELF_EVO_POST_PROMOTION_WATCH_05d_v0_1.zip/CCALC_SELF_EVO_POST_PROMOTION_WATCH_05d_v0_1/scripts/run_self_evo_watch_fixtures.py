#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from self_evo_post_promotion_watch_v0_1 import validate_bundle


def main() -> int:
    cases_dir = ROOT / 'fixtures' / 'cases'
    rows = ['case\texpected_status\tactual_status\texpected_decision\tactual_decision\texpected_error\tpass']
    total = passed = 0
    for path in sorted(cases_dir.glob('*.json')):
        data = json.loads(path.read_text(encoding='utf-8'))
        exp = data['fixture_expectation']
        res = validate_bundle(data['bundle'])
        actual_status = res['status']
        actual_decision = res['decision'] if actual_status == 'PASS' else res.get('required_decision', 'REJECT')
        expected_status = exp['status']
        expected_decision = exp.get('decision') or ''
        expected_error = exp.get('error_code') or ''
        error_codes = {e['code'] for e in res.get('errors', [])}
        ok = actual_status == expected_status
        if expected_decision:
            ok = ok and actual_decision == expected_decision
        if expected_error:
            ok = ok and expected_error in error_codes
        total += 1
        passed += 1 if ok else 0
        rows.append(f"{path.name}\t{expected_status}\t{actual_status}\t{expected_decision}\t{actual_decision}\t{expected_error}\t{'PASS' if ok else 'FAIL'}")
    print('\n'.join(rows))
    print(f'fixtures: {total}  PASS: {passed}  FAIL: {total - passed}', file=sys.stderr)
    return 0 if total == passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
