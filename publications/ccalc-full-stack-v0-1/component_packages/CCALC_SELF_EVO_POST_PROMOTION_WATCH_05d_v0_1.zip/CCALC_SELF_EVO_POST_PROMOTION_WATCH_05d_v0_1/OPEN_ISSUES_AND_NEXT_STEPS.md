# Open Issues and Next Steps

## Open

- Runtime-specific observation cadence calibration remains implementation-defined.
- Raw telemetry extraction is outside this seed and belongs to the runtime ledger layer.
- Statistical sufficiency of watch windows is not proven by this package.

## Next

- Build `05x` umbrella package for the complete Self-Evo stack.
- Then move to `06` for restricted security / private-cloud / authority isolation semantics.
