# Reading Order

1. `05d_SELF_EVO_POST_PROMOTION_WATCH_AND_DECAY_GUARD_v0_1.md`
2. `SOURCE_BINDINGS.tsv`
3. `schemas/post_promotion_watch_bundle.schema.json`
4. `src/self_evo_post_promotion_watch_v0_1.py`
5. `fixtures/cases/`
6. `FIXTURE_RESULTS.tsv`
7. `MUTATION_MATRIX.tsv`
8. `PACKAGE_VERIFICATION_LOG.md`
9. `NON_CLAIMS_AND_SCOPE.md`
