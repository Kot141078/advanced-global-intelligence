# Freeze Binding Protocol Note

File binding is external.

Use:

```bash
sha256sum <file> > <file>.sha256
```

Do not place a self-referential SHA-256 of a Markdown file inside the same Markdown file.
Package-level integrity is provided by `SHA256SUMS.txt` and the ZIP hash.
