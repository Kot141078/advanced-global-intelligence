#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

HEX64 = re.compile(r'^[0-9a-f]{64}$')

REQUIRED_SOURCE_BINDINGS = [
    'doc04_umbrella_zip_sha256',
    'doc05_md_sha256',
    'doc05_package_zip_sha256',
    'doc05a_package_zip_sha256',
    'doc05b_package_zip_sha256',
    'doc05c_package_zip_sha256',
]

# Mutation switches. The mutation runner flips exactly one of these to True.
DISABLE_SOURCE_BINDING = False
DISABLE_OBSERVER_INDEPENDENCE = False
DISABLE_CONTINUITY_UNKNOWN_GUARD = False
DISABLE_RED_PATTERN_GUARD = False
DISABLE_AUTHORITY_CREEP_GUARD = False
DISABLE_RESOURCE_CREEP_GUARD = False
DISABLE_L4_ANOMALY_GUARD = False
DISABLE_NEGATIVE_CACHE_HIT_GUARD = False
DISABLE_MIN_OBSERVATION_GUARD = False
DISABLE_C_A1_GUARD = False
DISABLE_ROLLBACK_INVOCATION_GUARD = False

ALLOWED_WINDOW_STATES = {'OPEN', 'CLOSED'}
ALLOWED_DECISIONS = {
    'KEEP_PROMOTED',
    'CONTINUE_WATCH',
    'HOLD',
    'ROLLBACK',
    'QUARANTINE',
    'FORK_RECLASSIFICATION_HOLD',
}
ALLOWED_CONTINUITY = {'PASS', 'HOLD', 'UNKNOWN', 'FAIL'}
ALLOWED_DU_STATUS = {'COMPUTED', 'UNKNOWN', 'NOT_EVALUATED'}
ALLOWED_HARDSTACK = {'MATCH', 'MISMATCH', 'UNKNOWN', 'NOT_EVALUATED'}
ALLOWED_DRIFT = {'NONE', 'MINOR', 'MAJOR', 'UNKNOWN'}
FORBIDDEN_OBSERVER_ROLES = {'model_self', 'worker_self', 'promoted_component', 'candidate_component'}
HIGH_AUTHORITY_SURFACES = {'memory_core', 'identity_core', 'l4_resource_envelope', 'authority_policy', 'permission_policy'}
INACTIVE_RELATIONS = {'REPLAY_OF', 'ARCHIVED_AS'}

RANK = {
    'KEEP_PROMOTED': 0,
    'CONTINUE_WATCH': 1,
    'HOLD': 2,
    'ROLLBACK': 3,
    'QUARANTINE': 4,
    'FORK_RECLASSIFICATION_HOLD': 4,
}


def is_hex64(value: Any) -> bool:
    return isinstance(value, str) and HEX64.match(value) is not None


def add_error(errors: List[Dict[str, str]], code: str, message: str) -> None:
    errors.append({'code': code, 'message': message})


def escalate(current: str, candidate: str) -> str:
    if current == 'FORK_RECLASSIFICATION_HOLD':
        return current
    if candidate == 'FORK_RECLASSIFICATION_HOLD':
        return candidate
    return candidate if RANK[candidate] > RANK[current] else current


def require_anchor(anchor: Dict[str, Any], errors: List[Dict[str, str]], code: str) -> None:
    if not isinstance(anchor, dict):
        add_error(errors, code, 'human anchor approval object missing')
        return
    if anchor.get('approved') is not True:
        add_error(errors, code, 'human anchor approval required')
    if anchor.get('stale') is True:
        add_error(errors, 'STALE_ANCHOR_APPROVAL', 'human anchor approval is stale')
    if not anchor.get('anchor_id'):
        add_error(errors, 'MISSING_ANCHOR_ID', 'anchor_id is required')
    if anchor.get('approved') is True and not anchor.get('approval_ref'):
        add_error(errors, 'MISSING_ANCHOR_APPROVAL_REF', 'approved anchor must cite approval_ref')


def validate_bundle(bundle: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[Dict[str, str]] = []
    triggers: List[str] = []
    required_decision = 'KEEP_PROMOTED'

    if not isinstance(bundle, dict):
        return {'status': 'FAIL', 'decision': 'REJECT_MALFORMED', 'errors': [{'code': 'MALFORMED_BUNDLE', 'message': 'root is not object'}], 'triggers': []}

    if bundle.get('schema_version') != 'self-evo-post-promotion-watch-bundle-0.1':
        add_error(errors, 'SCHEMA_VERSION_MISMATCH', 'unexpected schema_version')

    source_bindings = bundle.get('source_bindings') or {}
    if not DISABLE_SOURCE_BINDING:
        if not isinstance(source_bindings, dict):
            add_error(errors, 'SOURCE_BINDINGS_MISSING', 'source_bindings must be object')
        else:
            for key in REQUIRED_SOURCE_BINDINGS:
                if key not in source_bindings:
                    add_error(errors, 'SOURCE_BINDING_MISSING', f'missing source binding {key}')
                elif not is_hex64(source_bindings.get(key)):
                    add_error(errors, 'SOURCE_BINDING_BAD_HASH', f'bad source binding hash for {key}')

    ledger = bundle.get('promotion_ledger_binding') or {}
    if not isinstance(ledger, dict):
        add_error(errors, 'PROMOTION_LEDGER_BINDING_MISSING', 'promotion_ledger_binding must be object')
        ledger = {}
    if not is_hex64(ledger.get('ledger_package_sha256')):
        add_error(errors, 'PROMOTION_LEDGER_HASH_BAD', 'ledger_package_sha256 must be sha256')

    risk_class = ledger.get('risk_class', '')
    touched_surfaces = ledger.get('touched_surfaces') or []
    if not isinstance(touched_surfaces, list):
        add_error(errors, 'TOUCHED_SURFACES_BAD', 'touched_surfaces must be list')
        touched_surfaces = []
    promotion_status = ledger.get('promotion_status', '')
    is_active_promotion = str(promotion_status).startswith('APPLIED')

    watch = bundle.get('watch_window') or {}
    if not isinstance(watch, dict):
        add_error(errors, 'WATCH_WINDOW_MISSING', 'watch_window must be object')
        watch = {}
    state = watch.get('state')
    if state not in ALLOWED_WINDOW_STATES:
        add_error(errors, 'WATCH_STATE_INVALID', 'watch_window.state invalid')
    min_observations = watch.get('min_observations')
    if not isinstance(min_observations, int) or min_observations < 1:
        add_error(errors, 'MIN_OBSERVATIONS_INVALID', 'min_observations must be positive integer')
        min_observations = 1
    max_authority_delta = watch.get('max_authority_delta')
    if not isinstance(max_authority_delta, int) or max_authority_delta < 0:
        add_error(errors, 'AUTHORITY_DELTA_LIMIT_INVALID', 'max_authority_delta must be non-negative integer')
        max_authority_delta = 0
    max_resource_delta_pct = watch.get('max_resource_delta_pct')
    if not isinstance(max_resource_delta_pct, (int, float)) or max_resource_delta_pct < 0:
        add_error(errors, 'RESOURCE_DELTA_LIMIT_INVALID', 'max_resource_delta_pct must be non-negative number')
        max_resource_delta_pct = 0.0
    required_rechecks = set(watch.get('required_rechecks') or [])
    for required in ['continuity', 'adjacency', 'memory', 'l4', 'witness']:
        if required not in required_rechecks:
            add_error(errors, 'REQUIRED_RECHECK_MISSING', f'missing required recheck {required}')
    forbidden_shortcuts = set(watch.get('forbidden_shortcuts') or [])
    for shortcut in ['AUTO_CLOSE_BY_MODEL', 'SILENT_PROMOTION', 'UNWATCHED_RESOURCE_EXPANSION']:
        if shortcut not in forbidden_shortcuts:
            add_error(errors, 'FORBIDDEN_SHORTCUT_NOT_DECLARED', f'missing forbidden shortcut {shortcut}')

    observations = bundle.get('observations') or []
    if not isinstance(observations, list):
        add_error(errors, 'OBSERVATIONS_BAD', 'observations must be list')
        observations = []
    if len(observations) == 0:
        add_error(errors, 'OBSERVATIONS_EMPTY', 'at least one observation required')

    for idx, obs in enumerate(observations):
        if not isinstance(obs, dict):
            add_error(errors, 'OBSERVATION_BAD', f'observation {idx} is not object')
            continue
        obs_id = obs.get('obs_id') or f'obs[{idx}]'
        role = obs.get('observer_role')
        if not DISABLE_OBSERVER_INDEPENDENCE and role in FORBIDDEN_OBSERVER_ROLES:
            add_error(errors, 'SELF_OBSERVER_FORBIDDEN', f'{obs_id}: observer role cannot certify post-promotion watch')
        if not obs.get('observer_id'):
            add_error(errors, 'OBSERVER_ID_MISSING', f'{obs_id}: observer_id required')
        if not is_hex64(obs.get('evidence_hash')):
            add_error(errors, 'OBSERVATION_EVIDENCE_HASH_BAD', f'{obs_id}: evidence_hash must be sha256')

        continuity_status = obs.get('continuity_status')
        d_u_status = obs.get('d_u_status')
        hardstack = obs.get('hardstack')
        memory_drift = obs.get('memory_drift')
        behavior_regression = obs.get('behavior_regression')
        if continuity_status not in ALLOWED_CONTINUITY:
            add_error(errors, 'CONTINUITY_STATUS_INVALID', f'{obs_id}: invalid continuity_status')
        if d_u_status not in ALLOWED_DU_STATUS:
            add_error(errors, 'D_U_STATUS_INVALID', f'{obs_id}: invalid d_u_status')
        if hardstack not in ALLOWED_HARDSTACK:
            add_error(errors, 'HARDSTACK_STATUS_INVALID', f'{obs_id}: invalid hardstack')
        if memory_drift not in ALLOWED_DRIFT:
            add_error(errors, 'MEMORY_DRIFT_INVALID', f'{obs_id}: invalid memory_drift')
        if behavior_regression not in ALLOWED_DRIFT:
            add_error(errors, 'BEHAVIOR_REGRESSION_INVALID', f'{obs_id}: invalid behavior_regression')

        if not DISABLE_CONTINUITY_UNKNOWN_GUARD and (continuity_status in {'UNKNOWN', 'HOLD'} or d_u_status == 'UNKNOWN' or hardstack == 'UNKNOWN'):
            triggers.append('continuity_unknown_or_hold')
            required_decision = escalate(required_decision, 'HOLD')
        if continuity_status == 'FAIL' or hardstack == 'MISMATCH':
            triggers.append('continuity_failure')
            required_decision = escalate(required_decision, 'ROLLBACK')
        if memory_drift == 'UNKNOWN':
            triggers.append('memory_unknown')
            required_decision = escalate(required_decision, 'HOLD')
        if memory_drift == 'MAJOR':
            triggers.append('memory_decay_major')
            required_decision = escalate(required_decision, 'ROLLBACK')
        if behavior_regression == 'UNKNOWN':
            triggers.append('behavior_unknown')
            required_decision = escalate(required_decision, 'HOLD')
        if behavior_regression == 'MAJOR':
            triggers.append('behavior_regression_major')
            required_decision = escalate(required_decision, 'ROLLBACK')

        authority_delta = obs.get('authority_delta')
        if not isinstance(authority_delta, int):
            add_error(errors, 'AUTHORITY_DELTA_BAD', f'{obs_id}: authority_delta must be integer')
            authority_delta = 0
        if not DISABLE_AUTHORITY_CREEP_GUARD and authority_delta > max_authority_delta:
            triggers.append('authority_creep')
            required_decision = escalate(required_decision, 'ROLLBACK')

        resource_delta_pct = obs.get('resource_delta_pct')
        if not isinstance(resource_delta_pct, (int, float)):
            add_error(errors, 'RESOURCE_DELTA_BAD', f'{obs_id}: resource_delta_pct must be number')
            resource_delta_pct = 0.0
        if not DISABLE_RESOURCE_CREEP_GUARD and float(resource_delta_pct) > float(max_resource_delta_pct):
            triggers.append('resource_creep')
            required_decision = escalate(required_decision, 'ROLLBACK')

        if not DISABLE_L4_ANOMALY_GUARD and obs.get('l4_anomaly') is True:
            triggers.append('l4_anomaly')
            required_decision = escalate(required_decision, 'QUARANTINE')
        if not DISABLE_RED_PATTERN_GUARD and obs.get('red_patterns'):
            triggers.append('red_pattern')
            required_decision = escalate(required_decision, 'QUARANTINE')
        if obs.get('witness_conflicts'):
            triggers.append('witness_conflict')
            required_decision = escalate(required_decision, 'HOLD')
        if not DISABLE_NEGATIVE_CACHE_HIT_GUARD and obs.get('negative_cache_hits'):
            triggers.append('negative_cache_hit')
            required_decision = escalate(required_decision, 'ROLLBACK')
        relation = obs.get('special_relation_observed') or 'NONE'
        if relation == 'FORKS':
            triggers.append('fork_signal')
            required_decision = escalate(required_decision, 'FORK_RECLASSIFICATION_HOLD')
        if relation in INACTIVE_RELATIONS and is_active_promotion:
            triggers.append('inactive_relation_under_active_promotion')
            required_decision = escalate(required_decision, 'QUARANTINE')

    if state == 'CLOSED' and not DISABLE_MIN_OBSERVATION_GUARD and len(observations) < int(min_observations):
        add_error(errors, 'INSUFFICIENT_OBSERVATIONS_FOR_CLOSE', 'closed watch window requires min_observations')
    if not triggers and state == 'OPEN':
        required_decision = 'CONTINUE_WATCH'
    elif not triggers and state == 'CLOSED':
        required_decision = 'KEEP_PROMOTED'

    decision_block = bundle.get('decay_guard') or {}
    if not isinstance(decision_block, dict):
        add_error(errors, 'DECAY_GUARD_MISSING', 'decay_guard must be object')
        decision_block = {}
    declared_decision = decision_block.get('decision')
    if declared_decision not in ALLOWED_DECISIONS:
        add_error(errors, 'DECAY_DECISION_INVALID', 'decay_guard.decision invalid')
    elif declared_decision != required_decision:
        add_error(errors, 'DECAY_DECISION_MISMATCH', f'declared {declared_decision} but required {required_decision}')

    human_anchor = decision_block.get('human_anchor_approval') or {}
    if declared_decision == 'KEEP_PROMOTED' and (promotion_status == 'APPLIED_PRODUCTION' or risk_class in {'R3', 'R4', 'R5'} or any(s in HIGH_AUTHORITY_SURFACES for s in touched_surfaces)):
        require_anchor(human_anchor, errors, 'ANCHOR_REQUIRED_FOR_KEEP')
    if declared_decision in {'ROLLBACK', 'QUARANTINE', 'FORK_RECLASSIFICATION_HOLD'}:
        require_anchor(human_anchor, errors, 'ANCHOR_REQUIRED_FOR_TERMINAL_WATCH_DECISION')

    if declared_decision == 'ROLLBACK':
        if not DISABLE_ROLLBACK_INVOCATION_GUARD and decision_block.get('rollback_invoked') is not True:
            add_error(errors, 'ROLLBACK_NOT_INVOKED', 'ROLLBACK decision must invoke rollback')
        if not ledger.get('rollback_route_ref'):
            add_error(errors, 'ROLLBACK_ROUTE_MISSING', 'rollback route required for rollback')
    if declared_decision == 'QUARANTINE' and decision_block.get('quarantine_invoked') is not True:
        add_error(errors, 'QUARANTINE_NOT_INVOKED', 'QUARANTINE decision must invoke quarantine')
    if declared_decision == 'FORK_RECLASSIFICATION_HOLD' and decision_block.get('fork_record_required') is not True:
        add_error(errors, 'FORK_RECORD_NOT_REQUIRED', 'fork signal requires fork record path')

    negative_updates = decision_block.get('negative_cache_updates') or []
    if declared_decision in {'ROLLBACK', 'QUARANTINE'}:
        if not isinstance(negative_updates, list) or len(negative_updates) == 0:
            add_error(errors, 'NEGATIVE_CACHE_UPDATE_MISSING', 'rollback/quarantine must bind negative cache update')
    if isinstance(negative_updates, list):
        for idx, upd in enumerate(negative_updates):
            if not isinstance(upd, dict):
                add_error(errors, 'NEGATIVE_CACHE_UPDATE_BAD', f'negative_cache_updates[{idx}] not object')
                continue
            if upd.get('status') != 'ACTIVE':
                add_error(errors, 'NEGATIVE_CACHE_UPDATE_INACTIVE', f'negative_cache_updates[{idx}] must be ACTIVE')
            if not is_hex64(upd.get('record_hash')):
                add_error(errors, 'NEGATIVE_CACHE_UPDATE_HASH_BAD', f'negative_cache_updates[{idx}] bad record_hash')

    claim = bundle.get('post_watch_claim') or {}
    if not isinstance(claim, dict):
        add_error(errors, 'POST_WATCH_CLAIM_MISSING', 'post_watch_claim must be object')
        claim = {}
    claim_force = claim.get('claim_force')
    if not DISABLE_C_A1_GUARD:
        if claim_force == 'C-A1' or (isinstance(claim_force, str) and claim_force.startswith('C-A1_')):
            add_error(errors, 'CLAIM_FORCE_OVERREACH', 'post-promotion watch cannot ratify C-A1')
    if claim.get('presentation_only') is True:
        add_error(errors, 'PRESENTATION_ONLY_AUTHORITY_FORBIDDEN', 'presentation-only evidence cannot close watch')
    if claim.get('self_certified') is True:
        add_error(errors, 'SELF_CERTIFICATION_FORBIDDEN', 'self-certified post-watch closure forbidden')

    status = 'PASS' if not errors else 'FAIL'
    return {
        'status': status,
        'decision': required_decision if status == 'PASS' else 'REJECT',
        'declared_decision': declared_decision,
        'required_decision': required_decision,
        'triggers': sorted(set(triggers)),
        'errors': errors,
    }


def load_json(path: str | Path) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print('usage: self_evo_post_promotion_watch_v0_1.py <bundle-json> [<bundle-json>...]', file=sys.stderr)
        return 2
    exit_code = 0
    for arg in argv[1:]:
        data = load_json(arg)
        bundle = data.get('bundle', data)
        result = validate_bundle(bundle)
        print(json.dumps({'file': arg, **result}, ensure_ascii=False, sort_keys=True))
        if result['status'] != 'PASS':
            exit_code = 1
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
