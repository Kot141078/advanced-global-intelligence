# CCALC Self-Evo Post-Promotion Watch 05d v0.1

This package contains `05d_SELF_EVO_POST_PROMOTION_WATCH_AND_DECAY_GUARD_v0_1`.

It defines the post-promotion watch window and decay guard after a self-evolution promotion has been applied by `05c`.

## Run

```bash
PYTHONDONTWRITEBYTECODE=1 python3 scripts/run_self_evo_watch_fixtures.py
PYTHONDONTWRITEBYTECODE=1 python3 scripts/run_self_evo_watch_mutations.py
sha256sum -c SHA256SUMS.txt
```

## Status

Normative seed + executable checker seed. Not deployment authorization, safety certification, C-A1 ratification, live substrate truth, or proof of completeness.
