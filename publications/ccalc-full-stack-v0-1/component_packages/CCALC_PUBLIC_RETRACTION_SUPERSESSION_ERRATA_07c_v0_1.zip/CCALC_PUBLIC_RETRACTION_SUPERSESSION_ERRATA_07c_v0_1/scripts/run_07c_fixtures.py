#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from public_correction_ledger_checker_v0_1 import validate_record

root = Path(__file__).resolve().parents[1]
cases = sorted((root / "fixtures" / "cases").glob("*.json"))
rows = ["case_id\texpected\tactual\tfinding_codes"]
failed = 0
for path in cases:
    obj = json.loads(path.read_text(encoding="utf-8"))
    findings = validate_record(obj["record"])
    actual = "PASS" if not findings else "FAIL"
    expected = obj["expect"]
    if actual != expected:
        failed += 1
    rows.append(f"{obj['case_id']}\t{expected}\t{actual}\t{','.join(f['code'] for f in findings)}")
(root / "FIXTURE_RESULTS.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
print(f"fixtures: {len(cases)}  PASS: {len(cases)-failed}  FAIL: {failed}")
raise SystemExit(0 if failed == 0 else 1)
