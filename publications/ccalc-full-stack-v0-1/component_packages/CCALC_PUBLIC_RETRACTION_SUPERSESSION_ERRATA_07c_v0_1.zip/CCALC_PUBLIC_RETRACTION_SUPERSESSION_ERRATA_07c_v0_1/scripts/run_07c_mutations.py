#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from public_correction_ledger_checker_v0_1 import validate_record

MUTATIONS = [
    "MUT_IGNORE_SOURCE_BINDINGS",
    "MUT_ALLOW_IN_PLACE_EDIT",
    "MUT_ALLOW_MISSING_PUBLIC_NOTICE",
    "MUT_ALLOW_MODEL_ONLY_APPROVAL",
    "MUT_ALLOW_C_A1_OVERCLAIM",
    "MUT_IGNORE_REPLACEMENT_HASH_MATCH",
    "MUT_IGNORE_NEGATIVE_CACHE_UPDATE",
    "MUT_IGNORE_RED_PATTERN",
    "MUT_ALLOW_RAW_SECRET",
    "MUT_ALLOW_REDACTION_STRENGTHENS_CLAIM",
    "MUT_ALLOW_WITHHELD_AUTHORITY_LAUNDERING",
    "MUT_IGNORE_PRIVACY_REVIEW",
    "MUT_ALLOW_DELETE_OLD_ARTIFACT",
    "MUT_ALLOW_ACTIVE_RETRACTION_STATUS",
    "MUT_ALLOW_STALE_CITATION",
    "MUT_IGNORE_CUSTODY_CHAIN",
    "MUT_ALLOW_ERRATA_AS_SUPERSESSION",
    "MUT_C_A10_PREFIX_FALSE_POSITIVE",
]
root = Path(__file__).resolve().parents[1]
cases = sorted((root / "fixtures" / "cases").glob("*.json"))
rows = ["mutation\tstatus\tdisagreements\texample_cases"]
missed = 0
for mut in MUTATIONS:
    examples = []
    disagreements = 0
    for path in cases:
        obj = json.loads(path.read_text(encoding="utf-8"))
        findings = validate_record(obj["record"], mutation=mut)
        actual = "PASS" if not findings else "FAIL"
        if actual != obj["expect"]:
            disagreements += 1
            if len(examples) < 5:
                examples.append(obj["case_id"])
    status = "CAUGHT" if disagreements else "MISSED"
    if status == "MISSED":
        missed += 1
    rows.append(f"{mut}\t{status}\t{disagreements}\t{','.join(examples)}")
(root / "MUTATION_MATRIX.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
print(f"mutations: {len(MUTATIONS)}  CAUGHT: {len(MUTATIONS)-missed}  MISSED: {missed}")
raise SystemExit(0 if missed == 0 else 1)
