# CCALC Public Retraction / Supersession / Errata Ledger 07c v0.1

This package contains the `07c` public correction ledger layer.

Primary document:

```text
07c_PUBLIC_RETRACTION_SUPERSESSION_AND_ERRATA_LEDGER_v0_1.md
```

Core formula:

```text
publication is not irreversible authority;
publication opens a public correction ledger.
```

Run checks:

```bash
python3 scripts/run_07c_fixtures.py
python3 scripts/run_07c_mutations.py
sha256sum -c SHA256SUMS.txt
```
