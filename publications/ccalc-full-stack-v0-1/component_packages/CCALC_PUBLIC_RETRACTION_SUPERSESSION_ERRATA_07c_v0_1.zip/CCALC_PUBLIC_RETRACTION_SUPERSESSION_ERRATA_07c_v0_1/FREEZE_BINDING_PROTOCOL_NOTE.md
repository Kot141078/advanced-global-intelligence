# Freeze Binding Protocol Note

Use external sidecar binding:

```bash
sha256sum exact_file_bytes > filename.sha256
```

Do not place a self-referential hash inside the Markdown body being hashed.
