# Open Issues and Next Steps

Closed in this package:

```text
errata records
supersession records
retraction records
public correction notices
citation guidance
hash-custody correction checks
negative-cache update boundary
```

Natural next layer:

```text
07d_PUBLIC_CORPUS_INDEX_AND_CITATION_SURFACE_SYNC_v0_1
```

That layer should bind public pages, repository indexes, DOI metadata, citation files, and release pages after errata/supersession/retraction events.
