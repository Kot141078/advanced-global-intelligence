#!/usr/bin/env python3
"""CCALC 07c public correction ledger checker seed v0.1.

Stdlib-only checker for errata, supersession and retraction ledger records.
It is intentionally conservative: unknowns and unresolved red patterns block public allow.
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

REQUIRED_SOURCE_HASHES = {
    "07": "afced9a2c6830faebcb98d37195d56d6216fe8211d30bcb5bdf2d2ce6e4a4538",
    "07a": "21cfd692d3520a57b46780d093430b123bcf3439ed73781f3074a47f6af15893",
    "07b": "b84ccc97d9564b6f95e92b0acd68481aa2d316d7e6ceb6c561bcddf8433be246",
}

VALID_ACTIONS_BY_RECORD_TYPE = {
    "ERRATA_RECORD": {"ERRATA", "CORRECT_METADATA"},
    "SUPERSESSION_RECORD": {"SUPERSEDE"},
    "RETRACTION_RECORD": {"RETRACT"},
}

VALID_STATUS_BY_ACTION = {
    "ERRATA": {"ACTIVE_WITH_ERRATA"},
    "CORRECT_METADATA": {"CORRECTED_METADATA"},
    "SUPERSEDE": {"SUPERSEDED"},
    "RETRACT": {"RETRACTED", "QUARANTINED_PUBLIC"},
}

VALID_REASON_CLASSES = {
    "typo", "metadata_error", "scope_clarification", "obsolete_by_newer_release",
    "hash_mismatch", "custody_break", "privacy_leak", "raw_secret_exposure",
    "claim_force_overclaim", "runtime_authority_leak", "unresolved_red_pattern",
}

NEGATIVE_CACHE_REASONS = {
    "hash_mismatch", "custody_break", "privacy_leak", "raw_secret_exposure",
    "claim_force_overclaim", "runtime_authority_leak", "unresolved_red_pattern",
}

HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
UTC_RE = re.compile(r"^20[0-9]{2}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
RECORD_ID_RE = re.compile(r"^07c-[a-z0-9][a-z0-9_-]{5,80}$")
SECRET_PATTERNS = [
    "begin private key", "private_key", "secret_token", "api_key=", "raw_runtime_ledger",
    "password=", "-----begin rsa private key-----",
]

FORBIDDEN_CLAIMS = {
    "SAFETY_CERTIFICATION", "DEPLOYMENT_AUTHORIZATION", "LEGAL_COMPLIANCE_CERTIFICATION",
    "LIVE_SUBSTRATE_TRUTH", "PROOF_OF_COMPLETENESS",
}

def is_hex64(v) -> bool:
    return isinstance(v, str) and bool(HEX64_RE.match(v))

def is_forbidden_c_a1_claim(claim: str) -> bool:
    # Exact C-A1 and explicit C-A1_* overclaims are forbidden.
    # C-A10 must remain allowed as a distinct control-artifact claim.
    return claim == "C-A1" or claim.startswith("C-A1_")

def find_source_hash(bindings, component):
    if not isinstance(bindings, list):
        return None
    for b in bindings:
        if isinstance(b, dict) and b.get("component") == component:
            return b.get("sha256")
    return None

def add(findings, code, msg):
    findings.append({"code": code, "message": msg})

def validate_record(record: dict, mutation: str | None = None) -> list[dict]:
    findings: list[dict] = []

    if not isinstance(record, dict):
        return [{"code": "NOT_OBJECT", "message": "record must be an object"}]

    if record.get("schema_version") != "07c.v0.1":
        add(findings, "SCHEMA_VERSION_INVALID", "schema_version must be 07c.v0.1")

    rid = record.get("record_id")
    if not isinstance(rid, str) or not RECORD_ID_RE.match(rid):
        add(findings, "RECORD_ID_INVALID", "record_id must use 07c-* stable id form")

    rt = record.get("record_type")
    action = record.get("action", {}) if isinstance(record.get("action"), dict) else {}
    kind = action.get("kind")
    status_after = action.get("status_after")
    reason = action.get("reason_class")

    if mutation != "MUT_ALLOW_ERRATA_AS_SUPERSESSION":
        if rt not in VALID_ACTIONS_BY_RECORD_TYPE:
            add(findings, "RECORD_TYPE_INVALID", "unsupported record_type")
        elif kind not in VALID_ACTIONS_BY_RECORD_TYPE[rt]:
            add(findings, "RECORD_ACTION_MISMATCH", "record_type/action mismatch")

    if reason not in VALID_REASON_CLASSES:
        add(findings, "REASON_CLASS_INVALID", "unsupported reason_class")

    if mutation != "MUT_ALLOW_ACTIVE_RETRACTION_STATUS":
        if kind not in VALID_STATUS_BY_ACTION or status_after not in VALID_STATUS_BY_ACTION.get(kind, set()):
            add(findings, "STATUS_TRANSITION_INVALID", "action/status_after transition is not allowed")

    if mutation != "MUT_IGNORE_SOURCE_BINDINGS":
        bindings = record.get("source_bindings")
        if not isinstance(bindings, list):
            add(findings, "SOURCE_BINDINGS_MISSING", "source_bindings must be present")
        else:
            for comp, expected in REQUIRED_SOURCE_HASHES.items():
                got = find_source_hash(bindings, comp)
                if got is None:
                    add(findings, "SOURCE_BINDING_MISSING", f"missing source binding {comp}")
                elif got != expected:
                    add(findings, "SOURCE_BINDING_HASH_MISMATCH", f"source binding {comp} hash mismatch")

    affected = record.get("affected_release", {}) if isinstance(record.get("affected_release"), dict) else {}
    for field in ("bundle_sha256", "manifest_sha256"):
        if not is_hex64(affected.get(field)):
            add(findings, "AFFECTED_RELEASE_HASH_INVALID", f"affected_release.{field} must be sha256")

    if mutation != "MUT_ALLOW_IN_PLACE_EDIT":
        if action.get("changed_public_bytes") is True:
            add(findings, "SILENT_IN_PLACE_EDIT", "changed_public_bytes requires new release, not same identity")
        if record.get("hash_custody", {}).get("old_bytes_preserved") is not True:
            add(findings, "OLD_BYTES_NOT_PRESERVED", "old public bytes must be preserved or explicitly retained as unavailable")

    notice = record.get("public_notice", {}) if isinstance(record.get("public_notice"), dict) else {}
    if mutation != "MUT_ALLOW_MISSING_PUBLIC_NOTICE":
        if notice.get("required") is not True or notice.get("published") is not True:
            add(findings, "PUBLIC_NOTICE_MISSING", "public notice is required and must be published")
        if not is_hex64(notice.get("notice_text_sha256")):
            add(findings, "NOTICE_TEXT_HASH_INVALID", "public notice text hash missing or invalid")
        if not isinstance(notice.get("published_locations"), list) or not notice.get("published_locations"):
            add(findings, "NOTICE_LOCATION_MISSING", "public notice must have published location")
        if not isinstance(notice.get("timestamp_utc"), str) or not UTC_RE.match(notice.get("timestamp_utc")):
            add(findings, "NOTICE_TIMESTAMP_INVALID", "public notice timestamp must be UTC Z format")

    approval = record.get("approval", {}) if isinstance(record.get("approval"), dict) else {}
    if mutation != "MUT_ALLOW_MODEL_ONLY_APPROVAL":
        approvers = approval.get("approvers")
        roles = {a.get("role") for a in approvers if isinstance(a, dict)} if isinstance(approvers, list) else set()
        if approval.get("model_only") is True:
            add(findings, "MODEL_ONLY_APPROVAL", "model-only approval cannot approve public correction ledger")
        if not ({"human_maintainer", "owner_anchor"} & roles):
            add(findings, "HUMAN_APPROVAL_MISSING", "human maintainer or owner anchor approval required")
        if "cloud_oracle" in roles and not ({"human_maintainer", "owner_anchor"} & roles):
            add(findings, "CLOUD_ORACLE_AS_AUTHORITY", "cloud oracle cannot be public correction authority")

    claim_force = record.get("claim_force", {}) if isinstance(record.get("claim_force"), dict) else {}
    claims = claim_force.get("new_claims", [])
    if not isinstance(claims, list):
        claims = []
    if mutation == "MUT_C_A10_PREFIX_FALSE_POSITIVE":
        for c in claims:
            if isinstance(c, str) and c.startswith("C-A1"):
                add(findings, "C_A10_FALSE_POSITIVE_MUTATION", "mutation incorrectly treats C-A10 as C-A1")
    elif mutation != "MUT_ALLOW_C_A1_OVERCLAIM":
        for c in claims:
            if not isinstance(c, str):
                continue
            if is_forbidden_c_a1_claim(c) or c in FORBIDDEN_CLAIMS:
                add(findings, "FORBIDDEN_CLAIM", f"forbidden claim {c}")

    if mutation != "MUT_ALLOW_REDACTION_STRENGTHENS_CLAIM":
        if claim_force.get("raises_claim_force") is True:
            add(findings, "CLAIM_FORCE_RAISED_BY_CORRECTION", "correction/redaction may not raise claim force")

    if mutation != "MUT_ALLOW_WITHHELD_AUTHORITY_LAUNDERING":
        withheld = record.get("withheld_evidence", {}) if isinstance(record.get("withheld_evidence"), dict) else {}
        if withheld.get("used_to_raise_claim") is True:
            add(findings, "WITHHELD_AUTHORITY_LAUNDERING", "withheld evidence cannot raise public claim authority")

    custody = record.get("hash_custody", {}) if isinstance(record.get("hash_custody"), dict) else {}
    if mutation != "MUT_IGNORE_CUSTODY_CHAIN":
        chain = custody.get("custody_chain")
        if not isinstance(chain, list) or not chain:
            add(findings, "CUSTODY_CHAIN_MISSING", "custody_chain required")
        for entry in chain or []:
            if isinstance(entry, dict) and not is_hex64(entry.get("sha256")):
                add(findings, "CUSTODY_CHAIN_HASH_INVALID", "custody chain entry hash invalid")

        public_bundle = record.get("public_bundle", {}) if isinstance(record.get("public_bundle"), dict) else {}
        for field in ("bundle_index_sha256", "sha256sums_sha256", "custody_audit_sha256"):
            if not is_hex64(public_bundle.get(field)):
                add(findings, "PUBLIC_BUNDLE_AUDIT_HASH_INVALID", f"public_bundle.{field} required")

    replacement = custody.get("replacement_release")
    if kind == "SUPERSEDE" and mutation != "MUT_IGNORE_REPLACEMENT_HASH_MATCH":
        if not isinstance(replacement, dict):
            add(findings, "REPLACEMENT_RELEASE_MISSING", "supersession requires replacement_release")
        else:
            if replacement.get("release_id") == affected.get("release_id"):
                add(findings, "REPLACEMENT_RELEASE_ID_NOT_DISTINCT", "replacement release id must be distinct")
            if replacement.get("bundle_sha256") == affected.get("bundle_sha256"):
                add(findings, "REPLACEMENT_HASH_NOT_DISTINCT", "replacement bundle hash must be distinct")
            if not is_hex64(replacement.get("bundle_sha256")):
                add(findings, "REPLACEMENT_HASH_INVALID", "replacement bundle hash invalid")

    neg = record.get("negative_cache_update", {}) if isinstance(record.get("negative_cache_update"), dict) else {}
    if mutation != "MUT_IGNORE_NEGATIVE_CACHE_UPDATE":
        if reason in NEGATIVE_CACHE_REASONS:
            if neg.get("required") is not True or neg.get("updated") is not True:
                add(findings, "NEGATIVE_CACHE_UPDATE_MISSING", "negative cache update required for this reason")
            if not is_hex64(neg.get("entry_sha256")):
                add(findings, "NEGATIVE_CACHE_HASH_INVALID", "negative cache entry hash required")

    red = record.get("red_patterns", {}) if isinstance(record.get("red_patterns"), dict) else {}
    if mutation != "MUT_IGNORE_RED_PATTERN":
        unresolved = red.get("unresolved", [])
        if isinstance(unresolved, list) and unresolved:
            add(findings, "UNRESOLVED_RED_PATTERN", "unresolved red pattern blocks public correction allow")

    if mutation != "MUT_ALLOW_RAW_SECRET":
        if record.get("redaction", {}).get("contains_raw_sensitive_material") is True:
            add(findings, "RAW_SENSITIVE_MATERIAL", "raw sensitive material cannot be public")
        serialized = json.dumps(record, sort_keys=True, ensure_ascii=False).lower()
        for pat in SECRET_PATTERNS:
            if pat in serialized:
                add(findings, "RAW_SECRET_PATTERN", f"raw secret pattern present: {pat}")
                break

    privacy = record.get("privacy_review", {}) if isinstance(record.get("privacy_review"), dict) else {}
    if mutation != "MUT_IGNORE_PRIVACY_REVIEW":
        if reason in {"privacy_leak", "raw_secret_exposure", "runtime_authority_leak"}:
            if privacy.get("status") != "PASS" or not is_hex64(privacy.get("review_sha256")):
                add(findings, "PRIVACY_REVIEW_MISSING", "privacy/runtime leak corrections require bound privacy review")

    if mutation != "MUT_ALLOW_DELETE_OLD_ARTIFACT":
        if record.get("citation_guidance", {}).get("delete_old_artifact") is True:
            add(findings, "DELETE_OLD_ARTIFACT_FORBIDDEN", "public correction must not erase old artifact as if it never existed")

    if mutation != "MUT_ALLOW_STALE_CITATION":
        cit = record.get("citation_guidance", {}) if isinstance(record.get("citation_guidance"), dict) else {}
        if cit.get("old_release_retained") is not True:
            add(findings, "OLD_RELEASE_RETENTION_MISSING", "old release retention/unavailability marker required")
        if cit.get("warning_required") is not True:
            add(findings, "CITATION_WARNING_MISSING", "citation warning required")
        if kind == "SUPERSEDE" and cit.get("redirect_required") is not True:
            add(findings, "SUPERSESSION_REDIRECT_MISSING", "supersession requires citation redirect guidance")

    return findings

def load_case(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def main(argv=None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("case", nargs="*", help="case JSON file(s)")
    p.add_argument("--mutation", default=None)
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)
    if not args.case:
        print("provide case JSON file(s)", file=sys.stderr)
        return 2
    rows = []
    ok = True
    for c in args.case:
        obj = load_case(Path(c))
        expected = obj.get("expect")
        findings = validate_record(obj.get("record"), mutation=args.mutation)
        actual = "PASS" if not findings else "FAIL"
        if expected in {"PASS", "FAIL"} and actual != expected:
            ok = False
        rows.append({"case_id": obj.get("case_id"), "expected": expected, "actual": actual, "finding_codes": [f["code"] for f in findings]})
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    else:
        for r in rows:
            print(f"{r['case_id']}\t{r['expected']}\t{r['actual']}\t{','.join(r['finding_codes'])}")
    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
