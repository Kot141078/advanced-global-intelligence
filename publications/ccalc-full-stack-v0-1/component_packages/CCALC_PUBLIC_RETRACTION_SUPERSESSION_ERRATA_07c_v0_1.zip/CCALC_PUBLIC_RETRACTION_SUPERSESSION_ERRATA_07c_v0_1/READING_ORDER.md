# Reading Order

1. `07c_PUBLIC_RETRACTION_SUPERSESSION_AND_ERRATA_LEDGER_v0_1.md`
2. `schemas/public_correction_ledger_record.schema.json`
3. `src/public_correction_ledger_checker_v0_1.py`
4. `fixtures/cases/*.json`
5. `FIXTURE_RESULTS.tsv`
6. `MUTATION_MATRIX.tsv`
7. `COVERAGE_MATRIX.tsv`
8. `NON_CLAIMS_AND_SCOPE.md`
