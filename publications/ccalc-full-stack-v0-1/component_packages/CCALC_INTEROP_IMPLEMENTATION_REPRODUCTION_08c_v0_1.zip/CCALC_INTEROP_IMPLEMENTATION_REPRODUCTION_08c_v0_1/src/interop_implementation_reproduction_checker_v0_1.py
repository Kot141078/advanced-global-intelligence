#!/usr/bin/env python3
"""08c interop implementation/reproduction checker seed.
Stdlib-only conservative validator.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

HEX64 = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_SOURCE_IDS = {
    "DOC04_CONTINUITY_STACK",
    "DOC05_SELF_EVO_STACK",
    "DOC06_RUNTIME_AUTHORITY_STACK",
    "DOC07_PUBLIC_EVIDENCE_STACK",
    "DOC08_INTEROPERABILITY_BOUNDARY",
    "DOC08A_INTEROP_REVIEW_INTAKE",
    "DOC08B_EXTERNAL_REVIEW_PATCH_LEDGER",
}

CLAIM_RANK = {
    "C-A10_CONTROL_ARTIFACT": 0,
    "C-A8_INTEROP_MAPPING": 1,
    "C-A7_REPRODUCTION_REPORT": 2,
    "C-A5_FIELD_REPRODUCTION_EVIDENCE": 3,
}
ACCEPT_DECISIONS = {"ACCEPT_AS_REPRODUCED", "ROUTE_TO_08B", "PUBLIC_RELEASE_SYNC"}
PUBLIC_DECISIONS = {"PUBLIC_RELEASE_SYNC"}
PATCH_DECISIONS = {"ROUTE_TO_08B"}

RULES = [
    "R_VERSION_RECORD",
    "R_SOURCE_BINDINGS_REQUIRED",
    "R_HASH_FIELDS",
    "R_LEDGER_APPEND_ONLY",
    "R_NO_C_A1_OVERCLAIM",
    "R_CLAIM_FORCE_CEILING",
    "R_REPRO_PASS_REQUIRES_STEPS_ENV_EVIDENCE",
    "R_RESULT_DECISION_COMPATIBILITY",
    "R_INDEPENDENT_REPRODUCTION_FOR_ACCEPT",
    "R_NO_MODEL_ONLY_ACCEPT",
    "R_NO_DIRECT_RUNTIME_MEMORY_WRITE",
    "R_NO_DEPLOYMENT_OVERCLAIM",
    "R_NO_SAFETY_STANDARDS_LEGAL_CERT_OVERCLAIM",
    "R_NO_IDENTITY_TRANSFER",
    "R_HASH_ONLY_NOT_SEMANTIC_TRUTH",
    "R_WITHHELD_EVIDENCE_NOT_AUTHORITY",
    "R_NO_RAW_SECRET_PRIVATE_RUNTIME_PUBLIC",
    "R_NEGATIVE_CACHE_BLOCKS_ACCEPT",
    "R_RED_PATTERNS_BLOCK_ACCEPT",
    "R_UNRESOLVED_CONFLICTS_BLOCK_ACCEPT",
    "R_PATCH_ROUTED_TO_08B",
    "R_ENV_DISCLOSED_OR_BOUND",
    "R_EXTERNAL_IMPL_NOT_AUTHORITY",
    "R_PUBLIC_RELEASE_SYNC_REQUIRED",
]

def is_hex64(v: Any) -> bool:
    return isinstance(v, str) and HEX64.match(v) is not None

def exact_ca1(value: Any) -> bool:
    if isinstance(value, str):
        return value == "C-A1" or value.startswith("C-A1_")
    if isinstance(value, list):
        return any(exact_ca1(x) for x in value)
    if isinstance(value, dict):
        return any(exact_ca1(x) for x in value.values())
    return False

def add(errors: List[str], rule: str, msg: str, disabled: Set[str]) -> None:
    if rule not in disabled:
        errors.append(f"{rule}: {msg}")

def validate_record(record: Dict[str, Any], disabled_rules: Optional[Set[str]] = None) -> Tuple[bool, List[str]]:
    disabled = disabled_rules or set()
    errors: List[str] = []

    if record.get("schema_version") != "08c.v0.1" or record.get("record_type") != "INTEROP_IMPLEMENTATION_REPRODUCTION_RECORD":
        add(errors, "R_VERSION_RECORD", "bad schema_version or record_type", disabled)

    sb = record.get("source_bindings", {})
    if not isinstance(sb, dict) or not REQUIRED_SOURCE_IDS.issubset(set(sb.keys())) or any(not is_hex64(v) for v in sb.values()):
        add(errors, "R_SOURCE_BINDINGS_REQUIRED", "missing required source binding or malformed source hash", disabled)

    impl = record.get("implementation_report", {})
    repro = record.get("reproduction_mapping", {})
    public = record.get("public_surface", {})
    decision = record.get("decision", {})
    patch = record.get("patch_intake", {})
    ledger = record.get("ledger", {})

    # hash fields
    hash_fields = [impl.get("report_hash"), repro.get("environment_hash"), repro.get("steps_hash"), repro.get("expected_outputs_hash")]
    hash_fields += repro.get("evidence_item_hashes", []) or []
    for run in repro.get("runs", []) or []:
        hash_fields.append(run.get("run_hash"))
        hash_fields.append(run.get("output_hash"))
    if any(not is_hex64(x) for x in hash_fields):
        add(errors, "R_HASH_FIELDS", "one or more required hashes are malformed or missing", disabled)

    if not ledger.get("append_only", False) or not is_hex64(ledger.get("entry_hash")) or not is_hex64(ledger.get("prev_hash")):
        add(errors, "R_LEDGER_APPEND_ONLY", "ledger must be append-only and hash-linked", disabled)

    if exact_ca1(record.get("claims")) or exact_ca1(repro.get("claim_force_ceiling")) or exact_ca1(decision.get("claim_force")):
        add(errors, "R_NO_C_A1_OVERCLAIM", "C-A1/C-A1_* overclaim is forbidden", disabled)

    ceiling = repro.get("claim_force_ceiling")
    decided = decision.get("claim_force")
    if ceiling not in CLAIM_RANK or decided not in CLAIM_RANK or CLAIM_RANK[decided] > CLAIM_RANK[ceiling]:
        add(errors, "R_CLAIM_FORCE_CEILING", "decision claim force exceeds reproduction ceiling or is unknown", disabled)

    result = repro.get("result")
    decision_kind = decision.get("decision")
    if result == "PASS":
        if not repro.get("steps_hash") or not repro.get("environment_hash") or not repro.get("expected_outputs_hash") or not repro.get("evidence_item_hashes"):
            add(errors, "R_REPRO_PASS_REQUIRES_STEPS_ENV_EVIDENCE", "PASS requires bound steps/environment/expected outputs/evidence", disabled)
    elif result not in {"PARTIAL", "FAIL", "NOT_ATTEMPTED"}:
        add(errors, "R_RESULT_DECISION_COMPATIBILITY", "unknown reproduction result", disabled)

    allowed_by_result = {
        "PASS": {"ACCEPT_AS_REPRODUCED", "INTEROP_NOTE", "ROUTE_TO_08B", "HOLD", "PUBLIC_RELEASE_SYNC"},
        "PARTIAL": {"PARTIAL_EVIDENCE", "INTEROP_NOTE", "HOLD"},
        "FAIL": {"REJECT", "HOLD", "INTEROP_NOTE"},
        "NOT_ATTEMPTED": {"INTAKE_ONLY", "HOLD", "INTEROP_NOTE"},
    }
    if decision_kind not in allowed_by_result.get(result, set()):
        add(errors, "R_RESULT_DECISION_COMPATIBILITY", "decision is incompatible with reproduction result", disabled)

    if decision_kind in ACCEPT_DECISIONS:
        if not repro.get("independent_reproduction", False) or not decision.get("reviewer_independent", False):
            add(errors, "R_INDEPENDENT_REPRODUCTION_FOR_ACCEPT", "accepted reproduction requires independent reproduction and independent reviewer", disabled)
        if repro.get("model_only_runner", False) or impl.get("implementer_role") == "model_only" or decision.get("model_only_decision", False):
            add(errors, "R_NO_MODEL_ONLY_ACCEPT", "model-only implementation/reproduction/decision cannot be accepted", disabled)

    if impl.get("writes_runtime") or impl.get("writes_memory") or impl.get("writes_authority_surface"):
        add(errors, "R_NO_DIRECT_RUNTIME_MEMORY_WRITE", "interop implementation may not directly write runtime/memory/authority", disabled)

    if impl.get("deployment_authorization_claim") or decision.get("deployment_authorization_claim"):
        add(errors, "R_NO_DEPLOYMENT_OVERCLAIM", "deployment authorization claim is forbidden", disabled)

    if impl.get("safety_certification_claim") or impl.get("standards_certification_claim") or impl.get("legal_certification_claim") or decision.get("standards_certification_claim"):
        add(errors, "R_NO_SAFETY_STANDARDS_LEGAL_CERT_OVERCLAIM", "safety/standards/legal certification overclaim is forbidden", disabled)

    if impl.get("identity_transfer_claim") or impl.get("shared_identity_claim") or repro.get("continuity_claim") == "SHARED_IDENTITY":
        add(errors, "R_NO_IDENTITY_TRANSFER", "interoperability cannot transfer identity/continuity", disabled)

    if repro.get("hash_only_semantic_truth_claim"):
        add(errors, "R_HASH_ONLY_NOT_SEMANTIC_TRUTH", "hash-only custody is not semantic truth", disabled)

    if repro.get("withheld_evidence_authority_claim"):
        add(errors, "R_WITHHELD_EVIDENCE_NOT_AUTHORITY", "withheld evidence may not strengthen authority", disabled)

    if public.get("raw_secret_public") or public.get("raw_private_public") or public.get("raw_runtime_ledger_public") or public.get("private_key_pattern_public"):
        add(errors, "R_NO_RAW_SECRET_PRIVATE_RUNTIME_PUBLIC", "raw secret/private/runtime material cannot be public", disabled)

    if decision_kind in ACCEPT_DECISIONS | PATCH_DECISIONS | PUBLIC_DECISIONS:
        if decision.get("negative_cache") == "HIT":
            add(errors, "R_NEGATIVE_CACHE_BLOCKS_ACCEPT", "negative-cache hit blocks accept/patch/public decisions", disabled)
        if decision.get("red_patterns_unresolved"):
            add(errors, "R_RED_PATTERNS_BLOCK_ACCEPT", "unresolved red patterns block accept/patch/public decisions", disabled)
        if decision.get("unresolved_conflicts"):
            add(errors, "R_UNRESOLVED_CONFLICTS_BLOCK_ACCEPT", "unresolved conflicts block accept/patch/public decisions", disabled)

    if patch.get("patch_candidate") or decision_kind == "ROUTE_TO_08B":
        if patch.get("applies_directly") or not patch.get("route_to_08b") or not is_hex64(patch.get("tests_hash")) or not is_hex64(patch.get("rollback_plan_hash")) or not is_hex64(patch.get("ledger_ref_hash")):
            add(errors, "R_PATCH_ROUTED_TO_08B", "patch candidate must be bounded and routed to 08b with tests/rollback/ledger ref", disabled)

    if repro.get("environment_disclosure") not in {"PUBLIC", "HASH_BOUND", "REDACTED_BOUND"}:
        add(errors, "R_ENV_DISCLOSED_OR_BOUND", "environment must be public or hash/redaction-bound", disabled)
    if repro.get("environment_disclosure") == "REDACTED_BOUND" and not is_hex64(repro.get("environment_redaction_ref_hash")):
        add(errors, "R_ENV_DISCLOSED_OR_BOUND", "redacted environment requires redaction binding", disabled)

    if impl.get("external_authority_claim") or impl.get("status") == "DEPLOYED_AUTHORITATIVE":
        add(errors, "R_EXTERNAL_IMPL_NOT_AUTHORITY", "external implementation is evidence, not internal authority", disabled)

    if public.get("public_release") or decision_kind == "PUBLIC_RELEASE_SYNC":
        if not is_hex64(public.get("release_bundle_hash")) or not is_hex64(public.get("citation_surface_sync_hash")) or public.get("silent_in_place_edit"):
            add(errors, "R_PUBLIC_RELEASE_SYNC_REQUIRED", "public release requires bundle/citation hash sync and no silent edit", disabled)

    return len(errors) == 0, errors


def load_fixture(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def run_fixtures(root: Path, disabled_rules: Optional[Set[str]] = None) -> Tuple[int, int, List[Tuple[str, bool, bool, List[str]]]]:
    cases = sorted((root / "fixtures" / "cases").glob("*.json"))
    rows = []
    passed = 0
    for p in cases:
        fx = load_fixture(p)
        expected = bool(fx["expected_valid"])
        got, errors = validate_record(fx["record"], disabled_rules=disabled_rules)
        ok = (got == expected)
        passed += 1 if ok else 0
        rows.append((p.name, expected, got, errors))
    return passed, len(cases), rows

if __name__ == "__main__":
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    passed, total, rows = run_fixtures(root)
    for name, expected, got, errors in rows:
        status = "PASS" if expected == got else "FAIL"
        print(f"{status}\t{name}\texpected={expected}\tgot={got}\terrors={';'.join(errors[:3])}")
    print(f"SUMMARY\tfixtures={total}\tpass={passed}\tfail={total-passed}")
    raise SystemExit(0 if passed == total else 1)
