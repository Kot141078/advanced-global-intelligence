# Freeze Binding Protocol Note

All normative files in this package are bound by external `.sha256` sidecars and by `SHA256SUMS.txt`.

No Markdown file embeds its own final hash. Hashes are computed over exact file bytes after file writing is complete.
