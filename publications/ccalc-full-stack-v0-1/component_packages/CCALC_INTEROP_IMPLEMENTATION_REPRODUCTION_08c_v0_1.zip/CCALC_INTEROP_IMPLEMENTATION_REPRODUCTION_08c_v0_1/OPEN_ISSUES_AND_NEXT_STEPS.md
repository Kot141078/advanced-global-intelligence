# Open Issues and Next Steps

## Open

- Real third-party implementation reports are not bundled here.
- Environment normalization remains coarse and hash-bound only.
- Cross-platform nondeterminism policies should be expanded in a later profile.
- Test-vector disclosure requires a separate public/private split.

## Next

`08d_INTEROP_EXTERNAL_IMPLEMENTATION_DISCLOSURE_AND_TEST_VECTOR_REGISTRY_v0_1`
