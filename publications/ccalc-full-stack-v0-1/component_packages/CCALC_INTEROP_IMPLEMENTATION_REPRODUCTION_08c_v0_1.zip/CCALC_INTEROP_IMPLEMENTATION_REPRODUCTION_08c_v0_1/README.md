# CCALC Interop Implementation / Reproduction Mapping 08c v0.1

This package defines a conservative record and checker seed for admitting external implementation reports and reproduction mappings into the c-calculus corpus.

Run:

```bash
python3 scripts/run_implementation_reproduction_fixtures.py
python3 scripts/run_implementation_reproduction_mutations.py
sha256sum -c SHA256SUMS.txt
```
