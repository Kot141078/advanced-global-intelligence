#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from interop_implementation_reproduction_checker_v0_1 import RULES, run_fixtures

missed = 0
for rule in RULES:
    passed, total, rows = run_fixtures(ROOT, disabled_rules={rule})
    mismatches = total - passed
    caught = mismatches > 0
    print(f"{'CAUGHT' if caught else 'MISSED'}\tMUT_DISABLE_{rule}\tmismatches={mismatches}")
    if not caught:
        missed += 1
print(f"SUMMARY\tmutations={len(RULES)}\tcaught={len(RULES)-missed}\tmissed={missed}")
raise SystemExit(0 if missed == 0 else 1)
