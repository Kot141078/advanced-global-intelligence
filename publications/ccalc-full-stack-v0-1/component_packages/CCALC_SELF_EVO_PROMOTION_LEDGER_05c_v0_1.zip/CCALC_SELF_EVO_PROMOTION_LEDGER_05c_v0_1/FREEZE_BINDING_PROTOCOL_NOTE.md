# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each file:

```text
sha256sum exact_file_bytes > filename.sha256
```

Files do not include their own hashes internally.
