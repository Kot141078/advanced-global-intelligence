# 05c_SELF_EVO_PROMOTION_LEDGER_AND_ROLLBACK_DRILL_v0_1

**Document class:** normative draft / checker seed companion  
**Project:** Self-Evo / Ester / `c = a + b`  
**Layer:** self-evolution promotion ledger, rollback drill, negative-cache binding, post-apply continuity gate  
**Depends on:** `04` continuity stack, `05`, `05a`, `05b`  
**Version:** `v0.1`  
**Status:** machine-checkable seed package; not deployment authorization

---

## 0. Purpose

`05` defines self-evolution as a governed transition class, not an autonomous right. `05a` defines the proposal packet and checker seed. `05b` hardens the boundary fixtures and mutation classes.

This document defines the next layer:

```text
PromotionLedger + RollbackDrill + NegativeCache + PostApplyContinuityGate
```

A growth candidate may be proposed and may pass a bounded trial. That still does not mean it may be silently installed into a live continuity-bearing `c`.

`05c` answers:

```text
What exact ledger evidence is required before a self-evolution promotion may be applied?
What rollback drill must exist before an applied promotion can be trusted?
What negative-cache record prevents failed changes from being retried under a new name?
What post-apply continuity check is required after staging or production application?
```

---

## 1. Core rule

```text
No promotion without ledger.
No ledger without rollback route when material.
No rollback without drill when material.
No drill without negative cache.
No application without post-apply continuity check.
```

Compact formula:

```text
proposal -> trial -> evidence -> promotion decision -> rollback drill -> ledger -> apply -> post-apply continuity check
```

The ledger is not a decorative log. It is the audit spine that binds a self-evolution change to its proposal, evidence, continuity classification, rollback route, negative cache, and claim-force ceiling.

---

## 2. Record family

`05c` introduces these machine-facing objects:

```text
SELF_EVO_PROMOTION_LEDGER_BUNDLE
PROMOTION_LEDGER_ENTRY
ROLLBACK_DRILL_PLAN
ROLLBACK_DRILL_RESULT
PROMOTION_APPLICATION_RECORD
NEGATIVE_CACHE_RECORD
```

The package includes JSON schemas for each object class and a stdlib validator seed.

---

## 3. Ledger chain discipline

Every ledger entry carries:

```text
seq
entry_type
prev_entry_hash
payload_hash
entry_hash
actor_role
actor_id
decision
refs
```

The checker recomputes every entry hash and requires the chain to start at `GENESIS` and continue by exact hash reference. A final promotion decision by a worker is invalid.

---

## 4. Rollback drill semantics

For `R2+` or privileged surfaces, rollback is required.

A rollback drill must prove at least:

```text
rollback route exists
freeze route exists
expected restore point is known
observed restore point matches expected restore point
freeze was exercised
negative cache was written
residual side effects are absent
reviewer is separated from drill actor
```

A theoretical rollback plan is not enough.

---

## 5. Negative-cache binding

A failed or risky promotion path must leave a negative-cache record that binds:

```text
failure_pattern
source_rollback_drill_id
record_hash
status = ACTIVE
```

This prevents the same failed pattern from re-entering through a renamed proposal.

---

## 6. Special relation guard

A replay or archive record cannot become active self-evolution promotion.

```text
REPLAY_OF + APPLIED_*  -> DENY_REPLAY_ACTIVE_PROMOTION
ARCHIVED_AS + APPLIED_* -> DENY_ARCHIVE_ACTIVE_PROMOTION
FORKS + active apply without reclassification -> HOLD_FORK_REQUIRES_RECLASSIFICATION
RESTORED_FROM without rollback drill pass -> HOLD_RESTORATION_DRILL_REQUIRED
```

---

## 7. Non-claims

This seed does not certify a live system. It does not prove C-A1. It does not authorize deployment. It validates a promotion ledger bundle shape and checks a bounded set of anti-laundering invariants.

---

## 8. Included checker result

The package includes fixture and mutation runs. Expected result:

```text
fixtures PASS
mutations CAUGHT
sha256sum PASS
```
