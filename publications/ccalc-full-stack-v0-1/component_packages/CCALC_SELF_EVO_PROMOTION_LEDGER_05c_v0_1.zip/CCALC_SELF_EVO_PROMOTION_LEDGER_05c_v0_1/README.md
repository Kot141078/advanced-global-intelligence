# CCALC Self-Evo Promotion Ledger 05c v0.1

Promotion-ledger and rollback-drill layer for the Self-Evo stack.

This package binds `05`, `05a`, and `05b` into a promotion ledger bundle with rollback drill, negative-cache, and post-apply continuity checks.

Run:

```bash
python3 scripts/run_promotion_ledger_fixtures.py
python3 scripts/run_promotion_ledger_mutations.py
sha256sum -c SHA256SUMS.txt
```
