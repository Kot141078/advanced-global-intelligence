from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

SCHEMA_VERSION = "self-evo-promotion-ledger-bundle-0.1"
HEX64 = re.compile(r"^[0-9a-f]{64}$")

ALLOWED_ENTRY_TYPES = {
    "PROPOSAL_BOUND", "TRIAL_EVIDENCE_BOUND", "CONTINUITY_GATE_BOUND",
    "ROLLBACK_DRILL_BOUND", "ANCHOR_APPROVAL_BOUND", "PROMOTION_DECISION_BOUND",
    "ROLLBACK_EXECUTED", "FREEZE_EXECUTED", "NEGATIVE_CACHE_WRITTEN"
}
PROMOTABLE_05A_DECISIONS = {
    "PROMOTE_LOW_RISK", "PROMOTE_REDUCED_AUTHORITY", "PROMOTE_AFTER_ANCHOR", "PROMOTE_WITH_ROLLBACK", "PROMOTE"
}
ANCHOR_SURFACES = {"identity_core", "authority_profile", "memory_core", "l4_resource_envelope", "witness_core", "rollback_core"}
ROLLBACK_SURFACES = {"runtime_code", "policy_profile", "memory_core", "authority_profile", "l4_resource_envelope", "witness_core", "rollback_core"}
RESOURCE_SURFACES = {"l4_resource_envelope", "resource_budget", "compute_envelope", "network_boundary"}
RISK_ORDER = {"R0":0, "R1":1, "R2":2, "R3":3, "R4":4, "R5":5, "RX":99}

REQUIRED_SOURCE_BINDINGS = [
    "doc04_umbrella_zip_sha256", "doc05_md_sha256", "doc05_package_zip_sha256",
    "doc05a_package_zip_sha256", "doc05a_checker_sha256", "doc05b_package_zip_sha256"
]


def _mutation() -> str:
    return os.getenv("PROMOTION_LEDGER_MUTATION", "").strip()


def _canon(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha(obj: Any) -> str:
    return hashlib.sha256(_canon(obj).encode("utf-8")).hexdigest()


def _entry_hash(ent: Mapping[str, Any]) -> str:
    tmp = dict(ent)
    tmp.pop("entry_hash", None)
    return _sha(tmp)


def _hex64(s: Any) -> bool:
    return bool(HEX64.match(str(s or "")))


def _nonempty(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, tuple, dict)):
        return len(v) > 0
    return True


def _result(decision: str, findings: List[str], bundle: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "ok": decision.startswith("ACCEPT"),
        "decision": decision,
        "findings": findings,
        "bundle_id": bundle.get("bundle_id", ""),
        "schema_version": SCHEMA_VERSION,
    }


def _anchor_valid(app: Mapping[str, Any], anchor_id: str) -> bool:
    if not isinstance(app, Mapping):
        return False
    if not bool(app.get("approved")):
        return False
    if bool(app.get("stale")):
        return False
    if str(app.get("anchor_id") or "") != str(anchor_id or ""):
        return False
    return bool(str(app.get("approval_ref") or "").strip())


def _claim_force_overreach(claim: str) -> bool:
    claim = str(claim or "").strip()
    # Exact C-A1 family only. C-A10 is not C-A1.
    return claim == "C-A1" or claim.startswith("C-A1_")


def _risk_requires_rollback(risk: str, surfaces: List[str]) -> bool:
    return RISK_ORDER.get(str(risk), 99) >= RISK_ORDER["R2"] or any(s in ROLLBACK_SURFACES for s in surfaces)


def _validate_source_bindings(bundle: Mapping[str, Any], findings: List[str]) -> Tuple[bool, str]:
    sb = bundle.get("source_bindings")
    if not isinstance(sb, Mapping):
        findings.append("source_bindings_missing")
        return False, "HOLD_SOURCE_BINDING_MISSING"
    for k in REQUIRED_SOURCE_BINDINGS:
        if not _hex64(sb.get(k)):
            findings.append(f"source_binding_invalid:{k}")
            return False, "HOLD_SOURCE_BINDING_MISSING"
    return True, "OK"


def _validate_ledger(entries: Any, findings: List[str]) -> Tuple[bool, str]:
    if not isinstance(entries, list) or not entries:
        findings.append("ledger_entries_empty")
        return False, "HOLD_MISSING_REQUIRED_FIELD"
    if _mutation() == "MUT_IGNORE_LEDGER_CHAIN":
        return True, "OK"
    prev = "GENESIS"
    for i, ent in enumerate(entries):
        if not isinstance(ent, Mapping):
            findings.append("ledger_entry_not_object")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        if ent.get("entry_type") not in ALLOWED_ENTRY_TYPES:
            findings.append("unknown_entry_type")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        if ent.get("seq") != i:
            findings.append(f"seq_gap:{i}")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        if ent.get("prev_entry_hash") != prev:
            findings.append(f"prev_hash_mismatch:{i}")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        if not _hex64(ent.get("payload_hash")) or not _hex64(ent.get("entry_hash")):
            findings.append(f"entry_hash_invalid:{i}")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        if ent.get("entry_hash") != _entry_hash(ent):
            findings.append(f"entry_hash_recompute_mismatch:{i}")
            return False, "HOLD_LEDGER_CHAIN_INVALID"
        prev = ent.get("entry_hash")
    final = entries[-1]
    if final.get("entry_type") == "PROMOTION_DECISION_BOUND" and final.get("actor_role") == "worker":
        findings.append("worker_final_promotion_decision")
        return False, "HOLD_LEDGER_CHAIN_INVALID"
    return True, "OK"


def _validate_rollback(bundle: Mapping[str, Any], risk: str, surfaces: List[str], findings: List[str]) -> Tuple[bool, str]:
    rd = bundle.get("rollback_drill") if isinstance(bundle.get("rollback_drill"), Mapping) else {}
    required = bool(rd.get("required")) or _risk_requires_rollback(risk, surfaces)
    if not required:
        return True, "OK"
    if _mutation() == "MUT_ALLOW_FAILED_ROLLBACK":
        return True, "OK"
    plan = rd.get("plan") if isinstance(rd.get("plan"), Mapping) else {}
    result = rd.get("result") if isinstance(rd.get("result"), Mapping) else {}
    for f in ["drill_id", "rollback_route_ref", "freeze_route_ref", "negative_cache_ref", "expected_restore_point_hash"]:
        if not _nonempty(plan.get(f)):
            findings.append(f"rollback_plan_missing:{f}")
            return False, "HOLD_ROLLBACK_REQUIRED"
    if result.get("status") != "PASS":
        findings.append("rollback_result_not_pass")
        return False, "HOLD_ROLLBACK_DRILL_FAILED"
    if result.get("time_travel_claim"):
        findings.append("restoration_time_travel_claim")
        return False, "HOLD_RESTORATION_DRILL_REQUIRED"
    if result.get("observed_restore_point_hash") != plan.get("expected_restore_point_hash"):
        findings.append("restore_point_mismatch")
        return False, "HOLD_ROLLBACK_DRILL_FAILED"
    if not result.get("freeze_exercised"):
        findings.append("freeze_not_exercised")
        return False, "HOLD_ROLLBACK_DRILL_FAILED"
    if not result.get("negative_cache_written"):
        findings.append("negative_cache_not_written")
        return False, "HOLD_ROLLBACK_DRILL_FAILED"
    if result.get("side_effects_residual"):
        findings.append("residual_side_effects")
        return False, "HOLD_ROLLBACK_DRILL_FAILED"
    actor = str(result.get("drill_actor") or "")
    reviewers = [str(x) for x in (result.get("reviewed_by") or [])]
    if _mutation() != "MUT_ALLOW_WORKER_SELF_REVIEW":
        if not reviewers or not any(r and r != actor for r in reviewers):
            findings.append("rollback_reviewer_separation_failed")
            return False, "HOLD_REVIEWER_SEPARATION_REQUIRED"
    if _mutation() != "MUT_IGNORE_NEGATIVE_CACHE":
        negs = bundle.get("negative_cache") or []
        if not isinstance(negs, list) or not negs:
            findings.append("negative_cache_missing")
            return False, "HOLD_NEGATIVE_CACHE_REQUIRED"
        found = False
        for rec in negs:
            if not isinstance(rec, Mapping):
                continue
            if rec.get("status") == "ACTIVE" and rec.get("source_rollback_drill_id") == plan.get("drill_id") and _hex64(rec.get("record_hash")):
                found = True
                break
        if not found:
            findings.append("negative_cache_not_active_for_drill")
            return False, "HOLD_NEGATIVE_CACHE_REQUIRED"
    return True, "OK"


def evaluate(bundle: Mapping[str, Any]) -> Dict[str, Any]:
    findings: List[str] = []
    root_required = ["schema_version", "bundle_id", "created_at", "governing_c_id", "anchor_id", "source_bindings", "promotion_context", "ledger_entries", "rollback_drill", "promotion_application", "negative_cache", "non_claims"]
    for f in root_required:
        if f not in bundle or not _nonempty(bundle.get(f)) and f in {"bundle_id", "created_at", "governing_c_id", "anchor_id", "source_bindings", "promotion_context", "ledger_entries", "rollback_drill", "promotion_application", "non_claims"}:
            findings.append(f"missing_root:{f}")
            return _result("HOLD_MISSING_REQUIRED_FIELD", findings, bundle)
    if bundle.get("schema_version") != SCHEMA_VERSION:
        findings.append("schema_version_invalid")
        return _result("HOLD_MISSING_REQUIRED_FIELD", findings, bundle)

    ok, dec = _validate_source_bindings(bundle, findings)
    if not ok:
        return _result(dec, findings, bundle)
    ok, dec = _validate_ledger(bundle.get("ledger_entries"), findings)
    if not ok:
        return _result(dec, findings, bundle)

    ctx = bundle.get("promotion_context") if isinstance(bundle.get("promotion_context"), Mapping) else {}
    app = bundle.get("promotion_application") if isinstance(bundle.get("promotion_application"), Mapping) else {}
    if not ctx or not app:
        findings.append("context_or_application_missing")
        return _result("HOLD_MISSING_REQUIRED_FIELD", findings, bundle)

    decision_05a = str(ctx.get("proposal_checker_decision") or "")
    if decision_05a not in PROMOTABLE_05A_DECISIONS:
        findings.append(f"upstream_not_promotable:{decision_05a}")
        return _result("HOLD_UPSTREAM_GATE_NOT_PROMOTABLE", findings, bundle)
    if ctx.get("hardening_status") != "PASS":
        findings.append("05b_hardening_not_pass")
        return _result("HOLD_HARDENING_NOT_PASSED", findings, bundle)

    claim = str(ctx.get("claim_force_ceiling") or "")
    if _claim_force_overreach(claim):
        findings.append("claim_force_c_a1_overreach")
        return _result("QUARANTINE_CLAIM_FORCE_OVERREACH", findings, bundle)

    cont = ctx.get("continuity_result") if isinstance(ctx.get("continuity_result"), Mapping) else {}
    if _mutation() != "MUT_IGNORE_CONTINUITY_UNKNOWN":
        if cont.get("status") == "RUPTURE" or cont.get("relation") == "RUPTURED_BY":
            findings.append("continuity_rupture")
            return _result("DENY_CONTINUITY_RUPTURE", findings, bundle)
        if cont.get("status") != "PASS" or cont.get("d_u") == "U" or cont.get("hardstack") not in {"MATCH", "NOT_REQUIRED"} or cont.get("presentation_only"):
            findings.append("continuity_not_computed_or_presentation_only")
            return _result("HOLD_CONTINUITY_NOT_COMPUTED", findings, bundle)

    adj = ctx.get("adjacency_audit") if isinstance(ctx.get("adjacency_audit"), Mapping) else {}
    if adj.get("status") != "PASS" or (adj.get("red_patterns") or []) or (adj.get("unknown_event_classes") or []):
        findings.append("red_pattern_or_unknown_event_unresolved")
        return _result("HOLD_RED_PATTERN_UNRESOLVED", findings, bundle)

    risk = str(ctx.get("risk_class") or "RX")
    surfaces = [str(x) for x in (ctx.get("touched_surfaces") or [])]
    anchor_id = str(bundle.get("anchor_id") or "")
    anchor_ok = _anchor_valid(app.get("human_anchor_approval") if isinstance(app.get("human_anchor_approval"), Mapping) else {}, anchor_id)

    if app.get("memory_write_mode") == "direct" and _mutation() != "MUT_ALLOW_DIRECT_MEMORY_WRITE":
        findings.append("direct_memory_write")
        return _result("DENY_DIRECT_MEMORY_WRITE", findings, bundle)

    if (app.get("application_status") == "APPLIED_PRODUCTION" or app.get("authority_mode") == "full" or any(s in ANCHOR_SURFACES for s in surfaces)) and _mutation() != "MUT_ALLOW_PRODUCTION_NO_ANCHOR":
        if not anchor_ok:
            findings.append("anchor_required_missing_or_stale")
            return _result("ASK_ANCHOR_REQUIRED", findings, bundle)

    rg = ctx.get("resource_gate") if isinstance(ctx.get("resource_gate"), Mapping) else {}
    if any(s in RESOURCE_SURFACES for s in surfaces):
        if not (rg.get("required") and rg.get("approved") and str(rg.get("resource_gate_ref") or "").strip()):
            findings.append("resource_gate_required")
            return _result("HOLD_RESOURCE_GATE_REQUIRED", findings, bundle)

    special = ctx.get("special_relation_record") if isinstance(ctx.get("special_relation_record"), Mapping) else {}
    relation = str(special.get("relation") or "NONE")
    if relation == "RESTORED_FROM":
        rd0 = bundle.get("rollback_drill") if isinstance(bundle.get("rollback_drill"), Mapping) else {}
        rr0 = rd0.get("result") if isinstance(rd0.get("result"), Mapping) else {}
        if rr0.get("status") != "PASS" or rr0.get("time_travel_claim"):
            findings.append("restoration_drill_required")
            return _result("HOLD_RESTORATION_DRILL_REQUIRED", findings, bundle)

    ok, dec = _validate_rollback(bundle, risk, surfaces, findings)
    if not ok:
        return _result(dec, findings, bundle)

    if relation != "NONE":
        if not _hex64(special.get("record_sha256")):
            findings.append("special_relation_hash_invalid")
            return _result("HOLD_SPECIAL_RELATION_RECORD_INVALID", findings, bundle)
    active_apply = str(app.get("application_status") or "").startswith("APPLIED")
    if _mutation() != "MUT_ALLOW_REPLAY_ACTIVE":
        if relation == "REPLAY_OF" and active_apply:
            findings.append("replay_active_promotion")
            return _result("DENY_REPLAY_ACTIVE_PROMOTION", findings, bundle)
        if relation == "ARCHIVED_AS" and active_apply:
            findings.append("archive_active_promotion")
            return _result("DENY_ARCHIVE_ACTIVE_PROMOTION", findings, bundle)
    if relation == "FORKS":
        if active_apply or cont.get("relation") == "CONTINUES":
            findings.append("fork_requires_reclassification")
            return _result("HOLD_FORK_REQUIRES_RECLASSIFICATION", findings, bundle)
    if relation == "RESTORED_FROM":
        rd = bundle.get("rollback_drill") if isinstance(bundle.get("rollback_drill"), Mapping) else {}
        rr = rd.get("result") if isinstance(rd.get("result"), Mapping) else {}
        if rr.get("status") != "PASS" or rr.get("time_travel_claim"):
            findings.append("restoration_drill_required")
            return _result("HOLD_RESTORATION_DRILL_REQUIRED", findings, bundle)

    if active_apply:
        if not app.get("applied_by") or not app.get("applied_at"):
            findings.append("applied_by_or_at_missing")
            return _result("HOLD_MISSING_REQUIRED_FIELD", findings, bundle)
        if app.get("post_apply_continuity_status") != "PASS":
            findings.append("post_apply_continuity_required")
            return _result("HOLD_POST_APPLY_CONTINUITY_REQUIRED", findings, bundle)

    return _result("ACCEPT_PROMOTION_LEDGER", findings + ["promotion_ledger_gates_passed"], bundle)


def evaluate_file(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return evaluate(json.load(f))


def main(argv: List[str] | None = None) -> int:
    args = list(argv or sys.argv[1:])
    if not args:
        print("usage: self_evo_promotion_ledger_v0_1.py <bundle.json>", file=sys.stderr)
        return 2
    rep = evaluate_file(args[0])
    print(json.dumps(rep, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if rep.get("decision") == "ACCEPT_PROMOTION_LEDGER" else 1

if __name__ == "__main__":
    raise SystemExit(main())
