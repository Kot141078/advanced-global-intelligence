# Reading Order

1. `05c_SELF_EVO_PROMOTION_LEDGER_AND_ROLLBACK_DRILL_v0_1.md`
2. `schemas/*.schema.json`
3. `src/self_evo_promotion_ledger_v0_1.py`
4. `fixtures/cases/*.json`
5. `FIXTURE_RESULTS.tsv`
6. `MUTATION_MATRIX.tsv`
7. `NON_CLAIMS_AND_SCOPE.md`
