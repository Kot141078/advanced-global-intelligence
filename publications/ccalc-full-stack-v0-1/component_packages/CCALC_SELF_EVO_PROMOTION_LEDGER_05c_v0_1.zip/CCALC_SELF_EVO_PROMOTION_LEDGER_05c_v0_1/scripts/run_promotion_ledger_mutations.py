from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from self_evo_promotion_ledger_v0_1 import evaluate

MUTATIONS = [
    "MUT_IGNORE_LEDGER_CHAIN",
    "MUT_ALLOW_FAILED_ROLLBACK",
    "MUT_ALLOW_DIRECT_MEMORY_WRITE",
    "MUT_IGNORE_CONTINUITY_UNKNOWN",
    "MUT_ALLOW_REPLAY_ACTIVE",
    "MUT_ALLOW_WORKER_SELF_REVIEW",
    "MUT_ALLOW_PRODUCTION_NO_ANCHOR",
    "MUT_IGNORE_NEGATIVE_CACHE",
]


def main() -> int:
    cases = []
    for path in sorted((ROOT / "fixtures" / "cases").glob("*.json")):
        if not path.name.endswith(".json"):
            continue
        cases.append((path.name, json.loads(path.read_text(encoding="utf-8"))))
    rows = ["mutation\tstatus\tmismatching_cases"]
    caught = 0
    for mut in MUTATIONS:
        os.environ["PROMOTION_LEDGER_MUTATION"] = mut
        mismatches = []
        for name, data in cases:
            expected = data.get("expected_decision")
            actual = evaluate(data).get("decision")
            if actual != expected:
                mismatches.append(f"{name}:{expected}->{actual}")
        status = "CAUGHT" if mismatches else "MISSED"
        caught += int(bool(mismatches))
        rows.append(f"{mut}\t{status}\t{' | '.join(mismatches[:12])}")
    os.environ.pop("PROMOTION_LEDGER_MUTATION", None)
    (ROOT / "MUTATION_MATRIX.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"mutations": len(MUTATIONS), "caught": caught, "missed": len(MUTATIONS)-caught}, sort_keys=True))
    return 0 if caught == len(MUTATIONS) else 1

if __name__ == "__main__":
    raise SystemExit(main())
