from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from self_evo_promotion_ledger_v0_1 import evaluate


def main() -> int:
    rows = ["case\texpected\tactual\tstatus\tfindings"]
    total = passed = 0
    for path in sorted((ROOT / "fixtures" / "cases").glob("*.json")):
        if path.name.endswith(".sha256"):
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        expected = data.get("expected_decision")
        rep = evaluate(data)
        actual = rep.get("decision")
        ok = expected == actual
        total += 1
        passed += int(ok)
        rows.append(f"{path.name}\t{expected}\t{actual}\t{'PASS' if ok else 'FAIL'}\t{';'.join(rep.get('findings') or [])}")
    (ROOT / "FIXTURE_RESULTS.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"fixtures": total, "pass": passed, "fail": total-passed}, sort_keys=True))
    return 0 if total == passed else 1

if __name__ == "__main__":
    raise SystemExit(main())
