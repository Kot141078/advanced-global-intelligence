# Freeze Binding Protocol Note

This acceptance package uses external sidecar binding.

For each Markdown acceptance record:

```text
sha256sum exact_file_bytes > filename.md.sha256
```

The Markdown file itself does not mutate to include its own hash. This avoids self-referential instability.
