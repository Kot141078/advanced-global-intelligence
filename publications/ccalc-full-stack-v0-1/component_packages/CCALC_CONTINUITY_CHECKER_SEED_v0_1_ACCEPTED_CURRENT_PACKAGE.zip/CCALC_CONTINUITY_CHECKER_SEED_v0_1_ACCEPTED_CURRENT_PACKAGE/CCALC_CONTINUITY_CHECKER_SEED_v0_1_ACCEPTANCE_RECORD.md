# Acceptance Record — CCALC Continuity Checker Seed v0.1 (04a)

**Record class:** b-layer acceptance / disk-run verification record (advisory)  
**Project:** Self-Evo / Ester / `c = a + b`  
**Record date:** 2026-07-03T18:37:41Z  
**Accepted artifact:** `CCALC_CONTINUITY_CHECKER_SEED_v0_1.zip`  
**Artifact SHA256:** `dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32`  
**Checker source SHA256:** `da3bb12f44dfbd10e2fa1a02c73932f14ee1e8cf3c58e099d082c5a532de4e97`  
**Normative binding:** `04_C_CONTINUITY_METRIC_AND_EQUIVALENCE_SEMANTICS_v0_1_2.md`  
**Normative SHA256:** `35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9`  
**Authority:** advisory acceptance only; NOT a safety certification; NOT deployment authorization; NOT C-A1 ratification.

---

## 1. Verdict

```text
ACCEPTED_AS_CURRENT_04A_CONTINUITY_CHECKER_SEED
PASS_DISK_RUN_42_42
```

The archive is accepted as the current `04a` seed package for the doc-04 continuity metric / equivalence semantics checker layer.

This acceptance is based on:

```text
archive sha256 verified
safe extraction / no path traversal detected
internal SHA256SUMS.txt verified before runner
fixture runner executed successfully
internal SHA256SUMS.txt verified after runner
mutation matrix inspected
independent mutation probes executed for four target regression classes
```

---

## 2. Disk-run verification

### 2.1 Archive

```text
dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32  CCALC_CONTINUITY_CHECKER_SEED_v0_1.zip
```

The archive SHA matches the provided prefix `dc6f9c80...`.

### 2.2 Internal integrity

Internal package check:

```text
sha256sum -c SHA256SUMS.txt
```

Result: `PASS` before fixture execution and `PASS` after fixture execution.

### 2.3 Fixture runner

Executed command from extracted package root:

```bash
python scripts/run_continuity_fixtures.py
```

Observed result:

```text
fixtures: 42  PASS: 42  FAIL: 0
```

Covered families as reported by the package:

```text
metric:      13
trace:       17 including relation coverage
adversarial: 10
property:     2
```

### 2.4 Checker source

```text
da3bb12f44dfbd10e2fa1a02c73932f14ee1e8cf3c58e099d082c5a532de4e97  src/c_continuity_checker_v0_1.py
```

---

## 3. Mutation evidence

The package includes `MUTATION_MATRIX.tsv` describing four target regressions. I additionally ran independent mutation probes against a copied extraction tree, without modifying the accepted archive.

Result:

```text
MUT-1 replay/badbranch dominance regression: caught
MUT-2 UNKNOWN -> MISMATCH collapse: caught
MUT-3 fragment emits CONTINUES / laundering class: caught
MUT-4 style included in snapshot equivalence: caught
```

Note: the independently injected MUT-3 variant was broader than the packaged matrix variant, so the exact failure count differs from the packaged mutation matrix. The target regression class was still caught.

---

## 4. What is accepted

Accepted as current working `04a` seed:

```text
tri-state match discipline
d_U with U routing and refusal of numeric/comparison authority use
validator order binding to ProjectionRegistry
HardStack snapshot equivalence over I0..I11
presentation equivalence separated from snapshot authority
special relation dominance with rupture first
RESTORED_FROM reachability
20.3 fragment cannot emit CONTINUES
composite classifier as sole CONTINUES emitter
all §3.3 relations reachable
health-leak detection through reflexivity
property probes for equivalence and strong triangle inequality over computable triples
```

---

## 5. Non-claims

This record does NOT claim:

1. that the checker is complete or proven;
2. that fixture success proves deployment safety;
3. that metric equivalence proves ontology, personhood, or C-A1 identity;
4. that raw ledger extraction is solved here — the seed consumes classified hash-bound facts;
5. that mutation probes constitute formal proof;
6. that any live entity satisfies the profile.

This is C-A6/C-A7-style implementation/evidence material for the doc-04 checker seed.

---

## 6. Register handoff

```yaml
handoff:
  artifact: CCALC_CONTINUITY_CHECKER_SEED_v0_1.zip
  artifact_sha256: "dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32"
  checker_sha256: "da3bb12f44dfbd10e2fa1a02c73932f14ee1e8cf3c58e099d082c5a532de4e97"
  normative_doc04_v0_1_2_sha256: "35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9"
  verdict: ACCEPTED_AS_CURRENT_04A_CONTINUITY_CHECKER_SEED
  disk_run: PASS_42_42
  internal_sha256_before_runner: PASS
  internal_sha256_after_runner: PASS
  independent_mutations_caught: [MUT-1, MUT-2, MUT-3, MUT-4]
  blocking: false
  next_recommended:
    - "04b schemas for Fork/Replay/Archive/Restoration records (§10-§13)."
    - "04c continuity matrix / adjacency audit (§17-§18)."
    - "Optional: deterministic schema validator for trace input records consumed by 04a."
```

*End of acceptance record.*
