# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each non-sidecar file:

```text
sha256sum exact_file_bytes > sidecars/<filename>.sha256
```

The file itself does not mutate to include its own hash. This avoids self-referential instability.
