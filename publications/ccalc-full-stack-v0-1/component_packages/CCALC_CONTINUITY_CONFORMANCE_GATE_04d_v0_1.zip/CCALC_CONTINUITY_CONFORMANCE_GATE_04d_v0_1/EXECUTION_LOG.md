# Execution Log — 04d Continuity Conformance Gate v0.1

Created: 2026-07-03T19:04:29.678169Z

Commands executed during package assembly:

```text
python scripts/run_conformance_fixtures.py --cases fixtures/cases --write FIXTURE_RESULTS.tsv
python scripts/run_conformance_mutations.py --cases fixtures/cases --write MUTATION_MATRIX.tsv
sha256sum -c SHA256SUMS.txt
fresh unzip + fixture rerun
fresh unzip + mutation rerun
```

Observed results:

```text
fixtures: 36  PASS: 36  FAIL: 0
mutations: 6  CAUGHT: 6  MISSED: 0
SHA256SUMS.txt: PASS
fresh unzip fixture rerun: PASS
fresh unzip mutation rerun: PASS
```

Implementation note:

```text
A first validator draft accidentally treated C-A10 as C-A1 because it used prefix matching
("C-A1" prefix catches "C-A10"). This was corrected before sealing by requiring exact
C-A1 or C-A1_ prefix only. Fixture `control_artifact_only_accepts` covers this.
```

No network used. No private runtime state inspected. No live substrate claim made.
