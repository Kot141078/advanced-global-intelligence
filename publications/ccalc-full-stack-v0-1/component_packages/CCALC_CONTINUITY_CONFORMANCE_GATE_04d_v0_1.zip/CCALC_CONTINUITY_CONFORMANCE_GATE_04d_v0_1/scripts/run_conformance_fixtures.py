#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from continuity_conformance_gate_v0_1 import evaluate_bundle

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--cases', default=str(ROOT/'fixtures'/'cases'))
    p.add_argument('--write', default='')
    args=p.parse_args(argv)
    rows=[]; passed=0; failed=0
    for path in sorted(Path(args.cases).glob('*.json')):
        obj=json.loads(path.read_text(encoding='utf-8'))
        result=evaluate_bundle(obj)
        expected=obj.get('expected_verdict')
        got=result.get('verdict')
        ok=(got==expected)
        if ok: passed+=1
        else: failed+=1
        rows.append([path.name, expected, got, 'PASS' if ok else 'FAIL', ';'.join(result.get('problems') or [])])
    out='case\texpected\tactual\tresult\tproblems\n' + '\n'.join('\t'.join(map(str,r)) for r in rows) + '\n'
    if args.write:
        Path(args.write).write_text(out, encoding='utf-8', newline='\n')
    print(f'fixtures: {passed+failed}  PASS: {passed}  FAIL: {failed}')
    return 0 if failed==0 else 2
if __name__=='__main__':
    raise SystemExit(main())
