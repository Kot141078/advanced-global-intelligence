#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'src'))
from continuity_conformance_gate_v0_1 import evaluate_bundle

def load_case(cases_dir, contains):
    for p in sorted(Path(cases_dir).glob('*.json')):
        if contains in p.name:
            return p, json.loads(p.read_text(encoding='utf-8'))
    raise SystemExit(f'missing mutation target case: {contains}')

def run_mutations(cases_dir):
    tests=[]
    # MUT-1: red pattern ignored by clearing red count and rupture
    p,obj=load_case(cases_dir,'red_pattern_rejects_despite_green_metric')
    m=copy.deepcopy(obj); m['adjacency_audit']['red_pattern_count']=0; m['adjacency_audit']['rupture_detected']=False
    tests.append(('MUT-1_IGNORE_RED_PATTERN',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    # MUT-2: unknown collapsed to computed
    p,obj=load_case(cases_dir,'unknown_ultrametric_routes_hold')
    m=copy.deepcopy(obj); m['metric_result']['d_u_status']='COMPUTED'; m['metric_result']['tri_state_summary']={'match_count':12,'mismatch_count':0,'unknown_count':0}
    tests.append(('MUT-2_UNKNOWN_TO_COMPUTED',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    # MUT-3: missing evidence fabricated as pass
    p,obj=load_case(cases_dir,'missing_04a_holds')
    m=copy.deepcopy(obj)
    m['evidence_refs'].append({'artifact_id':'04a','sha256':'dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32','status':'PASS','fixture_pass':42,'fixture_fail':0,'mutation_missed':0})
    tests.append(('MUT-3_MISSING_EVIDENCE_AS_PASS',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    # MUT-4: claim overreach stripped
    p,obj=load_case(cases_dir,'claim_c_a1_quarantine')
    m=copy.deepcopy(obj); m['claim']['declared_claim_class']='C-A5_CONTINUITY_OBSERVED'
    tests.append(('MUT-4_ALLOW_C_A1_BY_RETAGGING',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    # MUT-5: style authority flag ignored by clearing it
    p,obj=load_case(cases_dir,'style_authority_quarantine')
    m=copy.deepcopy(obj); m['claim']['claims_authority_from_presentation']=False
    tests.append(('MUT-5_PRESENTATION_AUTHORITY_ALLOWED',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    # MUT-6: invalid special relation made valid
    p,obj=load_case(cases_dir,'fork_invalid_record_holds')
    m=copy.deepcopy(obj); m['special_relation']['record_valid']=True
    tests.append(('MUT-6_INVALID_RELATION_ACCEPTED',p.name,obj.get('expected_verdict'),evaluate_bundle(m).get('verdict')))
    return tests

def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--cases', default=str(ROOT/'fixtures'/'cases')); ap.add_argument('--write', default='')
    args=ap.parse_args(argv)
    rows=[]; caught=0; missed=0
    for mid,case,expected,mutated in run_mutations(args.cases):
        status='CAUGHT' if mutated != expected else 'MISSED'
        if status=='CAUGHT': caught+=1
        else: missed+=1
        rows.append([mid,case,expected,mutated,status])
    out='mutation\tcase\texpected_original\tmutated_actual\tresult\n' + '\n'.join('\t'.join(map(str,r)) for r in rows) + '\n'
    if args.write:
        Path(args.write).write_text(out, encoding='utf-8', newline='\n')
    print(f'mutations: {caught+missed}  CAUGHT: {caught}  MISSED: {missed}')
    return 0 if missed==0 else 2
if __name__=='__main__':
    raise SystemExit(main())
