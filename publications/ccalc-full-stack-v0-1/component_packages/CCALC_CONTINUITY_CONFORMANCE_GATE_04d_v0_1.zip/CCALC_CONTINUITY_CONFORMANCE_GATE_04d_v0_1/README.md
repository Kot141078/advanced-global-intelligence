# CCALC Continuity Conformance Gate 04d v0.1

This package binds doc-04 v0.1.2 plus 04a/04b/04c outputs into a conformance-bundle claim gate.

## Contents

- `04d_CONTINUITY_CONFORMANCE_GATE_AND_EVIDENCE_BUNDLE_v0_1.md`
- JSON schemas for bundle, report, evidence reference, and claim gate
- stdlib validator: `src/continuity_conformance_gate_v0_1.py`
- fixture runner and mutation runner
- 36 JSON fixture cases
- result matrices and source manifest

## Run

```bash
python scripts/run_conformance_fixtures.py --cases fixtures/cases
python scripts/run_conformance_mutations.py --cases fixtures/cases
sha256sum -c SHA256SUMS.txt
```

Expected:

```text
fixtures: 36 PASS: 36 FAIL: 0
mutations: 6 CAUGHT: 6 MISSED: 0
SHA256SUMS: PASS
```

## Normative binding

- doc-04 v0.1.2: `35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9`
- 04a archive: `dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32`
- 04b archive: `e6eb80c3da5301c3ce692e7450c099a96aff64e1c3f424eb024ae2569e05006c`
- 04c archive: `73690bff99eb32a7fcd579f4021eb703594308c6798a7b02f1db4d569463779a`

## Status

Seed package. Not certification. Not C-A1 ratification.
