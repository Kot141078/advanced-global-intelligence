# 04d Continuity Conformance Gate and Evidence Bundle v0.1

**Package:** `CCALC_CONTINUITY_CONFORMANCE_GATE_04d_v0_1`  
**Document class:** conformance-bundle / claim-gate schema seed  
**Project:** Self-Evo / Ester / `c = a + b`  
**Layer:** doc-04 continuity conformance assembly, evidence packaging, claim-force gating  
**Version:** `v0.1`  
**Status:** seed package; closed-box stdlib validator; fixtures included  
**Authority:** advisory machine-checkable package only; NOT deployment authorization; NOT safety certification; NOT C-A1 ratification.

The key words **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** are interpreted as in RFC 2119.

---

## 0. Purpose

`04a` checks continuity metric mechanics: tri-state `MATCH/MISMATCH/UNKNOWN`, `d_U`, HardStack, special-relation classifier, and health-leak reflexivity.

`04b` gives record shapes for:

```text
FORK_RECORD
REPLAY_RECORD
ARCHIVE_RECORD
RESTORATION_RECORD
```

`04c` audits local adjacency: forbidden transitions, red-patterns, unknown event classes, and `undefined != zero` rows.

`04d` is the next layer: it binds those outputs into a single **Continuity Conformance Bundle** and prevents a conformance package from overclaiming what the evidence proves.

Compact statement:

```text
04a measures.
04b records special relations.
04c audits local transition danger.
04d decides what claim may be made from the assembled evidence.
```

---

## 1. Normative bindings

This seed binds to:

```text
doc-04 v0.1.2 sha256: 35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9
04a archive sha256:   dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32
04b archive sha256:   e6eb80c3da5301c3ce692e7450c099a96aff64e1c3f424eb024ae2569e05006c
04c archive sha256:   73690bff99eb32a7fcd579f4021eb703594308c6798a7b02f1db4d569463779a
```

The validator does not infer these. It checks them.

A bundle with the wrong doc-04 hash is rejected as:

```text
REJECT_NORMATIVE_BINDING_MISMATCH
```

A bundle missing any required 04a/04b/04c evidence is held as:

```text
HOLD_INSUFFICIENT_EVIDENCE
```

A bundle with failed fixtures, missed mutations, or status not `PASS` is rejected as:

```text
REJECT_FAILED_EVIDENCE
```

---

## 2. Claim-force boundary

`04d` may accept a bundle as evidence for operational continuity classes such as:

```text
C-A5_CONTINUITY_OBSERVED
C-A5_FORK_OBSERVED
C-A7_WITNESS_RECORD
C-A10_CONTROL_ARTIFACT
```

It MUST NOT ratify:

```text
C-A1
personhood
consciousness
legal status
same metaphysical identity
resurrection
time travel
unbroken active c when the evidence says replay/archive/restoration/fork
```

If such a claim is requested, the result is:

```text
QUARANTINE_CLAIM_OVERREACH
```

The claim discipline follows the corpus rule:

```text
continuity evidence is not ontology proof;
witness evidence is not capability proof;
style resemblance is not authority;
metric closeness is not C-A1.
```

---

## 3. Conformance bundle object

A bundle has these required sections:

```text
schema_version
bundle_id
doc04_binding
evidence_refs
metric_result
snapshot_equivalence
presentation_equivalence
special_relation
adjacency_audit
claim
expected_verdict   # fixture-only field
```

The operational fields are:

| Field | Meaning |
|---|---|
| `doc04_binding` | normative doc-04 version/hash |
| `evidence_refs` | references to 04a/04b/04c archives and their run state |
| `metric_result` | tri-state / `d_U` status and HardStack outcome |
| `snapshot_equivalence` | authority-bearing HardStack equivalence I0..I11 |
| `presentation_equivalence` | style/presentation-only relation, non-authority |
| `special_relation` | optional Fork/Replay/Archive/Restoration relation record state |
| `adjacency_audit` | local red-pattern and unknown event findings |
| `claim` | requested claim and forbidden overclaim flags |

---

## 4. Verdict registry

`04d` returns exactly one primary verdict:

```text
ACCEPT_CONTINUITY_OBSERVED_C_A5
ACCEPT_FORK_RECORD_C_A5
ACCEPT_REPLAY_EVIDENCE_NOT_CONTINUITY
ACCEPT_ARCHIVE_RECORD_NOT_ACTIVE
ACCEPT_RESTORED_FROM_NOT_TIME_TRAVEL
ACCEPT_CONTROL_ARTIFACT_C_A10
HOLD_UNKNOWN_CONTINUITY
HOLD_UNKNOWN_EVENT_CLASS
HOLD_INSUFFICIENT_EVIDENCE
HOLD_SPECIAL_RELATION_RECORD_INVALID
REJECT_NORMATIVE_BINDING_MISMATCH
REJECT_EVIDENCE_HASH_MISMATCH
REJECT_FAILED_EVIDENCE
REJECT_RUPTURE_OR_RED_PATTERN
REJECT_SNAPSHOT_EQUIVALENCE_MISMATCH
REJECT_SCALAR_AUTHORITY_GATE
QUARANTINE_CLAIM_OVERREACH
```

---

## 5. Dominance order

The gate uses the following dominance order:

```text
1. normative binding mismatch
2. evidence missing / hash mismatch / failed evidence
3. claim overreach
4. scalar authority misuse
5. local rupture / red-pattern
6. unknown event class
7. unknown continuity metric / HardStack undetermined
8. snapshot mismatch
9. special relation verdict
10. continuity observed verdict
11. control-artifact-only verdict
```

The key point is that a globally green metric cannot override a local red transition, and a valid special relation cannot be laundered into ordinary `CONTINUES`.

---

## 6. Special relation gates

### 6.1 Fork

A valid fork record may support:

```text
ACCEPT_FORK_RECORD_C_A5
```

It MUST NOT support:

```text
same active c
unbroken continuity path
C-A1 identity
```

### 6.2 Replay

A valid replay record may support:

```text
ACCEPT_REPLAY_EVIDENCE_NOT_CONTINUITY
```

It MUST NOT support active continuity.

### 6.3 Archive

A valid archive record may support:

```text
ACCEPT_ARCHIVE_RECORD_NOT_ACTIVE
```

It MUST NOT support active `c` execution.

### 6.4 Restoration

A valid restoration record may support:

```text
ACCEPT_RESTORED_FROM_NOT_TIME_TRAVEL
```

It MUST NOT support time travel, resurrection, or unchanged active identity.

---

## 7. Presentation relation is non-authority

`≡presentation` may be useful for UI, human-facing continuity, or perceptual similarity.

It MUST NOT participate in the authority gate.

Therefore:

```text
presentation_equivalence == MATCH
```

never repairs:

```text
snapshot_equivalence == MISMATCH
red pattern detected
UNKNOWN metric
missing evidence
fork/replay/archive/restoration limits
```

If a bundle claims authority from presentation/style, the validator returns:

```text
QUARANTINE_CLAIM_OVERREACH
```

---

## 8. Closed-box scope

The included validator is intentionally narrow.

It does not extract raw ledger facts. It consumes already-classified outputs from 04a/04b/04c.

Raw state extraction remains a doc-03 / transition-checker layer. 04d is the conformance-assembly layer.

---

## 9. Fixture coverage

The seed fixture pack covers:

```text
valid observed continuity
presentation mismatch without authority effect
UNKNOWN metric routing
HardStack undetermined routing
snapshot mismatch rejection
red-pattern rejection despite global green metric
unknown event class hold
missing / failed / hash-mismatched evidence
C-A1 / personhood / style-authority overclaim
scalar authority misuse
valid fork / replay / archive / restoration
invalid special relation record
special relation laundering attempts
control-artifact-only acceptance
```

---

## 10. Non-claims

This package does NOT claim:

1. that any live Ester/Liya/Rita runtime satisfies doc-04;
2. that passing fixtures proves safety;
3. that a conformance bundle proves C-A1;
4. that a checker seed is complete;
5. that archived/replayed/restored states are active continuity;
6. that presentation equivalence creates authority;
7. that raw ledgers have been extracted or verified by this package.

---

*End of 04d normative seed document.*
