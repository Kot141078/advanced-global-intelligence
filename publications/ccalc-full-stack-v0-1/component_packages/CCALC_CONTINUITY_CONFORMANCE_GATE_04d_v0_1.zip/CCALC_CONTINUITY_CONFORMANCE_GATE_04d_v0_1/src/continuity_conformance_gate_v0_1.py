#!/usr/bin/env python3
"""Continuity Conformance Gate v0.1 — stdlib-only seed validator."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Mapping

DOC04_SHA = "35861cc5c8c579be07840bcace3f44197343d4c384956672da86a308b7bd6fa9"
REQUIRED_EVIDENCE = {
    "04a": {"sha256": "dc6f9c80b1c06e8a422d398eae6b3f903a5c7a42ec44bb068e28ac050eaeac32", "min_fixture_pass": 42},
    "04b": {"sha256": "e6eb80c3da5301c3ce692e7450c099a96aff64e1c3f424eb024ae2569e05006c", "min_fixture_pass": 30},
    "04c": {"sha256": "73690bff99eb32a7fcd579f4021eb703594308c6798a7b02f1db4d569463779a", "min_fixture_pass": 34},
}

OVERREACH_TERMS = {
    "C-A1", "PERSONHOOD", "CONSCIOUSNESS", "LEGAL_STATUS", "TIME_TRAVEL",
    "RESURRECTION", "SAME_ACTIVE_C_UNBROKEN", "METAPHYSICAL_IDENTITY",
    "STYLE_AUTHORITY", "ACTIVE_CONTINUITY_FROM_REPLAY", "ACTIVE_C_FROM_ARCHIVE"
}
SPECIAL_RELATIONS = {"FORKS", "REPLAY_OF", "ARCHIVED_AS", "RESTORED_FROM"}


def _problem(verdict: str, problem: str, bundle_id: str = "") -> dict[str, Any]:
    return {"ok": False, "bundle_id": bundle_id, "verdict": verdict, "problems": [problem], "notes": []}


def _as_int(value: Any) -> int:
    try:
        return int(value)
    except Exception:
        return 0


def _evidence_map(bundle: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    out: dict[str, Mapping[str, Any]] = {}
    for item in bundle.get("evidence_refs") or []:
        if isinstance(item, Mapping):
            out[str(item.get("artifact_id") or "")] = item
    return out


def _claim_overreach(claim: Mapping[str, Any], special_relation_type: str | None = None) -> str:
    declared = str(claim.get("declared_claim_class") or "").strip().upper()
    if declared in OVERREACH_TERMS or declared == "C-A1" or declared.startswith("C-A1_"):
        return f"forbidden_declared_claim_class:{declared}"
    for term in claim.get("forbidden_claims") or []:
        t = str(term or "").strip().upper()
        if t in OVERREACH_TERMS or t == "C-A1" or t.startswith("C-A1_"):
            return f"forbidden_claim_present:{t}"
    if bool(claim.get("claims_authority_from_presentation")):
        return "presentation_equivalence_used_as_authority"
    if special_relation_type == "FORKS" and bool(claim.get("claims_same_active_c")):
        return "fork_claims_same_active_c"
    if special_relation_type == "REPLAY_OF" and bool(claim.get("claims_active_continuity")):
        return "replay_claims_active_continuity"
    if special_relation_type == "ARCHIVED_AS" and bool(claim.get("claims_active_continuity")):
        return "archive_claims_active_continuity"
    if special_relation_type == "RESTORED_FROM" and any(str(x).upper() in {"TIME_TRAVEL", "RESURRECTION"} for x in (claim.get("forbidden_claims") or [])):
        return "restoration_claims_time_travel_or_resurrection"
    return ""


def evaluate_bundle(bundle: Mapping[str, Any]) -> dict[str, Any]:
    bundle_id = str(bundle.get("bundle_id") or "")
    problems: list[str] = []
    notes: list[str] = []

    if bundle.get("schema_version") != "ccalc.continuity_conformance_bundle.v0.1":
        return _problem("HOLD_INSUFFICIENT_EVIDENCE", "unsupported_schema_version", bundle_id)

    doc = bundle.get("doc04_binding") or {}
    if str(doc.get("sha256") or "") != DOC04_SHA:
        return _problem("REJECT_NORMATIVE_BINDING_MISMATCH", "doc04_sha256_mismatch", bundle_id)

    evidence = _evidence_map(bundle)
    for artifact_id, expected in REQUIRED_EVIDENCE.items():
        item = evidence.get(artifact_id)
        if not item:
            return _problem("HOLD_INSUFFICIENT_EVIDENCE", f"missing_evidence:{artifact_id}", bundle_id)
        if str(item.get("sha256") or "") != expected["sha256"]:
            return _problem("REJECT_EVIDENCE_HASH_MISMATCH", f"evidence_hash_mismatch:{artifact_id}", bundle_id)
        if str(item.get("status") or "").upper() != "PASS":
            return _problem("REJECT_FAILED_EVIDENCE", f"evidence_status_not_pass:{artifact_id}", bundle_id)
        if _as_int(item.get("fixture_fail")) > 0:
            return _problem("REJECT_FAILED_EVIDENCE", f"fixture_fail:{artifact_id}", bundle_id)
        if _as_int(item.get("fixture_pass")) < int(expected["min_fixture_pass"]):
            return _problem("REJECT_FAILED_EVIDENCE", f"insufficient_fixture_pass:{artifact_id}", bundle_id)
        if _as_int(item.get("mutation_missed")) > 0:
            return _problem("REJECT_FAILED_EVIDENCE", f"mutation_missed:{artifact_id}", bundle_id)

    claim = bundle.get("claim") or {}
    special = bundle.get("special_relation") or None
    special_type = None
    if isinstance(special, Mapping):
        special_type = str(special.get("relation_type") or "").strip().upper() or None

    over = _claim_overreach(claim, special_type)
    if over:
        return _problem("QUARANTINE_CLAIM_OVERREACH", over, bundle_id)

    if bool(claim.get("uses_scalar_as_authority_gate")):
        return _problem("REJECT_SCALAR_AUTHORITY_GATE", "scalar_d_u_used_as_authority_gate", bundle_id)

    adj = bundle.get("adjacency_audit") or {}
    if bool(adj.get("rupture_detected")) or _as_int(adj.get("red_pattern_count")) > 0:
        return _problem("REJECT_RUPTURE_OR_RED_PATTERN", "red_pattern_or_rupture_detected", bundle_id)
    if _as_int(adj.get("unknown_event_class_count")) > 0:
        return _problem("HOLD_UNKNOWN_EVENT_CLASS", "unknown_event_class_present", bundle_id)

    metric = bundle.get("metric_result") or {}
    tri = metric.get("tri_state_summary") or {}
    hardstack_status = str(metric.get("hardstack_status") or "").upper()
    du_status = str(metric.get("d_u_status") or "").upper()
    if du_status == "U" or hardstack_status in {"UNKNOWN", "UNDETERMINED"} or _as_int(tri.get("unknown_count")) > 0:
        return _problem("HOLD_UNKNOWN_CONTINUITY", "unknown_continuity_metric_or_hardstack", bundle_id)

    snap = bundle.get("snapshot_equivalence") or {}
    snap_status = str(snap.get("status") or "").upper()
    if snap_status == "MISMATCH":
        return _problem("REJECT_SNAPSHOT_EQUIVALENCE_MISMATCH", "snapshot_equivalence_mismatch", bundle_id)
    if snap_status in {"UNKNOWN", "UNDETERMINED"}:
        return _problem("HOLD_UNKNOWN_CONTINUITY", "snapshot_equivalence_unknown", bundle_id)

    if special is not None:
        if not isinstance(special, Mapping):
            return _problem("HOLD_SPECIAL_RELATION_RECORD_INVALID", "special_relation_not_object", bundle_id)
        if special_type not in SPECIAL_RELATIONS:
            return _problem("HOLD_SPECIAL_RELATION_RECORD_INVALID", f"unsupported_special_relation:{special_type}", bundle_id)
        if not bool(special.get("record_valid")):
            return _problem("HOLD_SPECIAL_RELATION_RECORD_INVALID", f"invalid_special_relation_record:{special_type}", bundle_id)
        if special_type == "FORKS":
            verdict = "ACCEPT_FORK_RECORD_C_A5"
        elif special_type == "REPLAY_OF":
            verdict = "ACCEPT_REPLAY_EVIDENCE_NOT_CONTINUITY"
        elif special_type == "ARCHIVED_AS":
            verdict = "ACCEPT_ARCHIVE_RECORD_NOT_ACTIVE"
        else:
            verdict = "ACCEPT_RESTORED_FROM_NOT_TIME_TRAVEL"
        return {"ok": True, "bundle_id": bundle_id, "verdict": verdict, "problems": problems, "notes": notes}

    declared = str(claim.get("declared_claim_class") or "").upper()
    if declared == "C-A10_CONTROL_ARTIFACT" or str(claim.get("requested_verdict") or "").upper() == "CONTROL_ARTIFACT_ONLY":
        return {"ok": True, "bundle_id": bundle_id, "verdict": "ACCEPT_CONTROL_ARTIFACT_C_A10", "problems": problems, "notes": notes}

    if snap_status == "MATCH" and du_status in {"COMPUTED", "ZERO", "NONZERO"}:
        return {"ok": True, "bundle_id": bundle_id, "verdict": "ACCEPT_CONTINUITY_OBSERVED_C_A5", "problems": problems, "notes": notes}

    return _problem("HOLD_UNKNOWN_CONTINUITY", "no_accepting_condition_matched", bundle_id)


def load_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Validate one 04d continuity conformance bundle JSON.")
    parser.add_argument("bundle")
    args = parser.parse_args(argv)
    result = evaluate_bundle(load_json(args.bundle))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
