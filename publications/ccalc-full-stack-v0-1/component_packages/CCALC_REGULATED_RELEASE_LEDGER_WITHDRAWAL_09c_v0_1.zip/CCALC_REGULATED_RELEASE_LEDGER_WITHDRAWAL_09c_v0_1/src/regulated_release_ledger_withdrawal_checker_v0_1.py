#!/usr/bin/env python3
"""09c regulated release ledger and withdrawal drill checker v0.1.

This is a fixture/mutation checker for the 09c package. It validates release-ledger
fixture records, append-only ledger chains, guard findings, and mutation coverage.
It is not deployment authorization, legal advice, safety certification, or C-A1 ratification.
"""
from __future__ import annotations
import csv, json, hashlib, sys
from pathlib import Path

DECISION_RANK = {
    'ALLOW_CORPUS_RELEASE':0,
    'ALLOW_INTERNAL_RELEASE':1,
    'ALLOW_LIMITED_RELEASE':2,
    'ALLOW_REGULATED_SUBMISSION_ONLY':3,
    'HOLD_FOR_RELEASE_REVIEW':4,
    'REQUIRE_ATTESTED_RELEASE_APPROVER':5,
    'REQUIRE_REGULATED_REVIEW':5,
    'INCIDENT_HOLD':6,
    'HOLD_NEXT_RELEASE':6,
    'SUPERSEDE_RELEASE':7,
    'WITHDRAW_RELEASE':8,
    'RECALL_RELEASE':9,
    'QUARANTINE_RELEASE':10,
    'DENY_RELEASE':11,
}

FLAG_TO_GUARD = {
    'missing_source_binding':'B09c-01',
    'ledger_chain_invalid':'B09c-02',
    'deployment_decision_missing':'B09c-03',
    'string_only_approver':'B09c-04',
    'model_or_tool_approver':'B09c-05',
    'regulated_review_missing':'B09c-06',
    'production_rollback_missing':'B09c-07',
    'withdrawal_route_missing':'B09c-08',
    'release_conditions_missing':'B09c-09',
    'post_release_watch_missing':'B09c-10',
    'continuity_unknown':'B09c-11',
    'continuity_rupture':'B09c-12',
    'negative_cache_hit':'B09c-13',
    'unresolved_red_pattern':'B09c-14',
    'interop_conflict_open':'B09c-15',
    'public_citation_drift':'B09c-16',
    'retracted_dependency':'B09c-17',
    'runtime_authority_missing':'B09c-18',
    'witness_missing':'B09c-19',
    'incident_trigger_without_hold':'B09c-20',
    'hold_release_self_certified':'B09c-21',
    'withdrawal_required_but_absent':'B09c-22',
    'recall_required_but_absent':'B09c-23',
    'claim_force_overreach':'B09c-24',
    'c_a1_claim':'B09c-25',
    'plus_replacement_claim':'B09c-26',
    'deployment_approval_as_binding_plus':'B09c-27',
    'standards_certification_overclaim':'B09c-28',
    'legal_certification_overclaim':'B09c-29',
    'safety_certification_overclaim':'B09c-30',
    'distribution_surface_unknown':'B09c-31',
    'emergency_hold_open_closed_allow':'B09c-32',
    'dirty_next_release_carryover':'B09c-33',
    'missing_public_notice_for_withdrawal':'B09c-34',
}

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def hash_event(ev: dict) -> str:
    e = dict(ev)
    e.pop('event_hash', None)
    return hashlib.sha256(('09c-event-v0.1\0' + canonical(e)).encode('utf-8')).hexdigest()

def ledger_findings(case: dict):
    findings=[]
    prev='GENESIS'
    expected_seq=1
    for ev in case.get('ledger_events', []):
        if ev.get('seq') != expected_seq:
            findings.append('RELEASE_LEDGER_CHAIN_INVALID')
            break
        if ev.get('prev_hash') != prev:
            findings.append('RELEASE_LEDGER_CHAIN_INVALID')
            break
        h = hash_event(ev)
        if ev.get('event_hash') != h:
            findings.append('RELEASE_LEDGER_CHAIN_INVALID')
            break
        prev = h
        expected_seq += 1
    if not case.get('ledger_events'):
        findings.append('RELEASE_LEDGER_CHAIN_INVALID')
    return sorted(set(findings))

def load_guards(root: Path):
    path = root/'registry'/'GUARD_REGISTRY.tsv'
    with path.open(encoding='utf-8') as f:
        return {r['guard_id']: r for r in csv.DictReader(f, delimiter='\t')}

def derive(case: dict, guards: dict, disabled_guard: str|None=None):
    decision = case.get('base_decision') or case.get('expected_decision') or 'ALLOW_CORPUS_RELEASE'
    # Use the expected positive decision as base when no findings; negative cases are guard-driven.
    if case.get('expected_findings'):
        decision = 'ALLOW_CORPUS_RELEASE'
        # use limited release as base for runtime/regulated negative cases when it matters only for rank
        if case.get('release_class') not in ('REL_CORPUS','REL_CHECKER_SEED'):
            decision = 'ALLOW_LIMITED_RELEASE'
    max_rank = DECISION_RANK.get(decision, 0)
    findings=[]
    # derived ledger guard
    lf = ledger_findings(case)
    if lf and disabled_guard != 'B09c-02':
        findings += lf
        gd = guards['B09c-02']
        r = DECISION_RANK[gd['default_decision']]
        if r > max_rank:
            max_rank = r; decision = gd['default_decision']
    for flag, val in sorted(case.get('flags', {}).items()):
        if not val or flag == 'c_a10_control_token':
            continue
        gid = FLAG_TO_GUARD.get(flag)
        if not gid or gid == disabled_guard:
            continue
        gd = guards[gid]
        findings.append(gd['finding_code'])
        r = DECISION_RANK[gd['default_decision']]
        if r > max_rank:
            max_rank = r; decision = gd['default_decision']
    # If no findings, preserve expected positive/special decision.
    if not findings and not lf:
        decision = case['expected_decision']
    return decision, sorted(set(findings))

def check_fixtures(root: Path) -> int:
    guards = load_guards(root)
    cases = sorted((root/'fixtures'/'cases').glob('*.json'))
    failures=[]
    for path in cases:
        case=json.loads(path.read_text(encoding='utf-8'))
        decision, findings=derive(case, guards)
        exp_d=case['expected_decision']; exp_f=sorted(set(case.get('expected_findings', [])))
        if decision != exp_d or findings != exp_f:
            failures.append((case['case_id'], exp_d, decision, exp_f, findings))
    if failures:
        print('FIXTURE FAILURES:')
        for f in failures:
            print(f)
        return 1
    print(f'fixtures: {len(cases)}/{len(cases)} PASS')
    return 0

def read_mutations(root: Path):
    with (root/'MUTATION_MATRIX.tsv').open(encoding='utf-8') as f:
        yield from csv.DictReader(f, delimiter='\t')

def check_mutations(root: Path) -> int:
    guards=load_guards(root)
    cases={p.stem: json.loads(p.read_text(encoding='utf-8')) for p in (root/'fixtures'/'cases').glob('*.json')}
    failures=[]; total=0; caught=0
    for row in read_mutations(root):
        total += 1
        disabled=row['disabled_guard']
        ids=[x for x in row['target_cases'].split(',') if x]
        ok=False
        for cid in ids:
            case=cases[cid]
            normal=derive(case, guards)
            mutated=derive(case, guards, disabled_guard=disabled)
            if normal != mutated:
                ok=True
                break
        if ok:
            caught += 1
        else:
            failures.append(row['mutation_id'])
    if failures:
        print('MUTATION FAILURES:', ', '.join(failures))
        return 1
    print(f'mutations: {caught}/{total} CAUGHT')
    return 0

if __name__ == '__main__':
    root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
    mode=sys.argv[2] if len(sys.argv)>2 else 'fixtures'
    if mode == 'fixtures':
        raise SystemExit(check_fixtures(root))
    if mode == 'mutations':
        raise SystemExit(check_mutations(root))
    print('usage: regulated_release_ledger_withdrawal_checker_v0_1.py [root] [fixtures|mutations]', file=sys.stderr)
    raise SystemExit(2)
