#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parents[1]
raise SystemExit(subprocess.call([sys.executable, str(root/'src'/'regulated_release_ledger_withdrawal_checker_v0_1.py'), str(root), 'fixtures']))
