# Freeze Binding Protocol Note

The package uses external sidecar hash binding.

Rule:

```text
sha256sum exact_file_bytes > filename.sha256
```

No Markdown file attempts to include its own self-referential hash. `SHA256SUMS.txt` excludes itself and binds the remaining package files.
