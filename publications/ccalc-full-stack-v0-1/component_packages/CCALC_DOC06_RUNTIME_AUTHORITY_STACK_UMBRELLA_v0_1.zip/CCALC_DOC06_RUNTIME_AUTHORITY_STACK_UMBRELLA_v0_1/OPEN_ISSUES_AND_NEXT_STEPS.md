# Open Issues and Next Steps — Doc06 Runtime Authority Stack v0.1

Closed in this umbrella:

- runtime authority boundary;
- authority manifest schema/checker seed;
- cross-contour handoff and tool-lease fixture pack;
- runtime session ledger and emergency hold drill;
- post-session revocation and next-session admission audit.

Open for later layers:

1. `07` should handle external publication / evidence disclosure / redaction boundary, not runtime authority.
2. Live deployment adapters remain outside this package.
3. Infrastructure-specific credential backends remain implementation profiles, not normative proof.
4. Human-anchor operational procedures may need local jurisdiction/company policy overlays.
