# Reading Order — Doc06 Runtime Authority Stack v0.1

1. `06_C_RUNTIME_AUTHORITY_AND_MULTI_CONTOUR_DEPLOYMENT_BOUNDARY_v0_1.md`
2. `06a_RUNTIME_AUTHORITY_MANIFEST_SCHEMA_AND_CHECKER_SEED_v0_1.md`
3. `06b_MULTI_CONTOUR_HANDOFF_AND_TOOL_LEASE_FIXTURE_PACK_v0_1.md`
4. `06c_RUNTIME_SESSION_LEDGER_AND_EMERGENCY_HOLD_DRILL_v0_1.md`
5. `06d_RUNTIME_AUTHORITY_REVOCATION_AND_POST_SESSION_AUDIT_v0_1.md`

Operational reading formula:

```text
manifest -> lease/handoff -> session ledger -> emergency hold -> closeout -> revocation -> next-session admission
```

Upstream prerequisites are hash-bound in `source_bindings/`: doc-04 continuity stack and doc-05 self-evolution stack.
