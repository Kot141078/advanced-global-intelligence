# Freeze Binding Protocol Note

This package uses external sidecar binding.

For each generated Markdown / TSV / JSON file except `SHA256SUMS.txt`:

```text
sha256sum exact_file_bytes > filename.sha256
```

The files themselves do not mutate to include their own hashes. This avoids self-referential instability.

The umbrella archive SHA-256 is computed over the final ZIP bytes after packaging.
