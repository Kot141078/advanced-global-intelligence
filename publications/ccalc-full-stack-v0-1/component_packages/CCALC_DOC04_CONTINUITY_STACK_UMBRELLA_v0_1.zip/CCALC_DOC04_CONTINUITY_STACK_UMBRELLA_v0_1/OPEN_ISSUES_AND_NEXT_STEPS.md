# Open Issues and Next Steps

## Closed for current `04` layer

- Continuity metric and equivalence semantics.
- Tri-state / unknown routing checker seed.
- Fork / Replay / Archive / Restoration record schemas.
- Red-pattern adjacency audit.
- Conformance evidence bundle claim gate.

## Not closed here

- Raw live ledger extraction.
- Live runtime certification.
- Full proof of completeness.
- C-A1 axiom ratification.
- Self-evolution semantics.

## Next recommended layer

```text
05_C_SELF_EVOLUTION_GATE_AND_BOUNDED_GROWTH_SEMANTICS_v0_1.md
```

Purpose: define how a `c` may grow without self-certifying its own growth, laundering authority, mutating identity core, or bypassing the continuity stack.
