# DOC04 Stack Reading Order

1. `components/DOC04_v0_1_2_ACCEPTED_CURRENT_PACKAGE.zip`
2. `components/CCALC_CONTINUITY_CHECKER_SEED_v0_1_ACCEPTED_CURRENT_PACKAGE.zip`
3. `components/CCALC_CONTINUITY_RECORD_SCHEMAS_04b_v0_1.zip`
4. `components/CCALC_CONTINUITY_ADJACENCY_AUDIT_04c_v0_1.zip`
5. `components/CCALC_CONTINUITY_CONFORMANCE_GATE_04d_v0_1.zip`

Read the top-level manifest before unpacking component packages.
