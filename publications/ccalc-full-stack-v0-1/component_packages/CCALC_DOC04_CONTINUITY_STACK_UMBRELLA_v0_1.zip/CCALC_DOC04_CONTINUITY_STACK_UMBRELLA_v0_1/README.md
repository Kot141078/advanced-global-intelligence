# CCALC DOC04 Continuity Stack Umbrella v0.1

Umbrella closure package for the `04` continuity layer.

## Included stack

```text
04   continuity metric / equivalence semantics
04a  continuity checker seed
04b  Fork / Replay / Archive / Restoration record schemas
04c  adjacency audit / red-pattern matrix
04d  conformance gate / evidence-bundle claim gate
```

## Primary manifest

Read:

```text
CCALC_DOC04_CONTINUITY_STACK_INDEX_AND_RELEASE_MANIFEST_v0_1.md
```

## Integrity

Run from package root:

```bash
sha256sum -c SHA256SUMS.txt
```

## Status

Current umbrella closure package. Not a safety certification. Not deployment authorization. Not C-A1 ratification.
